# Registro de decisiones técnicas

**D-01. La lógica pura está separada del store.** Las reglas (`missionLogic.ts`, `sim/*`) son funciones puras y el store de Zustand solo las orquesta. *Motivo:* el motor se puede probar sin navegador y reutilizar en el futuro modo cooperativo (un servidor podría ejecutar la misma simulación).

**D-02. Navegación con máquina de estados en Zustand, sin router.** *Motivo:* es un juego de una sola escena 3D persistente cuya cámara reacciona a la sección activa. Un router por URL desmontaría y volvería a montar capas, y aquí no aporta nada. Si más adelante se necesitan URL compartibles (por ejemplo, comparar diseños), se pueden sincronizar `screen` y `?view=` sin cambiar los componentes.

**D-03. Validación con Zod en dos puntos: datos estáticos (pruebas) y guardado (en ejecución).** Un guardado corrupto descarta solo las misiones inválidas y avisa al jugador. Nunca rompe la aplicación.

**D-04. Persistencia propia en lugar del middleware `persist`.** *Motivo:* control explícito de la validación, el versionado (`version: 1`) y las futuras migraciones.

**D-05. Escena 3D con carga diferida (`React.lazy`) y aislada (`SceneBoundary`).** La interfaz aparece antes de que se descargue Three.js. Three.js y R3F van en chunks separados (`vite.config.ts`).

**D-06. Modelos y texturas procedurales originales, marcados como provisionales.** El campo `model` de cada componente (`kind: 'procedural' | 'gltf'`, `provisional`) permite sustituirlos por GLB sin tocar la lógica.

**D-07. Partidas de presupuesto futuras como `null` ("Pendiente").** Cumple el criterio "sin estadísticas ficticias": el lanzamiento y la operación no tienen costo hasta que el jugador elige lanzador y plan.

**D-08. Sockets tipados (`top`, `side`, `bottom`, `internal`) definidos en el chasis.** Cada pieza declara `mountsOn`. Es la base del constructor de la Fase 2: colocar una pieza = asignarla a un socket libre de un tipo compatible.

**D-09. Colocar piezas está permitido aunque generen errores (Fase 2).** Solo se bloquea lo físicamente imposible: un anclaje ocupado, un tipo de anclaje incorrecto o la falta de chasis. Los requisitos sin cumplir y las incompatibilidades se permiten y se diagnostican. *Motivo:* el criterio del MVP "detectar y corregir incompatibilidades" exige que el jugador pueda cometer el error y entender por qué lo es.

**D-10. Borrador del Lab separado del diseño guardado.** Se edita un borrador en memoria con las opciones *Guardar* y *Descartar*. El resto del juego (Progreso, Presupuesto, Archivo y, más adelante, el lanzamiento) usa solo el diseño **guardado**, para que los datos sean coherentes entre pantallas.

**D-11. Arrastre con Pointer Events, no con HTML5 Drag & Drop.** Durante un arrastre HTML5 el navegador no emite `pointermove` sobre el canvas, y R3F no podría resaltar el anclaje bajo el cursor. Con Pointer Events, R3F recibe los eventos de forma nativa y el `pointerup` del anclaje se procesa antes que el de `window` (burbujeo), que cancela si se suelta fuera. En pantallas táctiles se usa *tocar para elegir y tocar el anclaje*. La lista de anclajes compatibles es la alternativa accesible.

**D-12. Un único `SpacecraftModel`.** Dibuja el diseño a partir de los datos (chasis + sockets + `model.key`). El Lab lo usa en modo interactivo y el lanzamiento y las operaciones lo reutilizarán en modo de solo lectura, lo que garantiza que vuela la nave construida.

**D-13. Dimensiones del chasis derivadas de sus sockets.** No se duplica la geometría en los datos: los semiejes de la caja se obtienen de las posiciones de los anclajes.

**D-14. Órbita de referencia hasta la Fase 4.** El análisis usa el punto medio de la órbita recomendada por el objetivo. Cuando el jugador elija la órbita en el Mission Planner, `analyzeEngineering({ orbit })` usará la suya sin cambiar nada más.

**D-15. La aprobación del diseño la decide el motor.** `approveDesign()` vuelve a ejecutar `analyzeEngineering` sobre el diseño **guardado** y solo avanza a Planificación si no hay críticos. Si se modifica y guarda un diseño aprobado, la misión vuelve a Diseño. Así no se puede declarar viable una misión que incumple restricciones obligatorias.

**D-16. Vista del cohete en el Lab.** El cohete se genera a partir de los datos del lanzador (`rocketLayout`, función pura y probada) y contiene el mismo `SpacecraftModel` del jugador en configuración plegada. Las Fases 4 y 5 reutilizan este modelo para la selección del lanzador y la secuencia de lanzamiento.

**D-17. Peor caso en eclipse y ocultación.** Se analiza con el Sol y la Tierra en el plano orbital (β = 0). Es la elección conservadora: si el diseño sobrevive al peor caso, sobrevive siempre.

**D-18. El plan de vuelo vive en la misión (`mission.plan`) y se guarda con cada cambio.** El planificador no tiene borrador: cada ajuste se valida y persiste al momento. *Confirmar plan* vuelve a ejecutar `analyzePlan` y solo avanza a Lanzamiento si no hay críticos. Si se cambia un plan confirmado, la misión vuelve a Planificación; si cambia el diseño, vuelve a Diseño.

**D-19. Una sola forma de construir la entrada del análisis: `analysisInputForMission()`.** Si la misión tiene plan, el análisis usa su órbita, su lanzador y su duración. La usan el Lab, el Mission Center y la aprobación del diseño, para que el presupuesto y la energía sean los mismos en todas las pantallas. Se añadió tras detectar en la prueba de navegador que el presupuesto del Mission Center ignoraba el plan.

**D-20. Inclinación limitada a 0–90° en el planificador.** Las órbitas retrógradas (> 90°) dan la misma cobertura y no aportan nada a LUNA-01; se excluyen para no confundir.

**D-21. El estado de vuelo se guarda; el lanzamiento no.** `mission.flight` (batería, memoria, datos, propelente, instrumentos, registro) se persiste en cada avance: se puede cerrar el navegador a mitad de campaña. La secuencia de lanzamiento dura un par de minutos y se reinicia si se recarga la página. La telemetría para los gráficos vive solo en memoria.

**D-22. Sin fallo de lanzamiento aleatorio en el MVP.** La fiabilidad del lanzador se muestra, pero no provoca fallos. Los acontecimientos inesperados que pide el proyecto (energía, comunicaciones, instrumento) llegan en la Fase 6, con consecuencias cuantificables y opciones de resolución, no como mala suerte sin remedio.

**D-23. El simulador de vuelo comparte los supuestos del análisis.** `MissionSystem` integra en el tiempo, con pasos de 2 min, los mismos modelos que `PowerSystem` y `DataSystem` promedian. Una prueba comprueba que coinciden (±3 %), así que lo que el jugador vio en el análisis es lo que vive en operaciones.

**D-24. Selectores de Zustand siempre estables.** Un selector que devuelve un objeto o arreglo nuevo en cada llamada provoca un bucle infinito de renders en React 19/Zustand 5. La prueba de navegador detectó uno tras recargar en operaciones; se corrigió con una constante y se revisaron todos los selectores.

**D-25. Acontecimientos deterministas con previsión del propio motor.** El calendario sale del id de la misión (reproducible, comparable entre intentos). Antes de decidir, `previewOptions` simula cada opción hasta el final de la campaña con `MissionSystem`: el jugador decide con información cuantitativa real, no con textos inventados. La posición de la opción elegida en esa previsión puntúa el criterio «Decisiones».

**D-26. Éxito técnico separado de la puntuación.** Éxito = datos en Tierra ≥ objetivo. La puntuación (0–100) evalúa la ejecución, pero sin éxito no hay desbloqueos y la XP es parcial: la progresión no sustituye los criterios científicos y técnicos.

**D-27. El crucero se anima, no se salta.** Los 4 días de viaje se muestran en la pantalla de trayectoria antes de la inserción lunar, con el reloj de misión y la telemetría coherentes con el mapa (una sola fuente de tiempo).

**D-28. Capas superpuestas y eventos de puntero.** Los contenedores del HUD dejan pasar clics a la escena (pointer-events: none). Todo panel interactivo dentro de ellos debe reactivarlos explícitamente. La prueba de navegador de la Fase 6 detectó que el panel de decisión no recibía clics por esta causa.

**D-29. Referencias NASA como herramientas, no como decoración.** Cada recurso aportado se tradujo en una función pura y probada que usa los números del análisis existente (STM, MEL, riesgos, CML, Kepler). Nada muestra cifras inventadas: lo que no modela el juego (CML 6–9, fases A–D) aparece marcado como fuera de alcance o comprimido.

**D-30. El nivel CML 3 mide exploración real.** `withPlan` anota en `mission.trades` los lanzadores, altitudes, inclinaciones y duraciones que el jugador evaluó, y el simulador elíptico anota sus estudios. Sin este registro el nivel 3 se habría concedido automáticamente al aprobar el diseño. Los guardados antiguos se leen con el registro vacío (valor por defecto de Zod).

**D-31. El asesor del catálogo avisa pero no bloquea.** Como en el juego del Webb, la tarjeta explica por qué una pieza no encaja antes de elegirla; el jugador puede intentarlo igualmente y el análisis seguirá marcándolo. Así se aprende del error sin ocultar opciones.

**D-32. La dificultad deriva la plantilla, no la copia.** La misión guarda solo su nivel; `applyDifficulty` (memorizada) produce la plantilla efectiva y `templateForMission` la usa en todas las pantallas, el análisis y el vuelo. Ingeniero devuelve la plantilla base sin tocarla, así que todo lo verificado antes sigue igual.

**D-33. Modo equipo en una sola computadora.** Elegido por el equipo del proyecto: funciona sin servidor ni internet y sirve para la demostración. Los votos no se guardan a medias (si se recarga, se vuelve a votar); las decisiones tomadas sí quedan en `mission.teamLog`.

**D-34. En equipo, la decisión la toma el voto.** Los acontecimientos no tienen botón individual: la opción ganadora se aplica y su posición en la previsión del motor cuenta para la puntuación, como en modo individual. Así el resultado de la misión depende de la coordinación.

**D-35. Compartir sin servidor.** Un código de texto (JSON en base64url con prefijo de versión) se copia y pega; al importar se valida con Zod y se crea una misión nueva en Diseño, sin plan: el equipo que lo recibe debe analizarlo y aprobarlo.

**D-36. Nueva misión guiada en 6 pasos.** Escenario → Modo → Dificultad → Objetivo → Restricciones → Recompensas. El modo y la dificultad empiezan sin elegir para que la elección sea consciente. Todo valor mostrado sale de `applyDifficulty`, la plantilla de la misión, `OrbitSystem` y `ScoringSystem` (que ahora exporta sus umbrales y su XP por punto para no duplicarlos). Los tooltips del glosario se dibujan en un portal para que ningún panel los recorte, y en pantallas táctiles se abren al tocar.

**D-37. El LAB guía con el mismo análisis que decide.** `LabGuidance` traduce `EngineeringReport` en parámetros, soluciones y restricciones; no calcula física ni valida por su cuenta. «Diseño listo» equivale exactamente a `report.viable`, así que lo que ve el jugador y lo que permite avanzar no pueden contradecirse.

**D-38. «Falta» no es «Incumple».** Un parámetro sin su pieza (sin antena, sin batería) está pendiente; uno con piezas cuyos números violan la restricción (balance energético negativo, presupuesto superado, datos insuficientes) incumple. Distinguirlos enseña la diferencia entre un diseño incompleto y uno mal dimensionado.

**D-39. La mano se repite hasta que el jugador actúa.** Desaparece con cualquier interacción o tras tres demostraciones, y deja de salir sola cuando el jugador coloca su primera pieza.

**D-40. La aprobación del diseño ocurre en un solo lugar.** La pantalla de análisis es el único punto que aprueba el diseño; el Centro y el LAB llevan a ella. Así hay un único camino para aprobar y una sola evaluación (la misma que usa todo el juego).

**D-41. El presupuesto del análisis incluye el lanzador estimado.** Antes de planificar, el análisis suma el lanzador más barato capaz de llevar la nave, rotulado «estimado», para que «restante» signifique lo que de verdad queda. El presupuesto del juego (`budgetSummary`) no cambia.

**D-42. Lanzadores reales con dos capas de datos.** Los 8 vehículos de *CubeSat 101* muestran sus datos reales con fuentes, separados de los valores simplificados del juego. Nunca se presentan todos como operativos: cada tarjeta indica su estado actual. Un vehículo que no se puede contratar o no llega a la Luna no se puede elegir. Lo impide tanto la interfaz como el estado del juego (`plannerUpdate`), y siempre se explica el motivo.

**D-43. La compatibilidad compara necesidad frente a oferta.** `LauncherCompatibility` evalúa cinco requisitos (disponibilidad, órbita requerida, masa de la carga útil, capacidad de la cofia y presupuesto de la misión) con los mismos números que el Planner. La ficha los muestra en una tabla: lo que tu misión necesita y lo que el vehículo ofrece.

**D-44. Planner en cuatro ventanas.** 1 Vehículo de lanzamiento con los recursos de la misión, 2 Órbita lunar con el simulador elíptico siempre visible, 3 Ventana de lanzamiento y 4 Verificaciones, presupuesto de Δv y problemas. Cada pestaña muestra su estado (✓, ! o ✗) a partir de las mismas verificaciones del plan. El botón «Confirmar plan» sigue siempre en el pie.

**D-45. Traducción en vivo en lugar de reescribir cada pantalla.** El juego tiene unas 2.000 frases repartidas en pantallas, simulación y datos. Una capa (`src/i18n/translator.ts`) traduce el texto visible con un diccionario y plantillas con huecos para los datos. Así se cubre también el texto que genera la simulación (problemas, acontecimientos, informes) sin tocar su lógica, y el español sigue siendo la fuente. Las pruebas recorren el juego en inglés y avisan si aparece texto sin traducir.

**D-46. La vista del cohete deja el centro limpio.** Toda la información del cohete vive en la pestaña «Cohete» de la columna derecha, igual que el resto de datos del LAB. Las etiquetas 3D son opcionales.


**D-47. Flujo LAB → Planner → Revisión → Vuelo.** Aprobar el lanzamiento en la vista del cohete guarda el vehículo en el plan y abre el Planner; el «Siguiente» final del Planner confirma el plan y abre la Revisión; la Revisión termina en «Ir al vuelo». La Revisión no bloquea el despegue (la regla sigue siendo el plan confirmado): informa de lo que podría fallar durante el vuelo.

**D-48. Revisión en dos capas: juego y expertos.** La capa de juego usa palabras sencillas, ilustraciones SVG originales (sin imágenes externas ni marcas) y estrellas; nada se calcula de nuevo, solo se traduce el análisis existente a tarjetas con los umbrales de la lista CML 4. Las tablas técnicas de la NASA no se eliminan: quedan en desplegables «Para expertos».

**D-49. Trayectoria de vuelo integrada, no animada.** El vuelo usa `sim/FlightDynamics`: el ascenso, la órbita de aparcamiento, la inyección translunar, el crucero y la aproximación se integran con gravedad real, giro terrestre y arrastre. La escena 3D y la telemetría leen el mismo estado (`flightStateAt`), así lo que se ve y los números coinciden. Los tiempos de los eventos siguen siendo los de `LaunchSystem` (datos de cada lanzador).

**D-50. Escala real con origen flotante.** La escena del vuelo trabaja en kilómetros con la Tierra y la Luna a tamaño y distancia reales. La cámara está siempre en el origen y el mundo se desplaza (cálculo en doble precisión), con búfer de profundidad logarítmico. Así conviven un cohete de 70 m y la Luna a 384 400 km sin temblores.

**D-51. HUD de vuelo que no tapa la escena.** El reloj es una franja fina arriba; los controles de cámara y de tiempo, una barra abajo; la verificación GO/NO-GO y la telemetría son cajones laterales plegables (la verificación se pliega sola al despegar). El mapa esquemático es opcional.

**D-52. Cámaras propias en lugar de OrbitControls.** Cinco modos (externa, a bordo, seguimiento, orbital, libre) con un único controlador de ratón: cada modo define su marco (vertical local, sentido del vuelo, cuerpo del cohete o inercial) y su ancla; la cámara nunca entra bajo el suelo ni dentro de la Luna.

**D-53. Sistemas de vuelo con variables propias.** Combustible, batería, temperatura, comunicaciones y radiación del viaje viven en `ui/flight/flightSim` (lógica pura en `sim/FlightEvents`), no en el guardado de la misión. Al pasar a Operaciones se descuentan el combustible gastado y se suman los datos de los descubrimientos. Así el resto del juego no cambia y las decisiones del vuelo tienen efecto real.

**D-54. Eventos aleatorios pero reproducibles.** La semilla sale de la misión y del número de intento: el mismo vuelo da los mismos eventos y «Reiniciar» da otros. Los pesos dependen del diseño, para que los problemas tengan sentido con la nave que se construyó.

**D-55. Ninguna decisión termina la misión.** El combustible reservado para frenar en la Luna no se puede gastar en imprevistos, la batería baja activa el modo seguro y los fallos se pueden recuperar. Las malas decisiones cuestan recursos, tiempo o ciencia, no la partida.

**D-56. Ventanas flotantes en lugar de paneles fijos.** El centro de control usa ventanas que se mueven, minimizan y recuerdan su sitio; la distribución inicial deja libre el centro de la escena 3D.

**D-57. Descubrimientos con posición física.** Los objetos no aparecen al azar en pantalla: se programan en el instante en que la trayectoria pasa por su zona (órbita baja, cruce de la órbita GPS o geoestacionaria, crucero, aproximación) y su posición sale de su órbita real o de sus coordenadas celestes. Si en ese momento no es visible (por ejemplo, una región lunar en la cara oculta), no se anuncia.

**D-58. Cámara de observación como sexto modo interno.** La cámara «objetivo» no está en la barra de cámaras: la activan «Observar» y el rescate. Va montada en la nave y su campo de visión se calcula con el tamaño angular real del objeto, así una estación de 109 m a decenas de kilómetros se ve sin cambiar la escala del mundo.

**D-59. El rescate es un minijuego en un marco local.** Mientras dura, el reloj del viaje se detiene y el rescate usa su propio reloj (movimiento relativo en línea recta, sin perturbaciones orbitales, válido para unos minutos y unos kilómetros). Al terminar, su duración se suma al crucero y su combustible se descuenta de la reserva para imprevistos (nunca del necesario para frenar en la Luna).

**D-60. Copiloto con los mismos datos que los indicadores.** Los consejos («frena con S», «pulsa D para seguirlo») se calculan con las mismas lecturas que ve el jugador. No pilotan: solo dicen qué tecla usar. La prueba e2e completa el rescate siguiendo solo esos consejos, que es la prueba de que es jugable.

**D-61. Una sola situación contrarreloj por vuelo, y no siempre.** Para que emocione sin agobiar: 80 % de probabilidad, en el crucero, lejos de otros eventos. El temporizador corre en tiempo real con el viaje en pausa. Se puede ajustar (15–25 s) o desactivar.

**D-62. El aterrizaje es un objetivo del vuelo que elige el estudiante.** LUNA-01 es un orbitador y ninguna plantilla de misión incluye todavía un objetivo de aterrizaje. Para no tocar los módulos de misiones, el objetivo «Aterrizar en la Luna» está en la verificación previa del vuelo, visible y marcado por defecto, y se guarda por misión; el botón de inserción lleva al descenso. La práctica («Probar aterrizaje ahora») no cuenta para la misión. Cuando exista una misión con aterrizaje, bastará con activar ese objetivo desde sus datos.

**D-63. Física fuera de la escena.** El descenso y el rover se simulan en sim/Lander y sim/Rover con pasos fijos (20 por segundo) desde la interfaz; la escena 3D solo dibuja el estado. Así se puede probar todo sin WebGL y los pilotos de las pruebas usan los mismos mandos que el jugador.

**D-64. Terreno compartido y reproducible.** El mismo terreno (semilla fija) sirve para el aterrizaje y el rover; tiene una zona segura allanada y sin rocas. La escena usa una malla lejana y otra de detalle (2 m) alrededor de donde se juega.

**D-65. Aterrizaje ágil.** El descenso completo era largo y difícil para el público objetivo. Se mantiene la física real (gravedad lunar, sin aire, combustible por la ecuación del cohete), pero se acorta (350 m), se simplifican los mandos (motor sí/no y estabilizador automático de la inclinación) y se amplían los márgenes. El jugador sigue decidiendo cuándo frenar y hacia dónde ir.

**D-66. El rover recoge los datos del objetivo de la misión.** Un plan por objetivo científico de LUNA-01 (cartografía, minerales, hielo polar), con el mismo terreno.

**D-67. Logros fuera del guardado de misiones.** Insignias, clasificación e informes se guardan aparte (clave `nexus-achievements`) para no cambiar el formato del guardado. La misión solo añade el campo opcional `pilotName`.

