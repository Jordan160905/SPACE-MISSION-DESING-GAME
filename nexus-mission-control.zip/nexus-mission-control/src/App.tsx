/**
 * Composición de capas: escena 3D (fondo, carga diferida) + HUD (interfaz).
 * Sin lógica de juego: las reglas están en src/state y src/sim.
 */
import { lazy, Suspense } from 'react';
import { SceneBoundary } from './scene/SceneBoundary';
import { useGameStore } from './state/useGameStore';
import { useLang } from './i18n/useLang';
import { NavRail } from './ui/hud/NavRail';
import { Toast } from './ui/hud/Toast';
import { TopBar } from './ui/hud/TopBar';
import { Tutorial } from './ui/hud/Tutorial';
import { ArchiveScreen } from './ui/screens/ArchiveScreen';
import { AnalysisScreen } from './ui/screens/AnalysisScreen';
import { BriefingScreen } from './ui/screens/BriefingScreen';
import { CenterScreen } from './ui/screens/CenterScreen';
import { GlossaryScreen } from './ui/screens/GlossaryScreen';
import { AchievementsScreen } from './ui/screens/AchievementsScreen';
import { LabScreen } from './ui/screens/LabScreen';
import { PlannerScreen } from './ui/screens/PlannerScreen';
import { ReviewScreen } from './ui/screens/ReviewScreen';
import { TeamVote } from './ui/team/TeamVote';
import { FlightScreen } from './ui/screens/FlightScreen';
import { useSurface } from './ui/surface/surfaceStore';

const MissionCenterScene = lazy(() => import('./scene/MissionCenterScene'));
const LabScene = lazy(() => import('./scene/lab/LabScene'));
const LaunchScene = lazy(() => import('./scene/launcher/LaunchScene'));
const OpsScene = lazy(() => import('./scene/ops/OpsScene'));
const LunarSurfaceScene = lazy(() => import('./scene/surface/LunarSurfaceScene'));

/** El Lab tiene su propio espacio 3D; el resto de secciones comparten el Mission Center. */
function ActiveScene() {
  const screen = useGameStore((s) => s.screen);
  const stage = useGameStore((s) => s.missions.find((m) => m.id === s.activeMissionId)?.stage);
  const surface = useSurface((s) => s.mode);
  if (screen === 'lab' || screen === 'analysis') return <LabScene />;
  if (screen === 'flight' && stage === 'LAUNCH' && surface) return <LunarSurfaceScene />;
  if (screen === 'flight' && stage === 'LAUNCH') return <LaunchScene />;
  if (screen === 'flight' && (stage === 'OPERATIONS' || stage === 'DEBRIEF' || stage === 'COMPLETE')) return <OpsScene />;
  return <MissionCenterScene />;
}

function ActiveScreen() {
  const screen = useGameStore((s) => s.screen);
  switch (screen) {
    case 'center':
      return <CenterScreen />;
    case 'briefing':
      return <BriefingScreen />;
    case 'analysis':
      return <AnalysisScreen />;
    case 'lab':
      return <LabScreen />;
    case 'planner':
      return <PlannerScreen />;
    case 'review':
      return <ReviewScreen />;
    case 'flight':
      return <FlightScreen />;
    case 'archive':
      return <ArchiveScreen />;
    case 'glossary':
      return <GlossaryScreen />;
    case 'achievements':
      return <AchievementsScreen />;
  }
}

export default function App() {
  const screen = useGameStore((s) => s.screen);
  // Al cambiar de idioma se vuelve a dibujar la interfaz (números y fechas con el formato del idioma).
  const lang = useLang();
  return (
    <div className="app">
      <div className="scene-layer" data-screen={screen}>
        <SceneBoundary>
          <Suspense fallback={<div className="scene-fallback" aria-busy="true" />}>
            <ActiveScene />
          </Suspense>
        </SceneBoundary>
      </div>
      <div className="hud" key={lang}>
        <TopBar />
        <NavRail />
        <main className="stage">
          <ActiveScreen />
          <Tutorial />
          <TeamVote />
          <Toast />
        </main>
      </div>
    </div>
  );
}
