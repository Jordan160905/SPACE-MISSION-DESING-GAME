/**
 * Minijuego del rover lunar (Fase 8.9): conducción sobre el terreno y misiones de exploración.
 * El rover es de juego, con valores parecidos a los rovers lunares reales (velocidad de unos pocos
 * metros por segundo, paneles solares, subida limitada por la pendiente).
 */
import { heightAt, slopeAt, TERRAIN, type Terrain } from './LunarTerrain';

export const ROVER = {
  maxSpeed: 5,
  accel: 0.9,
  brake: 2,
  turnDegS: 40,
  /** Pendiente máxima que puede subir (°). */
  maxClimbDeg: 22,
  radiusM: 1.6,
  /** Consumo de energía (% por segundo) parado, a toda velocidad y extra por subir. */
  idlePct: 0.01,
  drivePct: 0.09,
  /** Carga de los paneles solares parado (% por segundo). */
  solarPct: 0.06,
  /** Celda del mapa de exploración (m). */
  cell: 20,
};

/** Sitio del terreno donde se hace cada paso. «here» = donde esté el rover. */
export type RoverSite = 'rock' | 'crater' | 'sample' | 'hill' | 'here' | 'lander';
export type RoverMissionId = string;

export interface RoverMission {
  id: RoverMissionId;
  site: RoverSite;
  icon: string;
  title: string;
  goal: string;
  /** Mantener «Acción» (E) este tiempo, parado en el sitio. 0 = basta con llegar. */
  holdS: number;
  /** Texto del botón de acción (si hay que mantenerlo). */
  action?: string;
  points: number;
  gbit: number;
  /** Dato que se consigue y para qué sirve (aparece en el informe final). */
  data: { label: string; why: string };
  done: string;
}

export interface Investigation {
  question: string;
  options: string[];
  correct: number;
  explain: string;
  bonus: number;
}

export interface RoverPlan {
  /** Objetivo científico de la misión al que corresponde. */
  objectiveId: string;
  title: string;
  dataName: string;
  steps: RoverMission[];
  quiz: Investigation;
}

const SEND = (dataName: string): RoverMission => ({
  id: 'send',
  site: 'lander',
  icon: '📡',
  title: 'Enviar los resultados',
  goal: 'Vuelve junto al módulo (su antena llega a la Tierra) y mantén pulsado «Enviar» (E).',
  holdS: 3,
  action: 'Enviar (E)',
  points: 150,
  gbit: 0.4,
  data: { label: `${dataName} enviados a la Tierra`, why: 'Sin enviarlos, los científicos no podrían estudiarlos.' },
  done: '¡Datos recibidos en el centro de control!',
});

const INVESTIGATE = (why: string): RoverMission => ({
  id: 'investigate',
  site: 'here',
  icon: '🔬',
  title: 'Completar la investigación',
  goal: 'Para el rover donde quieras y mantén pulsado «Analizar» (E). Después responde la pregunta.',
  holdS: 3,
  action: 'Analizar (E)',
  points: 150,
  gbit: 0.3,
  data: { label: 'Análisis de los datos', why },
  done: 'Análisis terminado. Responde la pregunta.',
});

/** Un plan de exploración por cada objetivo científico: se recogen los datos que pide la misión. */
export const ROVER_PLANS: RoverPlan[] = [
  {
    objectiveId: 'obj-mapping',
    title: 'Cartografía de sitios de alunizaje',
    dataName: 'Fotos',
    steps: [
      {
        id: 'rock',
        site: 'rock',
        icon: '📷',
        title: 'Fotografiar una roca peligrosa',
        goal: 'Llega a la roca grande marcada y mantén «Foto» (E).',
        holdS: 2,
        action: 'Foto (E)',
        points: 120,
        gbit: 0.4,
        data: { label: 'Foto de una roca grande', why: 'Las rocas grandes pueden romper las patas de un módulo: el mapa las marca para evitarlas.' },
        done: 'Foto guardada: esta roca sería un peligro para aterrizar.',
      },
      {
        id: 'crater',
        site: 'crater',
        icon: '🕳️',
        title: 'Medir un cráter',
        goal: 'Entra en el cráter marcado: el rover medirá lo profundo que es.',
        holdS: 0,
        points: 120,
        gbit: 0.4,
        data: { label: 'Profundidad de un cráter', why: 'Saber dónde hay cuestas fuertes evita que un módulo vuelque.' },
        done: 'Cráter medido: sus paredes son demasiado empinadas para aterrizar.',
      },
      {
        id: 'hill',
        site: 'hill',
        icon: '🗺️',
        title: 'Foto panorámica desde la colina',
        goal: 'Sube a la cima de la colina y mantén «Panorámica» (E).',
        holdS: 3,
        action: 'Panorámica (E)',
        points: 150,
        gbit: 0.6,
        data: { label: 'Panorámica de la zona', why: 'Con ella se dibuja el mapa de los sitios seguros para futuras misiones.' },
        done: '¡Panorámica lista! Se ve toda la zona.',
      },
      INVESTIGATE('Comparar las fotos ayuda a elegir el mejor sitio para aterrizar.'),
      SEND('Fotos'),
    ],
    quiz: {
      question: '¿Qué sitio es mejor para que aterrice otra nave?',
      options: ['Una zona llana y sin rocas', 'El borde de un cráter', 'Encima de una roca grande'],
      correct: 0,
      explain: 'Un módulo necesita suelo llano y sin rocas para no volcar. Por eso tu zona verde era así.',
      bonus: 100,
    },
  },
  {
    objectiveId: 'obj-mineral',
    title: 'Minerales de la superficie',
    dataName: 'Espectros',
    steps: [
      {
        id: 'rock',
        site: 'rock',
        icon: '🪨',
        title: 'Analizar una roca',
        goal: 'Llega a la roca grande marcada y mantén «Espectrómetro» (E).',
        holdS: 2,
        action: 'Espectrómetro (E)',
        points: 120,
        gbit: 0.5,
        data: { label: 'Espectro de una roca', why: 'La luz que refleja cada mineral es como su huella: así se sabe de qué está hecha la roca.' },
        done: 'Huella de luz medida: la roca tiene basalto, una roca de lava antigua.',
      },
      {
        id: 'crater',
        site: 'crater',
        icon: '🕳️',
        title: 'Entrar en un cráter',
        goal: 'Baja al cráter marcado: el impacto sacó a la luz rocas de más abajo.',
        holdS: 0,
        points: 120,
        gbit: 0.3,
        data: { label: 'Rocas del interior de un cráter', why: 'Los impactos «excavan» la Luna y muestran materiales que estaban enterrados.' },
        done: '¡Dentro del cráter! Aquí hay rocas que estaban bajo tierra.',
      },
      {
        id: 'sample',
        site: 'sample',
        icon: '⚗️',
        title: 'Recoger una muestra',
        goal: 'En el fondo del cráter, para en el punto marcado y mantén «Recoger» (E).',
        holdS: 3,
        action: 'Recoger (E)',
        points: 150,
        gbit: 0.5,
        data: { label: 'Muestra de suelo del fondo', why: 'Comparar suelos de varios sitios cuenta la historia de la Luna.' },
        done: 'Muestra guardada: polvo fino (regolito) y trocitos de roca.',
      },
      INVESTIGATE('Los análisis dicen qué minerales hay y si se podrían usar en el futuro.'),
      SEND('Espectros'),
    ],
    quiz: {
      question: 'Los instrumentos dicen que el polvo es muy fino y afilado. ¿Por qué?',
      options: ['En la Luna no hay viento ni agua que redondeen los granos', 'Es arena de playa', 'Lo trituraron los astronautas'],
      correct: 0,
      explain: 'En la Tierra el viento y el agua redondean los granos. En la Luna nada los pule: el polvo es fino y afilado.',
      bonus: 100,
    },
  },
  {
    objectiveId: 'obj-polar-ice',
    title: 'Hielo en cráteres en sombra',
    dataName: 'Medidas de radar',
    steps: [
      {
        id: 'crater',
        site: 'crater',
        icon: '🕳️',
        title: 'Entrar en un cráter en sombra',
        goal: 'Baja al cráter marcado: su fondo casi nunca recibe Sol.',
        holdS: 0,
        points: 120,
        gbit: 0.3,
        data: { label: 'Temperatura del cráter en sombra', why: 'Donde nunca da el Sol hace tanto frío que el hielo no se derrite.' },
        done: '¡Dentro! El fondo está a unos −200 °C.',
      },
      {
        id: 'sample',
        site: 'sample',
        icon: '📡',
        title: 'Buscar hielo con el radar',
        goal: 'Para en el punto marcado del fondo y mantén «Radar» (E).',
        holdS: 3,
        action: 'Radar (E)',
        points: 170,
        gbit: 0.6,
        data: { label: 'Eco de radar del fondo', why: 'El hielo refleja el radar de una forma especial: así se detecta bajo el polvo.' },
        done: 'El eco del radar sugiere que puede haber hielo mezclado con el polvo.',
      },
      {
        id: 'rock',
        site: 'rock',
        icon: '🪨',
        title: 'Medir una roca al Sol',
        goal: 'Sal del cráter, llega a la roca marcada y mantén «Radar» (E) para comparar.',
        holdS: 2,
        action: 'Radar (E)',
        points: 120,
        gbit: 0.3,
        data: { label: 'Medida de comparación al Sol', why: 'Comparar con un sitio seco confirma que la señal del cráter es distinta.' },
        done: 'Medida tomada: aquí, al Sol, no hay señal de hielo.',
      },
      INVESTIGATE('Si hay hielo, las futuras misiones podrían sacar agua y oxígeno de él.'),
      SEND('Medidas de radar'),
    ],
    quiz: {
      question: '¿Por qué puede haber hielo en el fondo de algunos cráteres?',
      options: ['Porque nunca les da el Sol y hace muchísimo frío', 'Porque llueve en la Luna', 'Porque los astronautas lo dejaron allí'],
      correct: 0,
      explain: 'Cerca de los polos, el Sol nunca llega al fondo de algunos cráteres: hace tanto frío que el hielo dura miles de millones de años.',
      bonus: 100,
    },
  },
];

export function roverPlan(objectiveId: string | null | undefined): RoverPlan {
  return ROVER_PLANS.find((p) => p.objectiveId === objectiveId) ?? ROVER_PLANS[0];
}

export interface RoverState {
  /** Objetivo de la misión (elige el plan de exploración). */
  plan: string;
  x: number;
  z: number;
  heading: number;
  speed: number;
  energy: number;
  t: number;
  distanceM: number;
  mission: number;
  holdT: number;
  /** Misión 5: la medición terminó y falta responder. */
  quizPending: boolean;
  quizAnswer: number | null;
  points: number;
  gbit: number;
  explored: string[];
  bumps: number;
  /** Aviso del momento (pendiente, roca, batería…). */
  warn: 'steep' | 'rock' | 'energy' | 'edge' | null;
  lastDone: RoverMissionId | null;
  finished: boolean;
}

export interface RoverInput {
  drive: number;
  turn: number;
  action: boolean;
}
export const NO_ROVER_INPUT: RoverInput = { drive: 0, turn: 0, action: false };

const cellKey = (x: number, z: number) => `${Math.floor(x / ROVER.cell)},${Math.floor(z / ROVER.cell)}`;

export function newRover(x: number, z: number, objectiveId = 'obj-mapping'): RoverState {
  // Sale junto al módulo.
  return {
    plan: roverPlan(objectiveId).objectiveId,
    x: x + 6,
    z: z + 4,
    heading: 0.9,
    speed: 0,
    energy: 100,
    t: 0,
    distanceM: 0,
    mission: 0,
    holdT: 0,
    quizPending: false,
    quizAnswer: null,
    points: 0,
    gbit: 0,
    explored: [cellKey(x, z)],
    bumps: 0,
    warn: null,
    lastDone: null,
    finished: false,
  };
}

/** Pendiente del terreno en la dirección del movimiento (°; positiva = cuesta arriba). */
export function gradeAhead(t: Terrain, x: number, z: number, heading: number, dir: number) {
  const e = 2;
  const hx = Math.cos(heading) * dir;
  const hz = Math.sin(heading) * dir;
  const h0 = heightAt(t, x, z);
  const h1 = heightAt(t, x + hx * e, z + hz * e);
  return (Math.atan2(h1 - h0, e) * 180) / Math.PI;
}

/** Dónde está el objetivo de un paso. */
export function missionTarget(t: Terrain, site: RoverSite, lander: { x: number; z: number }, rover?: { x: number; z: number }) {
  const s = t.sites;
  switch (site) {
    case 'rock':
      return { x: s.rock.x, z: s.rock.z, r: 10 };
    case 'crater':
      return { x: s.crater.x, z: s.crater.z, r: s.crater.r * 0.55 };
    case 'sample':
      return { x: s.sample.x, z: s.sample.z, r: 7 };
    case 'hill':
      return { x: s.hill.x, z: s.hill.z, r: 15 };
    case 'here':
      return { x: rover?.x ?? lander.x, z: rover?.z ?? lander.z, r: 1e6 };
    case 'lander':
      return { x: lander.x, z: lander.z, r: 15 };
  }
}

const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));

export function stepRover(t: Terrain, s: RoverState, input: RoverInput, dt: number, lander: { x: number; z: number }): RoverState {
  if (s.finished) return s;
  let { x, z, heading, speed, energy } = s;
  let warn: RoverState['warn'] = null;
  const canDrive = energy > 0;
  const drive = canDrive ? clamp(input.drive, -1, 1) : 0;
  if (!canDrive && input.drive) warn = 'energy';
  // Giro (sobre sí mismo, como los rovers con dirección en las seis ruedas).
  if (canDrive) heading += ((clamp(input.turn, -1, 1) * ROVER.turnDegS * Math.PI) / 180) * dt;
  // Velocidad máxima según la pendiente.
  const dir = drive !== 0 ? Math.sign(drive) : Math.sign(speed) || 1;
  const grade = gradeAhead(t, x, z, heading, dir);
  let vmax = ROVER.maxSpeed * clamp(1 - Math.max(0, grade) / ROVER.maxClimbDeg, 0, 1.25);
  if (grade < 0) vmax = ROVER.maxSpeed * Math.min(1.2, 1 - grade / 60);
  if (drive !== 0 && grade > ROVER.maxClimbDeg) {
    vmax = 0;
    warn = 'steep';
  }
  const target = drive * vmax * (drive < 0 ? 0.6 : 1);
  const rate = Math.abs(target) > Math.abs(speed) && Math.sign(target) === Math.sign(speed || target) ? ROVER.accel : ROVER.brake;
  speed += clamp(target - speed, -rate * dt, rate * dt);
  // Gravedad en la pendiente: cuesta abajo se acelera un poco si no se frena.
  let nx = x + Math.cos(heading) * speed * dt;
  let nz = z + Math.sin(heading) * speed * dt;
  // Obstáculos: rocas de más de 0,6 m.
  let bumps = s.bumps;
  for (const k of t.rocks) {
    if (k.r < 0.6) continue;
    const d = Math.hypot(nx - k.x, nz - k.z);
    const min = k.r + ROVER.radiusM;
    if (d < min) {
      // Choque suave: se detiene y queda pegado al borde de la roca.
      const ux = (nx - k.x) / (d || 1);
      const uz = (nz - k.z) / (d || 1);
      nx = k.x + ux * min;
      nz = k.z + uz * min;
      if (Math.abs(speed) > 0.3) bumps++;
      speed = 0;
      warn = 'rock';
      break;
    }
  }
  const half = TERRAIN.size / 2 - 30;
  if (Math.abs(nx) > half || Math.abs(nz) > half) {
    nx = clamp(nx, -half, half);
    nz = clamp(nz, -half, half);
    speed = 0;
    warn = 'edge';
  }
  const moved = Math.hypot(nx - x, nz - z);
  x = nx;
  z = nz;
  // Energía: conducir y subir gasta; parado, los paneles cargan.
  const up = Math.max(0, grade) * (Math.abs(speed) > 0.05 ? 1 : 0);
  const use = ROVER.idlePct + ROVER.drivePct * (Math.abs(speed) / ROVER.maxSpeed) * (1 + up / 10);
  const charge = Math.abs(speed) < 0.05 ? ROVER.solarPct : 0;
  energy = clamp(energy + (charge - use) * dt, 0, 100);
  if (energy < 10 && !warn) warn = 'energy';
  // Mapa de exploración.
  const key = cellKey(x, z);
  const explored = s.explored.includes(key) ? s.explored : [...s.explored, key];
  let next: RoverState = { ...s, x, z, heading, speed, energy, t: s.t + dt, distanceM: s.distanceM + moved, explored, bumps, warn };
  next = checkMission(t, next, input.action, dt, lander);
  return next;
}

/** Avance de la misión actual. */
function checkMission(t: Terrain, s: RoverState, action: boolean, dt: number, lander: { x: number; z: number }): RoverState {
  const m = roverPlan(s.plan).steps[s.mission];
  if (!m || s.quizPending) return s;
  const tg = missionTarget(t, m.site, lander, s);
  const inside = Math.hypot(s.x - tg.x, s.z - tg.z) <= tg.r;
  if (!inside) return s.holdT ? { ...s, holdT: 0 } : s;
  if (m.holdS === 0) return complete(s, m);
  const still = Math.abs(s.speed) < 0.1;
  if (!(action && still)) return s.holdT ? { ...s, holdT: 0 } : s;
  const holdT = s.holdT + dt;
  if (holdT < m.holdS) return { ...s, holdT };
  if (m.id === 'investigate') return { ...s, holdT: 0, quizPending: true };
  return complete({ ...s, energy: m.id === 'send' ? Math.max(0, s.energy - 5) : s.energy }, m);
}

function complete(s: RoverState, m: RoverMission): RoverState {
  const mission = s.mission + 1;
  return { ...s, mission, holdT: 0, points: s.points + m.points, gbit: s.gbit + m.gbit, lastDone: m.id, finished: mission >= roverPlan(s.plan).steps.length };
}

/** Respuesta a la pregunta de la investigación. */
export function answerInvestigation(s: RoverState, option: number): RoverState {
  if (!s.quizPending) return s;
  const plan = roverPlan(s.plan);
  const m = plan.steps[s.mission];
  const ok = option === plan.quiz.correct;
  const done = complete({ ...s, quizPending: false, quizAnswer: option }, m);
  return ok ? { ...done, points: done.points + plan.quiz.bonus } : done;
}

/** Porcentaje del terreno cercano (600 × 600 m alrededor del módulo) ya explorado. */
export function exploredPct(s: RoverState, lander: { x: number; z: number }) {
  const half = 300;
  let n = 0;
  let total = 0;
  for (let gx = Math.floor((lander.x - half) / ROVER.cell); gx < Math.ceil((lander.x + half) / ROVER.cell); gx++)
    for (let gz = Math.floor((lander.z - half) / ROVER.cell); gz < Math.ceil((lander.z + half) / ROVER.cell); gz++) {
      total++;
      if (s.explored.includes(`${gx},${gz}`)) n++;
    }
  return total ? (n / total) * 100 : 0;
}

export function roverReadout(t: Terrain, s: RoverState, lander: { x: number; z: number }) {
  const m = roverPlan(s.plan).steps[s.mission];
  const tg = m ? missionTarget(t, m.site, lander, s) : null;
  const dist = tg ? Math.hypot(tg.x - s.x, tg.z - s.z) : 0;
  // Ángulo del objetivo respecto del frente del rover (+ = a la derecha).
  let rel = tg ? Math.atan2(tg.z - s.z, tg.x - s.x) - s.heading : 0;
  rel = Math.atan2(Math.sin(rel), Math.cos(rel));
  return {
    mission: m ?? null,
    target: tg,
    distanceM: dist,
    bearingDeg: (rel * 180) / Math.PI,
    slopeDeg: slopeAt(t, s.x, s.z).deg,
    grade: gradeAhead(t, s.x, s.z, s.heading, 1),
    inTarget: tg ? dist <= tg.r : false,
  };
}
