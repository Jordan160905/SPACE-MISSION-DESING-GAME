/**
 * Logros del jugador: insignias, rangos (bronce → plata → oro → diamante), puntuación total y
 * el informe divertido de cada misión (qué pasó, qué datos se consiguieron y para qué sirven,
 * qué problemas hubo y qué se puede mejorar). Funciones puras: el estado se guarda en
 * state/achievements.ts.
 */

/** Lo que pasó en el vuelo (se guarda al terminar el viaje a la Luna). */
export interface FlightStats {
  launched: boolean;
  reachedMoon: boolean;
  discoveries: Array<{ name: string; typeLabel: string }>;
  journalPoints: number;
  rescue: 'done' | 'failed' | 'declined' | null;
  rescuePoints: number;
  /** Situación contrarreloj: null si no hubo. */
  countdown: { title: string; onTime: boolean } | null;
  problems: Array<{ title: string; choice: string | null }>;
  goodNews: string[];
  extraFuelKg: number;
}

/** Lo que pasó en la superficie (aterrizaje y rover). */
export interface SurfaceStats {
  landing: { success: boolean; inSafe: boolean; attempts: number; points: number; lastOutcome: string; verticalMS: number } | null;
  rover: {
    planTitle: string;
    dataName: string;
    done: number;
    total: number;
    points: number;
    quizCorrect: boolean | null;
    collected: Array<{ icon: string; label: string; why: string }>;
    distanceM: number;
  } | null;
}

/** Resultado de la misión al terminar (informe final). */
export interface MissionOutcome {
  missionId: string;
  player: string;
  missionName: string;
  objectiveTitle: string;
  success: boolean;
  missionScore: number;
  grade: string;
  deliveredGbit: number;
  targetGbit: number;
}

export interface Badge {
  id: string;
  icon: string;
  title: string;
  how: string;
  check: (o: MissionOutcome, f: FlightStats | null, s: SurfaceStats | null) => boolean;
}

export const BADGES: Badge[] = [
  { id: 'liftoff', icon: '🚀', title: 'Primer despegue', how: 'Lanza un cohete.', check: (_o, f) => !!f?.launched },
  { id: 'moon', icon: '🌙', title: 'Rumbo a la Luna', how: 'Llega hasta la Luna.', check: (_o, f) => !!f?.reachedMoon },
  { id: 'stargazer', icon: '🔭', title: 'Explorador del cielo', how: 'Registra 3 descubrimientos en el diario.', check: (_o, f) => (f?.discoveries.length ?? 0) >= 3 },
  { id: 'journal', icon: '📔', title: 'Diario completo', how: 'Registra 5 descubrimientos.', check: (_o, f) => (f?.discoveries.length ?? 0) >= 5 },
  { id: 'rescuer', icon: '🛰️', title: 'Héroe del rescate', how: 'Completa un rescate espacial.', check: (_o, f) => f?.rescue === 'done' },
  { id: 'cool', icon: '⏱️', title: 'Sangre fría', how: 'Decide a tiempo en una situación contrarreloj.', check: (_o, f) => !!f?.countdown?.onTime },
  { id: 'fixer', icon: '🛠️', title: 'Solucionador', how: 'Resuelve 2 problemas durante el viaje.', check: (_o, f) => (f?.problems.length ?? 0) >= 2 },
  { id: 'thrifty', icon: '⛽', title: 'Ahorrador', how: 'Llega a la Luna gastando menos de 0,5 kg de combustible extra.', check: (_o, f) => !!f?.reachedMoon && (f?.extraFuelKg ?? 9) < 0.5 },
  { id: 'landed', icon: '🛬', title: 'Alunizaje', how: 'Aterriza en la Luna.', check: (_o, _f, s) => !!s?.landing?.success },
  { id: 'bullseye', icon: '🎯', title: 'En el centro', how: 'Aterriza dentro de la zona verde.', check: (_o, _f, s) => !!s?.landing?.success && !!s.landing.inSafe },
  { id: 'first-try', icon: '⭐', title: 'A la primera', how: 'Aterriza bien en el primer intento.', check: (_o, _f, s) => !!s?.landing?.success && s.landing.attempts === 1 },
  { id: 'driver', icon: '🚙', title: 'Piloto del rover', how: 'Completa una tarea con el rover.', check: (_o, _f, s) => (s?.rover?.done ?? 0) >= 1 },
  { id: 'scientist', icon: '🔬', title: 'Científico', how: 'Acierta la pregunta de la investigación.', check: (_o, _f, s) => s?.rover?.quizCorrect === true },
  { id: 'collector', icon: '📡', title: 'Cazador de datos', how: 'Completa todas las tareas del rover.', check: (_o, _f, s) => !!s?.rover && s.rover.done >= s.rover.total },
  { id: 'mission', icon: '🏆', title: 'Misión cumplida', how: 'Consigue los datos que pide la misión.', check: (o) => o.success },
  {
    id: 'perfect',
    icon: '💎',
    title: 'Misión perfecta',
    how: 'Cumple la misión, aterriza en la zona verde y completa el rover.',
    check: (o, _f, s) => o.success && !!s?.landing?.inSafe && !!s.rover && s.rover.done >= s.rover.total,
  },
];

export type TierId = 'none' | 'bronze' | 'silver' | 'gold' | 'diamond';
export const TIERS: Array<{ id: Exclude<TierId, 'none'>; label: string; icon: string; need: number }> = [
  { id: 'bronze', label: 'Bronce', icon: '🥉', need: 3 },
  { id: 'silver', label: 'Plata', icon: '🥈', need: 6 },
  { id: 'gold', label: 'Oro', icon: '🥇', need: 10 },
  { id: 'diamond', label: 'Diamante', icon: '💎', need: 15 },
];

/** Rango actual y cuánto falta para el siguiente. */
export function tierProgress(count: number) {
  let current: (typeof TIERS)[number] | null = null;
  for (const t of TIERS) if (count >= t.need) current = t;
  const next = TIERS.find((t) => count < t.need) ?? null;
  const from = current?.need ?? 0;
  const frac = next ? (count - from) / (next.need - from) : 1;
  return { current, next, missing: next ? next.need - count : 0, frac: Math.max(0, Math.min(1, frac)) };
}

export function earnedBadges(o: MissionOutcome, f: FlightStats | null, s: SurfaceStats | null): string[] {
  return BADGES.filter((b) => b.check(o, f, s)).map((b) => b.id);
}

/** Puntuación total del juego: la de la misión más los puntos de las actividades. */
export function totalScore(o: MissionOutcome, f: FlightStats | null, s: SurfaceStats | null) {
  return Math.round(o.missionScore * 10 + (f?.journalPoints ?? 0) + (f?.rescuePoints ?? 0) + (s?.landing?.points ?? 0) + (s?.rover?.points ?? 0));
}

/** Estrellas del informe (1–3). */
export function stars(o: MissionOutcome, s: SurfaceStats | null) {
  if (!o.success) return 1;
  return s?.landing?.success && s.rover && s.rover.done >= s.rover.total ? 3 : 2;
}

export interface FeedbackCard {
  icon: string;
  title: string;
  text: string;
  tone: 'good' | 'bad' | 'info';
}

/** «¿Cómo te fue?»: tarjetas cortas y con dibujos, para niños y para adultos sin conocimientos técnicos. */
export function missionFeedback(o: MissionOutcome, f: FlightStats | null, s: SurfaceStats | null) {
  const journey: FeedbackCard[] = [];
  if (f?.launched) journey.push({ icon: '🚀', title: 'Despegue', text: 'Tu cohete llegó al espacio.', tone: 'good' });
  if (f?.reachedMoon) journey.push({ icon: '🌙', title: 'Viaje', text: 'La nave viajó unos 384 000 km hasta la Luna.', tone: 'good' });
  if (f?.rescue === 'done') journey.push({ icon: '🛰️', title: 'Rescate', text: 'Salvaste a un satélite en apuros.', tone: 'good' });
  else if (f?.rescue === 'failed') journey.push({ icon: '🛰️', title: 'Rescate', text: 'El rescate no salió esta vez.', tone: 'bad' });
  if (s?.landing) journey.push(s.landing.success ? { icon: '🛬', title: 'Aterrizaje', text: s.landing.inSafe ? '¡Justo en la zona verde!' : 'Aterrizaste bien, fuera de la zona verde.', tone: 'good' } : { icon: '💥', title: 'Aterrizaje', text: 'El módulo no aterrizó bien.', tone: 'bad' });
  if (s?.rover) journey.push({ icon: '🚙', title: 'Rover', text: `${s.rover.done} de ${s.rover.total} tareas hechas.`, tone: s.rover.done >= s.rover.total ? 'good' : 'info' });
  journey.push(
    o.success
      ? { icon: '📡', title: 'Datos', text: 'Llegaron a la Tierra todos los datos que pedía la misión.', tone: 'good' }
      : { icon: '📡', title: 'Datos', text: 'Faltaron datos para cumplir la misión.', tone: 'bad' },
  );

  const found: FeedbackCard[] = [];
  for (const c of s?.rover?.collected ?? []) found.push({ icon: c.icon, title: c.label, text: c.why, tone: 'info' });
  for (const d of (f?.discoveries ?? []).slice(0, 4)) found.push({ icon: '🔭', title: d.name, text: `Lo viste por el camino: ${d.typeLabel.toLowerCase()}.`, tone: 'info' });

  const problems: FeedbackCard[] = (f?.problems ?? []).slice(0, 4).map((p) => ({ icon: '⚠️', title: p.title, text: p.choice ? `Decidiste: ${p.choice}` : 'Se acabó el tiempo sin decidir.', tone: p.choice ? 'info' : 'bad' }));

  const tips: FeedbackCard[] = [];
  if (!o.success) tips.push({ icon: '📶', title: 'Más datos', text: 'Una antena más potente o más tiempo con el instrumento encendido ayudan a enviar más datos.', tone: 'info' });
  if (s?.landing && !s.landing.success) tips.push({ icon: '🔥', title: 'Aterrizar', text: 'Mantén ESPACIO un poco antes de tocar el suelo para llegar despacio.', tone: 'info' });
  if (s?.landing?.success && !s.landing.inSafe) tips.push({ icon: '🎯', title: 'Zona verde', text: 'Usa las flechas al principio del descenso para llegar a la zona verde.', tone: 'info' });
  if (s?.rover && s.rover.done < s.rover.total) tips.push({ icon: '🚙', title: 'Rover', text: 'Sigue la columna de luz y el mapa para terminar todas las tareas.', tone: 'info' });
  if (s?.rover?.quizCorrect === false) tips.push({ icon: '🔬', title: 'Investigación', text: 'Lee la explicación de la pregunta: la próxima vez la aciertas.', tone: 'info' });
  if (f?.countdown && !f.countdown.onTime) tips.push({ icon: '⏱️', title: 'Contrarreloj', text: 'En una emergencia, cualquier decisión suele ser mejor que no decidir.', tone: 'info' });
  if (f?.rescue === 'failed') tips.push({ icon: '🛰️', title: 'Rescate', text: 'Cerca del satélite, frena con S y acércate muy despacio.', tone: 'info' });
  if ((f?.extraFuelKg ?? 0) >= 0.5) tips.push({ icon: '⛽', title: 'Combustible', text: 'Algunas decisiones gastaron combustible extra: piensa cuál ahorra más.', tone: 'info' });
  if (!tips.length) tips.push({ icon: '🌟', title: '¡Muy bien!', text: 'Lo hiciste genial. Prueba un nivel más difícil u otro objetivo.', tone: 'good' });

  return { journey, found, problems, tips };
}
