/**
 * Logros: insignias, rangos, puntuación e informe.
 */
import { describe, expect, it } from 'vitest';
import { BADGES, earnedBadges, missionFeedback, stars, TIERS, tierProgress, totalScore, type FlightStats, type MissionOutcome, type SurfaceStats } from './Achievements';

const O: MissionOutcome = { missionId: 'm1', player: 'Ana', missionName: 'LUNA-01 · Intento 1', objectiveTitle: 'Cartografía', success: true, missionScore: 80, grade: 'A', deliveredGbit: 120, targetGbit: 100 };
const F: FlightStats = {
  launched: true,
  reachedMoon: true,
  discoveries: [
    { name: 'ISS', typeLabel: 'Satélite' },
    { name: 'Orión', typeLabel: 'Constelación' },
    { name: 'Tycho', typeLabel: 'Cráter' },
  ],
  journalPoints: 300,
  rescue: 'done',
  rescuePoints: 400,
  countdown: { title: '¡Caída de energía!', onTime: true },
  problems: [{ title: 'Calor', choice: 'Girar' }],
  goodNews: [],
  extraFuelKg: 0.3,
};
const S: SurfaceStats = {
  landing: { success: true, inSafe: true, attempts: 1, points: 900, lastOutcome: 'perfect', verticalMS: 1.2 },
  rover: { planTitle: 'Cartografía', dataName: 'Fotos', done: 5, total: 5, points: 800, quizCorrect: true, collected: [{ icon: '📷', label: 'Foto', why: 'Para el mapa' }], distanceM: 600 },
};

describe('Logros', () => {
  it('las insignias salen de lo que pasó en el juego', () => {
    const all = earnedBadges(O, F, S);
    for (const id of ['liftoff', 'moon', 'stargazer', 'rescuer', 'cool', 'thrifty', 'landed', 'bullseye', 'first-try', 'driver', 'scientist', 'collector', 'mission', 'perfect']) expect(all).toContain(id);
    expect(all).not.toContain('journal');
    expect(earnedBadges({ ...O, success: false }, null, null)).toEqual([]);
    expect(new Set(BADGES.map((b) => b.id)).size).toBe(BADGES.length);
  });

  it('los rangos van de bronce a diamante y dicen cuántas faltan', () => {
    expect(tierProgress(0).current).toBe(null);
    expect(tierProgress(0).next!.id).toBe('bronze');
    expect(tierProgress(4).current!.id).toBe('bronze');
    expect(tierProgress(4).missing).toBe(2);
    expect(tierProgress(TIERS[3].need).current!.id).toBe('diamond');
    expect(tierProgress(TIERS[3].need).next).toBe(null);
    expect(TIERS[3].need).toBeLessThanOrEqual(BADGES.length);
  });

  it('la puntuación suma la misión y las actividades', () => {
    expect(totalScore(O, F, S)).toBe(800 + 300 + 400 + 900 + 800);
    expect(totalScore(O, null, null)).toBe(800);
  });

  it('el informe explica qué pasó, qué se encontró y qué mejorar', () => {
    const ok = missionFeedback(O, F, S);
    expect(ok.journey.length).toBeGreaterThanOrEqual(5);
    expect(ok.found.some((c) => c.text === 'Para el mapa')).toBe(true);
    expect(ok.tips.length).toBeGreaterThan(0);
    expect(stars(O, S)).toBe(3);
    const bad = missionFeedback({ ...O, success: false }, F, { landing: { ...S.landing!, success: false, inSafe: false }, rover: null });
    expect(bad.tips.some((c) => c.title === 'Aterrizar')).toBe(true);
    expect(bad.tips.some((c) => c.title === 'Más datos')).toBe(true);
    expect(stars({ ...O, success: false }, null)).toBe(1);
  });
});
