/**
 * Minijuego de aterrizaje lunar (Fase 8.8, versión ágil): física del descenso final.
 * Gravedad lunar real (1,62 m/s²), sin aire, empuje según la orientación del módulo y consumo
 * por la ecuación del cohete (ṁ = F / (Isp·g₀)). El módulo es de juego, con valores típicos de un
 * módulo robótico pequeño.
 * Mandos sencillos: mantener ESPACIO enciende el motor; las flechas inclinan el módulo y, al
 * soltarlas, un estabilizador lo endereza solo. No hay piloto automático: frenar es cosa del jugador.
 */
import { heightAt, inSafeZone, normalAt, rockNear, slopeAt, TERRAIN, mulberry, type Terrain } from './LunarTerrain';

export const G_MOON = 1.62;
const G0 = 9.80665;

export const LANDER = {
  dryKg: 1200,
  fuelKg: 300,
  thrustN: 6000,
  ispS: 320,
  /** Giro de la orientación (°/s) y máxima inclinación (°). */
  tiltRate: 25,
  maxTilt: 20,
  /** Empuje con el motor encendido (fracción del máximo) y rapidez con que responde (por segundo). */
  engineLevel: 0.75,
  throttleRate: 4,
  /** Radio de las patas (m). */
  footprintM: 2.2,
};

/** Límites para un aterrizaje seguro (del orden de los que se usaron en las misiones Apolo). */
export const LIMITS = {
  verticalMS: 3,
  horizontalMS: 1.5,
  tiltDeg: 12,
  slopeDeg: TERRAIN.maxSlopeDeg,
};

export type LandingOutcome = 'perfect' | 'ok' | 'crash' | 'tipped' | 'rock' | 'away';

export interface LanderState {
  p: [number, number, number];
  v: [number, number, number];
  /** Inclinación hacia +x (adelante) y hacia +z (derecha), en grados. */
  pitch: number;
  roll: number;
  throttle: number;
  fuelKg: number;
  t: number;
  done: boolean;
  touchdown: Touchdown | null;
}

export interface Touchdown {
  outcome: LandingOutcome;
  success: boolean;
  verticalMS: number;
  horizontalMS: number;
  tiltDeg: number;
  slopeDeg: number;
  rock: boolean;
  inSafe: boolean;
  distanceToSafeM: number;
  fuelLeftKg: number;
  t: number;
  x: number;
  z: number;
}

export interface LanderInput {
  /** Motor encendido (mantener ESPACIO). */
  engine: boolean;
  /** −1/0/+1: inclinar hacia atrás/adelante (x) y hacia la izquierda/derecha (z). Sin pulsar, se endereza solo. */
  pitch: number;
  roll: number;
}
export const NO_LANDER_INPUT: LanderInput = { engine: false, pitch: 0, roll: 0 };

/** Punto de partida: 350 m de altura, a ~220 m de la zona segura, bajando y avanzando hacia ella. */
export function newLander(t: Terrain, attempt = 0): LanderState {
  const r = mulberry(1000 + attempt * 7919);
  const x = -220 + (r() - 0.5) * 60;
  const z = 40 + (r() - 0.5) * 60;
  return {
    p: [x, heightAt(t, x, z) + 350, z],
    v: [6 + (r() - 0.5) * 2, -10, (r() - 0.5) * 2],
    pitch: 0,
    roll: 0,
    throttle: 0,
    fuelKg: LANDER.fuelKg,
    t: 0,
    done: false,
    touchdown: null,
  };
}

/** Dirección del empuje (unitaria) para una inclinación dada. */
export function thrustDir(pitchDeg: number, rollDeg: number): [number, number, number] {
  const a = (pitchDeg * Math.PI) / 180;
  const b = (rollDeg * Math.PI) / 180;
  const x = Math.sin(a) * Math.cos(b);
  const z = Math.sin(b);
  const y = Math.cos(a) * Math.cos(b);
  return [x, y, z];
}

export function tiltOf(s: Pick<LanderState, 'pitch' | 'roll'>) {
  const d = thrustDir(s.pitch, s.roll);
  return (Math.acos(Math.max(-1, Math.min(1, d[1]))) * 180) / Math.PI;
}

export function altitude(t: Terrain, s: LanderState) {
  return s.p[1] - heightAt(t, s.p[0], s.p[2]);
}

const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));

export function stepLander(t: Terrain, s: LanderState, input: LanderInput, dt: number): LanderState {
  if (s.done) return s;
  // Inclinación: con flecha se inclina; sin flecha, el estabilizador endereza.
  const tilt = (cur: number, inp: number) => {
    const k = LANDER.tiltRate * dt;
    if (inp) return clamp(cur + Math.sign(inp) * k, -LANDER.maxTilt, LANDER.maxTilt);
    return Math.abs(cur) <= k ? 0 : cur - Math.sign(cur) * k;
  };
  const pitch = tilt(s.pitch, input.pitch);
  const roll = tilt(s.roll, input.roll);
  // El motor responde rápido, pero no al instante.
  const want = input.engine && s.fuelKg > 0 ? LANDER.engineLevel : 0;
  let throttle = s.throttle + clamp(want - s.throttle, -LANDER.throttleRate * dt, LANDER.throttleRate * dt);
  if (s.fuelKg <= 0) throttle = 0;
  const m = LANDER.dryKg + s.fuelKg;
  const F = LANDER.thrustN * throttle;
  const burn = Math.min(s.fuelKg, (F / (LANDER.ispS * G0)) * dt);
  const d = thrustDir(pitch, roll);
  const a = F / m;
  const v: [number, number, number] = [s.v[0] + a * d[0] * dt, s.v[1] + (a * d[1] - G_MOON) * dt, s.v[2] + a * d[2] * dt];
  const p: [number, number, number] = [s.p[0] + v[0] * dt, s.p[1] + v[1] * dt, s.p[2] + v[2] * dt];
  const next: LanderState = { ...s, p, v, pitch, roll, throttle, fuelKg: s.fuelKg - burn, t: s.t + dt };
  const half = TERRAIN.size / 2 - 20;
  if (Math.abs(p[0]) > half || Math.abs(p[2]) > half) {
    return { ...next, done: true, touchdown: { ...evaluate(t, next), outcome: 'away', success: false } };
  }
  const ground = heightAt(t, p[0], p[2]);
  if (p[1] <= ground) {
    next.p = [p[0], ground, p[2]];
    return { ...next, done: true, touchdown: evaluate(t, { ...next, v }) };
  }
  return next;
}

/** Cómo fue el contacto con el suelo. */
export function evaluate(t: Terrain, s: LanderState): Touchdown {
  const [x, , z] = s.p;
  const verticalMS = Math.max(0, -s.v[1]);
  const horizontalMS = Math.hypot(s.v[0], s.v[2]);
  // Inclinación respecto del suelo: la del módulo combinada con la del terreno.
  const d = thrustDir(s.pitch, s.roll);
  const n = normalAt(t, x, z);
  const tiltDeg = (Math.acos(clamp(d[0] * n[0] + d[1] * n[1] + d[2] * n[2], -1, 1)) * 180) / Math.PI;
  const slopeDeg = slopeAt(t, x, z).deg;
  const rock = !!rockNear(t, x, z, LANDER.footprintM, 0.5);
  const inSafe = inSafeZone(x, z);
  let outcome: LandingOutcome;
  if (verticalMS > LIMITS.verticalMS || horizontalMS > LIMITS.horizontalMS * 2.5) outcome = 'crash';
  else if (rock) outcome = 'rock';
  else if (tiltDeg > LIMITS.tiltDeg || slopeDeg > LIMITS.slopeDeg || horizontalMS > LIMITS.horizontalMS) outcome = 'tipped';
  else outcome = inSafe ? 'perfect' : 'ok';
  return {
    outcome,
    success: outcome === 'perfect' || outcome === 'ok',
    verticalMS,
    horizontalMS,
    tiltDeg: tiltOf(s),
    slopeDeg,
    rock,
    inSafe,
    distanceToSafeM: Math.hypot(x - TERRAIN.safe.x, z - TERRAIN.safe.z),
    fuelLeftKg: s.fuelKg,
    t: s.t,
    x,
    z,
  };
}

/** Qué mejorar (o qué salió bien), en frases sencillas. */
export function landingAdvice(td: Touchdown): string[] {
  const out: string[] = [];
  const f = (n: number, k = 1) => n.toFixed(k).replace('.', ',');
  if (td.outcome === 'away') return ['Te alejaste demasiado. Usa las flechas para volver hacia la zona verde.'];
  if (td.verticalMS > LIMITS.verticalMS) out.push(`Bajaste a ${f(td.verticalMS)} m/s y el límite es ${LIMITS.verticalMS} m/s. Mantén ESPACIO un poco antes para frenar la caída.`);
  if (td.horizontalMS > LIMITS.horizontalMS) out.push(`Ibas de lado a ${f(td.horizontalMS)} m/s (límite: ${LIMITS.horizontalMS} m/s). Pulsa la flecha contraria a hacia donde vas para frenar, y suéltala antes de tocar el suelo.`);
  if (td.tiltDeg > LIMITS.tiltDeg) out.push(`El módulo estaba inclinado ${f(td.tiltDeg, 0)}° (límite: ${LIMITS.tiltDeg}°). Suelta las flechas en los últimos metros: el módulo se endereza solo.`);
  if (td.rock) out.push('Una pata cayó sobre una roca. Busca un sitio liso: la zona verde no tiene rocas.');
  if (td.slopeDeg > LIMITS.slopeDeg) out.push(`El suelo tenía una pendiente de ${f(td.slopeDeg, 0)}° (límite: ${LIMITS.slopeDeg}°). Los bordes de los cráteres son peligrosos: aterriza en la zona verde.`);
  if (td.fuelLeftKg <= 0.01 && !td.success) out.push('Te quedaste sin combustible. No mantengas el motor encendido todo el rato: úsalo a ratos.');
  if (td.success) {
    if (!td.inSafe) out.push(`Aterrizaste a ${f(td.distanceToSafeM, 0)} m de la zona verde, en un sitio aceptable. Para la puntuación máxima, aterriza dentro de ella.`);
    if (td.verticalMS < 1) out.push('¡Contacto muy suave!');
    out.push(`Te sobraron ${f(td.fuelLeftKg, 0)} kg de combustible.`);
  }
  return out;
}

export function landingPoints(td: Touchdown) {
  if (!td.success) return 0;
  const zone = td.inSafe ? 300 : 0;
  const soft = Math.round(Math.max(0, LIMITS.verticalMS - td.verticalMS) * 60);
  const fuel = Math.round((td.fuelLeftKg / LANDER.fuelKg) * 200);
  return 400 + zone + soft + fuel;
}

/** Lecturas para los indicadores. */
export function landerReadout(t: Terrain, s: LanderState) {
  const alt = altitude(t, s);
  const [x, , z] = s.p;
  const dx = TERRAIN.safe.x - x;
  const dz = TERRAIN.safe.z - z;
  const slope = slopeAt(t, x, z).deg;
  return {
    altitudeM: alt,
    verticalMS: s.v[1],
    horizontalMS: Math.hypot(s.v[0], s.v[2]),
    vx: s.v[0],
    vz: s.v[2],
    tiltDeg: tiltOf(s),
    fuelFrac: s.fuelKg / LANDER.fuelKg,
    safeDx: dx,
    safeDz: dz,
    safeDistM: Math.hypot(dx, dz),
    groundSlopeDeg: slope,
    groundRock: !!rockNear(t, x, z, LANDER.footprintM, 0.5),
    groundOk: slope <= LIMITS.slopeDeg && !rockNear(t, x, z, LANDER.footprintM, 0.5),
    /** Velocidad de bajada recomendada para esta altura (m/s). */
    recommendedMS: Math.max(2, Math.min(15, 0.08 * alt + 1.5)),
  };
}
