/**
 * Lógica pura del ciclo de vida de una misión. Sin React ni Zustand: se prueba de forma aislada
 * y el store solo la orquesta.
 */
import {
  MissionSchema,
  SaveFileSchema,
  type Mission,
  type MissionStage,
  type MissionTemplate,
  type SaveFile,
} from '../data/schemas';

export const STAGE_ORDER: MissionStage[] = ['DESIGN', 'PLANNING', 'LAUNCH', 'OPERATIONS', 'DEBRIEF', 'COMPLETE'];

export const STAGE_INFO: Record<MissionStage, { label: string; description: string; availableInPhase: number }> = {
  DESIGN: { label: 'Diseño', description: 'Construir la nave en el Spacecraft Lab y superar el análisis de ingeniería.', availableInPhase: 2 },
  PLANNING: { label: 'Planificación', description: 'Elegir lanzador, órbita, duración y ventana de lanzamiento en el Mission Planner.', availableInPhase: 4 },
  LAUNCH: { label: 'Lanzamiento', description: 'Verificación previa, cuenta regresiva, ascenso y viaje a la Luna en Launch Control.', availableInPhase: 5 },
  OPERATIONS: { label: 'Operaciones', description: 'Gestionar energía, datos, instrumentos y comunicaciones en órbita lunar.', availableInPhase: 5 },
  DEBRIEF: { label: 'Informe', description: 'Analizar resultados, errores y recomendaciones.', availableInPhase: 6 },
  COMPLETE: { label: 'Completada', description: 'Misión archivada.', availableInPhase: 6 },
};

export type StageStatus = 'done' | 'current' | 'locked';

export function stageStatus(mission: Mission, stage: MissionStage): StageStatus {
  const cur = STAGE_ORDER.indexOf(mission.stage);
  const idx = STAGE_ORDER.indexOf(stage);
  if (idx < cur) return 'done';
  if (idx === cur) return 'current';
  return 'locked';
}

export function stageProgress(mission: Mission): number {
  return STAGE_ORDER.indexOf(mission.stage) / (STAGE_ORDER.length - 1);
}

export class MissionError extends Error {}

export function createMission(params: {
  template: MissionTemplate;
  objectiveId: string;
  id: string;
  now: Date;
  existingCount?: number;
  difficulty?: Mission['difficulty'];
  team?: Mission['team'];
  pilotName?: string | null;
}): Mission {
  const { template, objectiveId, id, now, existingCount = 0, difficulty = 'engineer', team = null, pilotName = null } = params;
  if (!template.available) {
    throw new MissionError(`La misión ${template.code} está bloqueada: ${template.lockReason ?? 'sin motivo'}`);
  }
  if (!template.objectives.some((o) => o.id === objectiveId)) {
    throw new MissionError(`El objetivo ${objectiveId} no pertenece a ${template.code}`);
  }
  const iso = now.toISOString();
  return MissionSchema.parse({
    id,
    templateId: template.id,
    objectiveId,
    name: `${template.code} · Intento ${existingCount + 1}`,
    stage: 'DESIGN',
    createdAt: iso,
    updatedAt: iso,
    design: { chassisId: null, parts: [] },
    plan: null,
    flight: null,
    difficulty,
    team,
    pilotName: team ? null : pilotName?.trim() || null,
  });
}

/** Añade una decisión votada por el equipo al registro de la misión. */
export function withTeamDecision(mission: Mission, decision: Mission['teamLog'][number], now: Date): Mission {
  return MissionSchema.parse({ ...mission, teamLog: [...mission.teamLog, decision], updatedAt: now.toISOString() });
}

/** Guarda el resultado final (clasificación y comparación). */
export function withResult(mission: Mission, result: NonNullable<Mission['result']>, now: Date): Mission {
  return MissionSchema.parse({ ...mission, result, updatedAt: now.toISOString() });
}

/** Devuelve la misión con un nuevo diseño guardado (validado por esquema). */
export function withDesign(mission: Mission, design: Mission['design'], now: Date): Mission {
  return MissionSchema.parse({ ...mission, design, updatedAt: now.toISOString() });
}

/** Devuelve la misión con un nuevo estado de vuelo (validado por esquema). */
export function withFlight(mission: Mission, flight: Mission['flight'], now: Date): Mission {
  return MissionSchema.parse({ ...mission, flight, updatedAt: now.toISOString() });
}

/** Devuelve la misión con un plan de vuelo nuevo (validado por esquema). */
export function withPlan(mission: Mission, plan: Mission['plan'], now: Date): Mission {
  const trades = plan ? recordTrade(mission.trades, plan) : mission.trades;
  return MissionSchema.parse({ ...mission, plan, trades, updatedAt: now.toISOString() });
}

const TRADE_CAP = 40;
const addUnique = <T,>(list: T[], v: T): T[] => (list.includes(v) ? list : [...list, v].slice(-TRADE_CAP));

/** Añade al registro de compromisos las alternativas de un plan (sin duplicados, con tope). */
export function recordTrade(log: Mission['trades'], plan: NonNullable<Mission['plan']>): Mission['trades'] {
  return {
    ...log,
    launchers: addUnique(log.launchers, plan.launcherId),
    altitudes: addUnique(log.altitudes, plan.altitudeKm),
    inclinations: addUnique(log.inclinations, plan.inclinationDeg),
    durations: addUnique(log.durations, plan.durationDays),
  };
}

/** Anota un estudio de órbita elíptica hecho en el simulador del Planner. */
export function withEllipticalStudy(mission: Mission, now: Date): Mission {
  return MissionSchema.parse({ ...mission, trades: { ...mission.trades, ellipticalStudies: mission.trades.ellipticalStudies + 1 }, updatedAt: now.toISOString() });
}

/** Cambia la etapa de la misión (las reglas de cuándo se permite viven en el store/análisis). */
export function withStage(mission: Mission, stage: MissionStage, now: Date): Mission {
  return MissionSchema.parse({ ...mission, stage, updatedAt: now.toISOString() });
}

export function upsertMission(list: Mission[], mission: Mission): Mission[] {
  const i = list.findIndex((m) => m.id === mission.id);
  if (i === -1) return [...list, mission];
  const copy = list.slice();
  copy[i] = mission;
  return copy;
}

export function removeMission(list: Mission[], id: string): Mission[] {
  return list.filter((m) => m.id !== id);
}

export const EMPTY_SAVE: SaveFile = {
  version: 1,
  profile: { xp: 0, completedMissionIds: [], tutorialDone: false, labHintSeen: false },
  missions: [],
  activeMissionId: null,
};

/**
 * Valida un guardado leído de almacenamiento. Si el archivo entero es inválido se vuelve al
 * guardado vacío; si solo algunas misiones son inválidas se descartan esas (y se informa).
 */
export function sanitizeSave(raw: unknown): { save: SaveFile; dropped: number } {
  const full = SaveFileSchema.safeParse(raw);
  if (full.success) return { save: full.data, dropped: 0 };

  if (typeof raw !== 'object' || raw === null) return { save: EMPTY_SAVE, dropped: 0 };
  const r = raw as Record<string, unknown>;
  const rawMissions = Array.isArray(r.missions) ? r.missions : [];
  const missions = rawMissions.flatMap((m) => {
    const p = MissionSchema.safeParse(m);
    return p.success ? [p.data] : [];
  });
  const candidate = {
    ...EMPTY_SAVE,
    profile: r.profile ?? EMPTY_SAVE.profile,
    missions,
    activeMissionId: missions.some((m) => m.id === r.activeMissionId) ? r.activeMissionId : null,
  };
  const second = SaveFileSchema.safeParse(candidate);
  const save = second.success ? second.data : { ...EMPTY_SAVE, missions };
  return { save, dropped: rawMissions.length - missions.length };
}
