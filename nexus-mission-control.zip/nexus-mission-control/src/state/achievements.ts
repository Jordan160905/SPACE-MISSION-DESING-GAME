/**
 * Logros guardados en el navegador: lo que pasó en cada vuelo y en la superficie, las insignias
 * conseguidas (con fecha y misión), y la clasificación de puntuaciones.
 */
import { create } from 'zustand';
import { BADGES, earnedBadges, totalScore, type FlightStats, type MissionOutcome, type SurfaceStats } from '../sim/Achievements';

const KEY = 'nexus-achievements';

export interface EarnedBadge {
  id: string;
  atISO: string;
  missionName: string;
  player: string;
}

export interface ScoreEntry {
  missionId: string;
  player: string;
  missionName: string;
  objectiveTitle: string;
  score: number;
  success: boolean;
  badges: number;
  atISO: string;
}

export interface FinalResult {
  outcome: MissionOutcome;
  flight: FlightStats | null;
  surface: SurfaceStats | null;
  newBadges: string[];
  badges: string[];
  score: number;
  rank: number;
}

interface Saved {
  flights: Record<string, FlightStats>;
  surfaces: Record<string, SurfaceStats>;
  earned: EarnedBadge[];
  scores: ScoreEntry[];
  results: Record<string, FinalResult>;
}

function load(): Saved {
  const empty: Saved = { flights: {}, surfaces: {}, earned: [], scores: [], results: {} };
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) ?? 'null') as Partial<Saved> | null;
    if (!raw || typeof raw !== 'object') return empty;
    return {
      flights: raw.flights ?? {},
      surfaces: raw.surfaces ?? {},
      earned: Array.isArray(raw.earned) ? raw.earned.filter((e) => BADGES.some((b) => b.id === e.id)) : [],
      scores: Array.isArray(raw.scores) ? raw.scores : [],
      results: raw.results ?? {},
    };
  } catch {
    return empty;
  }
}

interface AchievementsState extends Saved {
  recordFlight: (missionId: string, stats: FlightStats) => void;
  recordSurface: (missionId: string, stats: SurfaceStats) => void;
  /** Cierra la misión: calcula insignias y puntuación y la añade a la clasificación (una sola vez). */
  finalize: (outcome: MissionOutcome) => FinalResult;
  /** Clasificación de mayor a menor. */
  ranking: () => ScoreEntry[];
}

export const useAchievements = create<AchievementsState>()((set, get) => {
  const save = () => {
    const { flights, surfaces, earned, scores, results } = get();
    try {
      localStorage.setItem(KEY, JSON.stringify({ flights, surfaces, earned, scores, results }));
    } catch {
      /* sin almacenamiento: solo dura esta sesión */
    }
  };
  return {
    ...load(),
    recordFlight: (missionId, stats) => {
      set({ flights: { ...get().flights, [missionId]: stats } });
      save();
    },
    recordSurface: (missionId, stats) => {
      set({ surfaces: { ...get().surfaces, [missionId]: stats } });
      save();
    },
    finalize: (outcome) => {
      const done = get().results[outcome.missionId];
      if (done) return done;
      const flight = get().flights[outcome.missionId] ?? null;
      const surface = get().surfaces[outcome.missionId] ?? null;
      const badges = earnedBadges(outcome, flight, surface);
      const have = new Set(get().earned.map((e) => e.id));
      const newBadges = badges.filter((b) => !have.has(b));
      const at = new Date().toISOString();
      const earned = [...get().earned, ...newBadges.map((id) => ({ id, atISO: at, missionName: outcome.missionName, player: outcome.player }))];
      const score = totalScore(outcome, flight, surface);
      const entry: ScoreEntry = {
        missionId: outcome.missionId,
        player: outcome.player,
        missionName: outcome.missionName,
        objectiveTitle: outcome.objectiveTitle,
        score,
        success: outcome.success,
        badges: badges.length,
        atISO: at,
      };
      const scores = [...get().scores.filter((x) => x.missionId !== outcome.missionId), entry];
      const rank = [...scores].sort((a, b) => b.score - a.score).findIndex((x) => x.missionId === outcome.missionId) + 1;
      const result: FinalResult = { outcome, flight, surface, newBadges, badges, score, rank };
      set({ earned, scores, results: { ...get().results, [outcome.missionId]: result } });
      save();
      return result;
    },
    ranking: () => [...get().scores].sort((a, b) => b.score - a.score || a.atISO.localeCompare(b.atISO)),
  };
});
