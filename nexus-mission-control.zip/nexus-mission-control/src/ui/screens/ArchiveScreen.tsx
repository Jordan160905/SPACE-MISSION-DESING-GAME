/**
 * Archivo: misiones guardadas, clasificación (local, por objetivo: varios equipos pueden competir
 * por el mismo objetivo en esta computadora), comparación de dos diseños y códigos para
 * compartir o importar diseños.
 */
import { useMemo, useState } from 'react';
import { difficultyDef } from '../../data/difficulty';
import { getComponent } from '../../data/components/catalog';
import { LUNA_01, templateForMission } from '../../data/missions/missions';
import type { Mission } from '../../data/schemas';
import { conceptMaturity } from '../../sim/ConceptReview';
import { designTotals } from '../../sim/DesignSystem';
import { missionResources } from '../../sim/ResourceSystem';
import { fmtNum } from '../../sim/units';
import { STAGE_INFO, stageProgress } from '../../state/missionLogic';
import { encodeShare } from '../../state/shareCode';
import { useGameStore } from '../../state/useGameStore';
import { Meter, Panel } from '../components/Panel';
import { reviewInputFor } from '../review/reviewInput';
import { numLocale } from '../../i18n/lang';

type Tab = 'list' | 'rank' | 'compare' | 'share';

function compareRow(m: Mission) {
  const input = reviewInputFor(m);
  if (!input || !m.design.chassisId) return null;
  const res = missionResources(input.engineering, input.plan);
  const get = (id: string) => res.resources.find((r) => r.id === id);
  const t = designTotals(m.design, getComponent);
  return {
    name: m.name,
    difficulty: difficultyDef(m.difficulty).label,
    objective: input.template.objectives.find((o) => o.id === m.objectiveId)?.title ?? '—',
    pieces: `${m.design.parts.length + 1}`,
    mass: `${fmtNum(t.massWetKg)} kg`,
    cost: input.engineering.budget ? `${fmtNum(input.engineering.budget.committedMUSD)} MUSD` : '—',
    energy: get('energy')?.available ?? '—',
    data: get('data')?.available ?? '—',
    time: get('time')?.used ?? '—',
    launcher: input.plan?.launcher.name ?? '—',
    dv: input.plan && Number.isFinite(input.plan.deltaV.marginFraction) ? `${Math.round(input.plan.deltaV.marginFraction * 100)} %` : '—',
    critical: res.critical.map((id) => get(id)?.label).join(', ') || '—',
    cml: `CML ${conceptMaturity(input).level}`,
    score: m.result ? `${m.result.score} (${m.result.grade})` : '—',
  };
}

const COMPARE_ROWS: Array<[keyof NonNullable<ReturnType<typeof compareRow>>, string]> = [
  ['difficulty', 'Dificultad'],
  ['objective', 'Objetivo'],
  ['pieces', 'Piezas'],
  ['mass', 'Masa húmeda'],
  ['cost', 'Costo comprometido'],
  ['energy', 'Energía por órbita'],
  ['data', 'Datos previstos'],
  ['time', 'Desarrollo'],
  ['launcher', 'Lanzador'],
  ['dv', 'Margen de Δv'],
  ['critical', 'Recursos críticos'],
  ['cml', 'Madurez'],
  ['score', 'Puntuación'],
];

export function ArchiveScreen() {
  const missions = useGameStore((s) => s.missions);
  const activeId = useGameStore((s) => s.activeMissionId);
  const setActive = useGameStore((s) => s.setActiveMission);
  const remove = useGameStore((s) => s.deleteMission);
  const navigate = useGameStore((s) => s.navigate);
  const openSelect = useGameStore((s) => s.openMissionSelect);
  const importShared = useGameStore((s) => s.importShared);
  const [confirmId, setConfirmId] = useState<string | null>(null);
  const [tab, setTab] = useState<Tab>('list');
  const [objective, setObjective] = useState<string>('all');
  const [a, setA] = useState<string>('');
  const [b, setB] = useState<string>('');
  const [code, setCode] = useState('');
  const [shown, setShown] = useState<{ id: string; code: string } | null>(null);

  const sorted = [...missions].sort((x, y) => y.updatedAt.localeCompare(x.updatedAt));
  const ranked = missions
    .filter((m) => m.result && difficultyDef(m.difficulty).ranked && (objective === 'all' || m.objectiveId === objective))
    .sort((x, y) => y.result!.score - x.result!.score || y.result!.deliveredGbit - x.result!.deliveredGbit);
  const withDesign = sorted.filter((m) => m.design.chassisId);
  const rowA = useMemo(() => {
    const m = missions.find((x) => x.id === a);
    return m ? compareRow(m) : null;
  }, [missions, a]);
  const rowB = useMemo(() => {
    const m = missions.find((x) => x.id === b);
    return m ? compareRow(m) : null;
  }, [missions, b]);

  const share = async (m: Mission) => {
    const c = encodeShare(m);
    setShown({ id: m.id, code: c });
    try {
      await navigator.clipboard.writeText(c);
    } catch {
      /* sin permiso de portapapeles: el código queda visible para copiarlo a mano */
    }
  };

  return (
    <Panel
      className="wide-panel archive"
      eyebrow="Archivo"
      title="Misiones guardadas"
      aside={<span className="badge badge--info">{missions.length}</span>}
      onClose={() => navigate('center')}
      tabs={
        <div className="tabs" role="tablist" aria-label="Secciones del archivo">
          {(
            [
              ['list', 'Misiones'],
              ['rank', 'Clasificación'],
              ['compare', 'Comparar'],
              ['share', 'Importar'],
            ] as Array<[Tab, string]>
          ).map(([id, label]) => (
            <button key={id} role="tab" className="tab" aria-selected={tab === id} onClick={() => setTab(id)}>
              {label}
            </button>
          ))}
        </div>
      }
    >
      {tab === 'list' &&
        (sorted.length === 0 ? (
          <>
            <p className="muted">Todavía no hay misiones. Se guardan automáticamente en este navegador.</p>
            <button
              className="btn btn--primary"
              onClick={() => {
                navigate('center');
                openSelect(true);
              }}
            >
              Nueva misión
            </button>
          </>
        ) : (
          sorted.map((m) => {
            const t = templateForMission(m);
            const obj = t?.objectives.find((o) => o.id === m.objectiveId);
            const isActive = m.id === activeId;
            return (
              <div key={m.id} className={`row-card ${isActive ? 'row-card--active' : ''}`}>
                <div>
                  <strong>{m.name}</strong>
                  {isActive && (
                    <span className="badge badge--ok" style={{ marginLeft: 8 }}>
                      Activa
                    </span>
                  )}
                  <span className="badge badge--info" style={{ marginLeft: 8 }}>
                    {difficultyDef(m.difficulty).label}
                  </span>
                  {m.team && (
                    <span className="badge badge--soft" style={{ marginLeft: 8 }}>
                      {m.team.name}
                    </span>
                  )}
                  <p className="small muted" style={{ margin: '4px 0 8px' }}>
                    {obj?.title ?? '—'} · {STAGE_INFO[m.stage].label} · {m.design.chassisId ? `${m.design.parts.length + 1} piezas` : 'sin nave'} ·{' '}
                    {new Date(m.createdAt).toLocaleString(numLocale())}
                    {m.result ? ` · ${m.result.score} puntos (${m.result.grade})` : ''}
                  </p>
                  <Meter value={stageProgress(m)} label={`Progreso de ${m.name}`} />
                  {shown?.id === m.id && (
                    <label className="field" style={{ marginTop: 8 }}>
                      <span className="small">Código para compartir (copiado si el navegador lo permite):</span>
                      <textarea readOnly rows={3} value={shown.code} onFocus={(e) => e.currentTarget.select()} aria-label={`Código de ${m.name}`} />
                    </label>
                  )}
                </div>
                <div className="row-actions">
                  {confirmId === m.id ? (
                    <>
                      <button
                        className="btn btn--danger"
                        onClick={() => {
                          remove(m.id);
                          setConfirmId(null);
                        }}
                      >
                        Confirmar
                      </button>
                      <button className="btn btn--ghost" onClick={() => setConfirmId(null)}>
                        No
                      </button>
                    </>
                  ) : (
                    <>
                      <button className="btn" disabled={isActive} onClick={() => setActive(m.id)}>
                        Cargar
                      </button>
                      <button className="btn btn--ghost" disabled={!m.design.chassisId} onClick={() => share(m)} aria-label={`Compartir ${m.name}`}>
                        Compartir
                      </button>
                      <button className="btn btn--ghost" onClick={() => setConfirmId(m.id)} aria-label={`Eliminar ${m.name}`}>
                        Eliminar
                      </button>
                    </>
                  )}
                </div>
              </div>
            );
          })
        ))}

      {tab === 'rank' && (
        <>
          <p className="small muted">
            Clasificación de las misiones archivadas en esta computadora. Para competir, varios equipos eligen el mismo objetivo y comparan puntuación. Sandbox no clasifica.
          </p>
          <label className="field">
            <span className="small">Objetivo</span>
            <select value={objective} onChange={(e) => setObjective(e.target.value)} aria-label="Filtrar por objetivo">
              <option value="all">Todos</option>
              {LUNA_01.objectives.map((o) => (
                <option key={o.id} value={o.id}>
                  {o.title}
                </option>
              ))}
            </select>
          </label>
          {ranked.length === 0 ? (
            <p className="muted">Aún no hay misiones archivadas en la clasificación.</p>
          ) : (
            <div className="table-wrap">
              <table className="data-table" aria-label="Clasificación">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Equipo</th>
                    <th>Misión</th>
                    <th>Dificultad</th>
                    <th>Puntos</th>
                    <th>Nota</th>
                    <th>Éxito</th>
                    <th>Datos</th>
                  </tr>
                </thead>
                <tbody>
                  {ranked.map((m, i) => (
                    <tr key={m.id}>
                      <td className="mono">{i + 1}</td>
                      <td>{m.team?.name ?? m.pilotName ?? 'Individual'}</td>
                      <td>{m.name}</td>
                      <td>{difficultyDef(m.difficulty).label}</td>
                      <td className="mono">{m.result!.score}</td>
                      <td className="mono">{m.result!.grade}</td>
                      <td>{m.result!.success ? '✓' : '✗'}</td>
                      <td className="mono">{fmtNum(m.result!.deliveredGbit, 0)} Gbit</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}

      {tab === 'compare' && (
        <>
          <p className="small muted">Elige dos misiones con nave para comparar sus diseños lado a lado.</p>
          <div className="compare-pick">
            {[
              [a, setA, 'Diseño A'],
              [b, setB, 'Diseño B'],
            ].map(([val, setVal, label]) => (
              <label key={label as string} className="field">
                <span className="small">{label as string}</span>
                <select value={val as string} onChange={(e) => (setVal as (v: string) => void)(e.target.value)} aria-label={label as string}>
                  <option value="">—</option>
                  {withDesign.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.name}
                    </option>
                  ))}
                </select>
              </label>
            ))}
          </div>
          {rowA && rowB && (
            <div className="table-wrap">
              <table className="data-table" aria-label="Comparación de diseños">
                <thead>
                  <tr>
                    <th />
                    <th>{rowA.name}</th>
                    <th>{rowB.name}</th>
                  </tr>
                </thead>
                <tbody>
                  {COMPARE_ROWS.map(([k, label]) => (
                    <tr key={k} className={rowA[k] !== rowB[k] ? 'compare-diff' : ''}>
                      <td className="muted">{label}</td>
                      <td>{rowA[k]}</td>
                      <td>{rowB[k]}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}

      {tab === 'share' && (
        <>
          <p className="small muted">
            Pega el código que otro equipo compartió (botón «Compartir» en la lista). Se crea una misión nueva con su nave para que la analicen, la mejoren y la comparen.
          </p>
          <label className="field">
            <span className="small">Código NEXUS1.…</span>
            <textarea rows={4} value={code} onChange={(e) => setCode(e.target.value)} aria-label="Código de diseño" />
          </label>
          <button className="btn btn--primary" disabled={!code.trim()} onClick={() => importShared(code) && setCode('')}>
            Importar diseño
          </button>
        </>
      )}
    </Panel>
  );
}
