/**
 * LOGROS: insignias conseguidas (con la barra de rango), clasificación de puntuaciones de mayor
 * a menor y registro de cada logro.
 */
import { useState } from 'react';
import { BADGES } from '../../sim/Achievements';
import { fmtNum } from '../../sim/units';
import { useAchievements } from '../../state/achievements';
import { useGameStore } from '../../state/useGameStore';
import { numLocale } from '../../i18n/lang';
import { BadgeCard, TierBar } from '../achievements/AchievementsUI';
import { Panel } from '../components/Panel';

type Tab = 'badges' | 'ranking' | 'log';

const fmtDate = (iso: string) => {
  try {
    return new Date(iso).toLocaleDateString(numLocale(), { day: 'numeric', month: 'short', year: 'numeric' });
  } catch {
    return iso.slice(0, 10);
  }
};

export function AchievementsScreen() {
  const navigate = useGameStore((s) => s.navigate);
  const earned = useAchievements((s) => s.earned);
  const scores = useAchievements((s) => s.scores);
  const [tab, setTab] = useState<Tab>('badges');
  const ranking = [...scores].sort((a, b) => b.score - a.score || a.atISO.localeCompare(b.atISO));
  const byId = new Map(earned.map((e) => [e.id, e]));
  const medal = (i: number) => (i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `${i + 1}`);

  return (
    <Panel
      className="wide-panel achievements"
      eyebrow="Tu agencia espacial"
      title="Logros"
      onClose={() => navigate('center')}
      tabs={
        <div className="segmented ach-tabs" role="tablist" aria-label="Secciones de logros">
          {(
            [
              ['badges', `Insignias (${earned.length}/${BADGES.length})`],
              ['ranking', 'Clasificación'],
              ['log', 'Registro'],
            ] as const
          ).map(([id, label]) => (
            <button key={id} role="tab" aria-selected={tab === id} aria-pressed={tab === id} onClick={() => setTab(id)}>
              {label}
            </button>
          ))}
        </div>
      }
    >
      {tab === 'badges' && (
        <>
          <TierBar count={earned.length} />
          <div className="badge-grid">
            {BADGES.map((b) => {
              const e = byId.get(b.id);
              return <BadgeCard key={b.id} id={b.id} earned={!!e} date={e ? fmtDate(e.atISO) : undefined} />;
            })}
          </div>
        </>
      )}

      {tab === 'ranking' &&
        (ranking.length === 0 ? (
          <p className="muted">Todavía no hay puntuaciones. Termina una misión y aparecerá aquí.</p>
        ) : (
          <table className="ach-table">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Jugador</th>
                <th scope="col">Misión</th>
                <th scope="col">Objetivo</th>
                <th scope="col">Insignias</th>
                <th scope="col">Resultado</th>
                <th scope="col">Puntos</th>
              </tr>
            </thead>
            <tbody>
              {ranking.map((r, i) => (
                <tr key={r.missionId} className={i < 3 ? 'top' : ''}>
                  <td className="ach-pos">{medal(i)}</td>
                  <td>
                    <strong>{r.player}</strong>
                  </td>
                  <td>{r.missionName}</td>
                  <td className="small">{r.objectiveTitle}</td>
                  <td className="mono">{r.badges}</td>
                  <td>{r.success ? '✓ Cumplida' : '✗ No cumplida'}</td>
                  <td className="mono ach-score">{fmtNum(r.score, 0)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ))}

      {tab === 'log' &&
        (earned.length === 0 ? (
          <p className="muted">Aquí se irá apuntando cada insignia que consigas.</p>
        ) : (
          <ol className="ach-log">
            {[...earned].reverse().map((e) => {
              const b = BADGES.find((x) => x.id === e.id);
              if (!b) return null;
              return (
                <li key={e.id}>
                  <span className="ach-log__icon" aria-hidden="true">
                    {b.icon}
                  </span>
                  <span>
                    <strong>{b.title}</strong>
                    <br />
                    <span className="small muted">{`${e.player} · ${e.missionName} · ${fmtDate(e.atISO)}`}</span>
                  </span>
                </li>
              );
            })}
          </ol>
        ))}
    </Panel>
  );
}
