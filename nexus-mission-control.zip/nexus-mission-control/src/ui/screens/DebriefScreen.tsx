/**
 * Mission Debrief (Fase 6): informe final con resultados, recursos, acontecimientos, aciertos,
 * errores de diseño, recomendaciones y puntuación transparente. Permite archivar la misión
 * (suma XP) y lanzar un nuevo intento modificando el diseño.
 */
import { useEffect, useMemo, useState } from 'react';
import { getComponent } from '../../data/components/catalog';
import { getLauncher } from '../../data/launchers/launchers';
import type { Mission } from '../../data/schemas';
import { analysisInputForMission, analyzeEngineering } from '../../sim/EngineeringAnalysis';
import { designTotals } from '../../sim/DesignSystem';
import { debriefInsights, eventLabel, scoreMission } from '../../sim/ScoringSystem';
import { fmtNum, formatMUSD } from '../../sim/units';
import { getMissionTemplate } from '../../data/missions/missions';
import { similarRealMissions } from '../../data/realMissions';
import { analyzePlan } from '../../sim/PlanningSystem';
import { coordination, roleDef, roleGoals } from '../../sim/TeamSystem';
import { difficultyDef } from '../../data/difficulty';
import { flightContextOf, useGameStore } from '../../state/useGameStore';
import { Meter, Panel } from '../components/Panel';
import { numLocale } from '../../i18n/lang';
import { useAchievements, type FinalResult } from '../../state/achievements';
import { MissionReport, ReportPrompt } from '../achievements/AchievementsUI';

export function DebriefScreen({ mission }: { mission: Mission }) {
  const archive = useGameStore((s) => s.archiveMission);
  const retry = useGameStore((s) => s.retryMission);
  const report = useMemo(() => {
    const fc = flightContextOf(mission);
    if (!fc || !mission.flight || !mission.plan) return null;
    const design = analyzeEngineering(analysisInputForMission(mission.design, getComponent, mission, getMissionTemplate));
    const input = {
      template: fc.template,
      objective: fc.objective,
      plan: mission.plan,
      model: fc.model,
      flight: mission.flight,
      budget: fc.budget,
      designOptimizations: design.issues.filter((i) => i.severity === 'optimization'),
    };
    const score = scoreMission(input);
    const plan = analyzePlan({ design: mission.design, lookup: getComponent, template: fc.template, objectiveId: mission.objectiveId, plan: mission.plan, difficulty: mission.difficulty });
    return { fc, score, insights: debriefInsights(input, score), totals: designTotals(mission.design, getComponent), teamGoals: roleGoals(plan.engineering, plan) };
  }, [mission]);
  // Logros: insignias, puntuación en la clasificación e informe divertido.
  const finalize = useAchievements((s) => s.finalize);
  const totalBadges = useAchievements((s) => s.earned.length);
  const navigate = useGameStore((s) => s.navigate);
  const [result, setResult] = useState<FinalResult | null>(null);
  const [view, setView] = useState<'prompt' | 'report' | null>(null);
  const player = mission.pilotName ?? mission.team?.name ?? 'Comandante';
  useEffect(() => {
    if (!report || !mission.flight) return;
    const r = finalize({
      missionId: mission.id,
      player,
      missionName: mission.name,
      objectiveTitle: report.fc.objective.title,
      success: report.score.success,
      missionScore: report.score.total,
      grade: report.score.grade,
      deliveredGbit: mission.flight.deliveredGbit,
      targetGbit: report.fc.objective.dataTargetGbit,
    });
    setResult(r);
    setView('prompt');
  }, [report, mission.id]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!report || !mission.flight || !mission.plan) return null;
  const { fc, score, insights, totals, teamGoals } = report;
  const coord = coordination(mission.teamLog);
  const f = mission.flight;
  const launcher = getLauncher(mission.plan.launcherId);
  const archived = mission.stage === 'COMPLETE';

  return (
    <>
    <Panel
      className="wide-panel debrief"
      eyebrow={`Mission Debrief · ${mission.name} · ${difficultyDef(mission.difficulty).label}${mission.team ? ` · ${mission.team.name}` : ''}`}
      title={score.success ? 'Misión cumplida' : 'Objetivo no alcanzado'}
      aside={
        <span style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          {result && (
            <button className="btn btn--primary btn--sm" onClick={() => setView('report')}>
              📋 Mi informe
            </button>
          )}
          <span className={`grade grade--${score.grade}`} data-testid="grade">
            {score.grade}
          </span>
        </span>
      }
      footer={
        <>
          <span className="small">
            {archived ? 'Misión archivada.' : `Al archivar sumarás ${score.xp} XP${score.success ? '' : ' (parcial: sin éxito técnico)'}.`}
          </span>
          <span style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            <button className="btn btn--ghost" onClick={() => retry(false)}>
              Nuevo intento desde cero
            </button>
            <button className="btn" onClick={() => retry(true)}>
              Modificar este diseño y volver a volar
            </button>
            {!archived && (
              <button className="btn btn--primary" onClick={archive}>
                Archivar y sumar {score.xp} XP
              </button>
            )}
          </span>
        </>
      }
    >
      <div className="debrief-score">
        <div className="debrief-score__total">
          <span className="mono" data-testid="score-total">
            {score.total}
          </span>
          <span className="small muted">/ 100</span>
        </div>
        <ul className="criteria">
          {score.criteria.map((c) => (
            <li key={c.id}>
              <div className="criteria__head">
                <strong>{c.label}</strong>
                <span className="mono">
                  {fmtNum(c.points)} / {c.max}
                </span>
              </div>
              <Meter value={c.points / c.max} label={c.label} />
              <span className="small muted">{c.explanation}</span>
            </li>
          ))}
        </ul>
      </div>
      <p className="small muted">
        Éxito técnico = datos en Tierra ≥ objetivo ({fc.objective.dataTargetGbit.toLocaleString(numLocale())} Gbit). La puntuación mide la calidad de la ejecución, pero
        no convierte un fracaso técnico en éxito.
      </p>

      <div className="briefing-grid">
        <div>
          <h3 className="section-title">Objetivos y resultados científicos</h3>
          <dl className="kv">
            <dt>{fc.objective.title}</dt>
            <dd className={score.success ? 'ok' : 'bad'}>{score.success ? 'Cumplido' : 'No cumplido'}</dd>
            <dt>Datos en Tierra</dt>
            <dd>
              {fmtNum(f.deliveredGbit, 0)} / {fc.objective.dataTargetGbit.toLocaleString(numLocale())} Gbit
            </dd>
            <dt>Objetivo alcanzado</dt>
            <dd>{insights.daysToTarget !== null ? `día ${fmtNum(insights.daysToTarget, 1)}` : '—'}</dd>
            <dt>Cobertura de la superficie</dt>
            <dd>{Math.round(insights.coverage * 100)} %</dd>
            <dt>Valor científico</dt>
            <dd className="small" style={{ textAlign: 'right', whiteSpace: 'normal' }}>{score.success ? fc.objective.scienceValue : '—'}</dd>
          </dl>

          <h3 className="section-title">Datos y comunicaciones</h3>
          <dl className="kv">
            <dt>Generados / entregados / perdidos</dt>
            <dd>
              {fmtNum(f.generatedGbit, 0)} / {fmtNum(f.deliveredGbit, 0)} / {fmtNum(f.lostGbit, 0)} Gbit
            </dd>
            <dt>Eficiencia del enlace</dt>
            <dd>{f.generatedGbit ? Math.round((f.deliveredGbit / f.generatedGbit) * 100) : 0} %</dd>
          </dl>

          <h3 className="section-title">Energía</h3>
          <dl className="kv">
            <dt>Batería mínima</dt>
            <dd>{Math.round(f.minBatteryFraction * 100)} %</dd>
            <dt>Modo seguro / apagón</dt>
            <dd>
              {f.safeModeEntries} · {fmtNum(f.blackoutH)} h
            </dd>
          </dl>

          <h3 className="section-title">Masa, recursos y presupuesto</h3>
          <dl className="kv">
            <dt>Masa seca / húmeda</dt>
            <dd>
              {fmtNum(totals.massDryKg)} / {fmtNum(totals.massWetKg)} kg
            </dd>
            <dt>Propelente restante</dt>
            <dd>{fmtNum(f.propellantKg)} kg</dd>
            <dt>Lanzador</dt>
            <dd>{launcher?.name ?? '—'}</dd>
            {fc.budget.lines.map((l) => (
              <div key={l.id} style={{ display: 'contents' }}>
                <dt>{l.label}</dt>
                <dd>{l.amountMUSD === null ? '—' : formatMUSD(l.amountMUSD)}</dd>
              </div>
            ))}
            <dt>Costos de acontecimientos</dt>
            <dd>{formatMUSD(f.extraCostMUSD)}</dd>
            <dt>Total</dt>
            <dd className={score.spentMUSD > fc.template.budgetCapMUSD ? 'bad' : 'ok'}>
              {formatMUSD(score.spentMUSD)} / {fc.template.budgetCapMUSD} MUSD
            </dd>
          </dl>
        </div>

        <div>
          <h3 className="section-title">Acontecimientos vividos</h3>
          {f.eventHistory.length === 0 && <p className="small muted">Ninguno.</p>}
          <ul className="issues">
            {f.eventHistory.map((e) => (
              <li key={e.id} className={`issue ${e.rank === 1 ? 'issue--ok' : 'issue--optimization'}`}>
                <strong className="small">
                  Día {fmtNum(e.atH / 24, 1)} · {eventLabel(e.type)}
                </strong>
                <p className="small" style={{ margin: '4px 0 0' }}>
                  Decisión: {e.choiceLabel}{' '}
                  <span className={`badge ${e.rank === 1 ? 'badge--ok' : 'badge--soft'}`}>{e.rank === 1 ? 'mejor opción' : `opción ${e.rank} de ${e.optionCount}`}</span>
                </p>
              </li>
            ))}
          </ul>

          <h3 className="section-title">Decisiones acertadas</h3>
          <ul className="insights insights--good">
            {insights.good.map((g, k) => (
              <li key={k}>
                <strong>{g.text}</strong> <span className="small muted">{g.why}</span>
              </li>
            ))}
          </ul>
          <h3 className="section-title">Errores de diseño y operación</h3>
          {insights.errors.length === 0 && <p className="small muted">Ninguno detectado.</p>}
          <ul className="insights insights--bad">
            {insights.errors.map((g, k) => (
              <li key={k}>
                <strong>{g.text}</strong> <span className="small muted">{g.why}</span>
              </li>
            ))}
          </ul>
          <h3 className="section-title">Recomendaciones para el próximo intento</h3>
          {insights.recommendations.length === 0 && <p className="small muted">Diseño y operación sin cambios necesarios: prueba a abaratar la misión.</p>}
          <ul className="insights">
            {insights.recommendations.map((g, k) => (
              <li key={k}>
                <strong>{g.text}</strong> <span className="small muted">{g.why}</span>
              </li>
            ))}
          </ul>

          {mission.team && (
            <>
              <h3 className="section-title">Coordinación de {mission.team.name}</h3>
              <p className="small">
                <strong className="mono">{coord.index}/100</strong> — {coord.verdict}
              </p>
              <ul className="insights">
                {mission.team.members.map((m) => {
                  const g = teamGoals.find((x) => x.role === m.role)!;
                  return (
                    <li key={m.role}>
                      <strong>
                        {g.met ? '✓' : '✗'} {m.name} ({roleDef(m.role).label})
                      </strong>{' '}
                      <span className="small muted">
                        {g.goal}: {g.status}
                      </span>
                    </li>
                  );
                })}
              </ul>
              <p className="small muted">
                {coord.bestOptionShare !== null
                  ? `En los acontecimientos, el ${Math.round(coord.bestOptionShare * 100)} % de los votos fue a la opción que el motor preveía mejor: las decisiones del equipo cambiaron directamente los datos entregados.`
                  : 'Las decisiones votadas determinaron el diseño y el plan con los que voló la misión.'}
              </p>
            </>
          )}

          <h3 className="section-title">Misiones reales parecidas a la tuya</h3>
          <ul className="real-missions">
            {similarRealMissions(mission.objectiveId).map((m) => (
              <li key={m.id}>
                <strong className="small">
                  {m.name} · {m.agency}, {m.launchYear}
                </strong>
                <span className="small muted"> — {m.orbit.label}. Tu plan: {mission.plan!.altitudeKm} km, {mission.plan!.inclinationDeg}°.</span>
                <p className="small" style={{ margin: '2px 0' }}>{m.summary}</p>
                <p className="small muted" style={{ margin: 0 }}>
                  {m.lesson}{' '}
                  <a href={m.source.url} target="_blank" rel="noreferrer">
                    Fuente: {m.source.title}
                  </a>
                </p>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </Panel>
    {result && view === 'prompt' && <ReportPrompt player={player} success={result.outcome.success} onOpen={() => setView('report')} onLater={() => setView(null)} />}
    {result && view === 'report' && (
      <MissionReport
        result={result}
        totalBadges={totalBadges}
        onClose={() => setView(null)}
        onAchievements={() => {
          setView(null);
          navigate('achievements');
        }}
      />
    )}
    </>
  );
}
