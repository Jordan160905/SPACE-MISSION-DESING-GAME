/**
 * Nueva misión: asistente guiado en 6 pasos (escenario → modo de juego → dificultad → objetivo →
 * restricciones → recompensas). Cada paso muestra solo lo necesario para decidir y se anima al
 * avanzar o retroceder. Todos los valores salen de la plantilla de la misión ajustada a la
 * dificultad elegida (`applyDifficulty`), del catálogo de componentes y de los lanzadores reales:
 * no hay cifras escritas a mano en esta pantalla.
 */
import { useState, type ReactNode } from 'react';
import { getComponent } from '../../data/components/catalog';
import { applyDifficulty, DIFFICULTIES, difficultyDef, type Difficulty } from '../../data/difficulty';
import { LUNAR_LAUNCHERS } from '../../data/launchers/launchers';
import { getMissionTemplate } from '../../data/missions/missions';
import type { MissionTemplate, TeamRole } from '../../data/schemas';
import { eclipseFraction, GROUND_STATION_HOURS_PER_DAY, orbitalPeriodS } from '../../sim/OrbitSystem';
import { GRADE_THRESHOLDS, XP_PER_POINT_FAIL, XP_PER_POINT_SUCCESS } from '../../sim/ScoringSystem';
import { ROLES } from '../../sim/TeamSystem';
import { fmtNum } from '../../sim/units';
import { useGameStore } from '../../state/useGameStore';
import { Glossed } from '../components/Glossary';
import { Panel } from '../components/Panel';
import { numLocale } from '../../i18n/lang';

type Seat = { name: string; role: TeamRole };
const DEFAULT_SEATS: Seat[] = ROLES.map((r, i) => ({ name: `Integrante ${i + 1}`, role: r.id }));
const STEPS = ['Escenario', 'Modo de juego', 'Dificultad', 'Objetivo', 'Restricciones', 'Recompensas'] as const;
const TARGET_LABEL = { MOON: 'Órbita lunar', MARS: 'Marte', EARTH: 'Órbita terrestre' } as const;

// ─── Ilustraciones (originales, vectoriales) ───
function ScenarioArt() {
  return (
    <svg viewBox="0 0 320 150" className="wiz-art" role="img" aria-label="Ilustración: la Tierra, la Luna y la órbita de la nave">
      <defs>
        <radialGradient id="wz-earth" cx="40%" cy="35%">
          <stop offset="0%" stopColor="#5ab0ff" />
          <stop offset="100%" stopColor="#123a6b" />
        </radialGradient>
        <radialGradient id="wz-moon" cx="40%" cy="35%">
          <stop offset="0%" stopColor="#d7dbe2" />
          <stop offset="100%" stopColor="#6b7280" />
        </radialGradient>
      </defs>
      {[...Array(40)].map((_, i) => (
        <circle key={i} cx={(i * 73) % 320} cy={(i * 37) % 150} r={i % 5 === 0 ? 1.1 : 0.6} fill="#fff" opacity={0.5} />
      ))}
      <circle cx="52" cy="80" r="34" fill="url(#wz-earth)" />
      <path d="M86 78 C 150 30, 200 40, 236 66" fill="none" stroke="var(--accent)" strokeWidth="1.4" strokeDasharray="5 4" className="wiz-art__path" />
      <circle cx="252" cy="78" r="22" fill="url(#wz-moon)" />
      <ellipse cx="252" cy="78" rx="12" ry="33" fill="none" stroke="var(--signal)" strokeWidth="1.2" />
      <circle cx="252" cy="45" r="3" fill="var(--signal)" className="wiz-art__sat" />
      <text x="52" y="134" textAnchor="middle" fontSize="10" fill="var(--text-md)">Tierra</text>
      <text x="252" y="134" textAnchor="middle" fontSize="10" fill="var(--text-md)">Luna · órbita polar</text>
    </svg>
  );
}
const SoloArt = () => (
  <svg viewBox="0 0 80 60" className="wiz-icon" aria-hidden="true">
    <circle cx="40" cy="20" r="10" fill="none" stroke="currentColor" strokeWidth="2.5" />
    <path d="M22 54 C 24 38, 56 38, 58 54" fill="none" stroke="currentColor" strokeWidth="2.5" />
    <path d="M60 14 l6 -6 M64 22 h8" stroke="var(--signal)" strokeWidth="2" />
  </svg>
);
const TeamArt = () => (
  <svg viewBox="0 0 80 60" className="wiz-icon" aria-hidden="true">
    {[14, 31, 49, 66].map((x, i) => (
      <g key={x} opacity={i % 3 === 0 ? 0.75 : 1}>
        <circle cx={x} cy={i % 3 === 0 ? 24 : 18} r="7" fill="none" stroke="currentColor" strokeWidth="2.2" />
        <path d={`M${x - 10} ${54} C ${x - 9} ${i % 3 === 0 ? 38 : 32}, ${x + 9} ${i % 3 === 0 ? 38 : 32}, ${x + 10} 54`} fill="none" stroke="currentColor" strokeWidth="2.2" />
      </g>
    ))}
  </svg>
);
function Gauge({ level }: { level: number }) {
  return (
    <svg viewBox="0 0 60 34" className="wiz-gauge" aria-hidden="true">
      <path d="M6 30 A 24 24 0 0 1 54 30" fill="none" stroke="var(--line-strong)" strokeWidth="5" />
      <path d="M6 30 A 24 24 0 0 1 54 30" fill="none" stroke="var(--accent)" strokeWidth="5" strokeDasharray={`${(level / 3) * 75} 200`} />
      <line x1="30" y1="30" x2={30 + 20 * Math.cos(Math.PI - (level / 3) * Math.PI)} y2={30 - 20 * Math.sin(Math.PI - (level / 3) * Math.PI)} stroke="var(--text-hi)" strokeWidth="2" />
    </svg>
  );
}
const Medal = ({ label }: { label: string }) => (
  <svg viewBox="0 0 48 56" className="wiz-medal" aria-hidden="true">
    <path d="M14 0 L24 18 L34 0" fill="none" stroke="var(--accent)" strokeWidth="5" />
    <circle cx="24" cy="34" r="17" fill="var(--surface-2)" stroke="var(--signal)" strokeWidth="3" />
    <text x="24" y="40" textAnchor="middle" fontSize="15" fontWeight="700" fill="var(--signal)">
      {label}
    </text>
  </svg>
);

function Card({ title, value, children, icon }: { title: string; value?: ReactNode; children?: ReactNode; icon?: ReactNode }) {
  return (
    <div className="wiz-card">
      <div className="wiz-card__head">
        {icon}
        <span className="eyebrow">{title}</span>
      </div>
      {value !== undefined && <div className="wiz-card__value">{value}</div>}
      {children && <div className="small wiz-card__text">{children}</div>}
    </div>
  );
}

export function BriefingScreen() {
  const templateId = useGameStore((s) => s.briefingTemplateId);
  const accept = useGameStore((s) => s.acceptMission);
  const navigate = useGameStore((s) => s.navigate);
  const openSelect = useGameStore((s) => s.openMissionSelect);
  const [step, setStep] = useState(0);
  const [dir, setDir] = useState<'fwd' | 'back'>('fwd');
  const [mode, setMode] = useState<'solo' | 'team' | null>(null);
  const [difficulty, setDifficulty] = useState<Difficulty | null>(null);
  const [objectiveId, setObjectiveId] = useState<string | null>(null);
  const [teamName, setTeamName] = useState('Equipo Artemisa');
  const [pilotName, setPilotName] = useState('');
  const [seats, setSeats] = useState<Seat[]>(DEFAULT_SEATS.slice(0, 2));
  const base = templateId ? getMissionTemplate(templateId) : undefined;
  const template: MissionTemplate | undefined = base && applyDifficulty(base, difficulty ?? 'engineer');
  const rolesOk = new Set(seats.map((x) => x.role)).size === seats.length && seats.every((x) => x.name.trim());

  if (!template || !base) {
    return (
      <Panel className="side-panel" title="Sin escenario" onClose={() => navigate('center')}>
        <p className="muted">No hay ninguna misión seleccionada.</p>
      </Panel>
    );
  }

  const objective = template.objectives.find((o) => o.id === objectiveId);
  const canNext = [true, (mode === 'solo' && pilotName.trim().length > 0) || (mode === 'team' && rolesOk), difficulty !== null, objective !== undefined, true, true][step];
  const blockedWhy = [
    '',
    mode === null ? 'Elige cómo vais a jugar.' : mode === 'solo' ? 'Escribe tu nombre para continuar.' : 'Cada integrante necesita un nombre y un rol distinto.',
    'Elige una dificultad.',
    'Elige el objetivo científico.',
    '',
    '',
  ][step];
  const go = (to: number) => {
    setDir(to > step ? 'fwd' : 'back');
    setStep(to);
  };
  const start = () => {
    if (!objectiveId || !difficulty || !mode) return;
    accept(objectiveId, {
      difficulty,
      team: mode === 'team' ? { name: teamName.trim() || 'Equipo', members: seats.map((x) => ({ name: x.name.trim(), role: x.role })) } : null,
      pilotName: mode === 'solo' ? pilotName.trim() : null,
    });
    navigate('center');
  };

  return (
    <Panel
      className="wide-panel wizard"
      eyebrow={`Nueva misión · ${template.code}`}
      title={template.name}
      onClose={() => navigate('center')}
      tabs={
        <ol className="wiz-steps" aria-label="Pasos para crear la misión">
          {STEPS.map((s, i) => (
            <li key={s} className={`wiz-step ${i < step ? 'wiz-step--done' : ''}`} aria-current={i === step ? 'step' : undefined}>
              <span className="wiz-step__n">{i < step ? '✓' : i + 1}</span>
              <span className="wiz-step__label">{s}</span>
            </li>
          ))}
        </ol>
      }
      footer={
        <>
          <button
            className="btn btn--ghost"
            onClick={() => {
              if (step === 0) {
                navigate('center');
                openSelect(true);
              } else go(step - 1);
            }}
          >
            ← Volver
          </button>
          <span className="small muted wiz-why" aria-live="polite">
            {!canNext ? blockedWhy : `Paso ${step + 1} de ${STEPS.length}`}
          </span>
          {step < STEPS.length - 1 ? (
            <button className="btn btn--primary" disabled={!canNext} onClick={() => go(step + 1)}>
              Siguiente →
            </button>
          ) : (
            <button className="btn btn--primary btn--glow" onClick={start}>
              Comenzar diseño →
            </button>
          )}
        </>
      }
    >
      <div key={step} className={`wiz-page wiz-page--${dir}`}>
        {step === 0 && (
          <div className="wiz-scenario">
            <ScenarioArt />
            <div>
              <h3 className="wiz-h">{base.tagline}</h3>
              <p>
                <Glossed text={base.scenario} />
              </p>
              <div className="wiz-cards">
                <Card title="Entorno" value={TARGET_LABEL[base.target]}>
                  La Luna no tiene aire: el calor se gana o se pierde por radiación y hay un eclipse en cada vuelta.
                </Card>
                <Card title="Campaña" value={`${base.durationDays} días`}>
                  Tiempo de observación desde la órbita.
                </Card>
                <Card title="Tu nave" value="Orbitador pequeño">
                  Diseñarás, lanzarás y operarás un satélite que dará vueltas a la Luna.
                </Card>
              </div>
              {base.inspiration && (
                <p className="small muted">
                  <Glossed text={base.inspiration} />
                </p>
              )}
            </div>
          </div>
        )}

        {step === 1 && (
          <>
            <h3 className="wiz-h">¿Cómo vais a jugar?</h3>
            <div className="wiz-options" role="radiogroup" aria-label="Modo de juego">
              <button role="radio" aria-checked={mode === 'solo'} className="wiz-option" onClick={() => setMode('solo')}>
                <SoloArt />
                <strong>Jugar individual</strong>
                <span className="small">Diseñas y diriges toda la misión tú solo: cada decisión es tuya.</span>
              </button>
              <button role="radio" aria-checked={mode === 'team'} className="wiz-option" onClick={() => setMode('team')}>
                <TeamArt />
                <strong>Jugar en equipo</strong>
                <span className="small">De 2 a 4 personas en esta computadora. Cada una tiene un rol y las decisiones importantes se votan.</span>
              </button>
            </div>
            {mode === 'solo' && (
              <div className="team-setup wiz-reveal">
                <label className="field">
                  <span className="small">¿Cómo te llamas, comandante?</span>
                  <input value={pilotName} maxLength={30} autoFocus placeholder="Escribe tu nombre" onChange={(e) => setPilotName(e.target.value)} aria-label="Tu nombre" />
                </label>
                <p className="small muted">Tu nombre aparecerá en tus logros y en la clasificación.</p>
              </div>
            )}
            {mode === 'team' && (
              <div className="team-setup wiz-reveal">
                <label className="field">
                  <span className="small">Nombre del equipo</span>
                  <input value={teamName} maxLength={40} onChange={(e) => setTeamName(e.target.value)} aria-label="Nombre del equipo" />
                </label>
                {seats.map((seat, i) => (
                  <div key={i} className="team-seat">
                    <input
                      value={seat.name}
                      maxLength={30}
                      aria-label={`Nombre del integrante ${i + 1}`}
                      onChange={(e) => setSeats(seats.map((x, j) => (j === i ? { ...x, name: e.target.value } : x)))}
                    />
                    <select
                      value={seat.role}
                      aria-label={`Rol del integrante ${i + 1}`}
                      onChange={(e) => setSeats(seats.map((x, j) => (j === i ? { ...x, role: e.target.value as TeamRole } : x)))}
                    >
                      {ROLES.map((r) => (
                        <option key={r.id} value={r.id}>
                          {r.label}
                        </option>
                      ))}
                    </select>
                    {seats.length > 2 && (
                      <button className="btn btn--ghost btn--sm" onClick={() => setSeats(seats.filter((_, j) => j !== i))} aria-label={`Quitar integrante ${i + 1}`}>
                        ✕
                      </button>
                    )}
                  </div>
                ))}
                {seats.length < 4 && (
                  <button
                    className="btn btn--sm"
                    onClick={() => {
                      const free = ROLES.find((r) => !seats.some((x) => x.role === r.id))!;
                      setSeats([...seats, { name: `Integrante ${seats.length + 1}`, role: free.id }]);
                    }}
                  >
                    + Añadir integrante
                  </button>
                )}
                {!rolesOk && <p className="small bad">Cada integrante necesita un nombre y un rol distinto.</p>}
                <ul className="small role-list">
                  {ROLES.filter((r) => seats.some((x) => x.role === r.id)).map((r) => (
                    <li key={r.id}>
                      <strong>{r.label}:</strong> {r.priority}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </>
        )}

        {step === 2 && (
          <>
            <h3 className="wiz-h">Elige la dificultad</h3>
            <p className="small muted">Cambia de verdad los parámetros de la misión: presupuesto, meses de desarrollo, datos exigidos y piezas disponibles.</p>
            <div className="wiz-options wiz-options--3" role="radiogroup" aria-label="Dificultad">
              {DIFFICULTIES.filter((d) => d.id !== 'sandbox').map((d, i) => {
                const t = applyDifficulty(base, d.id);
                return (
                  <button key={d.id} role="radio" aria-checked={difficulty === d.id} className="wiz-option" onClick={() => setDifficulty(d.id)}>
                    <Gauge level={i + 1} />
                    <strong>
                      {d.label} <span className="muted small">· {d.persona}</span>
                    </strong>
                    <span className="small">{d.summary}</span>
                    <dl className="kv small">
                      <dt>Presupuesto</dt>
                      <dd>{t.budgetCapMUSD} MUSD</dd>
                      <dt>Desarrollo</dt>
                      <dd>{t.developmentMonths} meses</dd>
                      <dt>Datos (objetivo 1)</dt>
                      <dd>{t.objectives[0].dataTargetGbit.toLocaleString(numLocale())} Gbit</dd>
                      <dt>Piezas</dt>
                      <dd>{d.allowAdvanced ? 'simples y avanzadas' : 'solo simples'}</dd>
                    </dl>
                  </button>
                );
              })}
            </div>
            {(() => {
              const sb = difficultyDef('sandbox');
              return (
                <button role="radio" aria-checked={difficulty === 'sandbox'} className="wiz-sandbox" onClick={() => setDifficulty('sandbox')}>
                  <strong>Modo libre (Sandbox)</strong> <span className="small muted">— {sb.summary}</span>
                </button>
              );
            })()}
          </>
        )}

        {step === 3 && (
          <>
            <h3 className="wiz-h">¿Qué quieres descubrir?</h3>
            <div className="wiz-options wiz-options--3" role="radiogroup" aria-label="Objetivo científico">
              {template.objectives.map((o) => {
                const inst = getComponent(o.primaryInstrumentId);
                return (
                  <button key={o.id} role="radio" aria-checked={objectiveId === o.id} className="wiz-option" onClick={() => setObjectiveId(o.id)}>
                    <strong>{o.title}</strong>
                    <span className="small">{o.summary}</span>
                    <span className="small muted">
                      {inst?.name} · {o.dataTargetGbit.toLocaleString(numLocale())} Gbit
                    </span>
                  </button>
                );
              })}
            </div>
            {objective && (
              <ObjectiveExplainer key={objective.id} template={template} objectiveId={objective.id} />
            )}
          </>
        )}

        {step === 4 && objective && <Constraints template={template} objectiveId={objective.id} difficulty={difficulty ?? 'engineer'} />}

        {step === 5 && <Rewards template={template} base={base} difficulty={difficulty ?? 'engineer'} />}
      </div>
    </Panel>
  );
}

function ObjectiveExplainer({ template, objectiveId }: { template: MissionTemplate; objectiveId: string }) {
  const o = template.objectives.find((x) => x.id === objectiveId)!;
  const inst = getComponent(o.primaryInstrumentId);
  const reqs = inst?.requires.map((id) => getComponent(id)?.name ?? id) ?? [];
  return (
    <div className="wiz-explainer wiz-reveal">
      <div className="wiz-cards">
        <Card title="Por qué importa">
          <Glossed text={o.scienceValue} />
        </Card>
        <Card title="Qué necesitará tu nave">
          <Glossed text={`Instrumento: ${inst?.name.toLowerCase()}${reqs.length ? `. Para funcionar necesita ${reqs.join(' y ').toLowerCase()}` : ''}. ${inst?.engineeringNote ?? ''}`} />
        </Card>
        <Card title="Dónde volar">
          <Glossed text={o.recommendedOrbit.rationale} />
        </Card>
      </div>
      <p className="small muted">Pasa el cursor (o toca) las palabras subrayadas para ver qué significan.</p>
    </div>
  );
}

function Constraints({ template, objectiveId, difficulty }: { template: MissionTemplate; objectiveId: string; difficulty: Difficulty }) {
  const o = template.objectives.find((x) => x.id === objectiveId)!;
  const inst = getComponent(o.primaryInstrumentId)!;
  const [h0, h1] = o.recommendedOrbit.altitudeKm;
  const [i0, i1] = o.recommendedOrbit.inclinationDeg;
  const hMid = (h0 + h1) / 2;
  const eclMin = (eclipseFraction(hMid) * orbitalPeriodS(hMid)) / 60;
  const d = difficultyDef(difficulty);
  return (
    <>
      <h3 className="wiz-h">Las reglas de tu misión</h3>
      <p className="small muted">
        Son los límites reales con los que el juego evaluará tu diseño. Las <strong>obligatorias</strong> hacen inviable la misión si no se cumplen; las{' '}
        <strong>recomendadas</strong> dan puntos y seguridad.
      </p>
      <div className="wiz-cards wiz-cards--grid">
        <Card title="Presupuesto máximo" value={`${template.budgetCapMUSD} MUSD`}>
          <Glossed text="Incluye construir la nave, el cohete y la operación diaria." />
          <span className="muted"> Operar cuesta {fmtNum(template.opsCostPerDayMUSD, 2)} MUSD por día.</span>
        </Card>
        <Card title="Masa máxima" value="La del cohete">
          <Glossed text="La masa de la nave (con combustible y un 10 % de margen) no puede superar lo que el cohete lleva a la Luna:" />
          <ul className="wiz-list">
            {LUNAR_LAUNCHERS.map((l) => (
              <li key={l.id}>
                {l.name}: {l.payloadToTLIKg.toLocaleString(numLocale())} kg · {fmtNum(l.costMUSD ?? 0, 1)} MUSD
              </li>
            ))}
          </ul>
        </Card>
        <Card title="Energía" value="Balance positivo">
          <Glossed text={`Los paneles deben recargar en cada vuelta lo que la batería gasta en el eclipse (unos ${Math.round(eclMin)} minutos a ${hMid} km).`} />
        </Card>
        <Card title="Comunicación" value={`${GROUND_STATION_HOURS_PER_DAY} h al día`}>
          <Glossed text="La estación terrestre solo te atiende unas horas al día: el enlace debe enviar los datos a tiempo y la memoria guardarlos mientras." />
        </Card>
        <Card title="Órbita" value={`${h0}–${h1} km · ${i0}–${Math.min(90, i1)}°`}>
          <Glossed text={o.recommendedOrbit.rationale} />
        </Card>
        <Card title="Instrumento obligatorio" value={inst.name}>
          Consume {inst.powerDrawW} W, pesa {inst.massKg} kg y produce {fmtNum(inst.dataGenGbitPerH, 1)} Gbit por hora.
          {inst.requires.length > 0 && <> Necesita: {inst.requires.map((id) => getComponent(id)?.name).join(', ')}.</>}
        </Card>
        <Card title="Datos a devolver" value={`${o.dataTargetGbit.toLocaleString(numLocale())} Gbit`}>
          <Glossed text={`Deben llegar a la Tierra en los ${template.durationDays} días de campaña.`} />
        </Card>
        <Card title="Tiempo de desarrollo" value={`${template.developmentMonths} meses`}>
          Lo que tardes en construir y probar la nave debe caber antes de la ventana de lanzamiento. Las piezas nuevas tardan más.
        </Card>
        {!d.allowAdvanced && (
          <Card title="Piezas" value="Solo simples">
            En el nivel {d.label} solo puedes usar componentes de gama simple.
          </Card>
        )}
      </div>
      <p className="eyebrow" style={{ marginTop: 14 }}>
        Lista de comprobación de la misión
      </p>
      {template.constraints.map((c) => (
        <div key={c.id} className="constraint">
          <span className={`badge ${c.severity === 'hard' ? 'badge--hard' : 'badge--soft'}`}>{c.severity === 'hard' ? 'Obligatoria' : 'Recomendada'}</span>
          <span>
            <strong>{c.label}</strong>
            <br />
            <span className="muted">
              <Glossed text={c.description} />
            </span>
          </span>
        </div>
      ))}
    </>
  );
}

function Rewards({ template, base, difficulty }: { template: MissionTemplate; base: MissionTemplate; difficulty: Difficulty }) {
  const d = difficultyDef(difficulty);
  const unlock = template.rewards.unlocks.map((id) => getMissionTemplate(id)).filter(Boolean);
  return (
    <>
      <h3 className="wiz-h">Lo que puedes ganar</h3>
      <div className="wiz-rewards">
        <div className="wiz-reward wiz-reward--xp">
          <span className="wiz-reward__big">{template.rewards.xp}</span>
          <span className="eyebrow">XP de agencia</span>
          <span className="small">
            Base de la misión si devuelves los datos prometidos, más {XP_PER_POINT_SUCCESS} XP por cada punto de la nota final.
            {d.xpFactor !== 1 && ` Nivel ${d.label}: ×${fmtNum(d.xpFactor, 2)} (base ${base.rewards.xp}).`}
          </span>
        </div>
        <div className="wiz-reward">
          <div className="wiz-medals">
            {GRADE_THRESHOLDS.map(([g]) => (
              <Medal key={g} label={g} />
            ))}
          </div>
          <span className="eyebrow">Calificación por desempeño</span>
          <span className="small">
            {GRADE_THRESHOLDS.map(([g, min]) => `${g} ≥ ${min}`).join(' · ')} puntos. La nota suma ciencia (40), presupuesto (15), energía (15), datos (10) y decisiones (20).
          </span>
        </div>
        <div className="wiz-reward">
          <svg viewBox="0 0 40 40" className="wiz-reward__icon" aria-hidden="true">
            <rect x="9" y="18" width="22" height="16" rx="2" fill="none" stroke="var(--accent)" strokeWidth="2.5" />
            <path d="M14 18 v-5 a6 6 0 0 1 12 0" fill="none" stroke="var(--accent)" strokeWidth="2.5" />
          </svg>
          <span className="eyebrow">Desbloqueo</span>
          <span className="small">
            {unlock.length
              ? `Si la misión tiene éxito se desbloquea ${unlock.map((t) => `${t!.code} · ${t!.name}`).join(', ')}.`
              : d.id === 'sandbox'
                ? 'El modo libre no desbloquea misiones ni suma XP.'
                : 'Esta misión no desbloquea otras.'}
          </span>
        </div>
        <div className="wiz-reward">
          <svg viewBox="0 0 40 40" className="wiz-reward__icon" aria-hidden="true">
            <path d="M12 6 h16 v8 a8 8 0 0 1 -16 0 z M12 9 h-5 a5 5 0 0 0 5 7 M28 9 h5 a5 5 0 0 1 -5 7 M20 22 v7 M13 34 h14" fill="none" stroke="var(--signal)" strokeWidth="2.5" />
          </svg>
          <span className="eyebrow">Clasificación</span>
          <span className="small">{d.ranked ? 'Al archivar la misión entras en la clasificación del Archivo, junto a otros equipos con el mismo objetivo.' : 'El modo libre no entra en la clasificación.'}</span>
        </div>
      </div>
      <p className="small muted">
        <strong>Cómo se consigue:</strong> la misión tiene éxito si llegan a la Tierra los datos científicos prometidos. Si no lo consigues, recibes solo {fmtNum(XP_PER_POINT_FAIL, 1)} XP por punto
        de la nota. Al final, el informe explica por qué salió bien o mal.
      </p>
    </>
  );
}
