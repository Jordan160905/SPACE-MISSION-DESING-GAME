/**
 * Minijuego de aterrizaje lunar (Fase 8.8, versión ágil): interfaz e indicadores.
 * El centro de la pantalla queda libre para la escena 3D (módulo, terreno, zona segura).
 * Mandos: mantener ESPACIO (o W) = motor; flechas = mover el módulo (al soltarlas se endereza solo); P = pausa.
 */
import { useEffect, useMemo, useRef, useState, type PointerEvent as RPointerEvent } from 'react';
import { landerReadout, LANDER, landingAdvice, landingPoints, LIMITS, NO_LANDER_INPUT, type LanderInput, type Touchdown } from '../../sim/Lander';
import { getTerrain, TERRAIN } from '../../sim/LunarTerrain';
import { fmtNum } from '../../sim/units';
import { useGameStore } from '../../state/useGameStore';
import { NpcAvatar } from '../review/ReviewArt';
import { useSurface, type LandingCam } from './surfaceStore';

type Ctl = 'engine' | 'fwd' | 'back' | 'left' | 'right';
const KEYS: Record<string, Ctl> = { Space: 'engine', KeyW: 'engine', ArrowUp: 'fwd', ArrowDown: 'back', ArrowLeft: 'left', ArrowRight: 'right' };

const OUTCOME_TITLE: Record<Touchdown['outcome'], string> = {
  perfect: '¡Alunizaje perfecto en la zona segura!',
  ok: '¡Alunizaje conseguido!',
  crash: 'El módulo golpeó el suelo demasiado rápido',
  tipped: 'El módulo volcó al tocar el suelo',
  rock: 'Una pata cayó sobre una roca',
  away: 'El módulo se alejó de la zona de aterrizaje',
};

const CAMS: Array<{ id: LandingCam; label: string }> = [
  { id: 'chase', label: 'Persecución' },
  { id: 'ground', label: 'Desde el suelo' },
  { id: 'top', label: 'Desde arriba' },
];

function Hold({ ctl, label, title, held, set, className = '' }: { ctl: Ctl; label: string; title: string; held: Record<string, boolean>; set: (c: Ctl, v: boolean) => void; className?: string }) {
  const on = (e: RPointerEvent<HTMLButtonElement>) => {
    e.currentTarget.setPointerCapture(e.pointerId);
    set(ctl, true);
  };
  const off = () => set(ctl, false);
  return (
    <button className={`sf-pad ${held[ctl] ? 'sf-pad--on' : ''} ${className}`} onPointerDown={on} onPointerUp={off} onPointerCancel={off} onLostPointerCapture={off} title={title} aria-label={title} aria-pressed={!!held[ctl]}>
      {label}
    </button>
  );
}

/** Indicador de orientación (horizonte artificial) e inclinación. */
function Attitude({ pitch, roll, tilt }: { pitch: number; roll: number; tilt: number }) {
  // Vista desde detrás del módulo: inclinar adelante baja el horizonte; a la derecha lo gira.
  const shift = Math.max(-40, Math.min(40, pitch * 1.6));
  const ok = tilt <= LIMITS.tiltDeg;
  return (
    <svg viewBox="0 0 120 120" className="ld-att" role="img" aria-label={`Orientación: inclinación ${fmtNum(tilt, 0)}°, adelante ${fmtNum(pitch, 0)}°, lado ${fmtNum(roll, 0)}°`}>
      <defs>
        <clipPath id="ld-att-clip">
          <circle cx={60} cy={60} r={52} />
        </clipPath>
      </defs>
      <g clipPath="url(#ld-att-clip)">
        <g transform={`rotate(${-roll} 60 60) translate(0 ${shift})`}>
          <rect x={-60} y={-100} width={240} height={160} className="ld-att__sky" />
          <rect x={-60} y={60} width={240} height={160} className="ld-att__ground" />
          <line x1={-60} x2={180} y1={60} y2={60} className="ld-att__horizon" />
          {[-20, -10, 10, 20].map((d) => (
            <line key={d} x1={45} x2={75} y1={60 - d * 1.6} y2={60 - d * 1.6} className="ld-att__tick" />
          ))}
        </g>
      </g>
      <circle cx={60} cy={60} r={52} className={`ld-att__ring ${ok ? 'ok' : 'bad'}`} />
      <path d="M36 60 H52 L60 68 L68 60 H84" className="ld-att__mark" />
    </svg>
  );
}

/** Indicador de inclinación: arco 0–35° con la zona permitida en verde. */
function TiltGauge({ tilt }: { tilt: number }) {
  const max = LANDER.maxTilt;
  const ang = (v: number) => Math.PI + (Math.min(v, max) / max) * Math.PI;
  const p = (v: number, r: number) => [60 + r * Math.cos(ang(v)), 62 + r * Math.sin(ang(v))];
  const [x0, y0] = p(0, 44);
  const [xl, yl] = p(LIMITS.tiltDeg, 44);
  const [x1, y1] = p(max, 44);
  const [nx, ny] = p(tilt, 38);
  return (
    <svg viewBox="0 0 120 70" className="ld-gauge" role="img" aria-label={`Inclinación ${fmtNum(tilt, 0)}°; límite ${LIMITS.tiltDeg}°`}>
      <path d={`M${x0} ${y0} A44 44 0 0 1 ${xl} ${yl}`} className="ld-gauge__ok" />
      <path d={`M${xl} ${yl} A44 44 0 0 1 ${x1} ${y1}`} className="ld-gauge__bad" />
      <line x1={60} y1={62} x2={nx} y2={ny} className="ld-gauge__needle" />
      <circle cx={60} cy={62} r={4} className="ld-gauge__hub" />
      <text x={60} y={50} textAnchor="middle" className="ld-gauge__val">{`${fmtNum(tilt, 0)}°`}</text>
    </svg>
  );
}

/** Zona segura vista desde arriba (arriba = adelante, como la cámara de persecución). */
function SafeRadar({ dx, dz, groundOk }: { dx: number; dz: number; groundOk: boolean }) {
  const d = Math.hypot(dx, dz);
  const scale = (m: number) => (52 * Math.log10(1 + m / 5)) / Math.log10(1 + 1000 / 5);
  const k = d > 0 ? scale(d) / d : 0;
  const sx = 60 + dz * k;
  const sy = 60 - dx * k;
  const zr = Math.max(5, scale(Math.max(1, d)) - scale(Math.max(0, d - TERRAIN.safe.r)));
  return (
    <svg viewBox="0 0 120 120" className="ld-radar" role="img" aria-label={`Zona segura a ${fmtNum(d, 0)} m`}>
      <circle cx={60} cy={60} r={56} className="ld-radar__bg" />
      {[10, 100, 500].map((m) => (
        <circle key={m} cx={60} cy={60} r={scale(m)} className="ld-radar__ring" />
      ))}
      <circle cx={sx} cy={sy} r={d < TERRAIN.safe.r ? scale(TERRAIN.safe.r) : zr} className="ld-radar__zone" />
      <line x1={60} y1={60} x2={sx} y2={sy} className="ld-radar__line" />
      <circle cx={60} cy={60} r={4} className={groundOk ? 'ld-radar__me ok' : 'ld-radar__me bad'} />
      <text x={60} y={116} textAnchor="middle" className="ld-radar__label">
        ↑ adelante
      </text>
    </svg>
  );
}

function Briefing({ onStart, label, onSkip, skipLabel }: { onStart: () => void; label: string; onSkip?: () => void; skipLabel?: string }) {
  const practice = useSurface((s) => s.practice);
  return (
    <div className="sf-overlay" role="dialog" aria-modal="true" aria-labelledby="ld-brief-title">
      <div className="sf-card ld-brief">
        <p className="eyebrow">{practice ? 'Práctica · Descenso a la Luna' : 'Minijuego · Descenso a la Luna'}</p>
        <h2 className="h2" id="ld-brief-title">
          Aterriza el módulo de descenso
        </h2>
        <div className="fev__msg">
          <NpcAvatar mood="happy" />
          <p className="fev__bubble">
            <strong>Centro de control:</strong> Estamos a 350 m sobre la Luna. Lleva el módulo a la zona verde y apóyalo con suavidad. ¡Tú pilotas!
          </p>
        </div>
        <div className="ld-steps">
          <div className="ld-step">
            <span className="ld-step__icon" aria-hidden="true">
              🔥
            </span>
            <strong>Mantén ESPACIO</strong>
            <span className="small">El motor frena la caída. Suéltalo y vuelves a bajar.</span>
          </div>
          <div className="ld-step">
            <span className="ld-step__icon" aria-hidden="true">
              ⬅️➡️
            </span>
            <strong>Flechas para moverte</strong>
            <span className="small">Lleva el módulo hasta la zona verde. Al soltarlas se endereza solo.</span>
          </div>
          <div className="ld-step">
            <span className="ld-step__icon" aria-hidden="true">
              🟢
            </span>
            <strong>Toca el suelo despacio</strong>
            <span className="small">{`Cuando el velocímetro esté en verde (menos de ${LIMITS.verticalMS} m/s), ¡aterrizas!`}</span>
          </div>
        </div>
        <p className="small muted">La Luna atrae con 1,62 m/s², seis veces menos que la Tierra, y no hay aire que frene. P = pausa.</p>
        <div className="ld-result__actions">
          <button className="btn btn--primary" onClick={onStart}>
            {label}
          </button>
          {onSkip && (
            <button className="btn btn--ghost" onClick={onSkip}>
              {skipLabel}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

function Metric({ label, value, limit, ok }: { label: string; value: string; limit: string; ok: boolean }) {
  return (
    <tr className={ok ? 'ok' : 'bad'}>
      <th scope="row">{label}</th>
      <td className="mono">{value}</td>
      <td className="mono">{limit}</td>
      <td aria-label={ok ? 'Bien' : 'Fuera del límite'}>{ok ? '✓' : '✗'}</td>
    </tr>
  );
}

function Result({ td, attempts, onRetry, onRover, onLeave, onHelp, practice }: { td: Touchdown; attempts: number; onRetry: () => void; onRover: () => void; onLeave: () => void; onHelp: () => void; practice: boolean }) {
  const advice = landingAdvice(td);
  return (
    <div className="sf-overlay" role="dialog" aria-modal="true" aria-labelledby="ld-res-title">
      <div className={`sf-card ld-result ${td.success ? 'ld-result--ok' : 'ld-result--bad'}`}>
        <p className="eyebrow">{td.success ? `Aterrizaje · intento ${attempts}` : `Intento ${attempts} · no conseguido`}</p>
        <h2 className="h2" id="ld-res-title">
          {OUTCOME_TITLE[td.outcome]}
        </h2>
        {td.success && <p className="ld-result__pts mono">{`+${landingPoints(td)} puntos`}</p>}
        <table className="ld-table">
          <thead>
            <tr>
              <th scope="col">Medida</th>
              <th scope="col">Tu aterrizaje</th>
              <th scope="col">Límite</th>
              <th scope="col">
                <span className="sr-only">Resultado</span>
              </th>
            </tr>
          </thead>
          <tbody>
            <Metric label="Velocidad de bajada" value={`${fmtNum(td.verticalMS, 1)} m/s`} limit={`≤ ${LIMITS.verticalMS} m/s`} ok={td.verticalMS <= LIMITS.verticalMS} />
            <Metric label="Velocidad de lado" value={`${fmtNum(td.horizontalMS, 1)} m/s`} limit={`≤ ${LIMITS.horizontalMS} m/s`} ok={td.horizontalMS <= LIMITS.horizontalMS} />
            <Metric label="Inclinación" value={`${fmtNum(td.tiltDeg, 0)}°`} limit={`≤ ${LIMITS.tiltDeg}°`} ok={td.tiltDeg <= LIMITS.tiltDeg} />
            <Metric label="Pendiente del suelo" value={`${fmtNum(td.slopeDeg, 0)}°`} limit={`≤ ${LIMITS.slopeDeg}°`} ok={td.slopeDeg <= LIMITS.slopeDeg} />
            <Metric label="Rocas bajo las patas" value={td.rock ? 'Sí' : 'No'} limit="No" ok={!td.rock} />
            <Metric label="Distancia a la zona verde" value={`${fmtNum(td.distanceToSafeM, 0)} m`} limit={`≤ ${TERRAIN.safe.r} m`} ok={td.inSafe} />
          </tbody>
        </table>
        <h3 className="section-title">{td.success ? 'Comentarios' : 'Qué mejorar'}</h3>
        <ul className="small ld-advice">
          {advice.map((a) => (
            <li key={a}>{a}</li>
          ))}
        </ul>
        <div className="ld-result__actions">
          {td.success ? (
            <>
              <button className="btn btn--primary" onClick={onRover}>
                Explorar con el rover →
              </button>
              <button className="btn" onClick={onRetry}>
                Repetir el aterrizaje
              </button>
              <button className="btn btn--ghost" onClick={onLeave}>
                {practice ? 'Volver al control del vuelo' : 'Volver a la órbita sin explorar'}
              </button>
            </>
          ) : (
            <>
              <button className="btn btn--primary" onClick={onRetry}>
                Intentarlo otra vez
              </button>
              <button className="btn" onClick={onHelp}>
                Ver los mandos
              </button>
              <button className="btn btn--ghost" onClick={onLeave}>
                {practice ? 'Volver al control del vuelo' : 'Dejarlo y volver a la órbita'}
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

export function LandingGame() {
  const phase = useSurface((s) => s.phase);
  const lander = useSurface((s) => s.lander);
  const history = useSurface((s) => s.history);
  const attempt = useSurface((s) => s.attempt);
  const cam = useSurface((s) => s.landingCam);
  const setCam = useSurface((s) => s.setLandingCam);
  const begin = useSurface((s) => s.beginDescent);
  const setPaused = useSurface((s) => s.setPaused);
  const endCinematic = useSurface((s) => s.endCinematic);
  const retry = useSurface((s) => s.retryLanding);
  const startRover = useSurface((s) => s.startRover);
  const leave = useSurface((s) => s.leave);
  const finishFlight = useGameStore((s) => s.launchFinish);
  const practice = useSurface((s) => s.practice);
  const exit = () => {
    leave();
    finishFlight();
  };
  const [held, setHeld] = useState<Record<string, boolean>>({});
  const live = useMemo(() => ({ current: {} as Record<string, boolean> }), []);
  const [help, setHelp] = useState(false);
  const setCtl = (c: Ctl, v: boolean) => {
    live.current = { ...live.current, [c]: v };
    setHeld(live.current);
  };
  const flying = phase === 'flying';
  const terrain = getTerrain();

  // Teclado.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
      if (e.code === 'KeyP' && e.type === 'keydown') {
        const p = useSurface.getState().phase;
        if (p === 'flying' || p === 'paused') setPaused(p === 'flying');
        return;
      }
      const c = KEYS[e.code];
      if (!c) return;
      e.preventDefault();
      const down = e.type === 'keydown';
      if (!!live.current[c] !== down) {
        live.current = { ...live.current, [c]: down };
        setHeld(live.current);
      }
    };
    window.addEventListener('keydown', onKey);
    window.addEventListener('keyup', onKey);
    return () => {
      window.removeEventListener('keydown', onKey);
      window.removeEventListener('keyup', onKey);
    };
  }, [live, setPaused]);

  // Bucle de la física: 20 pasos por segundo, en tiempo real.
  useEffect(() => {
    if (!flying) return;
    const id = window.setInterval(() => {
      const h = live.current;
      const input: LanderInput = {
        ...NO_LANDER_INPUT,
        engine: !!h.engine,
        pitch: (h.fwd ? 1 : 0) - (h.back ? 1 : 0),
        roll: (h.right ? 1 : 0) - (h.left ? 1 : 0),
      };
      useSurface.getState().stepLanding(input, 0.05);
    }, 50);
    return () => window.clearInterval(id);
  }, [flying, live]);

  // Cinemática de éxito: unos segundos y después el resultado.
  const cineRef = useRef<number | null>(null);
  useEffect(() => {
    if (phase !== 'cinematic') return;
    cineRef.current = window.setTimeout(endCinematic, 7000);
    return () => {
      if (cineRef.current) window.clearTimeout(cineRef.current);
    };
  }, [phase, endCinematic]);

  if (!lander) return null;
  const r = landerReadout(terrain, lander);
  const vDown = Math.max(0, -r.verticalMS);
  const recommended = r.recommendedMS;
  const vState = vDown <= recommended ? 'ok' : vDown <= recommended * 1.5 ? 'warn' : 'bad';
  const hState = r.altitudeM > 30 || r.horizontalMS <= LIMITS.horizontalMS ? 'ok' : 'bad';
  const last = history[history.length - 1];

  const tips: string[] = [];
  if (flying) {
    if (vState !== 'ok') tips.push('¡Bajas muy rápido! Mantén ESPACIO para frenar.');
    else if (lander.v[1] > 0.5) tips.push('Estás subiendo: suelta ESPACIO.');
    const along = (lander.v[0] * r.safeDx + lander.v[2] * r.safeDz) / Math.max(1, r.safeDistM);
    if (r.safeDistM > TERRAIN.safe.r * 0.6) {
      const ahead = r.safeDx > Math.abs(r.safeDz) * 0.6;
      const behind = -r.safeDx > Math.abs(r.safeDz) * 0.6;
      const dir = ahead ? '↑' : behind ? '↓' : r.safeDz > 0 ? '→' : '←';
      if (along < 2) tips.push(`La zona verde está hacia ${dir}: mantén esa flecha.`);
      else if (along > Math.max(5, r.safeDistM / 12)) tips.push('¡Vas muy deprisa hacia la zona! Pulsa la flecha contraria para frenar.');
    }
    if (r.altitudeM < 25 && r.horizontalMS > LIMITS.horizontalMS) tips.push('Frena el movimiento de lado con la flecha contraria.');
    if (r.altitudeM < 15 && r.tiltDeg > LIMITS.tiltDeg * 0.7) tips.push('¡Suelta las flechas para enderezarte!');
    if (r.fuelFrac < 0.2) tips.push('¡Poco combustible! Usa el motor solo a ratos.');
  }
  const speedo = vDown <= recommended ? { cls: 'ok', txt: 'Bien' } : vDown <= recommended * 1.5 ? { cls: 'warn', txt: 'Rápido' } : { cls: 'bad', txt: '¡Muy rápido!' };

  return (
    <div className="sf-hud ld-hud">
      {/* Indicadores principales (izquierda) */}
      <section className="sf-panel sf-left" aria-label="Indicadores del descenso">
        <p className="eyebrow">{`Descenso a la Luna · intento ${attempt + 1}`}</p>
        <div className="ld-big">
          <span className="stat__label">Altitud sobre el suelo</span>
          <span className="ld-big__val mono" data-testid="ld-alt" data-v={r.altitudeM.toFixed(2)}>{`${fmtNum(Math.max(0, r.altitudeM), r.altitudeM < 100 ? 1 : 0)} m`}</span>
        </div>
        <div className={`ld-row ld-row--${vState}`}>
          <span>Velocidad de bajada</span>
          <span className="mono" data-testid="ld-vs" data-v={r.verticalMS.toFixed(3)}>{`${r.verticalMS >= 0 ? '↑' : '↓'} ${fmtNum(Math.abs(r.verticalMS), 1)} m/s`}</span>
          <span className={`ld-speedo ld-speedo--${speedo.cls}`}>{speedo.txt}</span>
          <span className="small muted">{`recomendado ahora: ≤ ${fmtNum(recommended, 1)} · al tocar: ≤ ${LIMITS.verticalMS}`}</span>
        </div>
        <div className={`ld-row ld-row--${hState}`}>
          <span>Velocidad de lado</span>
          <span className="mono">{`${fmtNum(r.horizontalMS, 1)} m/s`}</span>
          <span className="small muted" data-testid="ld-drift" data-vf={lander.v[0].toFixed(3)} data-vr={lander.v[2].toFixed(3)}>
            {`${lander.v[0] >= 0 ? 'adelante' : 'atrás'} ${fmtNum(Math.abs(lander.v[0]), 1)} · ${lander.v[2] >= 0 ? 'derecha' : 'izquierda'} ${fmtNum(Math.abs(lander.v[2]), 1)} m/s · al tocar: ≤ ${LIMITS.horizontalMS}`}
          </span>
        </div>
        <div className="ld-row">
          <span>Combustible</span>
          <span className={`tm-bar ${r.fuelFrac < 0.2 ? 'tm-bar--warn' : ''}`} role="img" aria-label={`Combustible ${Math.round(r.fuelFrac * 100)} %`}>
            <span style={{ width: `${r.fuelFrac * 100}%` }} />
          </span>
          <span className="mono">{`${fmtNum(lander.fuelKg, 0)} kg`}</span>
        </div>
        <div className={`ld-engine ${lander.throttle > 0.05 ? 'on' : ''}`}>
          <span aria-hidden="true">🔥</span>
          <span data-testid="ld-thr" data-v={lander.throttle.toFixed(3)} data-pitch={lander.pitch.toFixed(2)} data-roll={lander.roll.toFixed(2)}>
            {lander.throttle > 0.05 ? 'Motor encendido' : 'Motor apagado'}
          </span>
        </div>
      </section>

      {/* Orientación, inclinación y zona segura (derecha) */}
      <section className="sf-panel sf-right" aria-label="Orientación y zona segura">
        <h3 className="section-title">Orientación</h3>
        <div className="ld-att-row">
          <Attitude pitch={lander.pitch} roll={lander.roll} tilt={r.tiltDeg} />
          <div>
            <span className="stat__label">Inclinación</span>
            <TiltGauge tilt={r.tiltDeg} />
            <p className={`small ${r.tiltDeg <= LIMITS.tiltDeg ? 'ok-text' : 'bad-text'}`}>{r.tiltDeg <= LIMITS.tiltDeg ? 'Recto: bien para tocar el suelo' : `Muy inclinado (límite ${LIMITS.tiltDeg}°)`}</p>
          </div>
        </div>
        <h3 className="section-title">Zona segura</h3>
        <div className="ld-att-row">
          <SafeRadar dx={r.safeDx} dz={r.safeDz} groundOk={r.groundOk} />
          <div className="small">
            <p className="mono ld-safe-dist" data-testid="ld-safe" data-dx={r.safeDx.toFixed(2)} data-dz={r.safeDz.toFixed(2)}>
              {r.safeDistM <= TERRAIN.safe.r ? 'Estás sobre la zona verde ✓' : `A ${fmtNum(r.safeDistM, 0)} m`}
            </p>
            <p className="small muted">{`${r.safeDx >= 0 ? 'Adelante' : 'Atrás'} ${fmtNum(Math.abs(r.safeDx), 0)} m · ${r.safeDz >= 0 ? 'derecha' : 'izquierda'} ${fmtNum(Math.abs(r.safeDz), 0)} m`}</p>
            <p>
              Suelo debajo:{' '}
              <strong className={r.groundOk ? 'ok-text' : 'bad-text'}>{r.groundOk ? 'llano y sin rocas ✓' : r.groundRock ? 'rocas ✗' : `pendiente de ${fmtNum(r.groundSlopeDeg, 0)}° ✗`}</strong>
            </p>
          </div>
        </div>
      </section>

      {/* Consejos del centro de control */}
      {tips.length > 0 && (
        <ul className="sf-tips small" aria-live="polite">
          {tips.slice(0, 3).map((t) => (
            <li key={t}>{t}</li>
          ))}
        </ul>
      )}

      {/* Mandos */}
      <section className="sf-panel sf-bottom" aria-label="Mandos del módulo">
        <div className="sf-ctl">
          <div className="sf-ctl__group" role="group" aria-label="Motor">
            <span className="small muted">Motor</span>
            <Hold ctl="engine" label="🔥 MOTOR (Espacio)" title="Mantener para encender el motor (Espacio)" held={held} set={setCtl} className="ld-engine-btn" />
          </div>
          <div className="sf-ctl__group" role="group" aria-label="Mover el módulo">
            <span className="small muted">Mover</span>
            <div className="sf-grid">
              <span />
              <Hold ctl="fwd" label="↑" title="Hacia adelante (↑)" held={held} set={setCtl} />
              <span />
              <Hold ctl="left" label="←" title="Hacia la izquierda (←)" held={held} set={setCtl} />
              <span />
              <Hold ctl="right" label="→" title="Hacia la derecha (→)" held={held} set={setCtl} />
              <span />
              <Hold ctl="back" label="↓" title="Hacia atrás (↓)" held={held} set={setCtl} />
              <span />
            </div>
          </div>
          <div className="sf-ctl__group" role="group" aria-label="Cámara y pausa">
            <span className="small muted">Cámara</span>
            <span className="segmented">
              {CAMS.map((c) => (
                <button key={c.id} aria-pressed={cam === c.id} onClick={() => setCam(c.id)}>
                  {c.label}
                </button>
              ))}
            </span>
            <button className="chip chip--neutral" disabled={phase !== 'flying' && phase !== 'paused'} onClick={() => setPaused(phase === 'flying')}>
              {phase === 'paused' ? '▶ Seguir (P)' : '⏸ Pausa (P)'}
            </button>
            <button
              className="chip chip--neutral"
              onClick={() => {
                if (phase === 'flying') setPaused(true);
                setHelp(true);
              }}
            >
              ❓ Mandos
            </button>
          </div>
        </div>
      </section>

      {phase === 'paused' && (
        <div className="sf-paused" role="status">
          En pausa · pulsa P o «Seguir» para continuar
        </div>
      )}

      {(phase === 'brief' || help) && (
        <Briefing
          label={phase === 'brief' ? 'Empezar el descenso' : phase === 'result' ? 'Intentarlo otra vez' : 'Seguir pilotando'}
          onSkip={phase === 'brief' ? exit : undefined}
          skipLabel={practice ? 'Volver al control del vuelo' : 'Saltar el aterrizaje (solo órbita)'}
          onStart={() => {
            setHelp(false);
            if (phase === 'brief') begin();
            else if (phase === 'paused') setPaused(false);
            else if (phase === 'result') retry();
          }}
        />
      )}

      {phase === 'cinematic' && (
        <div className="ld-cine" role="status">
          <div className="ld-cine__bar" />
          <div className="ld-cine__title">
            <p className="ld-cine__big">¡Alunizaje!</p>
            <p>Contacto con la superficie · motor apagado · el módulo está en la Luna</p>
            <button className="chip chip--neutral" onClick={endCinematic}>
              Saltar
            </button>
          </div>
          <div className="ld-cine__bar ld-cine__bar--bottom" />
        </div>
      )}

      {phase === 'result' && last && !help && (
        <Result
          td={last}
          attempts={history.length}
          onRetry={retry}
          onRover={startRover}
          onHelp={() => setHelp(true)}
          practice={practice}
          onLeave={exit}
        />
      )}
    </div>
  );
}
