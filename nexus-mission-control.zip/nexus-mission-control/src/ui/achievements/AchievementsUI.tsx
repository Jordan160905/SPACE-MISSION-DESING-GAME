/**
 * Logros: barra de rango (bronce → plata → oro → diamante), tarjetas de insignias e informe
 * divertido de la misión (con más dibujos que texto).
 */
import { BADGES, missionFeedback, stars, TIERS, tierProgress, type FeedbackCard } from '../../sim/Achievements';
import { fmtNum } from '../../sim/units';
import type { FinalResult } from '../../state/achievements';
import { NpcAvatar } from '../review/ReviewArt';

/** Barra que se va llenando con las insignias y marca cuántas faltan para el siguiente rango. */
export function TierBar({ count }: { count: number }) {
  const tp = tierProgress(count);
  const max = TIERS[TIERS.length - 1].need;
  return (
    <div className="tier" aria-label={tp.next ? `Tienes ${count} insignias. Te faltan ${tp.missing} para ${tp.next.label}.` : `Tienes ${count} insignias: rango Diamante.`}>
      <div className="tier__head">
        <span className="tier__now">
          <span className="tier__icon" aria-hidden="true">
            {tp.current?.icon ?? '🚀'}
          </span>
          <strong>{tp.current ? `Rango ${tp.current.label}` : 'Sin rango todavía'}</strong>
        </span>
        <span className="small">{tp.next ? `${count} insignias · te faltan ${tp.missing} para ${tp.next.label} ${tp.next.icon}` : `${count} insignias · ¡rango máximo!`}</span>
      </div>
      <div className="tier__track" role="progressbar" aria-valuemin={0} aria-valuemax={max} aria-valuenow={Math.min(count, max)} aria-label="Insignias conseguidas">
        <span className="tier__fill" style={{ width: `${Math.min(100, (count / max) * 100)}%` }} />
        {TIERS.map((t) => (
          <span key={t.id} className={`tier__mark ${count >= t.need ? 'on' : ''}`} style={{ left: `${(t.need / max) * 100}%` }}>
            <span className="tier__markicon" aria-hidden="true">
              {t.icon}
            </span>
            <span className="tier__marklabel">{`${t.label} · ${t.need}`}</span>
          </span>
        ))}
      </div>
    </div>
  );
}

export function BadgeCard({ id, earned, isNew, date }: { id: string; earned: boolean; isNew?: boolean; date?: string }) {
  const b = BADGES.find((x) => x.id === id);
  if (!b) return null;
  return (
    <div className={`badge-card ${earned ? 'on' : 'off'} ${isNew ? 'new' : ''}`}>
      {isNew && <span className="badge-card__new">¡Nueva!</span>}
      <span className="badge-card__icon" aria-hidden="true">
        {earned ? b.icon : '🔒'}
      </span>
      <strong>{b.title}</strong>
      <span className="small">{b.how}</span>
      {date && <span className="small muted">{date}</span>}
    </div>
  );
}

function Cards({ list }: { list: FeedbackCard[] }) {
  return (
    <div className="fb-cards">
      {list.map((c, i) => (
        <div key={`${c.title}${i}`} className={`fb-card fb-card--${c.tone}`}>
          <span className="fb-card__icon" aria-hidden="true">
            {c.icon}
          </span>
          <strong>{c.title}</strong>
          <span className="small">{c.text}</span>
        </div>
      ))}
    </div>
  );
}

/** Informe divertido de la misión. */
export function MissionReport({ result, totalBadges, onClose, onAchievements }: { result: FinalResult; totalBadges: number; onClose: () => void; onAchievements: () => void }) {
  const { outcome: o, flight: f, surface: s } = result;
  const fb = missionFeedback(o, f, s);
  const st = stars(o, s);
  const dataFrac = o.targetGbit > 0 ? Math.min(1, o.deliveredGbit / o.targetGbit) : 1;
  return (
    <div className="sf-overlay report-overlay" role="dialog" aria-modal="true" aria-labelledby="report-title">
      <div className={`sf-card report ${o.success ? 'report--ok' : 'report--bad'}`}>
        <header className="report__head">
          <span className="report__big" aria-hidden="true">
            {o.success ? '🏆' : '🔧'}
          </span>
          <div>
            <p className="eyebrow">{`Informe de ${o.player} · ${o.missionName}`}</p>
            <h2 className="h2" id="report-title">
              {o.success ? '¡Misión cumplida!' : 'Esta vez la misión no se completó'}
            </h2>
            <p className="report__stars" aria-label={`${st} de 3 estrellas`}>
              {[1, 2, 3].map((i) => (
                <span key={i} className={i <= st ? 'on' : ''} aria-hidden="true">
                  ★
                </span>
              ))}
            </p>
          </div>
          <div className="report__score">
            <span className="mono" data-testid="report-score">
              {fmtNum(result.score, 0)}
            </span>
            <span className="small">puntos</span>
            <span className="small">{`Puesto #${result.rank}`}</span>
          </div>
        </header>

        <div className="fev__msg">
          <NpcAvatar mood={o.success ? 'happy' : 'thinking'} />
          <p className="fev__bubble">
            {o.success
              ? `¡Bravo, ${o.player}! Conseguiste lo que pedía la misión: ${o.objectiveTitle}. Mira cómo te fue paso a paso.`
              : `¡Buen intento, ${o.player}! Aprendimos mucho. Mira qué pasó y qué puedes hacer la próxima vez.`}
          </p>
        </div>

        <section>
          <h3 className="section-title">Tu aventura</h3>
          <Cards list={fb.journey} />
        </section>

        <section>
          <h3 className="section-title">Datos enviados a la Tierra</h3>
          <div className="report__data">
            <span aria-hidden="true">🛰️ → 🌍</span>
            <span className="tm-bar" role="img" aria-label={`${fmtNum(o.deliveredGbit, 0)} de ${fmtNum(o.targetGbit, 0)} Gbit`}>
              <span style={{ width: `${dataFrac * 100}%` }} />
            </span>
            <span className="mono">{`${fmtNum(o.deliveredGbit, 0)} / ${fmtNum(o.targetGbit, 0)} Gbit`}</span>
          </div>
        </section>

        {fb.found.length > 0 && (
          <section>
            <h3 className="section-title">Lo que encontraste y para qué sirve</h3>
            <Cards list={fb.found} />
          </section>
        )}

        {fb.problems.length > 0 && (
          <section>
            <h3 className="section-title">Problemas del viaje</h3>
            <Cards list={fb.problems} />
          </section>
        )}

        <section>
          <h3 className="section-title">{o.success ? 'Para hacerlo aún mejor' : 'Qué puedes mejorar'}</h3>
          <Cards list={fb.tips} />
        </section>

        <section>
          <h3 className="section-title">{`Insignias de esta misión (${result.badges.length})`}</h3>
          {result.badges.length ? (
            <div className="badge-grid">
              {result.badges.map((id) => (
                <BadgeCard key={id} id={id} earned isNew={result.newBadges.includes(id)} />
              ))}
            </div>
          ) : (
            <p className="small muted">Esta vez no hubo insignias. ¡La próxima seguro que sí!</p>
          )}
          <TierBar count={totalBadges} />
        </section>

        <div className="ld-result__actions">
          <button className="btn btn--primary" onClick={onAchievements}>
            🏅 Ver todos mis logros
          </button>
          <button className="btn" onClick={onClose}>
            Cerrar el informe
          </button>
        </div>
      </div>
    </div>
  );
}

/** El avatar pregunta si se quiere ver el informe. */
export function ReportPrompt({ player, success, onOpen, onLater }: { player: string; success: boolean; onOpen: () => void; onLater: () => void }) {
  return (
    <div className="report-prompt" role="dialog" aria-labelledby="report-prompt-text">
      <NpcAvatar mood={success ? 'happy' : 'thinking'} />
      <div>
        <p className="fev__bubble" id="report-prompt-text">
          {`¡${player}, la misión terminó! ¿Quieres ver tu informe? Te enseño lo que conseguiste, las insignias que ganaste y lo que puedes mejorar.`}
        </p>
        <div className="ld-result__actions">
          <button className="btn btn--primary" onClick={onOpen}>
            ¡Sí, ver mi informe!
          </button>
          <button className="btn btn--ghost" onClick={onLater}>
            Ahora no
          </button>
        </div>
      </div>
    </div>
  );
}
