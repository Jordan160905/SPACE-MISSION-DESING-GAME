import type { ReactElement } from 'react';
import { useGameStore, type Screen } from '../../state/useGameStore';
import { IconArchive, IconBook, IconCenter, IconHelp, IconLab, IconPlanner, IconReview, IconRocket, IconTrophy } from '../components/icons';

const ITEMS: Array<{ screen: Screen; label: string; Icon: () => ReactElement }> = [
  { screen: 'center', label: 'Centro', Icon: IconCenter },
  { screen: 'lab', label: 'Lab', Icon: IconLab },
  { screen: 'planner', label: 'Planner', Icon: IconPlanner },
  { screen: 'review', label: 'Revisión', Icon: IconReview },
  { screen: 'flight', label: 'Vuelo', Icon: IconRocket },
  { screen: 'archive', label: 'Archivo', Icon: IconArchive },
  { screen: 'glossary', label: 'Glosario', Icon: IconBook },
  { screen: 'achievements', label: 'Logros', Icon: IconTrophy },
];

export function NavRail() {
  const screen = useGameStore((s) => s.screen);
  const navigate = useGameStore((s) => s.navigate);
  const setTutorialStep = useGameStore((s) => s.setTutorialStep);

  return (
    <nav className="rail" aria-label="Navegación principal">
      {ITEMS.map(({ screen: target, label, Icon }) => {
        const current = screen === target || (target === 'center' && screen === 'briefing') || (target === 'lab' && screen === 'analysis');
        return (
          <button key={target} className="rail__btn" aria-current={current ? 'page' : undefined} onClick={() => navigate(target)}>
            <Icon />
            <span>{label}</span>
          </button>
        );
      })}
      <div className="rail__sep" />
      <button className="rail__btn" onClick={() => setTutorialStep(0)} title="Volver a ver el tutorial">
        <IconHelp />
        <span>Guía</span>
      </button>
    </nav>
  );
}
