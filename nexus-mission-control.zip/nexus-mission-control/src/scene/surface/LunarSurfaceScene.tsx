/**
 * Escena 3D de la superficie lunar (Fases 8.8 y 8.9).
 *  - Terreno con relieve, cráteres y rocas (sim/LunarTerrain), con una zona de detalle fina
 *    alrededor del sitio de aterrizaje o del rover.
 *  - Sol bajo (sombras largas, como en los alunizajes reales), cielo negro con estrellas y la Tierra.
 *  - Módulo de descenso con llama del motor y polvo levantado cerca del suelo.
 *  - Rover de seis ruedas que se apoya en el terreno, y marcas de las misiones.
 *  - Cámaras: persecución / desde el suelo / desde arriba (aterrizaje) y seguimiento / desde el
 *    rover / desde arriba (rover). Cinemática al aterrizar.
 * La física corre fuera de la escena (ui/surface/surfaceStore); aquí solo se dibuja su estado.
 */
import { Suspense, useEffect, useMemo, useRef } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';
import { heightAt, getTerrain, normalAt, TERRAIN, mulberry, type Terrain } from '../../sim/LunarTerrain';
import { altitude, thrustDir } from '../../sim/Lander';
import { missionTarget, roverPlan } from '../../sim/Rover';
import { useSurface } from '../../ui/surface/surfaceStore';
import { createEarthTexture, createFoilBumpTexture } from '../proceduralTextures';

const SUN = new THREE.Vector3(-0.78, 0.2, -0.45).normalize();

// ───────────────────────── Terreno ─────────────────────────

function regolithColor(t: Terrain, x: number, z: number, h: number, nY: number, out: THREE.Color) {
  // Gris lunar con variaciones: cráteres jóvenes más claros (material fresco), llanuras algo más oscuras.
  let v = 0.5 + h * 0.004 + (Math.sin(x * 0.013) * Math.cos(z * 0.011)) * 0.03;
  for (const c of t.craters) {
    const d = Math.hypot(x - c.x, z - c.z) / c.r;
    if (d < 2.4 && c.r > 25) v += 0.06 * Math.max(0, 1 - Math.abs(d - 1.15) / 1.2);
  }
  v += (1 - nY) * 0.25;
  v = Math.max(0.28, Math.min(0.78, v));
  return out.setRGB(v * 0.98, v * 0.97, v * 0.95);
}

function buildTerrain(t: Terrain, cx: number, cz: number, size: number, seg: number, hole?: { cx: number; cz: number; half: number }) {
  const g = new THREE.PlaneGeometry(size, size, seg, seg);
  g.rotateX(-Math.PI / 2);
  const pos = g.attributes.position as THREE.BufferAttribute;
  const colors = new Float32Array(pos.count * 3);
  const c = new THREE.Color();
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i) + cx;
    const z = pos.getZ(i) + cz;
    let h = heightAt(t, x, z);
    // Bajo la zona de detalle, el terreno lejano se esconde un poco para no solaparse.
    if (hole && Math.abs(x - hole.cx) < hole.half - 4 && Math.abs(z - hole.cz) < hole.half - 4) h -= 1.5;
    pos.setXYZ(i, x, h, z);
    const n = normalAt(t, x, z);
    regolithColor(t, x, z, h, n[1], c);
    colors[i * 3] = c.r;
    colors[i * 3 + 1] = c.g;
    colors[i * 3 + 2] = c.b;
  }
  g.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  g.computeVertexNormals();
  return g;
}

/** Textura de grano fino del regolito (se repite). */
function grainTexture() {
  const n = 256;
  const cv = document.createElement('canvas');
  cv.width = cv.height = n;
  const ctx = cv.getContext('2d')!;
  const img = ctx.createImageData(n, n);
  const r = mulberry(99);
  for (let i = 0; i < n * n; i++) {
    const v = 200 + (r() - 0.5) * 70;
    img.data[i * 4] = img.data[i * 4 + 1] = img.data[i * 4 + 2] = v;
    img.data[i * 4 + 3] = 255;
  }
  ctx.putImageData(img, 0, 0);
  // Pequeños cráteres en la textura.
  for (let k = 0; k < 40; k++) {
    const x = r() * n;
    const y = r() * n;
    const rad = 2 + r() * 7;
    const gr = ctx.createRadialGradient(x - rad * 0.3, y - rad * 0.3, 0, x, y, rad);
    gr.addColorStop(0, 'rgba(60,60,60,0.35)');
    gr.addColorStop(0.8, 'rgba(255,255,255,0.15)');
    gr.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = gr;
    ctx.beginPath();
    ctx.arc(x, y, rad, 0, Math.PI * 2);
    ctx.fill();
  }
  const tex = new THREE.CanvasTexture(cv);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function Ground({ center }: { center: { x: number; z: number } }) {
  const t = getTerrain();
  const detailHalf = 300;
  const far = useMemo(() => buildTerrain(t, 0, 0, TERRAIN.size, 300, { cx: center.x, cz: center.z, half: detailHalf }), [t, center.x, center.z]);
  const near = useMemo(() => buildTerrain(t, center.x, center.z, detailHalf * 2, 300), [t, center.x, center.z]);
  const grainFar = useMemo(() => {
    const g = grainTexture();
    g.repeat.set(60, 60);
    return g;
  }, []);
  const grainNear = useMemo(() => {
    const g = grainTexture();
    g.repeat.set(60, 60);
    return g;
  }, []);
  useEffect(
    () => () => {
      far.dispose();
      near.dispose();
    },
    [far, near],
  );
  return (
    <group>
      <mesh geometry={far} receiveShadow>
        <meshStandardMaterial vertexColors map={grainFar} roughness={1} metalness={0} />
      </mesh>
      <mesh geometry={near} receiveShadow castShadow>
        <meshStandardMaterial vertexColors map={grainNear} roughness={1} metalness={0} />
      </mesh>
    </group>
  );
}

function Rocks() {
  const t = getTerrain();
  const ref = useRef<THREE.InstancedMesh>(null);
  const list = useMemo(() => t.rocks.filter((k) => k.r >= 0.25), [t]);
  const geom = useMemo(() => {
    const g = new THREE.IcosahedronGeometry(1, 1);
    const p = g.attributes.position as THREE.BufferAttribute;
    const r = mulberry(5);
    const v = new THREE.Vector3();
    for (let i = 0; i < p.count; i++) {
      v.fromBufferAttribute(p, i);
      v.multiplyScalar(0.8 + r() * 0.35);
      p.setXYZ(i, v.x, v.y, v.z);
    }
    g.computeVertexNormals();
    return g;
  }, []);
  useEffect(() => {
    const m = ref.current;
    if (!m) return;
    const o = new THREE.Object3D();
    const r = mulberry(17);
    list.forEach((k, i) => {
      o.position.set(k.x, heightAt(t, k.x, k.z) + k.r * 0.25, k.z);
      o.rotation.set(r() * 3, r() * 3, r() * 3);
      o.scale.set(k.r, k.r * (0.55 + r() * 0.3), k.r * (0.8 + r() * 0.4));
      o.updateMatrix();
      m.setMatrixAt(i, o.matrix);
    });
    m.instanceMatrix.needsUpdate = true;
  }, [list, t]);
  return (
    <instancedMesh ref={ref} args={[geom, undefined, list.length]} castShadow receiveShadow>
      <meshStandardMaterial color="#8d8a84" roughness={0.95} flatShading />
    </instancedMesh>
  );
}

function SafeZone({ faint }: { faint?: boolean }) {
  const t = getTerrain();
  const y = heightAt(t, TERRAIN.safe.x, TERRAIN.safe.z) + 0.15;
  const ref = useRef<THREE.Mesh>(null);
  useFrame(({ clock }) => {
    const m = ref.current?.material as THREE.MeshBasicMaterial | undefined;
    if (m) m.opacity = (faint ? 0.25 : 0.55) + Math.sin(clock.elapsedTime * 2) * 0.12;
  });
  return (
    <group position={[TERRAIN.safe.x, y, TERRAIN.safe.z]}>
      <mesh ref={ref} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[TERRAIN.safe.r - 1.2, TERRAIN.safe.r, 96]} />
        <meshBasicMaterial color="#5cf08a" transparent opacity={0.5} depthWrite={false} side={THREE.DoubleSide} toneMapped={false} />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]}>
        <circleGeometry args={[TERRAIN.safe.r - 1.2, 64]} />
        <meshBasicMaterial color="#5cf08a" transparent opacity={faint ? 0.04 : 0.09} depthWrite={false} toneMapped={false} />
      </mesh>
      {!faint &&
        [0, 1, 2, 3].map((i) => {
          const a = (i * Math.PI) / 2 + Math.PI / 4;
          return (
            <mesh key={i} position={[Math.cos(a) * TERRAIN.safe.r, 3, Math.sin(a) * TERRAIN.safe.r]}>
              <cylinderGeometry args={[0.15, 0.15, 6, 8]} />
              <meshBasicMaterial color="#5cf08a" toneMapped={false} />
            </mesh>
          );
        })}
    </group>
  );
}

// ───────────────────────── Cielo ─────────────────────────

function Sky() {
  const stars = useMemo(() => {
    const r = mulberry(3);
    const n = 2500;
    const p = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) {
      const u = r() * 2 - 1;
      const a = r() * Math.PI * 2;
      const s = Math.sqrt(1 - u * u);
      p[i * 3] = Math.cos(a) * s * 9000;
      p[i * 3 + 1] = Math.abs(u) * 9000 + 200;
      p[i * 3 + 2] = Math.sin(a) * s * 9000;
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(p, 3));
    return g;
  }, []);
  const earthTex = useMemo(() => createEarthTexture(512), []);
  const group = useRef<THREE.Group>(null);
  const { camera } = useThree();
  // El cielo sigue a la cámara (está «en el infinito»).
  useFrame(() => {
    if (group.current) group.current.position.copy(camera.position);
  });
  const earthDir = new THREE.Vector3(0.35, 0.55, 0.75).normalize().multiplyScalar(8000);
  return (
    <group ref={group}>
      <points geometry={stars} frustumCulled={false}>
        <pointsMaterial size={1.6} sizeAttenuation={false} color="#ffffff" />
      </points>
      <mesh position={earthDir} rotation={[0.2, 1.4, 0]}>
        <sphereGeometry args={[133, 48, 32]} />
        <meshStandardMaterial map={earthTex} roughness={0.8} emissive="#0a1830" emissiveIntensity={0.2} />
      </mesh>
    </group>
  );
}

// ───────────────────────── Módulo de descenso ─────────────────────────

function LanderModel({ throttle, failed }: { throttle: number; failed: boolean }) {
  const foil = useMemo(() => createFoilBumpTexture(11), []);
  const plume = useRef<THREE.Mesh>(null);
  const light = useRef<THREE.PointLight>(null);
  useFrame(({ clock }) => {
    const k = throttle * (0.85 + Math.sin(clock.elapsedTime * 40) * 0.08 + Math.sin(clock.elapsedTime * 23) * 0.07);
    if (plume.current) {
      plume.current.visible = throttle > 0.02 && !failed;
      plume.current.scale.set(0.6 + k * 0.6, 0.4 + k * 5, 0.6 + k * 0.6);
    }
    if (light.current) light.current.intensity = failed ? 0 : k * 60;
  });
  return (
    <group>
      {/* Cuerpo (octogonal, con lámina térmica dorada) */}
      <mesh position={[0, 1.7, 0]} castShadow>
        <cylinderGeometry args={[1.35, 1.35, 1.3, 8]} />
        <meshStandardMaterial color="#c9a24a" metalness={0.7} roughness={0.35} bumpMap={foil} bumpScale={0.6} />
      </mesh>
      <mesh position={[0, 2.45, 0]} castShadow>
        <cylinderGeometry args={[1.0, 1.35, 0.25, 8]} />
        <meshStandardMaterial color="#d6d9de" metalness={0.5} roughness={0.4} />
      </mesh>
      {/* Tanques */}
      {[-1, 1].map((s) => (
        <mesh key={s} position={[s * 0.6, 1.75, 0]} castShadow>
          <sphereGeometry args={[0.55, 20, 14]} />
          <meshStandardMaterial color="#e6e9ee" metalness={0.6} roughness={0.3} />
        </mesh>
      ))}
      {/* Antena */}
      <mesh position={[0.5, 2.9, 0.4]} rotation={[0.3, 0, -0.5]}>
        <coneGeometry args={[0.4, 0.2, 20, 1, true]} />
        <meshStandardMaterial color="#f2f2f2" side={THREE.DoubleSide} />
      </mesh>
      {/* Patas y apoyos */}
      {[0, 1, 2, 3].map((i) => {
        const a = (i * Math.PI) / 2 + Math.PI / 4;
        const fx = Math.cos(a) * 2.2;
        const fz = Math.sin(a) * 2.2;
        const tx = Math.cos(a) * 1.1;
        const tz = Math.sin(a) * 1.1;
        const mid = new THREE.Vector3((fx + tx) / 2, 0.75, (fz + tz) / 2);
        const dir = new THREE.Vector3(tx - fx, 1.4, tz - fz);
        const len = dir.length();
        const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.normalize());
        return (
          <group key={i}>
            <mesh position={mid} quaternion={q} castShadow>
              <cylinderGeometry args={[0.07, 0.07, len, 8]} />
              <meshStandardMaterial color="#b9bcc2" metalness={0.8} roughness={0.3} />
            </mesh>
            <mesh position={[fx, 0.04, fz]} castShadow>
              <cylinderGeometry args={[0.32, 0.36, 0.08, 16]} />
              <meshStandardMaterial color="#c9a24a" metalness={0.6} roughness={0.4} />
            </mesh>
          </group>
        );
      })}
      {/* Tobera del motor */}
      <mesh position={[0, 0.85, 0]}>
        <cylinderGeometry args={[0.18, 0.42, 0.6, 20, 1, true]} />
        <meshStandardMaterial color="#3a3a3e" metalness={0.8} roughness={0.4} side={THREE.DoubleSide} />
      </mesh>
      {/* Llama (casi invisible en el vacío: un brillo azulado) */}
      <mesh ref={plume} position={[0, 0.55, 0]} rotation={[Math.PI, 0, 0]}>
        <coneGeometry args={[0.38, 1, 20, 1, true]} />
        <meshBasicMaterial color="#9fc4ff" transparent opacity={0.45} blending={THREE.AdditiveBlending} depthWrite={false} side={THREE.DoubleSide} toneMapped={false} />
      </mesh>
      <pointLight ref={light} position={[0, -0.5, 0]} color="#bcd4ff" distance={30} decay={2} />
    </group>
  );
}

/** Polvo levantado por el motor cerca del suelo. */
function Dust() {
  const n = 400;
  const geo = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(n * 3), 3));
    return g;
  }, []);
  const seeds = useMemo(() => {
    const r = mulberry(8);
    return Array.from({ length: n }, () => ({ a: r() * Math.PI * 2, s: 0.5 + r(), ph: r() }));
  }, []);
  const mat = useRef<THREE.PointsMaterial>(null);
  const ref = useRef<THREE.Points>(null);
  useFrame(({ clock }) => {
    const st = useSurface.getState();
    const l = st.lander;
    const pts = ref.current;
    if (!l || !pts) return;
    const t = getTerrain();
    const alt = altitude(t, l);
    const active = st.mode === 'landing' && (st.phase === 'flying' || st.phase === 'paused' || st.phase === 'cinematic');
    const k = active ? Math.max(0, 1 - alt / 30) * (st.phase === 'cinematic' ? 0.35 : l.throttle) : 0;
    if (mat.current) mat.current.opacity = Math.min(0.75, k * 1.2);
    pts.visible = k > 0.02;
    if (!pts.visible) return;
    const p = geo.attributes.position as THREE.BufferAttribute;
    const time = clock.elapsedTime;
    for (let i = 0; i < n; i++) {
      const s = seeds[i];
      const u = (time * 0.6 * s.s + s.ph) % 1;
      const rad = 1 + u * (10 + 18 * k);
      const x = l.p[0] + Math.cos(s.a) * rad;
      const z = l.p[2] + Math.sin(s.a) * rad;
      p.setXYZ(i, x, heightAt(t, x, z) + 0.2 + u * 1.2 * (1 - u) * 3, z);
    }
    p.needsUpdate = true;
  });
  return (
    <points ref={ref} geometry={geo} frustumCulled={false}>
      <pointsMaterial ref={mat} size={0.35} color="#bdb7ac" transparent opacity={0.5} depthWrite={false} />
    </points>
  );
}

// ───────────────────────── Rover ─────────────────────────

function RoverModel() {
  const wheels = useRef<THREE.Group>(null);
  const arm = useRef<THREE.Group>(null);
  useFrame((_, dt) => {
    const r = useSurface.getState().rover;
    if (!r) return;
    if (wheels.current) wheels.current.children.forEach((w) => (w.rotation.y -= (r.speed / 0.4) * dt));
    if (arm.current) {
      const want = r.holdT > 0 ? -0.9 : 0;
      arm.current.rotation.z += (want - arm.current.rotation.z) * Math.min(1, dt * 4);
    }
  });
  // Ejes locales: +x adelante, +y arriba, +z derecha.
  return (
    <group>
      <mesh position={[0, 0.75, 0]} castShadow>
        <boxGeometry args={[2.2, 0.35, 1.5]} />
        <meshStandardMaterial color="#d8dbe0" metalness={0.4} roughness={0.5} />
      </mesh>
      <mesh position={[-0.2, 0.98, 0]} castShadow>
        <boxGeometry args={[1.8, 0.05, 1.7]} />
        <meshStandardMaterial color="#1d3a7a" metalness={0.3} roughness={0.35} emissive="#06122e" />
      </mesh>
      {/* Mástil con cámaras */}
      <mesh position={[0.8, 1.35, 0]} castShadow>
        <cylinderGeometry args={[0.05, 0.05, 0.8, 8]} />
        <meshStandardMaterial color="#b9bcc2" metalness={0.8} roughness={0.3} />
      </mesh>
      <mesh position={[0.85, 1.8, 0]} castShadow>
        <boxGeometry args={[0.25, 0.18, 0.4]} />
        <meshStandardMaterial color="#e6e9ee" />
      </mesh>
      {/* Antena */}
      <mesh position={[-0.7, 1.45, 0.45]} rotation={[0.3, 0, 0.4]}>
        <coneGeometry args={[0.3, 0.12, 18, 1, true]} />
        <meshStandardMaterial color="#f2f2f2" side={THREE.DoubleSide} />
      </mesh>
      {/* Brazo de instrumentos */}
      <group ref={arm} position={[1.1, 0.7, 0.4]}>
        <mesh position={[0.35, 0, 0]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.04, 0.04, 0.7, 8]} />
          <meshStandardMaterial color="#b9bcc2" metalness={0.8} roughness={0.3} />
        </mesh>
        <mesh position={[0.72, -0.05, 0]}>
          <boxGeometry args={[0.12, 0.12, 0.12]} />
          <meshStandardMaterial color="#c9a24a" metalness={0.6} roughness={0.4} />
        </mesh>
      </group>
      {/* Seis ruedas */}
      <group ref={wheels}>
        {[-0.85, 0, 0.85].flatMap((x) =>
          [-0.85, 0.85].map((z) => (
            <mesh key={`${x}${z}`} position={[x, 0.4, z]} rotation={[Math.PI / 2, 0, 0]} castShadow>
              <cylinderGeometry args={[0.4, 0.4, 0.28, 18]} />
              <meshStandardMaterial color="#6d6f73" metalness={0.5} roughness={0.7} />
            </mesh>
          )),
        )}
      </group>
    </group>
  );
}

/** Marcas de las misiones: columna de luz en el objetivo actual y aros en los cumplidos. */
function MissionMarkers({ lander }: { lander: { x: number; z: number } }) {
  const rover = useSurface((s) => s.rover);
  const t = getTerrain();
  if (!rover) return null;
  const seen = new Set<string>();
  return (
    <group>
      {roverPlan(rover.plan).steps.map((m, i) => {
        if (m.site === 'here') return null;
        const tg = missionTarget(t, m.site, lander);
        const key = `${Math.round(tg.x)},${Math.round(tg.z)}`;
        const active = i === rover.mission;
        if (seen.has(key) && !active) return null;
        seen.add(key);
        const done = i < rover.mission;
        if (!active && !done) return null;
        const y = heightAt(t, tg.x, tg.z);
        const r = Math.max(3, Math.min(tg.r, 40));
        return (
          <group key={m.id} position={[tg.x, y, tg.z]}>
            <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.2, 0]}>
              <ringGeometry args={[r - 0.6, r, 64]} />
              <meshBasicMaterial color={done ? '#5cf08a' : '#63e6f0'} transparent opacity={0.7} depthWrite={false} side={THREE.DoubleSide} toneMapped={false} />
            </mesh>
            {active && (
              <mesh position={[0, 30, 0]}>
                <cylinderGeometry args={[0.6, 0.6, 60, 16, 1, true]} />
                <meshBasicMaterial color="#63e6f0" transparent opacity={0.28} blending={THREE.AdditiveBlending} depthWrite={false} side={THREE.DoubleSide} toneMapped={false} />
              </mesh>
            )}
          </group>
        );
      })}
    </group>
  );
}

// ───────────────────────── Escena y cámaras ─────────────────────────

const tmp = {
  q: new THREE.Quaternion(),
  q2: new THREE.Quaternion(),
  up: new THREE.Vector3(0, 1, 0),
  v: new THREE.Vector3(),
  w: new THREE.Vector3(),
  look: new THREE.Vector3(),
  cam: new THREE.Vector3(),
};

function SurfaceWorld() {
  const mode = useSurface((s) => s.mode);
  const phase = useSurface((s) => s.phase);
  const landed = useSurface((s) => s.landed);
  const failed = useSurface((s) => s.phase === 'result' && !!s.lander?.touchdown && !s.lander.touchdown.success);
  const t = getTerrain();
  const lander = useRef<THREE.Group>(null);
  const rover = useRef<THREE.Group>(null);
  const { camera } = useThree();
  const cine = useMemo(() => ({ current: 0 }), []);
  const tip = useMemo(() => ({ current: 0 }), []);
  const shown = useMemo(() => ({ p: new THREE.Vector3(), init: false, rp: new THREE.Vector3(), rInit: false, cam: new THREE.Vector3(), camInit: false }), []);
  const center = mode === 'rover' && landed ? { x: landed.x, z: landed.z } : { x: TERRAIN.safe.x, z: TERRAIN.safe.z };
  const throttle = useSurface((s) => (s.phase === 'flying' ? (s.lander?.throttle ?? 0) : 0));

  useEffect(() => {
    cine.current = 0;
    tip.current = 0;
  }, [phase, cine, tip]);

  useFrame((_, dtRaw) => {
    const dt = Math.min(0.1, dtRaw);
    const st = useSurface.getState();
    const cam = camera as THREE.PerspectiveCamera;
    const l = st.lander;
    // Módulo de descenso.
    if (lander.current && l) {
      const target = tmp.v.set(l.p[0], l.p[1], l.p[2]);
      if (!shown.init || st.phase !== 'flying') {
        shown.p.copy(target);
        shown.init = true;
      } else shown.p.lerp(target, 1 - Math.exp(-dt * 18));
      lander.current.position.copy(shown.p);
      const d = thrustDir(l.pitch, l.roll);
      tmp.q.setFromUnitVectors(tmp.up, tmp.w.set(d[0], d[1], d[2]));
      // Si el aterrizaje falló, el módulo vuelca despacio.
      if (failed && st.lander?.touchdown?.outcome !== 'away') {
        tip.current = Math.min(1, tip.current + dt / 1.6);
        const e = tip.current * tip.current * (3 - 2 * tip.current);
        tmp.q2.setFromAxisAngle(tmp.w.set(0, 0, 1), -e * 1.25);
        tmp.q.multiply(tmp.q2);
      }
      lander.current.quaternion.copy(tmp.q);
    }
    // Rover apoyado en el terreno.
    const r = st.rover;
    if (rover.current && r) {
      const y = heightAt(t, r.x, r.z);
      tmp.v.set(r.x, y, r.z);
      if (!shown.rInit) {
        shown.rp.copy(tmp.v);
        shown.rInit = true;
      } else shown.rp.lerp(tmp.v, 1 - Math.exp(-dt * 15));
      rover.current.position.copy(shown.rp);
      const n = normalAt(t, r.x, r.z);
      tmp.q.setFromUnitVectors(tmp.up, tmp.w.set(n[0], n[1], n[2]));
      tmp.q2.setFromAxisAngle(tmp.up, -r.heading);
      rover.current.quaternion.copy(tmp.q).multiply(tmp.q2);
    }

    // Cámaras.
    let fov = 55;
    if (st.mode === 'landing' && l) {
      const P = shown.p;
      const alt = altitude(t, l);
      if (st.phase === 'cinematic') {
        // Cinemática: la cámara rodea el módulo mientras el polvo se asienta.
        cine.current += dt;
        const k = Math.min(1, cine.current / 7);
        const a = -Math.PI * 0.9 + k * Math.PI * 1.3;
        const rad = 26 - k * 12;
        tmp.cam.set(P.x + Math.cos(a) * rad, P.y + 7 - k * 4.5, P.z + Math.sin(a) * rad);
        tmp.look.set(P.x, P.y + 1.6, P.z);
        fov = 45;
      } else if (st.landingCam === 'ground') {
        const gx = TERRAIN.safe.x + 70;
        const gz = TERRAIN.safe.z + 60;
        tmp.cam.set(gx, heightAt(t, gx, gz) + 2.5, gz);
        tmp.look.set(P.x, P.y + 1.5, P.z);
        const dist = tmp.cam.distanceTo(tmp.look);
        fov = Math.max(6, Math.min(55, (2 * Math.atan(24 / dist) * 180) / Math.PI));
      } else if (st.landingCam === 'top') {
        tmp.cam.set(P.x - 1, P.y + 60 + Math.min(200, alt * 0.15), P.z);
        tmp.look.set(P.x + 2, P.y - 5, P.z);
      } else {
        const back = 20 + Math.min(60, alt * 0.04);
        const up = 7 + Math.min(80, alt * 0.06);
        tmp.cam.set(P.x - back, P.y + up, P.z);
        tmp.look.set(P.x + 6, P.y - Math.min(30, alt * 0.2), P.z);
        // Que la cámara no se meta bajo el suelo.
        const gy = heightAt(t, tmp.cam.x, tmp.cam.z) + 2;
        if (tmp.cam.y < gy) tmp.cam.y = gy;
      }
    } else if (st.mode === 'rover' && r) {
      const P = shown.rp;
      const fx = Math.cos(r.heading);
      const fz = Math.sin(r.heading);
      if (st.roverCam === 'onboard') {
        tmp.cam.set(P.x + fx * 0.9, P.y + 1.9, P.z + fz * 0.9);
        tmp.look.set(P.x + fx * 20, heightAt(t, P.x + fx * 20, P.z + fz * 20) + 0.5, P.z + fz * 20);
        fov = 65;
      } else if (st.roverCam === 'top') {
        tmp.cam.set(P.x - fx * 2, P.y + 70, P.z - fz * 2);
        tmp.look.set(P.x, P.y, P.z);
      } else {
        tmp.cam.set(P.x - fx * 9, P.y + 4.2, P.z - fz * 9);
        const gy = heightAt(t, tmp.cam.x, tmp.cam.z) + 1.5;
        if (tmp.cam.y < gy) tmp.cam.y = gy;
        tmp.look.set(P.x + fx * 4, P.y + 1, P.z + fz * 4);
      }
    }
    if (!shown.camInit || st.roverCam === 'onboard') {
      shown.cam.copy(tmp.cam);
      shown.camInit = true;
    } else shown.cam.lerp(tmp.cam, 1 - Math.exp(-dt * 6));
    cam.position.copy(shown.cam);
    cam.up.set(0, 1, 0);
    cam.lookAt(tmp.look);
    if (Math.abs(cam.fov - fov) > 0.01) {
      cam.fov += (fov - cam.fov) * Math.min(1, dt * 5);
      cam.updateProjectionMatrix();
    }
  });

  return (
    <>
      <color attach="background" args={['#000000']} />
      <ambientLight intensity={0.05} />
      <hemisphereLight args={['#2a3550', '#000000', 0.12]} />
      <directionalLight
        position={[SUN.x * 600 + center.x, SUN.y * 600, SUN.z * 600 + center.z]}
        intensity={3.2}
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
        shadow-camera-left={-120}
        shadow-camera-right={120}
        shadow-camera-top={120}
        shadow-camera-bottom={-120}
        shadow-camera-near={10}
        shadow-camera-far={1500}
        shadow-bias={-0.0008}
      />
      <Sky />
      <Ground center={center} />
      <Rocks />
      <SafeZone faint={mode === 'rover'} />
      {(mode === 'landing' || landed) && (
        <group ref={lander}>
          <LanderModel throttle={throttle} failed={failed} />
        </group>
      )}
      {mode === 'landing' && <Dust />}
      {mode === 'rover' && landed && (
        <>
          <group ref={rover}>
            <RoverModel />
          </group>
          <MissionMarkers lander={{ x: landed.x, z: landed.z }} />
        </>
      )}
    </>
  );
}

/** Mantiene la sombra centrada en lo que se ve. */
function ShadowFollow() {
  const { scene } = useThree();
  useFrame(() => {
    const st = useSurface.getState();
    const c = st.mode === 'rover' && st.rover ? { x: st.rover.x, z: st.rover.z } : st.lander ? { x: st.lander.p[0], z: st.lander.p[2] } : { x: 0, z: 0 };
    scene.traverse((o) => {
      const dl = o as THREE.DirectionalLight;
      if (dl.isDirectionalLight) {
        const y = heightAt(getTerrain(), c.x, c.z);
        dl.position.set(c.x + SUN.x * 600, y + SUN.y * 600, c.z + SUN.z * 600);
        dl.target.position.set(c.x, y, c.z);
        dl.target.updateMatrixWorld();
      }
    });
  });
  return null;
}

export default function LunarSurfaceScene() {
  return (
    <Canvas
      className="scene-canvas surface-canvas"
      dpr={[1, 1.75]}
      shadows
      camera={{ fov: 55, near: 0.1, far: 20000, position: [-30, 20, 0] }}
      gl={{ antialias: true }}
      onCreated={({ gl }) => {
        gl.toneMapping = THREE.ACESFilmicToneMapping;
        gl.toneMappingExposure = 1.0;
        gl.shadowMap.type = THREE.PCFSoftShadowMap;
      }}
    >
      <Suspense fallback={null}>
        <SurfaceWorld />
        <ShadowFollow />
      </Suspense>
    </Canvas>
  );
}
