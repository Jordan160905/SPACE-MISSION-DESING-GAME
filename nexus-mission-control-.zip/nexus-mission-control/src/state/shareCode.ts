/**
 * Códigos para compartir diseños: texto que se copia y pega (sin servidor). Contiene la misión,
 * el objetivo, la dificultad, la nave y el plan, y se valida con Zod al importarlo.
 */
import { z } from 'zod';
import { DifficultySchema, MissionPlanSchema, SpacecraftDesignSchema, type Mission } from '../data/schemas';

const PREFIX = 'NEXUS1.';

export const SharedDesignSchema = z.object({
  templateId: z.string().min(1),
  objectiveId: z.string().min(1),
  difficulty: DifficultySchema,
  name: z.string().max(80),
  design: SpacecraftDesignSchema,
  plan: MissionPlanSchema.nullable(),
});
export type SharedDesign = z.infer<typeof SharedDesignSchema>;

function toBase64Url(text: string): string {
  const bytes = new TextEncoder().encode(text);
  let bin = '';
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function fromBase64Url(code: string): string {
  const b64 = code.replace(/-/g, '+').replace(/_/g, '/');
  const bin = atob(b64 + '='.repeat((4 - (b64.length % 4)) % 4));
  return new TextDecoder().decode(Uint8Array.from(bin, (c) => c.charCodeAt(0)));
}

export function encodeShare(m: Mission): string {
  const payload: SharedDesign = { templateId: m.templateId, objectiveId: m.objectiveId, difficulty: m.difficulty, name: m.name, design: m.design, plan: m.plan };
  return PREFIX + toBase64Url(JSON.stringify(payload));
}

export class ShareCodeError extends Error {}

export function decodeShare(code: string): SharedDesign {
  const c = code.trim();
  if (!c.startsWith(PREFIX)) throw new ShareCodeError('El código debe empezar por «NEXUS1.».');
  let json: unknown;
  try {
    json = JSON.parse(fromBase64Url(c.slice(PREFIX.length)));
  } catch {
    throw new ShareCodeError('El código está incompleto o dañado: cópialo entero.');
  }
  const r = SharedDesignSchema.safeParse(json);
  if (!r.success) throw new ShareCodeError('El código no contiene un diseño válido de NEXUS.');
  return r.data;
}
