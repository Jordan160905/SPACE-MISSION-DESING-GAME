import { describe, expect, it } from 'vitest';
import { LUNA_01, MISSION_TEMPLATES } from '../data/missions/missions';
import {
  createMission,
  EMPTY_SAVE,
  MissionError,
  removeMission,
  sanitizeSave,
  stageProgress,
  stageStatus,
  upsertMission,
} from './missionLogic';
import { loadSave, SAVE_KEY, writeSave, type KeyValueStorage } from './persistence';

const now = new Date('2026-11-12T12:00:00Z');

function memoryStorage(): KeyValueStorage & { data: Map<string, string> } {
  const data = new Map<string, string>();
  return { data, getItem: (k) => data.get(k) ?? null, setItem: (k, v) => void data.set(k, v) };
}

describe('createMission', () => {
  it('crea una misión en etapa de diseño con nave vacía', () => {
    const m = createMission({ template: LUNA_01, objectiveId: 'obj-mapping', id: 'x1', now });
    expect(m.stage).toBe('DESIGN');
    expect(m.design).toEqual({ chassisId: null, parts: [] });
    expect(m.name).toBe('LUNA-01 · Intento 1');
    expect(m.createdAt).toBe('2026-11-12T12:00:00.000Z');
  });

  it('numera los intentos', () => {
    const m = createMission({ template: LUNA_01, objectiveId: 'obj-mineral', id: 'x2', now, existingCount: 2 });
    expect(m.name).toBe('LUNA-01 · Intento 3');
  });

  it('rechaza objetivos que no pertenecen a la misión', () => {
    expect(() => createMission({ template: LUNA_01, objectiveId: 'nope', id: 'x', now })).toThrow(MissionError);
  });

  it('rechaza misiones bloqueadas', () => {
    const locked = MISSION_TEMPLATES.find((t) => !t.available)!;
    expect(() => createMission({ template: locked, objectiveId: 'obj-mapping', id: 'x', now })).toThrow(MissionError);
  });
});

describe('etapas', () => {
  it('diseño es la etapa actual y el resto están bloqueadas', () => {
    const m = createMission({ template: LUNA_01, objectiveId: 'obj-mapping', id: 'x', now });
    expect(stageStatus(m, 'DESIGN')).toBe('current');
    expect(stageStatus(m, 'LAUNCH')).toBe('locked');
    expect(stageProgress(m)).toBe(0);
    const later = { ...m, stage: 'LAUNCH' as const };
    expect(stageStatus(later, 'DESIGN')).toBe('done');
    expect(stageProgress(later)).toBeCloseTo(0.4, 10);
  });
});

describe('lista de misiones', () => {
  it('upsert añade y reemplaza; remove elimina', () => {
    const a = createMission({ template: LUNA_01, objectiveId: 'obj-mapping', id: 'a', now });
    let list = upsertMission([], a);
    expect(list).toHaveLength(1);
    list = upsertMission(list, { ...a, name: 'Renombrada' });
    expect(list).toHaveLength(1);
    expect(list[0].name).toBe('Renombrada');
    expect(removeMission(list, 'a')).toHaveLength(0);
  });
});

describe('guardado', () => {
  it('sanitizeSave acepta un guardado válido', () => {
    const m = createMission({ template: LUNA_01, objectiveId: 'obj-mapping', id: 'a', now });
    const save = { ...EMPTY_SAVE, missions: [m], activeMissionId: 'a' };
    expect(sanitizeSave(save)).toEqual({ save, dropped: 0 });
  });

  it('descarta misiones corruptas y conserva las válidas', () => {
    const m = createMission({ template: LUNA_01, objectiveId: 'obj-mapping', id: 'a', now });
    const raw = { ...EMPTY_SAVE, missions: [m, { id: 'roto' }], activeMissionId: 'roto' };
    const { save, dropped } = sanitizeSave(raw);
    expect(dropped).toBe(1);
    expect(save.missions).toHaveLength(1);
    expect(save.activeMissionId).toBe(null);
  });

  it('basura total devuelve el guardado vacío', () => {
    expect(sanitizeSave('hola').save).toEqual(EMPTY_SAVE);
    expect(sanitizeSave(null).save).toEqual(EMPTY_SAVE);
  });

  it('ida y vuelta por almacenamiento', () => {
    const st = memoryStorage();
    const m = createMission({ template: LUNA_01, objectiveId: 'obj-polar-ice', id: 'z', now });
    const save = { ...EMPTY_SAVE, missions: [m], activeMissionId: 'z' };
    expect(writeSave(st, save)).toBe(true);
    expect(st.data.has(SAVE_KEY)).toBe(true);
    expect(loadSave(st).save).toEqual(save);
  });

  it('JSON corrupto no rompe la carga', () => {
    const st = memoryStorage();
    st.setItem(SAVE_KEY, '{no es json');
    expect(loadSave(st).save).toEqual(EMPTY_SAVE);
    expect(loadSave(null).save).toEqual(EMPTY_SAVE);
  });
});
