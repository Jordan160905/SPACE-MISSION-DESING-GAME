import type { SaveFile } from '../data/schemas';
import { EMPTY_SAVE, sanitizeSave } from './missionLogic';

export const SAVE_KEY = 'nexus-mission-control/save-v1';

/** Interfaz mínima de almacenamiento (localStorage o un sustituto en pruebas). */
export interface KeyValueStorage {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
}

export function getBrowserStorage(): KeyValueStorage | null {
  try {
    if (typeof window === 'undefined' || !window.localStorage) return null;
    const probe = '__nexus_probe__';
    window.localStorage.setItem(probe, '1');
    window.localStorage.removeItem(probe);
    return window.localStorage;
  } catch {
    return null; // modo privado, iframe sin almacenamiento, etc.
  }
}

export function loadSave(storage: KeyValueStorage | null): { save: SaveFile; dropped: number } {
  if (!storage) return { save: EMPTY_SAVE, dropped: 0 };
  try {
    const raw = storage.getItem(SAVE_KEY);
    if (!raw) return { save: EMPTY_SAVE, dropped: 0 };
    return sanitizeSave(JSON.parse(raw));
  } catch {
    return { save: EMPTY_SAVE, dropped: 0 };
  }
}

export function writeSave(storage: KeyValueStorage | null, save: SaveFile): boolean {
  if (!storage) return false;
  try {
    storage.setItem(SAVE_KEY, JSON.stringify(save));
    return true;
  } catch {
    return false;
  }
}
