/**
 * Estado global del juego (Zustand).
 *
 * - Navegación entre secciones (máquina de estados simple, ver docs/DECISIONS.md D-02).
 * - Misiones del jugador y perfil de agencia (persistidos en localStorage, validados con Zod).
 * - Borrador del Spacecraft Lab (en memoria hasta que el jugador lo guarda en la misión).
 *
 * Las reglas viven en missionLogic.ts y sim/DesignSystem.ts; aquí solo se orquestan.
 */
import { create } from 'zustand';
import { getComponent } from '../data/components/catalog';
import { getMissionTemplate, templateForMission } from '../data/missions/missions';
import type { AgencyProfile, ComponentCategory, Mission, MissionPlan, SaveFile, SpacecraftDesign, TeamRole } from '../data/schemas';
import { DesignError, EMPTY_DESIGN, movePart, placePart, removePart, setChassis } from '../sim/DesignSystem';
import { analysisInputForMission, analyzeEngineering } from '../sim/EngineeringAnalysis';
import { analyzePlan, defaultPlan } from '../sim/PlanningSystem';
import { designTotals } from '../sim/DesignSystem';
import { CRUISE_HOURS, launchTimeline, nextEvent } from '../sim/LaunchSystem';
import { buildFlightModel, initFlight, setInstrument, stepFlight, type FlightModel } from '../sim/MissionSystem';
import { eventContext, resolveEvent, scheduleEvents } from '../sim/EventSystem';
import { scoreMission } from '../sim/ScoringSystem';
import { getLauncher, LUNAR_LAUNCHERS } from '../data/launchers/launchers';
import { createMission, MissionError, removeMission, STAGE_ORDER, upsertMission, withDesign, withFlight, withPlan, withEllipticalStudy, withResult, withStage, withTeamDecision } from './missionLogic';
import { decodeShare, ShareCodeError } from './shareCode';
import { tallyVotes } from '../sim/TeamSystem';
import { difficultyDef } from '../data/difficulty';
import { getBrowserStorage, loadSave, writeSave } from './persistence';

export type Screen = 'center' | 'briefing' | 'lab' | 'analysis' | 'planner' | 'review' | 'flight' | 'archive' | 'glossary';
export type CenterTab = 'objectives' | 'budget' | 'progress';

export interface LabState {
  draft: SpacecraftDesign;
  /** Misión a la que pertenece el borrador (null = modo libre sin misión). */
  missionId: string | null;
  dirty: boolean;
  /** Pieza «en la mano»: del catálogo o una pieza existente que se está moviendo. */
  armed: { componentId: string; moveInstanceId?: string } | null;
  dragging: boolean;
  /** instanceId de la pieza seleccionada, o 'chassis'. */
  selectedId: string | null;
  xray: boolean;
  /** 'craft' = construir la nave · 'rocket' = ver la nave integrada en el cohete. */
  view: 'craft' | 'rocket';
  rocket: { launcherId: string; fairing: 'closed' | 'cutaway' | 'open'; exploded: boolean; labels: boolean };
  /** Categoría abierta en el catálogo y piezas destacadas (al pulsar un parámetro o «Solucionar problema»). */
  catalogCategory: ComponentCategory;
  highlight: string[];
}

export interface LaunchState {
  phase: 'ready' | 'countdown' | 'flight' | 'arrived' | 'cruise' | 'lunar-arrival';
  /** Horas de crucero transcurridas (0–96). */
  cruiseH: number;
  /** Tiempo de misión en segundos (negativo durante la cuenta regresiva). */
  t: number;
  running: boolean;
  /** Aceleración del tiempo tras el despegue (×1, ×10, ×60…). */
  speed: number;
}

export interface OpsSample {
  tH: number;
  battery: number;
  storage: number;
  deliveredGbit: number;
}

export interface TeamVoteRequest {
  kind: 'design' | 'plan' | 'event';
  label: string;
  options: Array<{ id: string; label: string }>;
  /** Mejor opción según la previsión del motor (solo acontecimientos). */
  bestOptionId?: string;
}

export interface MissionSetup {
  difficulty: Mission['difficulty'];
  team: Mission['team'];
}

export interface GameState {
  screen: Screen;
  centerTab: CenterTab;
  briefingTemplateId: string | null;
  missionSelectOpen: boolean;
  tutorialStep: number | null;
  notice: { kind: 'info' | 'error'; text: string } | null;

  profile: AgencyProfile;
  missions: Mission[];
  activeMissionId: string | null;

  lab: LabState;
  launch: LaunchState;
  /** Telemetría reciente (solo en memoria; el estado de vuelo sí se guarda). */
  opsHistory: { missionId: string | null; samples: OpsSample[] };
  /** Votación del equipo en curso (modo equipo). */
  teamVote: TeamVoteRequest | null;

  navigate: (screen: Screen) => void;
  setCenterTab: (tab: CenterTab) => void;
  openMissionSelect: (open: boolean) => void;
  openBriefing: (templateId: string) => void;
  acceptMission: (objectiveId: string, setup?: MissionSetup) => void;
  /** Abre la votación del equipo (si la misión tiene equipo) o ejecuta la decisión directamente. */
  requestDecision: (req: TeamVoteRequest, direct: () => void) => void;
  submitTeamVote: (votes: Array<{ role: TeamRole; choice: string }>) => void;
  cancelTeamVote: () => void;
  /** Crea una misión nueva a partir de un código compartido. */
  importShared: (code: string) => boolean;
  setActiveMission: (id: string) => void;
  deleteMission: (id: string) => void;
  setTutorialStep: (step: number | null) => void;
  completeTutorial: () => void;
  dismissNotice: () => void;

  labSetChassis: (chassisId: string | null) => void;
  labArm: (componentId: string | null) => void;
  labArmMove: (instanceId: string) => void;
  labStartDrag: (componentId: string) => void;
  labEndDrag: () => void;
  /** Suelta/coloca la pieza armada en un anclaje. */
  labDropOn: (socketId: string) => void;
  labRemove: (instanceId: string) => void;
  labSelect: (id: string | null) => void;
  labToggleXray: () => void;
  labSave: () => void;
  labRevert: () => void;
  labSetView: (view: LabState['view']) => void;
  /** Aprueba el diseño GUARDADO de la misión activa si el análisis no tiene críticos → Planificación. */
  approveDesign: () => void;
  /** Cambia el plan de vuelo de la misión activa (se guarda al momento). */
  plannerUpdate: (patch: Partial<MissionPlan>) => void;
  /** Anota en el registro de compromisos (CML 3) un estudio de órbita elíptica. */
  noteEllipticalStudy: () => void;
  /** Confirma el plan si el análisis completo no tiene críticos → etapa Lanzamiento. */
  confirmPlan: () => void;
  launchStartCountdown: () => void;
  launchAbort: () => void;
  launchAdvance: (realSeconds: number) => void;
  launchSetSpeed: (speed: number) => void;
  launchTogglePause: () => void;
  launchSkipToNext: () => void;
  /** Tras la separación: comienza el crucero de 4 días (animado). */
  launchStartCruise: () => void;
  /** Encendido de inserción en órbita lunar → etapa Operaciones. */
  launchFinish: () => void;
  opsAdvance: (hours: number) => void;
  opsSetInstrument: (instanceId: string, on: boolean) => void;
  /** Decide ante el acontecimiento pendiente. */
  opsResolveEvent: (optionId: string) => void;
  /** Cierra el informe: suma la XP y archiva la misión (etapa Completada). */
  archiveMission: () => void;
  /** Nuevo intento de la misma misión, con el diseño copiado o desde cero. */
  retryMission: (copyDesign: boolean) => void;
  labSetRocket: (patch: Partial<LabState['rocket']>) => void;
  /** Abre una categoría del catálogo y destaca las piezas que resuelven un problema, sin salir del LAB. */
  labFocusCatalog: (category: ComponentCategory, highlight?: string[]) => void;
  markLabHintSeen: () => void;
  /** Guarda el borrador del LAB (si hay cambios) y abre la pantalla de análisis y aprobación. */
  labGoAnalyze: () => void;
}

function newId(): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) return crypto.randomUUID();
  return `m-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

const storage = getBrowserStorage();
const initial = loadSave(storage);

const freshLab = (draft: SpacecraftDesign = EMPTY_DESIGN, missionId: string | null = null): LabState => ({
  draft,
  missionId,
  dirty: false,
  armed: null,
  dragging: false,
  selectedId: null,
  xray: false,
  view: 'craft',
  rocket: { launcherId: 'falcon-9', fairing: 'cutaway', exploded: false, labels: false },
  catalogCategory: 'STRUCTURE',
  highlight: [],
});

const nameOf = (id: string) => getComponent(id)?.name ?? id;

/** Modelo de vuelo, plantilla, objetivo y presupuesto comprometido de una misión en vuelo. */
export function flightContextOf(mission: Mission) {
  const template = templateForMission(mission);
  const objective = template?.objectives.find((o) => o.id === mission.objectiveId);
  if (!template || !objective || !mission.plan) return null;
  const model = buildFlightModel(mission.design, getComponent, mission.plan, objective.dataTargetGbit);
  const budget = analyzeEngineering(analysisInputForMission(mission.design, getComponent, mission, getMissionTemplate)).budget;
  if (!budget) return null;
  const remaining = template.budgetCapMUSD - budget.committedMUSD - (mission.flight?.extraCostMUSD ?? 0);
  return { template, objective, model, budget, ctx: eventContext(mission.design, getComponent, model, remaining) };
}

/** Acción diferida mientras el equipo vota (no se guarda: es estado de la interfaz). */
let pendingDecision: (() => void) | null = null;

export const useGameStore = create<GameState>()((set, get) => {
  /** Aplica un cambio al borrador capturando los errores de reglas como aviso. */
  const editDraft = (fn: (d: SpacecraftDesign) => { draft: SpacecraftDesign; patch?: Partial<LabState>; text?: string }) => {
    const { lab } = get();
    try {
      const r = fn(lab.draft);
      set({ lab: { ...lab, draft: r.draft, dirty: true, ...r.patch }, ...(r.text ? { notice: { kind: 'info' as const, text: r.text } } : {}) });
    } catch (e) {
      if (!(e instanceof DesignError)) throw e;
      set({ lab: { ...lab, armed: null, dragging: false }, notice: { kind: 'error', text: e.message } });
    }
  };

  return {
    screen: 'center',
    centerTab: 'objectives',
    briefingTemplateId: null,
    missionSelectOpen: false,
    tutorialStep: initial.save.profile.tutorialDone ? null : 0,
    notice:
      initial.dropped > 0
        ? { kind: 'error', text: `Se descartaron ${initial.dropped} misiones guardadas con datos inválidos.` }
        : storage
          ? null
          : { kind: 'info', text: 'El navegador no permite guardar: el progreso se perderá al cerrar la pestaña.' },

    profile: initial.save.profile,
    missions: initial.save.missions,
    activeMissionId: initial.save.activeMissionId,

    lab: freshLab(),
    launch: { phase: 'ready', t: -10, running: false, speed: 30, cruiseH: 0 },
    opsHistory: { missionId: null, samples: [] },
    teamVote: null,

    navigate: (screen) => {
      const s = get();
      let lab = s.lab;
      let notice = s.notice;
      if (screen === 'lab') {
        // Carga el diseño guardado si el borrador corresponde a otra misión (o a ninguna).
        const mission = s.missions.find((m) => m.id === s.activeMissionId) ?? null;
        if ((mission?.id ?? null) !== lab.missionId) lab = { ...freshLab(mission?.design ?? EMPTY_DESIGN, mission?.id ?? null), view: lab.view, rocket: lab.rocket };
        if (mission?.plan) lab = { ...lab, rocket: { ...lab.rocket, launcherId: mission.plan.launcherId } };
      } else if (s.screen === 'lab') {
        lab = { ...lab, armed: null, dragging: false };
        if (lab.dirty && lab.missionId) notice = { kind: 'info', text: 'Tienes cambios sin guardar en el Spacecraft Lab.' };
      }
      let missions = s.missions;
      if (screen === 'planner') {
        const mission = s.missions.find((m) => m.id === s.activeMissionId);
        const template = mission && templateForMission(mission);
        if (mission && template && !mission.plan && mission.stage !== 'DESIGN') {
          missions = upsertMission(missions, withPlan(mission, defaultPlan(mission.design, getComponent, template, mission.objectiveId), new Date()));
        }
      }
      set({ screen, missionSelectOpen: false, lab, notice, missions });
    },
    setCenterTab: (centerTab) => set({ centerTab }),
    openMissionSelect: (missionSelectOpen) => set({ missionSelectOpen }),

    openBriefing: (templateId) => {
      const t = getMissionTemplate(templateId);
      if (!t) return set({ notice: { kind: 'error', text: `Misión desconocida: ${templateId}` } });
      if (!t.available) return set({ notice: { kind: 'info', text: `${t.code}: ${t.lockReason ?? 'bloqueada'}` } });
      set({ briefingTemplateId: templateId, screen: 'briefing', missionSelectOpen: false });
    },

    acceptMission: (objectiveId, setup) => {
      const { briefingTemplateId, missions } = get();
      const template = briefingTemplateId ? getMissionTemplate(briefingTemplateId) : undefined;
      if (!template) return set({ notice: { kind: 'error', text: 'No hay misión seleccionada.' } });
      try {
        const mission = createMission({
          template,
          objectiveId,
          id: newId(),
          now: new Date(),
          existingCount: missions.filter((m) => m.templateId === template.id).length,
          difficulty: setup?.difficulty,
          team: setup?.team ?? null,
        });
        set({
          missions: upsertMission(missions, mission),
          activeMissionId: mission.id,
          screen: 'center',
          centerTab: 'progress',
          notice: { kind: 'info', text: `${mission.name} creada. Siguiente paso: diseñar la nave en el Spacecraft Lab.` },
        });
      } catch (e) {
        const text = e instanceof MissionError ? e.message : 'No se pudo crear la misión.';
        set({ notice: { kind: 'error', text } });
      }
    },

    setActiveMission: (id) => {
      if (!get().missions.some((m) => m.id === id)) return;
      set({ activeMissionId: id, screen: 'center', centerTab: 'progress' });
    },

    deleteMission: (id) => {
      const { missions, activeMissionId, lab } = get();
      set({
        missions: removeMission(missions, id),
        activeMissionId: activeMissionId === id ? null : activeMissionId,
        lab: lab.missionId === id ? freshLab() : lab,
      });
    },

    setTutorialStep: (tutorialStep) => set({ tutorialStep }),
    completeTutorial: () => set((s) => ({ tutorialStep: null, profile: { ...s.profile, tutorialDone: true } })),
    dismissNotice: () => set({ notice: null }),

    // ───────── Spacecraft Lab ─────────
    labSetChassis: (chassisId) =>
      editDraft((d) => {
        const r = setChassis(d, chassisId, getComponent);
        const parts: string[] = [];
        if (r.relocated.length) parts.push(`Reubicadas: ${r.relocated.map((p) => nameOf(p.componentId)).join(', ')}.`);
        if (r.removed.length && chassisId) parts.push(`No caben y se retiraron: ${r.removed.map((p) => nameOf(p.componentId)).join(', ')}.`);
        return {
          draft: r.design,
          patch: { armed: null, dragging: false, selectedId: chassisId ? 'chassis' : null },
          text: chassisId ? `${nameOf(chassisId)} instalado. ${parts.join(' ')}`.trim() : 'Diseño vaciado.',
        };
      }),

    labArm: (componentId) => {
      const { lab: current } = get();
      // Elegir una pieza siempre devuelve a la vista de construcción.
      const lab = current.view === 'craft' ? current : { ...current, view: 'craft' as const };
      if (componentId && getComponent(componentId)?.category === 'STRUCTURE') return get().labSetChassis(componentId);
      const same = lab.armed?.componentId === componentId && !lab.armed?.moveInstanceId;
      set({ lab: { ...lab, armed: componentId && !same ? { componentId } : null, dragging: false } });
    },

    labArmMove: (instanceId) => {
      const { lab } = get();
      const part = lab.draft.parts.find((p) => p.instanceId === instanceId);
      if (!part) return;
      set({ lab: { ...lab, armed: { componentId: part.componentId, moveInstanceId: instanceId }, selectedId: instanceId } });
    },

    labStartDrag: (componentId) => {
      const { lab } = get();
      set({ lab: { ...lab, armed: { componentId }, dragging: true } });
    },

    labEndDrag: () => {
      const { lab } = get();
      if (!lab.dragging) return;
      const armed = lab.armed;
      // Soltar un chasis en cualquier punto lo instala.
      if (armed && getComponent(armed.componentId)?.category === 'STRUCTURE') return get().labSetChassis(armed.componentId);
      set({ lab: { ...lab, armed: null, dragging: false } });
    },

    labDropOn: (socketId) => {
      const { lab } = get();
      const armed = lab.armed;
      if (!armed) return;
      if (getComponent(armed.componentId)?.category === 'STRUCTURE') return get().labSetChassis(armed.componentId);
      if (armed.moveInstanceId) {
        const id = armed.moveInstanceId;
        return editDraft((d) => ({
          draft: movePart(d, id, socketId, getComponent),
          patch: { armed: null, dragging: false, selectedId: id },
        }));
      }
      editDraft((d) => {
        const r = placePart(d, armed.componentId, socketId, getComponent);
        // Tras un clic (no arrastre) se mantiene armada para colocar varias iguales.
        return { draft: r.design, patch: { armed: lab.dragging ? null : armed, dragging: false, selectedId: r.instanceId } };
      });
    },

    labRemove: (instanceId) =>
      editDraft((d) => ({ draft: removePart(d, instanceId), patch: { selectedId: null, armed: null } })),

    labSelect: (selectedId) => set((s) => ({ lab: { ...s.lab, selectedId } })),
    labToggleXray: () => set((s) => ({ lab: { ...s.lab, xray: !s.lab.xray } })),

    labSave: () => {
      const { lab, missions } = get();
      const mission = missions.find((m) => m.id === lab.missionId);
      if (!mission) return set({ notice: { kind: 'error', text: 'Crea o carga una misión para guardar el diseño.' } });
      if (STAGE_ORDER.indexOf(mission.stage) > STAGE_ORDER.indexOf('LAUNCH')) {
        return set({ notice: { kind: 'info', text: 'Esta nave ya está en vuelo: su diseño no se puede cambiar. Crea un nuevo intento para probar otro diseño.' } });
      }
      let updated = withDesign(mission, lab.draft, new Date());
      let text = `Diseño guardado en ${mission.name}.`;
      // Un diseño aprobado que cambia debe volver a pasar el análisis.
      if ((mission.stage === 'PLANNING' || mission.stage === 'LAUNCH') && JSON.stringify(mission.design) !== JSON.stringify(lab.draft)) {
        updated = withStage(updated, 'DESIGN', new Date());
        text += ' El diseño cambió: vuelve a aprobarlo en el análisis de ingeniería.';
      }
      set({ missions: upsertMission(missions, updated), lab: { ...lab, dirty: false }, notice: { kind: 'info', text } });
    },

    labRevert: () => {
      const { lab, missions } = get();
      const mission = missions.find((m) => m.id === lab.missionId);
      set({ lab: { ...freshLab(mission?.design ?? EMPTY_DESIGN, mission?.id ?? null), view: lab.view, rocket: lab.rocket } });
    },

    approveDesign: () => {
      const { missions, activeMissionId, lab } = get();
      const mission = missions.find((m) => m.id === activeMissionId);
      if (!mission) return set({ notice: { kind: 'error', text: 'No hay misión activa.' } });
      if (mission.stage !== 'DESIGN') return;
      if (lab.missionId === mission.id && lab.dirty) return set({ notice: { kind: 'error', text: 'Guarda el diseño antes de aprobarlo.' } });
      const report = analyzeEngineering(analysisInputForMission(mission.design, getComponent, mission, getMissionTemplate));
      if (!report.viable) {
        const n = report.issues.filter((i) => i.severity === 'critical').length;
        return set({ notice: { kind: 'error', text: `No se puede aprobar: el diseño tiene ${n} problema(s) crítico(s).` } });
      }
      const template = templateForMission(mission);
      let approved = withStage(mission, 'PLANNING', new Date());
      if (!approved.plan && template) approved = withPlan(approved, defaultPlan(approved.design, getComponent, template, approved.objectiveId), new Date());
      set({
        missions: upsertMission(missions, approved),
        notice: { kind: 'info', text: 'Diseño aprobado. Siguiente etapa: Planificación en el Mission Planner.' },
      });
    },

    requestDecision: (req, direct) => {
      const mission = get().missions.find((m) => m.id === get().activeMissionId);
      if (!mission?.team) return direct();
      pendingDecision = direct;
      set({ teamVote: req });
    },
    submitTeamVote: (votes) => {
      const { teamVote, missions, activeMissionId } = get();
      const mission = missions.find((m) => m.id === activeMissionId);
      const run = pendingDecision;
      if (!teamVote || !mission?.team || !votes.length) return;
      const roles = new Set(mission.team.members.map((m) => m.role));
      const valid = votes.filter((v) => roles.has(v.role) && teamVote.options.some((o) => o.id === v.choice));
      if (valid.length !== roles.size) return set({ notice: { kind: 'error', text: 'Falta el voto de algún miembro del equipo.' } });
      const t = tallyVotes(valid);
      const label = teamVote.options.find((o) => o.id === t.outcome)?.label ?? t.outcome;
      const decision = {
        kind: teamVote.kind,
        atISO: new Date().toISOString(),
        label: teamVote.label,
        votes: valid,
        outcome: t.outcome,
        unanimous: t.unanimous,
        ...(teamVote.bestOptionId ? { bestShare: valid.filter((v) => v.choice === teamVote.bestOptionId).length / valid.length } : {}),
      };
      pendingDecision = null;
      set({
        missions: upsertMission(missions, withTeamDecision(mission, decision, new Date())),
        teamVote: null,
        notice: { kind: 'info', text: `El equipo decidió: ${label}${t.unanimous ? ' (unanimidad)' : t.tieBrokenByDirector ? ' (empate: desempató la dirección)' : ' (por mayoría)'}.` },
      });
      // Ejecuta la decisión elegida (aprobar / confirmar / opción del acontecimiento).
      if (teamVote.kind === 'event') get().opsResolveEvent(t.outcome);
      else if (t.outcome === 'approve' && run) run();
    },
    cancelTeamVote: () => {
      pendingDecision = null;
      set({ teamVote: null });
    },
    importShared: (code) => {
      try {
        const shared = decodeShare(code);
        const template = getMissionTemplate(shared.templateId);
        if (!template) throw new ShareCodeError('La misión de ese código no existe en esta versión.');
        const { missions } = get();
        let mission = createMission({
          template,
          objectiveId: shared.objectiveId,
          id: newId(),
          now: new Date(),
          existingCount: missions.filter((m) => m.templateId === template.id).length,
          difficulty: shared.difficulty,
        });
        mission = withDesign(mission, shared.design, new Date());
        mission = { ...mission, name: `${mission.name} · importado` };
        set({
          missions: upsertMission(missions, mission),
          activeMissionId: mission.id,
          screen: 'lab',
          lab: { ...freshLab(mission.design, mission.id), view: get().lab.view, rocket: get().lab.rocket },
          notice: { kind: 'info', text: `Diseño «${shared.name}» importado. Revísalo en el Lab y apruébalo para planificar.` },
        });
        return true;
      } catch (e) {
        set({ notice: { kind: 'error', text: e instanceof ShareCodeError || e instanceof MissionError ? e.message : 'No se pudo importar el diseño.' } });
        return false;
      }
    },
    labFocusCatalog: (catalogCategory, highlight = []) => {
      const { lab } = get();
      // Conserva el diseño, la selección, la vista interna y la cámara: solo cambia el catálogo.
      set({ screen: 'lab', lab: { ...lab, view: 'craft', catalogCategory, highlight } });
    },
    labGoAnalyze: () => {
      const { lab, missions } = get();
      const mission = missions.find((m) => m.id === lab.missionId);
      if (!mission) return set({ notice: { kind: 'error', text: 'Crea una misión para analizar el diseño.' } });
      if (lab.dirty) get().labSave();
      set({ screen: 'analysis' });
    },
    markLabHintSeen: () => set((s) => (s.profile.labHintSeen ? {} : { profile: { ...s.profile, labHintSeen: true } })),
    noteEllipticalStudy: () => {
      const { missions, activeMissionId } = get();
      const mission = missions.find((m) => m.id === activeMissionId);
      if (!mission) return;
      set({ missions: upsertMission(missions, withEllipticalStudy(mission, new Date())) });
    },
    plannerUpdate: (patch) => {
      const { missions, activeMissionId } = get();
      const mission = missions.find((m) => m.id === activeMissionId);
      const template = mission && templateForMission(mission);
      if (!mission || !template || STAGE_ORDER.indexOf(mission.stage) < STAGE_ORDER.indexOf('PLANNING')) return;
      if (STAGE_ORDER.indexOf(mission.stage) > STAGE_ORDER.indexOf('LAUNCH') || get().launch.phase !== 'ready') {
        return set({ notice: { kind: 'info', text: 'La nave ya despegó: el plan de vuelo no se puede cambiar.' } });
      }
      if (patch.launcherId) {
        // Un vehículo que no se puede contratar o no llega a la Luna nunca entra en el plan.
        const l = getLauncher(patch.launcherId);
        if (!l || !LUNAR_LAUNCHERS.includes(l)) {
          return set({ notice: { kind: 'error', text: `${l?.name ?? 'Ese vehículo'} no se puede elegir: ${l?.unavailableReason ?? 'no está disponible para ir a la Luna.'}` } });
        }
      }
      const base = mission.plan ?? defaultPlan(mission.design, getComponent, template, mission.objectiveId);
      let updated = withPlan(mission, { ...base, ...patch }, new Date());
      let notice = get().notice;
      if (mission.stage === 'LAUNCH') {
        updated = withStage(updated, 'PLANNING', new Date());
        notice = { kind: 'info', text: 'El plan cambió: vuelve a confirmarlo antes del lanzamiento.' };
      }
      set({ missions: upsertMission(missions, updated), notice });
    },

    confirmPlan: () => {
      const { missions, activeMissionId } = get();
      const mission = missions.find((m) => m.id === activeMissionId);
      const template = mission && templateForMission(mission);
      if (!mission || !template || !mission.plan || mission.stage !== 'PLANNING') return;
      const report = analyzePlan({ design: mission.design, lookup: getComponent, template, objectiveId: mission.objectiveId, plan: mission.plan, difficulty: mission.difficulty });
      if (!report.ready) {
        const n = report.issues.filter((i) => i.severity === 'critical').length;
        return set({ notice: { kind: 'error', text: `No se puede confirmar: el plan tiene ${n} problema(s) crítico(s).` } });
      }
      set({
        missions: upsertMission(missions, withStage(mission, 'LAUNCH', new Date())),
        notice: { kind: 'info', text: `Plan confirmado. ${report.launcher.name} listo en la plataforma: siguiente etapa, Lanzamiento.` },
      });
    },

    launchStartCountdown: () => {
      const { missions, activeMissionId } = get();
      const mission = missions.find((m) => m.id === activeMissionId);
      const template = mission && templateForMission(mission);
      if (!mission || !template || !mission.plan || mission.stage !== 'LAUNCH') return;
      const report = analyzePlan({ design: mission.design, lookup: getComponent, template, objectiveId: mission.objectiveId, plan: mission.plan, difficulty: mission.difficulty });
      if (!report.ready) return set({ notice: { kind: 'error', text: 'NO-GO: el plan ya no supera las verificaciones. Revísalo en el Mission Planner.' } });
      set({ launch: { ...get().launch, phase: 'countdown', t: -10, running: true } });
    },

    launchAbort: () => {
      const { launch } = get();
      if (launch.phase !== 'countdown') return;
      set({ launch: { ...launch, phase: 'ready', t: -10, running: false, cruiseH: 0 }, notice: { kind: 'info', text: 'Cuenta regresiva abortada. El cohete sigue en la plataforma.' } });
    },

    launchAdvance: (realSeconds) => {
      const { launch, missions, activeMissionId } = get();
      if (launch.phase === 'cruise') {
        // 96 h de crucero en ~6 s reales.
        const cruiseH = Math.min(CRUISE_HOURS, launch.cruiseH + realSeconds * 16);
        return set({ launch: { ...launch, cruiseH, phase: cruiseH >= CRUISE_HOURS ? 'lunar-arrival' : 'cruise', running: cruiseH < CRUISE_HOURS } });
      }
      if (!launch.running || (launch.phase !== 'countdown' && launch.phase !== 'flight')) return;
      const mission = missions.find((m) => m.id === activeMissionId);
      const launcher = (mission?.plan && getLauncher(mission.plan.launcherId)) || LUNAR_LAUNCHERS[0];
      const tl = launchTimeline(launcher);
      // La cuenta regresiva va en tiempo real; después, acelerada.
      let t = launch.t;
      if (t < 0) t = Math.min(0, t + realSeconds) + Math.max(0, t + realSeconds) * launch.speed;
      else t += realSeconds * launch.speed;
      if (t >= tl.endS) return set({ launch: { ...launch, t: tl.endS, phase: 'arrived', running: false } });
      set({ launch: { ...launch, t, phase: t >= 0 ? 'flight' : 'countdown' } });
    },

    launchSetSpeed: (speed) => set((s) => ({ launch: { ...s.launch, speed } })),
    launchTogglePause: () => set((s) => (s.launch.phase === 'flight' ? { launch: { ...s.launch, running: !s.launch.running } } : {})),

    launchSkipToNext: () => {
      const { launch, missions, activeMissionId } = get();
      if (launch.phase !== 'flight') return;
      const mission = missions.find((m) => m.id === activeMissionId);
      const tl = launchTimeline((mission?.plan && getLauncher(mission.plan.launcherId)) || LUNAR_LAUNCHERS[0]);
      const next = nextEvent(launch.t, tl);
      if (!next) return;
      set({ launch: { ...launch, t: next.tS, phase: next.tS >= tl.endS ? 'arrived' : 'flight', running: next.tS < tl.endS && launch.running } });
    },

    launchStartCruise: () => {
      const { launch } = get();
      if (launch.phase !== 'arrived') return;
      set({ launch: { ...launch, phase: 'cruise', cruiseH: 0, running: true } });
    },

    launchFinish: () => {
      const { missions, activeMissionId, launch } = get();
      const mission = missions.find((m) => m.id === activeMissionId);
      const template = mission && templateForMission(mission);
      if (!mission || !template || !mission.plan || mission.stage !== 'LAUNCH' || launch.phase !== 'lunar-arrival') return;
      const target = template.objectives.find((o) => o.id === mission.objectiveId)?.dataTargetGbit ?? 0;
      const model = buildFlightModel(mission.design, getComponent, mission.plan, target);
      const events = difficultyDef(mission.difficulty).events ? scheduleEvents(mission.id, model.durationH, model.instruments.length > 0) : [];
      const flight = initFlight(model, mission.plan, designTotals(mission.design, getComponent).propellantKg, events);
      const updated = withStage(withFlight(mission, flight, new Date()), 'OPERATIONS', new Date());
      set({
        missions: upsertMission(missions, updated),
        launch: { phase: 'ready', t: -10, running: false, speed: launch.speed, cruiseH: 0 },
        opsHistory: { missionId: mission.id, samples: [{ tH: 0, battery: 1, storage: 0, deliveredGbit: 0 }] },
        notice: { kind: 'info', text: 'Tras 4 días de crucero, la nave frenó y está en órbita lunar. ¡Comienzan las operaciones!' },
      });
    },

    opsAdvance: (hours) => {
      const { missions, activeMissionId, opsHistory } = get();
      const mission = missions.find((m) => m.id === activeMissionId);
      const template = mission && templateForMission(mission);
      if (!mission || !template || !mission.plan || !mission.flight || mission.stage !== 'OPERATIONS') return;
      const model: FlightModel = buildFlightModel(
        mission.design,
        getComponent,
        mission.plan,
        template.objectives.find((o) => o.id === mission.objectiveId)?.dataTargetGbit ?? 0,
      );
      let flight = mission.flight;
      let samples = opsHistory.missionId === mission.id ? [...opsHistory.samples] : [];
      const chunk = 0.25;
      let remaining = hours;
      while (remaining > 1e-9 && !flight.complete && !flight.pendingEventId) {
        const h = Math.min(chunk, remaining);
        flight = stepFlight(model, flight, h);
        remaining -= h;
        samples.push({
          tH: flight.elapsedH,
          battery: model.batteryCapacityWh > 0 ? flight.batteryWh / model.batteryCapacityWh : 0,
          storage: model.storageCapacityGbit > 0 ? flight.storageGbit / model.storageCapacityGbit : 0,
          deliveredGbit: flight.deliveredGbit,
        });
      }
      if (samples.length > 3000) samples = samples.slice(samples.length - 3000);
      let updated = withFlight(mission, flight, new Date());
      let notice = get().notice;
      if (flight.complete) {
        updated = withStage(updated, 'DEBRIEF', new Date());
        notice = { kind: 'info', text: 'Campaña completada. La misión pasa a la etapa de Informe.' };
      }
      set({ missions: upsertMission(missions, updated), opsHistory: { missionId: mission.id, samples }, notice });
    },

    opsSetInstrument: (instanceId, on) => {
      const { missions, activeMissionId } = get();
      const mission = missions.find((m) => m.id === activeMissionId);
      if (!mission?.flight || mission.stage !== 'OPERATIONS') return;
      const comp = getComponent(mission.design.parts.find((p) => p.instanceId === instanceId)?.componentId ?? '');
      if (!comp) return;
      set({ missions: upsertMission(missions, withFlight(mission, setInstrument(mission.flight, { instanceId, name: comp.name }, on), new Date())) });
    },

    opsResolveEvent: (optionId) => {
      const { missions, activeMissionId } = get();
      const mission = missions.find((m) => m.id === activeMissionId);
      if (!mission?.flight?.pendingEventId || mission.stage !== 'OPERATIONS') return;
      const fc = flightContextOf(mission);
      if (!fc) return;
      const next = resolveEvent(fc.ctx, mission.flight, optionId);
      if (next === mission.flight) return set({ notice: { kind: 'error', text: 'Esa opción no está disponible ahora.' } });
      set({ missions: upsertMission(missions, withFlight(mission, next, new Date())) });
    },

    archiveMission: () => {
      const { missions, activeMissionId, profile } = get();
      const mission = missions.find((m) => m.id === activeMissionId);
      if (!mission?.flight || mission.stage !== 'DEBRIEF') return;
      const fc = flightContextOf(mission);
      if (!fc) return;
      const score = scoreMission({ template: fc.template, objective: fc.objective, plan: mission.plan!, model: fc.model, flight: mission.flight, budget: fc.budget, designOptimizations: [] });
      const result = {
        score: score.total,
        grade: score.grade,
        success: score.success,
        xp: score.xp,
        deliveredGbit: mission.flight.deliveredGbit,
        spentMUSD: score.spentMUSD,
        archivedAt: new Date().toISOString(),
      };
      set({
        missions: upsertMission(missions, withStage(withResult(mission, result, new Date()), 'COMPLETE', new Date())),
        profile: {
          ...profile,
          xp: profile.xp + score.xp,
          completedMissionIds: score.success && !profile.completedMissionIds.includes(mission.id) ? [...profile.completedMissionIds, mission.id] : profile.completedMissionIds,
        },
        notice: {
          kind: 'info',
          text: score.success
            ? `Misión archivada: +${score.xp} XP. ¡${fc.template.rewards.unlocks.length ? 'Nuevas misiones desbloqueadas' : 'Enhorabuena'}!`
            : `Misión archivada: +${score.xp} XP (parcial: el objetivo científico no se cumplió).`,
        },
      });
    },

    retryMission: (copyDesign) => {
      const { missions, activeMissionId } = get();
      const old = missions.find((m) => m.id === activeMissionId);
      const template = old && templateForMission(old);
      if (!old || !template) return;
      try {
        let mission = createMission({
          template,
          objectiveId: old.objectiveId,
          id: newId(),
          now: new Date(),
          existingCount: missions.filter((m) => m.templateId === template.id).length,
          difficulty: old.difficulty,
          team: old.team,
        });
        if (copyDesign) mission = withDesign(mission, old.design, new Date());
        set({
          missions: upsertMission(missions, mission),
          activeMissionId: mission.id,
          screen: 'lab',
          lab: { ...freshLab(mission.design, mission.id), view: get().lab.view, rocket: get().lab.rocket },
          notice: { kind: 'info', text: `${mission.name}: ${copyDesign ? 'diseño copiado; modifícalo y vuelve a volar' : 'diseño desde cero'}.` },
        });
      } catch (e) {
        set({ notice: { kind: 'error', text: e instanceof MissionError ? e.message : 'No se pudo crear el nuevo intento.' } });
      }
    },

    labSetView: (view) => set((s) => ({ lab: { ...s.lab, view, armed: null, dragging: false } })),
    labSetRocket: (patch) => set((s) => ({ lab: { ...s.lab, rocket: { ...s.lab.rocket, ...patch } } })),
  };
});

// Persistencia: escribe solo cuando cambia la parte guardable.
let lastSaved = '';
useGameStore.subscribe((s) => {
  const save: SaveFile = { version: 1, profile: s.profile, missions: s.missions, activeMissionId: s.activeMissionId };
  const json = JSON.stringify(save);
  if (json === lastSaved) return;
  lastSaved = json;
  writeSave(storage, save);
});

/** Selector derivado: misión activa (o null). */
export function selectActiveMission(s: GameState): Mission | null {
  return s.missions.find((m) => m.id === s.activeMissionId) ?? null;
}

/** Instrumento exigido por el objetivo de la misión del borrador del Lab. */
export function selectLabObjectiveInstrument(s: GameState): string | undefined {
  const m = s.missions.find((x) => x.id === s.lab.missionId);
  if (!m) return undefined;
  return templateForMission(m)?.objectives.find((o) => o.id === m.objectiveId)?.primaryInstrumentId;
}
