/**
 * Geometría de la vista de operaciones (pura y probada).
 * El Sol y la Tierra están en +X (peor caso usado por el simulador: β = 0). La fase orbital
 * φ ∈ [0,1) del simulador se coloca de modo que el arco de eclipse [1 − f, 1) quede justo detrás
 * de la Luna (lado −X), así lo que se ve coincide con lo que se simula.
 */
export type V3 = [number, number, number];

export function orbitAngle(phase: number, sunlitFraction: number): number {
  const eclipseCenter = (sunlitFraction + 1) / 2;
  return 2 * Math.PI * (phase - eclipseCenter) + Math.PI;
}

/** Punto de la órbita (radio r, inclinación i en grados) para una fase del simulador. */
export function orbitPoint(phase: number, sunlitFraction: number, inclinationDeg: number, r: number): V3 {
  const th = orbitAngle(phase, sunlitFraction);
  const i = (inclinationDeg * Math.PI) / 180;
  // Plano orbital: contiene el eje X (línea Sol–Luna) y está inclinado i respecto del ecuador (XZ).
  return [r * Math.cos(th), r * Math.sin(th) * Math.sin(i), r * Math.sin(th) * Math.cos(i)];
}

/** ¿El punto está dentro de la sombra cilíndrica de una Luna de radio R (Sol en +X)? */
export function inShadow(p: V3, R: number): boolean {
  return p[0] < 0 && Math.hypot(p[1], p[2]) < R;
}

/** Puntos de la órbita completa, para dibujarla. */
export function orbitPolyline(sunlitFraction: number, inclinationDeg: number, r: number, n = 180): V3[] {
  return Array.from({ length: n + 1 }, (_, k) => orbitPoint(k / n, sunlitFraction, inclinationDeg, r));
}
