/**
 * Escena de operaciones: Luna, órbita elegida, arco de eclipse (del simulador), Tierra y Sol en +X,
 * y la nave del jugador en la posición que dicta la simulación. Línea de enlace cuando hay contacto.
 */
import { Suspense, useMemo, useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Html, OrbitControls } from '@react-three/drei';
import * as THREE from 'three';
import { getComponent } from '../../data/components/catalog';
import { templateForMission } from '../../data/missions/missions';
import { MOON_RADIUS_KM } from '../../sim/OrbitSystem';
import { buildFlightModel, snapshot } from '../../sim/MissionSystem';
import { selectActiveMission, useGameStore } from '../../state/useGameStore';
import { Starfield } from '../objects/Starfield';
import { createEarthTexture, createMoonTexture } from '../proceduralTextures';
import { SpacecraftModel } from '../spacecraft/SpacecraftModel';
import { orbitPoint, orbitPolyline } from './orbitGeometry';

/** Altitud exagerada ×4 para que la órbita se separe visualmente de la superficie. */
const ALT_EXAGGERATION = 4;
const EARTH_POS: [number, number, number] = [9, 0.6, -1.5];

function OpsContent() {
  const mission = useGameStore(selectActiveMission);
  const moonMap = useMemo(() => createMoonTexture(1024), []);
  const earthMap = useMemo(() => createEarthTexture(512), []);
  const craftRef = useRef<THREE.Group>(null);

  const model = useMemo(() => {
    if (!mission?.plan) return null;
    const t = templateForMission(mission);
    const target = t?.objectives.find((o) => o.id === mission.objectiveId)?.dataTargetGbit ?? 0;
    return buildFlightModel(mission.design, getComponent, mission.plan, target);
  }, [mission?.design, mission?.plan, mission?.templateId, mission?.objectiveId]);

  const r = 1 + (((mission?.plan?.altitudeKm ?? 100) / MOON_RADIUS_KM) * ALT_EXAGGERATION);
  const incl = mission?.plan?.inclinationDeg ?? 90;
  const sf = model?.sunlitFraction ?? 0.6;

  // Objetos THREE.Line explícitos: <line> en JSX choca con el elemento SVG del mismo nombre.
  const { litLine, darkLine } = useMemo(() => {
    const pts = orbitPolyline(sf, incl, r, 240);
    const mk = (a: typeof pts, color: string) =>
      new THREE.Line(new THREE.BufferGeometry().setFromPoints(a.map((q) => new THREE.Vector3(...q))), new THREE.LineBasicMaterial({ color }));
    const cut = Math.round(sf * 240);
    return { litLine: mk(pts.slice(0, cut + 1), '#ffb547'), darkLine: mk(pts.slice(cut), '#ff5d73') };
  }, [sf, incl, r]);

  const flight = mission?.flight;
  const snap = model && flight ? snapshot(model, flight) : null;
  const p = orbitPoint(snap?.orbitPhase ?? 0, sf, incl, r);

  useFrame((_, dt) => {
    if (craftRef.current) craftRef.current.position.lerp(new THREE.Vector3(...p), Math.min(1, dt * 6));
  });

  const link = useMemo(() => new THREE.Line(new THREE.BufferGeometry(), new THREE.LineBasicMaterial({ color: '#63e6f0', transparent: true, opacity: 0.8 })), []);
  link.geometry.setFromPoints([new THREE.Vector3(...p), new THREE.Vector3(...EARTH_POS)]);

  return (
    <>
      <color attach="background" args={['#02040a']} />
      <ambientLight intensity={0.06} />
      {/* Sol en +X: ilumina la cara diurna; la sombra cae hacia −X */}
      <directionalLight position={[30, 0, 0]} intensity={3} color="#fff4e2" />
      <Starfield count={3000} radius={120} />
      <OrbitControls makeDefault enablePan={false} minDistance={2.2} maxDistance={14} />

      <mesh rotation={[0, Math.PI, 0]}>
        <sphereGeometry args={[1, 96, 64]} />
        <meshStandardMaterial map={moonMap} roughness={0.95} />
      </mesh>
      <primitive object={litLine} />
      <primitive object={darkLine} />

      <mesh position={EARTH_POS}>
        <sphereGeometry args={[0.55, 48, 32]} />
        <meshStandardMaterial map={earthMap} emissive="#0a2a55" emissiveIntensity={0.2} />
      </mesh>
      <Html position={[EARTH_POS[0], EARTH_POS[1] + 0.85, EARTH_POS[2]]} center style={{ pointerEvents: 'none' }}>
        <div className="scene-tag">Tierra · Sol detrás</div>
      </Html>

      {snap?.contact && <primitive object={link} />}

      <group ref={craftRef} position={p}>
        <group scale={0.045}>
          {mission && <SpacecraftModel design={mission.design} />}
        </group>
        <mesh>
          <sphereGeometry args={[0.03, 12, 12]} />
          <meshBasicMaterial color={snap?.sunlit ? '#fff2c8' : '#ff5d73'} toneMapped={false} />
        </mesh>
        <Html center position={[0, 0.16, 0]} style={{ pointerEvents: 'none' }}>
          <div className="scene-tag">{snap ? (snap.sunlit ? 'Iluminada' : 'Eclipse') + (snap.contact ? ' · contacto' : '') : 'Nave'}</div>
        </Html>
      </group>
    </>
  );
}

export default function OpsScene() {
  return (
    <Canvas className="scene-canvas" dpr={[1, 1.75]} camera={{ position: [2.6, 2.2, 4.2], fov: 42, near: 0.01, far: 500 }}
      onCreated={({ gl }) => {
        gl.toneMapping = THREE.ACESFilmicToneMapping;
      }}
    >
      <Suspense fallback={null}>
        <OpsContent />
      </Suspense>
    </Canvas>
  );
}
