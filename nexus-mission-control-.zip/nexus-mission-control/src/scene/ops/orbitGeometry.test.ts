import { describe, expect, it } from 'vitest';
import { analyzeOrbit, MOON_RADIUS_KM } from '../../sim/OrbitSystem';
import { inShadow, orbitPoint } from './orbitGeometry';

describe('geometría de la vista orbital', () => {
  for (const h of [30, 75, 200]) {
    it(`a ${h} km, la nave se ve en la sombra exactamente en el arco de eclipse del simulador`, () => {
      const o = analyzeOrbit({ altitudeKm: h, inclinationDeg: 90 });
      const sf = 1 - o.eclipseFraction;
      const R = 1;
      const r = (MOON_RADIUS_KM + h) / MOON_RADIUS_KM; // a escala real
      for (let k = 0; k < 400; k++) {
        const phase = (k + 0.5) / 400;
        const simEclipse = phase >= sf;
        expect(inShadow(orbitPoint(phase, sf, 90, r), R), `fase ${phase}`).toBe(simEclipse);
      }
    });
  }

  it('la inclinación inclina el plano: 0° ecuatorial (y = 0), 90° polar (z = 0)', () => {
    for (let k = 0; k < 10; k++) {
      expect(orbitPoint(k / 10, 0.6, 0, 2)[1]).toBeCloseTo(0, 9);
      expect(orbitPoint(k / 10, 0.6, 90, 2)[2]).toBeCloseTo(0, 9);
    }
  });
});
