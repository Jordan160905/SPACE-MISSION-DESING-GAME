/**
 * Escena 3D del Mission Center. Lee el estado del juego (solo lectura + acciones de navegación);
 * el estado NO depende de la escena, de modo que la UI funciona aunque WebGL falle.
 */
import { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import * as THREE from 'three';
import { templateForMission } from '../data/missions/missions';
import { selectActiveMission, useGameStore } from '../state/useGameStore';
import { CameraRig } from './CameraRig';
import { shotForScreen, STATIONS } from './layout';
import { CommandDeck } from './objects/CommandDeck';
import { Console } from './objects/Console';
import { Earth } from './objects/Earth';
import { HoloTable } from './objects/HoloTable';
import { Starfield } from './objects/Starfield';

/** Inclinación a mostrar: punto medio de la órbita recomendada del objetivo activo; polar por defecto. */
function useHologramInclination(): { inclinationDeg: number; altitudeKm: number; label: string } {
  const mission = useGameStore(selectActiveMission);
  if (!mission) return { inclinationDeg: 90, altitudeKm: 100, label: 'Seleccionar misión' };
  const t = templateForMission(mission);
  const obj = t?.objectives.find((o) => o.id === mission.objectiveId);
  if (mission.plan) {
    return { inclinationDeg: mission.plan.inclinationDeg, altitudeKm: mission.plan.altitudeKm, label: `${t?.code ?? ''} · ${mission.plan.altitudeKm} km · ${mission.plan.inclinationDeg}°` };
  }
  if (!obj) return { inclinationDeg: 90, altitudeKm: 100, label: mission.name };
  const [a, b] = obj.recommendedOrbit.inclinationDeg;
  const [h0, h1] = obj.recommendedOrbit.altitudeKm;
  return { inclinationDeg: (a + b) / 2, altitudeKm: (h0 + h1) / 2, label: `${t!.code} · ${obj.title}` };
}

function SceneContent() {
  const screen = useGameStore((s) => s.screen);
  const tab = useGameStore((s) => s.centerTab);
  const hasMission = useGameStore((s) => s.activeMissionId !== null);
  const navigate = useGameStore((s) => s.navigate);
  const setCenterTab = useGameStore((s) => s.setCenterTab);
  const openMissionSelect = useGameStore((s) => s.openMissionSelect);
  const holo = useHologramInclination();

  const activeStation =
    screen === 'lab' ? 'lab' : screen === 'archive' ? 'archive' : screen === 'glossary' ? 'glossary' : screen === 'center' && tab === 'budget' ? 'budget' : null;

  return (
    <>
      <color attach="background" args={['#02040a']} />
      <fog attach="fog" args={['#02040a', 14, 70]} />
      <ambientLight intensity={0.25} color="#8fb3ff" />
      <directionalLight position={[30, 18, 20]} intensity={2.4} color="#fff1dc" castShadow shadow-mapSize={[1024, 1024]} />
      <hemisphereLight args={['#2c4a7a', '#05070c', 0.35]} />

      <CameraRig shot={shotForScreen(screen, tab)} />
      <Starfield />
      <Earth position={[-34, 10, -62]} radius={15} />
      <CommandDeck />
      <HoloTable
        inclinationDeg={holo.inclinationDeg}
        altitudeKm={holo.altitudeKm}
        label={holo.label}
        onActivate={() => {
          if (hasMission) {
            navigate('center');
            setCenterTab('objectives');
          } else {
            navigate('center');
            openMissionSelect(true);
          }
        }}
      />
      {STATIONS.map((st) => (
        <Console
          key={st.id}
          station={st}
          active={activeStation === st.id}
          onActivate={() => {
            navigate(st.action.screen);
            if (st.action.tab) setCenterTab(st.action.tab);
          }}
        />
      ))}
    </>
  );
}

export default function MissionCenterScene() {
  return (
    <Canvas
      className="scene-canvas"
      shadows
      dpr={[1, 1.75]}
      camera={{ position: [0, 3.4, 8.2], fov: 42, near: 0.1, far: 400 }}
      gl={{ antialias: true, powerPreference: 'high-performance' }}
      onCreated={({ gl }) => {
        gl.toneMapping = THREE.ACESFilmicToneMapping;
        gl.toneMappingExposure = 1.1;
      }}
    >
      <Suspense fallback={null}>
        <SceneContent />
      </Suspense>
    </Canvas>
  );
}
