/**
 * Distribución espacial del Mission Center y encuadres de cámara.
 * Puro (sin Three.js) para poder probarlo y reutilizarlo desde la UI.
 * Unidades de escena: 1 = 1 m. El origen es el centro de la mesa holográfica.
 */
import type { CenterTab, Screen } from '../state/useGameStore';

export type Vec3 = [number, number, number];

export type StationId = 'lab' | 'archive' | 'budget' | 'glossary';

export interface StationDef {
  id: StationId;
  title: string;
  subtitle: string;
  accent: string;
  position: Vec3;
  /** Acción de navegación al pulsar la consola. */
  action: { screen: Screen; tab?: CenterTab };
}

export const STATIONS: StationDef[] = [
  { id: 'lab', title: 'Spacecraft Lab', subtitle: 'Diseño y ensamblaje', accent: '#63e6f0', position: [-3.6, 0, -0.6], action: { screen: 'lab' } },
  { id: 'archive', title: 'Archivo', subtitle: 'Misiones guardadas', accent: '#9fb3ff', position: [-2.1, 0, -3.1], action: { screen: 'archive' } },
  { id: 'budget', title: 'Finanzas', subtitle: 'Presupuesto de misión', accent: '#ffb547', position: [2.1, 0, -3.1], action: { screen: 'center', tab: 'budget' } },
  { id: 'glossary', title: 'Biblioteca', subtitle: 'Glosario espacial', accent: '#7ef0a8', position: [3.6, 0, -0.6], action: { screen: 'glossary' } },
];

/** Rotación Y para que un objeto cuyo frente mira a +Z apunte hacia el origen. */
export function facingOrigin(p: Vec3): number {
  return Math.atan2(-p[0], -p[2]);
}

export interface CameraShot {
  position: Vec3;
  target: Vec3;
}

export const OVERVIEW_SHOT: CameraShot = { position: [0, 3.4, 8.2], target: [0, 1.1, -0.6] };
export const HOLOGRAM_SHOT: CameraShot = { position: [0.6, 2.4, 3.6], target: [0, 1.75, 0] };
/** Planner: el panel ocupa la derecha, así que el holograma se encuadra a la izquierda. */
export const PLANNER_SHOT: CameraShot = { position: [2.2, 2.3, 3.4], target: [1.55, 1.7, 0] };

/** Encuadre frente a una consola: retrocede hacia el origen y mira la pantalla. */
export function stationShot(p: Vec3, distance = 2.6): CameraShot {
  const len = Math.hypot(p[0], p[2]) || 1;
  const dir: Vec3 = [-p[0] / len, 0, -p[2] / len];
  return {
    position: [p[0] + dir[0] * distance, 1.75, p[2] + dir[2] * distance],
    target: [p[0], 1.15, p[2]],
  };
}

export function shotForScreen(screen: Screen, tab: CenterTab): CameraShot {
  switch (screen) {
    case 'briefing':
      return HOLOGRAM_SHOT;
    case 'planner':
      return PLANNER_SHOT;
    case 'review': // panel ancho: vista general de la sala
    case 'flight': // la pantalla de vuelo usa sus propias escenas (lanzamiento / órbita)
      return OVERVIEW_SHOT;
    case 'lab':
    case 'analysis':
      return stationShot(STATIONS[0].position);
    case 'archive':
      return stationShot(STATIONS[1].position);
    case 'glossary':
      return stationShot(STATIONS[3].position);
    case 'center':
      return tab === 'budget' ? stationShot(STATIONS[2].position, 3.4) : OVERVIEW_SHOT;
  }
}
