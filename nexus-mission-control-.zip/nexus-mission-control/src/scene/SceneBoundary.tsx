import { Component, type ReactNode } from 'react';

function hasWebGL(): boolean {
  try {
    const c = document.createElement('canvas');
    return !!(c.getContext('webgl2') || c.getContext('webgl'));
  } catch {
    return false;
  }
}

interface State {
  error: string | null;
}

/**
 * Aísla la escena 3D: si WebGL no está disponible o la escena falla, la interfaz del juego
 * sigue funcionando y se muestra un aviso claro en lugar de una pantalla en blanco.
 */
export class SceneBoundary extends Component<{ children: ReactNode }, State> {
  state: State = { error: hasWebGL() ? null : 'Este navegador no ofrece WebGL. La vista 3D está desactivada.' };

  static getDerivedStateFromError(err: unknown): State {
    return { error: err instanceof Error ? err.message : 'Error desconocido en la escena 3D.' };
  }

  render() {
    if (this.state.error) {
      return (
        <div className="scene-fallback" role="status">
          <div className="scene-fallback__grid" />
          <p>
            <strong>Vista 3D no disponible.</strong> {this.state.error}
          </p>
        </div>
      );
    }
    return this.props.children;
  }
}
