/**
 * Disposición geométrica del cohete (pura, en metros). y = 0 es la base de la primera etapa;
 * los motores cuelgan por debajo. Las proporciones imitan cohetes reales de dos etapas.
 */
import type { Launcher } from '../../data/schemas';
import type { Envelope } from '../../sim/EnvelopeSystem';

export interface Span {
  y0: number;
  y1: number;
}

export interface RocketLayout {
  r1: number;
  r2: number;
  engine: { count: number; bellR: number; bellLen: number; ringR: number };
  vacuumEngine: { bellR: number; bellLen: number };
  stage1: Span;
  interstage: Span;
  stage2: Span;
  adapter: Span & { rBottom: number; rTop: number };
  /** Centro del chasis de la nave. */
  craftCenterY: number;
  fairing: { y0: number; boattailTop: number; cylinderTop: number; tip: number; r: number };
  boosters: { count: number; r: number; length: number; offsetX: number; bellR: number; bellLen: number } | null;
  /** Altura total desde la boca de los motores hasta la punta de la cofia. */
  heightM: number;
  /** Desplazamientos verticales por grupo en la vista explosionada. */
  explode: { interstage: number; stage2: number; payload: number; fairing: number; fairingSpread: number; boosterSpread: number };
  /** Si la nave plegada no cabe en la cofia (comprobación detallada en la Fase 4). */
  fitsFairing: boolean;
}

/** Radio de boca de cada motor en un racimo de n (1 central + anillo). */
function clusterBell(n: number, r: number): { bellR: number; ringR: number } {
  if (n === 1) return { bellR: r * 0.6, ringR: 0 };
  const ringR = r * 0.64;
  const ringCount = n - 1;
  const bellR = Math.min(ringR * Math.sin(Math.PI / ringCount) * 0.95, ringR * 0.48, r * 0.32);
  return { bellR, ringR };
}

export function computeRocketLayout(launcher: Launcher, env: Envelope | null, exploded: boolean): RocketLayout {
  const [s1, s2] = launcher.stages;
  const r1 = s1.diameterM / 2;
  const r2 = s2.diameterM / 2;
  const { bellR, ringR } = clusterBell(s1.engines, r1);
  const bellLen = bellR * 2.2;
  const vacR = r2 * 0.62;
  const vacLen = vacR * 2.3;

  const stage1: Span = { y0: 0, y1: s1.lengthM };
  const interH = vacLen + 0.35;
  const interstage: Span = { y0: stage1.y1, y1: stage1.y1 + interH };
  const stage2: Span = { y0: interstage.y1, y1: interstage.y1 + s2.lengthM };

  const ringRadius = env ? Math.min(env.half[0], env.half[2]) * 0.9 : r2 * 0.4;
  const belowParts = env ? Math.max(0, env.belowM - 0.12) : 0;
  const adapterH = Math.max(0.45, belowParts + 0.15);
  const adapter = { y0: stage2.y1, y1: stage2.y1 + adapterH, rBottom: r2 * 0.85, rTop: ringRadius };
  const craftCenterY = adapter.y1 + 0.12 + (env ? env.half[1] : 0.5);

  const fr = Math.max(r2, launcher.fairing.innerDiameterM / 2 + 0.05);
  const boattailH = fr > r2 + 0.01 ? (fr - r2) * 1.6 : 0;
  const noseLen = fr * 1.5;
  const cylH = Math.max(launcher.fairing.heightM - noseLen * 0.4, 0.6);
  const fairing = {
    y0: stage2.y1,
    boattailTop: stage2.y1 + boattailH,
    cylinderTop: stage2.y1 + boattailH + cylH,
    tip: stage2.y1 + boattailH + cylH + noseLen,
    r: fr,
  };

  const b = launcher.boosters;
  const boosters =
    b && b.count > 0
      ? {
          count: b.count,
          r: b.diameterM / 2,
          length: b.lengthM,
          offsetX: r1 + b.diameterM / 2 + 0.08,
          bellR: (b.diameterM / 2) * 0.6,
          bellLen: (b.diameterM / 2) * 0.6 * 2.2,
        }
      : null;

  const heightM = fairing.tip + bellLen;
  const g = exploded ? heightM * 0.06 : 0;
  const fitsFairing = env ? env.diameterM <= launcher.fairing.innerDiameterM && env.heightM <= launcher.fairing.heightM : true;

  return {
    r1,
    r2,
    engine: { count: s1.engines, bellR, bellLen, ringR },
    vacuumEngine: { bellR: vacR, bellLen: vacLen },
    stage1,
    interstage,
    stage2,
    adapter,
    craftCenterY,
    fairing,
    boosters,
    heightM,
    explode: {
      interstage: g,
      stage2: g * 2,
      payload: g * 3,
      fairing: g * 4,
      fairingSpread: exploded ? fr * 1.6 : 0,
      boosterSpread: exploded ? r1 * 1.2 : 0,
    },
    fitsFairing,
  };
}
