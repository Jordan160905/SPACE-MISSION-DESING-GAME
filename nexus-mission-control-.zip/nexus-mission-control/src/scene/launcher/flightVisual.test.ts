import { describe, expect, it } from 'vitest';
import { LAUNCHERS } from '../../data/launchers/launchers';
import { launchTimeline } from '../../sim/LaunchSystem';
import { flightVisualAt } from './flightVisual';

describe('flightVisualAt', () => {
  const heavy = launchTimeline(LAUNCHERS.find((l) => l.id === 'delta-ii')!); // con propulsores acoplados
  const ev = (id: string) => heavy.events.find((e) => e.id === id)!.tS;

  it('en la plataforma todo está unido y apagado', () => {
    const v = flightVisualAt(-5, heavy);
    expect(v).toEqual({ boosterSep: 0, stage1Sep: 0, fairingSep: 0, stage2Sep: 0, plume: 0, deployed: false });
  });

  it('primera etapa encendida hasta MECO; luego se separa', () => {
    expect(flightVisualAt(10, heavy).plume).toBe(1);
    expect(flightVisualAt(heavy.mecoS + 1, heavy).plume).toBe(0);
    expect(flightVisualAt(ev('stage-sep') + 5, heavy).stage1Sep).toBeGreaterThan(0);
  });

  it('propulsores laterales se separan antes que la primera etapa', () => {
    const t = ev('booster-sep') + 3;
    const v = flightVisualAt(t, heavy);
    expect(v.boosterSep).toBeGreaterThan(0);
    expect(v.stage1Sep).toBe(0);
  });

  it('segunda etapa encendida en ascenso y en la inyección translunar', () => {
    expect(flightVisualAt(ev('ses') + 5, heavy).plume).toBe(2);
    expect(flightVisualAt(heavy.secoS + 60, heavy).plume).toBe(0);
    expect(flightVisualAt(heavy.tliStartS + 5, heavy).plume).toBe(2);
  });

  it('cofia, separación de la nave y despliegue en orden', () => {
    expect(flightVisualAt(ev('fairing') - 1, heavy).fairingSep).toBe(0);
    expect(flightVisualAt(ev('fairing') + 2, heavy).fairingSep).toBeGreaterThan(0);
    expect(flightVisualAt(ev('sc-sep') + 30, heavy).stage2Sep).toBeGreaterThan(0);
    expect(flightVisualAt(ev('deploy') - 1, heavy).deployed).toBe(false);
    expect(flightVisualAt(ev('deploy'), heavy).deployed).toBe(true);
  });

  it('sin propulsores laterales, boosterSep siempre 0', () => {
    const small = launchTimeline(LAUNCHERS[0]);
    expect(flightVisualAt(100, small).boosterSep).toBe(0);
  });
});
