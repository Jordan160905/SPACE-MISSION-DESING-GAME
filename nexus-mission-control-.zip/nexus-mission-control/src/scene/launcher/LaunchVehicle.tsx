/**
 * LaunchVehicle — cohete de dos etapas con la nave del jugador integrada bajo la cofia.
 * Toda la geometría sale de computeRocketLayout() (probada); aquí solo se dibuja.
 *
 * Componentes visibles (de abajo arriba): racimo de motores con escudo térmico, primera etapa
 * (con patrón de balanceo, túnel de cables y rótulo), [propulsores laterales], interetapa,
 * motor de vacío de la segunda etapa, segunda etapa, adaptador de carga, nave plegada, cofia.
 */
import { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Html } from '@react-three/drei';
import * as THREE from 'three';
import type { Launcher, SpacecraftDesign } from '../../data/schemas';
import type { Envelope } from '../../sim/EnvelopeSystem';
import { fmtNum } from '../../sim/units';
import { partMaterials } from '../spacecraft/materials';
import { SpacecraftModel } from '../spacecraft/SpacecraftModel';
import { computeRocketLayout } from './rocketLayout';

export type FairingMode = 'closed' | 'cutaway' | 'open';

/**
 * Estado visual durante el vuelo (Fase 5). Las distancias son desplazamientos relativos, en metros,
 * de cada pieza que se separa respecto del resto del cohete.
 */
export interface FlightVisual {
  boosterSep: number;
  stage1Sep: number;
  fairingSep: number;
  stage2Sep: number;
  /** Qué motores encienden: 0 ninguno, 1 primera etapa (y laterales), 2 segunda etapa. */
  plume: 0 | 1 | 2;
  /** Paneles desplegados (tras la separación de la nave). */
  deployed: boolean;
}

/** Chorro de gases: cono aditivo exterior + núcleo brillante, con parpadeo. */
function Plume({ radius, length, vacuum = false }: { radius: number; length: number; vacuum?: boolean }) {
  const ref = useRef<THREE.Group>(null);
  useFrame((st) => {
    if (!ref.current) return;
    const f = 1 + Math.sin(st.clock.elapsedTime * 47) * 0.04 + Math.sin(st.clock.elapsedTime * 23) * 0.03;
    ref.current.scale.set(1, f, 1);
  });
  return (
    <group ref={ref}>
      <mesh position={[0, -length / 2, 0]}>
        <cylinderGeometry args={[radius * 0.95, radius * (vacuum ? 3.2 : 1.9), length, 24, 1, true]} />
        <meshBasicMaterial color={vacuum ? '#9fc8ff' : '#ff9a3c'} transparent opacity={vacuum ? 0.28 : 0.55} blending={THREE.AdditiveBlending} depthWrite={false} side={THREE.DoubleSide} toneMapped={false} />
      </mesh>
      <mesh position={[0, -length * 0.22, 0]}>
        <cylinderGeometry args={[radius * 0.6, radius * 0.25, length * 0.44, 16, 1, true]} />
        <meshBasicMaterial color={vacuum ? '#e8f2ff' : '#fff2c8'} transparent opacity={0.9} blending={THREE.AdditiveBlending} depthWrite={false} side={THREE.DoubleSide} toneMapped={false} />
      </mesh>
    </group>
  );
}

interface Props {
  launcher: Launcher;
  design: SpacecraftDesign;
  envelope: Envelope | null;
  craftMassKg: number;
  fairingMode: FairingMode;
  exploded: boolean;
  labels: boolean;
  /** Solo durante el lanzamiento (Launch Control). */
  flight?: FlightVisual;
}

const FAR = 600; // a partir de aquí una pieza separada deja de dibujarse

function lathe(points: Array<[number, number]>, segments = 48, phiStart = 0, phiLength = Math.PI * 2) {
  return new THREE.LatheGeometry(points.map(([r, y]) => new THREE.Vector2(Math.max(r, 0.0001), y)), segments, phiStart, phiLength);
}

/** Rótulo vertical curvado sobre el fuselaje (textura de lienzo). */
function useDecalTexture(text: string) {
  return useMemo(() => {
    const c = document.createElement('canvas');
    c.width = 256;
    c.height = 1024;
    const ctx = c.getContext('2d');
    if (ctx) {
      ctx.clearRect(0, 0, 256, 1024);
      ctx.translate(128, 512);
      ctx.rotate(-Math.PI / 2);
      ctx.fillStyle = '#1b2028';
      ctx.font = '700 150px "Chakra Petch", "IBM Plex Sans", sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(text.toUpperCase(), 0, 0);
    }
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    return t;
  }, [text]);
}

function Callout({ position, title, detail, show }: { position: [number, number, number]; title: string; detail?: string; show: boolean }) {
  if (!show) return null;
  return (
    <Html position={position} style={{ pointerEvents: 'none' }} zIndexRange={[10, 0]}>
      <div className="rocket-callout">
        <span className="rocket-callout__line" />
        <strong>{title}</strong>
        {detail && <span>{detail}</span>}
      </div>
    </Html>
  );
}

function EngineBell({ bellR, bellLen, vacuum = false }: { bellR: number; bellLen: number; vacuum?: boolean }) {
  const m = partMaterials();
  const geom = useMemo(
    () =>
      lathe(
        [
          [bellR * 0.32, 0],
          [bellR * 0.3, -bellLen * 0.08],
          [bellR * 0.5, -bellLen * 0.35],
          [bellR * 0.78, -bellLen * 0.72],
          [bellR, -bellLen],
        ],
        32,
      ),
    [bellR, bellLen],
  );
  return (
    <group>
      {/* cámara de combustión y turbobomba */}
      <mesh material={m.rocketGrey} position={[0, bellR * 0.25, 0]}>
        <cylinderGeometry args={[bellR * 0.34, bellR * 0.32, bellR * 0.5, 16]} />
      </mesh>
      <mesh geometry={geom} material={vacuum ? m.engineCopper : m.engineBell} />
      {vacuum && (
        // extensión de tobera (más oscura) típica de los motores de vacío
        <mesh geometry={geom} material={m.engineBell} scale={[1.002, 0.55, 1.002]} position={[0, -bellLen * 0.45, 0]} />
      )}
    </group>
  );
}

export function LaunchVehicle({ launcher, design, envelope, craftMassKg, fairingMode, exploded, labels, flight }: Props) {
  const m = partMaterials();
  const L = useMemo(() => computeRocketLayout(launcher, envelope, exploded), [launcher, envelope, exploded]);
  const decal = useDecalTexture(launcher.name);
  const [s1, s2] = launcher.stages;
  const ex = L.explode;

  const engines = useMemo(() => {
    const out: Array<[number, number]> = [[0, 0]];
    const ring = L.engine.count - 1;
    for (let i = 0; i < ring; i++) {
      const a = (i / ring) * Math.PI * 2;
      out.push([Math.cos(a) * L.engine.ringR, Math.sin(a) * L.engine.ringR]);
    }
    return L.engine.count === 1 ? [[0, 0] as [number, number]] : out;
  }, [L.engine.count, L.engine.ringR]);

  const fairingHalves = useMemo(() => {
    const f = L.fairing;
    const pts: Array<[number, number]> = [
      [L.r2, 0],
      [f.r, f.boattailTop - f.y0],
      [f.r, f.cylinderTop - f.y0],
    ];
    const noseLen = f.tip - f.cylinderTop;
    for (let i = 1; i <= 14; i++) {
      const t = i / 14;
      pts.push([f.r * Math.pow(1 - t * t, 0.62), f.cylinderTop - f.y0 + noseLen * t]);
    }
    return [lathe(pts, 48, 0, Math.PI), lathe(pts, 48, Math.PI, Math.PI)];
  }, [L.fairing, L.r2]);

  const adapterGeom = useMemo(
    () => lathe([[L.adapter.rBottom, 0], [L.adapter.rTop, L.adapter.y1 - L.adapter.y0]], 48),
    [L.adapter],
  );

  const tankLen1 = L.stage1.y1 - L.stage1.y0;
  const rollY = L.stage1.y1 - L.r1 * 3.2;
  const calloutX = Math.max(L.fairing.r, L.r1 + (L.boosters ? L.boosters.offsetX + L.boosters.r : 0)) + 0.4 + ex.fairingSpread;
  const fairingOpenX = fairingMode === 'open' ? L.fairing.r * 1.4 : 0;
  const fairingTilt = fairingMode === 'open' ? 0.18 : 0;

  return (
    <group>
      {/* ── PRIMERA ETAPA ───────────────────────── */}
      <group position={[0, -(flight?.stage1Sep ?? 0), 0]} rotation={[0, 0, (flight?.stage1Sep ?? 0) * 0.002]} visible={(flight?.stage1Sep ?? 0) < FAR}>
        {flight?.plume === 1 &&
          engines.map(([x, z], i) => (
            <group key={`p${i}`} position={[x, -L.engine.bellLen, z]}>
              <Plume radius={L.engine.bellR} length={L.engine.bellLen * 9} />
            </group>
          ))}
        {engines.map(([x, z], i) => (
          <group key={i} position={[x, 0, z]}>
            <EngineBell bellR={L.engine.bellR} bellLen={L.engine.bellLen} />
          </group>
        ))}
        {/* escudo térmico de la base */}
        <mesh material={m.rocketGrey} position={[0, 0.02, 0]}>
          <cylinderGeometry args={[L.r1 * 0.98, L.r1 * 0.98, 0.04, 48]} />
        </mesh>
        {/* falda (sección de empuje) negra */}
        <mesh material={m.rocketBlack} position={[0, L.r1 * 0.5, 0]}>
          <cylinderGeometry args={[L.r1, L.r1 * 1.02, L.r1, 48]} />
        </mesh>
        {/* tanques */}
        <mesh material={m.rocketWhite} position={[0, L.r1 + (tankLen1 - L.r1) / 2, 0]} castShadow>
          <cylinderGeometry args={[L.r1, L.r1, tankLen1 - L.r1, 48]} />
        </mesh>
        {/* junta entre tanque de combustible y de oxidante */}
        <mesh material={m.rocketGrey} position={[0, L.r1 + (tankLen1 - L.r1) * 0.38, 0]}>
          <cylinderGeometry args={[L.r1 * 1.006, L.r1 * 1.006, 0.08, 48]} />
        </mesh>
        {/* patrón de balanceo (franjas blanco/negro para seguir la rotación en vídeo) */}
        {[0, 1, 2, 3].map((q) => (
          <mesh key={q} material={q % 2 === 0 ? m.rocketBlack : m.rocketWhite} position={[0, rollY, 0]}>
            <cylinderGeometry args={[L.r1 * 1.004, L.r1 * 1.004, L.r1 * 1.1, 24, 1, true, (q * Math.PI) / 2, Math.PI / 2]} />
          </mesh>
        ))}
        {/* túnel de cableado (raceway) */}
        <mesh material={m.rocketGrey} position={[L.r1 + 0.03, L.r1 + (tankLen1 - L.r1) / 2, 0]}>
          <boxGeometry args={[0.07, tankLen1 - L.r1 * 1.4, 0.16]} />
        </mesh>
        {/* rótulo */}
        <mesh position={[0, L.r1 + tankLen1 * 0.42, 0]}>
          <cylinderGeometry args={[L.r1 * 1.003, L.r1 * 1.003, Math.min(tankLen1 * 0.45, L.r1 * 7), 32, 1, true, 0.05, 0.55]} />
          <meshStandardMaterial map={decal} transparent roughness={0.6} />
        </mesh>
        <Callout
          show={labels}
          position={[calloutX, tankLen1 * 0.45, 0]}
          title={s1.name}
          detail={`${s1.engines} × ${s1.engineName} · ${s1.propellant} · ${s1.burnTimeS} s de combustión`}
        />
      </group>

      {/* ── PROPULSORES LATERALES ───────────────── */}
      {L.boosters &&
        [-1, 1].slice(0, L.boosters.count).map((side) => {
          const B = L.boosters!;
          const sep = flight?.boosterSep ?? 0;
          const x = side * (B.offsetX + ex.boosterSpread + sep * 0.35);
          if (sep > FAR) return null;
          return (
            <group key={side} position={[x, -sep, 0]} rotation={[0, 0, side * Math.min(sep * 0.004, 0.6)]}>
              {flight?.plume === 1 && sep === 0 && (
                <group position={[0, -B.bellLen, 0]}>
                  <Plume radius={B.bellR} length={B.bellLen * 9} />
                </group>
              )}
              <group position={[0, 0, 0]}>
                <EngineBell bellR={B.bellR} bellLen={B.bellLen} />
              </group>
              <mesh material={m.rocketWhite} position={[0, B.length / 2, 0]}>
                <cylinderGeometry args={[B.r, B.r, B.length, 32]} />
              </mesh>
              <mesh material={m.rocketBlack} position={[0, B.r * 0.4, 0]}>
                <cylinderGeometry args={[B.r * 1.01, B.r * 1.03, B.r * 0.8, 32]} />
              </mesh>
              <mesh material={m.rocketWhite} position={[0, B.length + B.r * 1.3, 0]}>
                <coneGeometry args={[B.r, B.r * 2.6, 32]} />
              </mesh>
              {/* puntales de unión */}
              {[0.15, 0.8].map((f) => (
                <mesh key={f} material={m.rocketGrey} position={[(-side * (B.offsetX + B.r - L.r1)) / 2, B.length * f, 0]} rotation={[0, 0, Math.PI / 2]}>
                  <cylinderGeometry args={[0.05, 0.05, B.offsetX - B.r - L.r1 + 0.1, 8]} />
                </mesh>
              ))}
            </group>
          );
        })}
      {L.boosters && (
        <Callout
          show={labels}
          position={[-(calloutX + L.boosters.r * 2), L.boosters.length * 0.5, 0]}
          title={`Propulsores laterales × ${L.boosters.count}`}
          detail="Se separan a los ~2 minutos"
        />
      )}

      {/* ── INTERETAPA (fibra de carbono) ───────── */}
      <group position={[0, ex.interstage - (flight?.stage1Sep ?? 0), 0]} visible={(flight?.stage1Sep ?? 0) < FAR}>
        <mesh material={m.rocketBlack} position={[0, (L.interstage.y0 + L.interstage.y1) / 2, 0]}>
          <cylinderGeometry args={[L.r2, L.r1, L.interstage.y1 - L.interstage.y0, 48, 1, true]} />
        </mesh>
        <Callout show={labels} position={[calloutX, (L.interstage.y0 + L.interstage.y1) / 2, 0]} title="Interetapa" detail="Protege el motor de vacío" />
      </group>

      {/* ── SEGUNDA ETAPA ───────────────────────── */}
      <group position={[0, ex.stage2 - (flight?.stage2Sep ?? 0), 0]} visible={(flight?.stage2Sep ?? 0) < FAR}>
        <group position={[0, L.stage2.y0, 0]}>
          <EngineBell bellR={L.vacuumEngine.bellR} bellLen={L.vacuumEngine.bellLen} vacuum />
          {flight?.plume === 2 && (
            <group position={[0, -L.vacuumEngine.bellLen, 0]}>
              <Plume radius={L.vacuumEngine.bellR} length={L.vacuumEngine.bellLen * 6} vacuum />
            </group>
          )}
        </group>
        <mesh material={m.rocketWhite} position={[0, (L.stage2.y0 + L.stage2.y1) / 2, 0]} castShadow>
          <cylinderGeometry args={[L.r2, L.r2, L.stage2.y1 - L.stage2.y0, 48]} />
        </mesh>
        <mesh material={m.rocketGrey} position={[0, L.stage2.y1 - 0.05, 0]}>
          <cylinderGeometry args={[L.r2 * 1.01, L.r2 * 1.01, 0.1, 48]} />
        </mesh>
        <Callout
          show={labels}
          position={[calloutX, (L.stage2.y0 + L.stage2.y1) / 2, 0]}
          title={s2.name}
          detail={`1 × ${s2.engineName} (vacío) · ${s2.burnTimeS} s · te lleva hacia la Luna`}
        />
      </group>

      {/* ── ADAPTADOR DE CARGA + NAVE PLEGADA ───── */}
      <group position={[0, ex.payload, 0]}>
        <mesh geometry={adapterGeom} material={m.aluminum} position={[0, L.adapter.y0 - (flight?.stage2Sep ?? 0), 0]} visible={(flight?.stage2Sep ?? 0) < FAR} />
        <group position={[0, L.craftCenterY, 0]}>
          <SpacecraftModel design={design} stowed={!flight?.deployed} />
        </group>
        <Callout show={labels} position={[calloutX, L.adapter.y0 + 0.1, 0]} title="Adaptador de carga" detail="Une la nave al cohete; se separa en órbita" />
        <Callout
          show={labels}
          position={[calloutX, L.craftCenterY, 0]}
          title="Tu nave (plegada)"
          detail={envelope ? `${fmtNum(craftMassKg)} kg · Ø ${fmtNum(envelope.diameterM, 2)} m × ${fmtNum(envelope.heightM, 2)} m` : 'Sin diseño'}
        />
      </group>

      {/* ── COFIA ───────────────────────────────── */}
      <group position={[0, L.fairing.y0 + ex.fairing - (flight?.fairingSep ?? 0) * 0.6, 0]} visible={(flight?.fairingSep ?? 0) < FAR}>
        {fairingHalves.map((geom, i) => {
          const sign = i === 0 ? 1 : -1;
          const ghost = fairingMode === 'cutaway' && i === 0;
          const fs = flight?.fairingSep ?? 0;
          return (
            <group key={i} position={[sign * (fairingOpenX + ex.fairingSpread + fs), 0, 0]} rotation={[0, 0, -sign * (fairingTilt + Math.min(fs * 0.05, 1.2))]}>
              <mesh geometry={geom} material={ghost ? m.fairingGhost : m.fairing} castShadow={!ghost} />
            </group>
          );
        })}
        <Callout
          show={labels}
          position={[calloutX, L.fairing.cylinderTop - L.fairing.y0, 0]}
          title="Cofia"
          detail={`Ø útil ${fmtNum(launcher.fairing.innerDiameterM, 2)} m × ${fmtNum(launcher.fairing.heightM, 2)} m · protege la nave en la atmósfera`}
        />
      </group>
    </group>
  );
}

/** Plataforma de lanzamiento con torre de servicio de celosía. */
export function LaunchPad({ height, radius, engineDrop }: { height: number; radius: number; engineDrop: number }) {
  const m = partMaterials();
  const towerX = -(radius + 3.2);
  const levels = Math.max(4, Math.round((height * 0.92) / 3));
  const step = (height * 0.92) / levels;
  const towerW = 1.6;
  const deckY = -engineDrop - 1.2;
  return (
    <group position={[0, deckY, 0]}>
      <mesh material={m.padConcrete} position={[0, -0.6, 0]} receiveShadow>
        <cylinderGeometry args={[radius * 2 + 9, radius * 2 + 10, 1.2, 64]} />
      </mesh>
      {/* foso de llamas */}
      <mesh position={[0, 0.01, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[radius * 2.2, radius * 6]} />
        <meshStandardMaterial color="#0b0d10" roughness={1} />
      </mesh>
      {/* anillo de sujeción con 4 garras */}
      <mesh material={m.rocketGrey} position={[0, 0.5, 0]}>
        <cylinderGeometry args={[radius * 1.15, radius * 1.25, 1, 32, 1, true]} />
      </mesh>
      {[0, 1, 2, 3].map((i) => {
        const a = (i / 4) * Math.PI * 2 + Math.PI / 4;
        return (
          <mesh key={i} material={m.frame} position={[Math.cos(a) * radius * 1.05, 1.1, Math.sin(a) * radius * 1.05]}>
            <boxGeometry args={[0.25, 0.4, 0.25]} />
          </mesh>
        );
      })}
      {/* torre de servicio */}
      <group position={[towerX, 0, 0]}>
        {[
          [-1, -1],
          [1, -1],
          [-1, 1],
          [1, 1],
        ].map(([sx, sz], i) => (
          <mesh key={i} material={m.frame} position={[(sx * towerW) / 2, (height * 0.92) / 2, (sz * towerW) / 2]}>
            <boxGeometry args={[0.12, height * 0.92, 0.12]} />
          </mesh>
        ))}
        {Array.from({ length: levels }, (_, k) => (
          <group key={k} position={[0, (k + 1) * step, 0]}>
            {[-1, 1].map((s) => (
              <mesh key={`x${s}`} material={m.frame} position={[0, 0, (s * towerW) / 2]}>
                <boxGeometry args={[towerW, 0.08, 0.08]} />
              </mesh>
            ))}
            {[-1, 1].map((s) => (
              <mesh key={`z${s}`} material={m.frame} position={[(s * towerW) / 2, 0, 0]}>
                <boxGeometry args={[0.08, 0.08, towerW]} />
              </mesh>
            ))}
            <mesh material={m.frame} position={[towerW / 2, -step / 2, 0]} rotation={[Math.atan2(towerW, step), 0, 0]}>
              <boxGeometry args={[0.05, Math.hypot(step, towerW), 0.05]} />
            </mesh>
          </group>
        ))}
        {/* brazo de acceso a la cofia */}
        <mesh material={m.frame} position={[(radius + 3.2) / 2, height * 0.8, 0]}>
          <boxGeometry args={[radius + 3.2 - radius * 1.1, 0.25, 0.9]} />
        </mesh>
        <pointLight position={[0.8, height * 0.6, 0]} color="#ffcf8a" intensity={40} distance={30} />
      </group>
    </group>
  );
}
