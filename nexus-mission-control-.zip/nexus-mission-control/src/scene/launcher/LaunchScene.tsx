/**
 * Escena 3D del vuelo (Fase 8.1): Tierra y Luna a escala real, plataforma y torre, el cohete elegido
 * con la nave del jugador, y la trayectoria FÍSICA de sim/FlightDynamics (ascenso, órbita de
 * aparcamiento, inyección translunar, crucero y aproximación a la Luna).
 *
 * Técnicas:
 *  - Unidades en kilómetros. Origen flotante: la cámara está siempre en (0,0,0) y el mundo se
 *    desplaza (las posiciones se calculan en doble precisión en JS), así un cohete de 70 m y la Luna
 *    a 384 400 km se dibujan sin temblores.
 *  - Búfer de profundidad logarítmico para distancias de 0,5 m a decenas de millones de km.
 *  - El tiempo sale del store (launch.t / cruiseH); entre ticks se interpola para que el
 *    movimiento sea fluido.
 *  - Cinco cámaras (externa, a bordo, seguimiento, orbital y libre) con ratón: arrastrar gira,
 *    rueda acerca/aleja; en la libre, botón derecho (o Mayús) desplaza.
 */
import { Suspense, useEffect, useMemo, useRef, useState } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';
import { getComponent } from '../../data/components/catalog';
import type { Launcher, SpacecraftDesign } from '../../data/schemas';
import type { Envelope } from '../../sim/EnvelopeSystem';
import { getLauncher, LUNAR_LAUNCHERS } from '../../data/launchers/launchers';
import { designTotals } from '../../sim/DesignSystem';
import { stowedEnvelope } from '../../sim/EnvelopeSystem';
import { FLIGHT_GAME, flightStateAt, R_EARTH, R_MOON, sunDirection, trajectoryPolyline, type FlightProfile } from '../../sim/FlightDynamics';
import { selectActiveMission, useGameStore } from '../../state/useGameStore';
import { mulberry32 } from '../proceduralTextures';
import { loadFlightTextures, type FlightTextures } from '../flight/flightTextures';
import { useFlightProfile, useFlightView, type CamMode } from '../flight/flightView';
import { PAD_LON_DEG } from '../flight/geography';
import { useFlightSim } from '../../ui/flight/flightSim';
import { bodyAxes } from '../../sim/Rescue';
import { currentTarget, DiscoverySky, DiscoveryWorld, rescueInView } from '../flight/DiscoveryLayer';
import { flightVisualAt } from './flightVisual';
import { LaunchPad, LaunchVehicle, type FlightVisual } from './LaunchVehicle';
import { computeRocketLayout } from './rocketLayout';

/** Longitud de la plataforma en la textura (cerca de la desembocadura del Amazonas, sobre el ecuador). */
const PAD_LON = (PAD_LON_DEG * Math.PI) / 180;
const SKY_DAY = new THREE.Color('#6fa6de');
const SPACE = new THREE.Color('#000004');
const UP = new THREE.Vector3(0, 1, 0);

/** Física (x, y) en el plano → three (x, 0, −y): el plano del vuelo es horizontal y +Y es su normal. */
const v3 = (x: number, y: number, out = new THREE.Vector3()) => out.set(x, 0, -y);
const dirOf = (a: number, out = new THREE.Vector3()) => out.set(Math.cos(a), 0, -Math.sin(a));

function logDepthShader(fragmentBody: string, uniforms: Record<string, THREE.IUniform>) {
  return new THREE.ShaderMaterial({
    uniforms,
    vertexShader: /* glsl */ `
      #include <common>
      #include <logdepthbuf_pars_vertex>
      varying vec3 vNormalW;
      varying vec3 vViewDir;
      void main() {
        vec4 wp = modelMatrix * vec4(position, 1.0);
        vNormalW = normalize(mat3(modelMatrix) * normal);
        vViewDir = normalize(cameraPosition - wp.xyz);
        gl_Position = projectionMatrix * viewMatrix * wp;
        #include <logdepthbuf_vertex>
      }`,
    fragmentShader: /* glsl */ `
      #include <logdepthbuf_pars_fragment>
      uniform vec3 uColor;
      uniform vec3 uSun;
      varying vec3 vNormalW;
      varying vec3 vViewDir;
      void main() {
        #include <logdepthbuf_fragment>
        ${fragmentBody}
      }`,
    transparent: true,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
  });
}

function makeStars() {
  const rand = mulberry32(7);
  const n = 5000;
  const pos = new Float32Array(n * 3);
  const col = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) {
    const u = rand() * 2 - 1;
    const t = rand() * Math.PI * 2;
    const s = Math.sqrt(1 - u * u);
    const r = 1e7;
    pos.set([r * s * Math.cos(t), r * u, r * s * Math.sin(t)], i * 3);
    const b = 0.35 + Math.pow(rand(), 3) * 0.65;
    const temp = rand();
    col.set(temp < 0.15 ? [b, b * 0.85, b * 0.7] : temp > 0.85 ? [b * 0.8, b * 0.9, b] : [b, b, b], i * 3);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  g.setAttribute('color', new THREE.BufferAttribute(col, 3));
  return g;
}

function markerTexture() {
  const c = document.createElement('canvas');
  c.width = c.height = 64;
  const ctx = c.getContext('2d')!;
  const g = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
  g.addColorStop(0, 'rgba(255,255,255,1)');
  g.addColorStop(0.25, 'rgba(99,230,240,0.95)');
  g.addColorStop(1, 'rgba(99,230,240,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 64, 64);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

/** Encuadre inicial de cada cámara. Las distancias de externa/seguimiento/libre son múltiplos del tamaño del objetivo. */
function defaults(mode: CamMode) {
  switch (mode) {
    case 'external':
      return { yaw: -0.75, pitch: 0.12, dist: 2.6, fov: 50, pan: new THREE.Vector3() };
    case 'chase':
      return { yaw: 0, pitch: 0.16, dist: 3.2, fov: 55, pan: new THREE.Vector3() };
    case 'onboard':
      return { yaw: 0, pitch: 0, dist: 1, fov: 72, pan: new THREE.Vector3() };
    case 'orbital':
      return { yaw: -0.6, pitch: 0.55, dist: 1, fov: 45, pan: new THREE.Vector3() };
    case 'free':
      return { yaw: 0.9, pitch: 0.3, dist: 3, fov: 50, pan: new THREE.Vector3() };
    case 'target':
      return { yaw: 0, pitch: 0, dist: 1, fov: 30, pan: new THREE.Vector3() };
  }
}

interface WorldProps {
  profile: FlightProfile;
  tex: FlightTextures;
}

function FlightWorld({ profile, tex }: WorldProps) {
  const mission = useGameStore(selectActiveMission);
  const launcher = (mission?.plan && getLauncher(mission.plan.launcherId)) || LUNAR_LAUNCHERS[0];
  const design = mission?.design ?? { chassisId: null, parts: [] };
  const env = useMemo(() => stowedEnvelope(design, getComponent), [design]);
  const mass = useMemo(() => designTotals(design, getComponent).massWetKg, [design]);
  const layout = useMemo(() => computeRocketLayout(launcher, env, false), [launcher, env]);
  const tl = profile.tl;
  const mode = useFlightView((s) => s.mode);
  const resetKey = useFlightView((s) => s.resetKey);
  const { camera, scene, gl } = useThree();
  const cam = camera as THREE.PerspectiveCamera;

  // ── Objetos ──
  const world = useRef<THREE.Group>(null);
  const earth = useRef<THREE.Group>(null);
  const clouds = useRef<THREE.Mesh>(null);
  const cap = useRef<THREE.Mesh>(null);
  const moon = useRef<THREE.Group>(null);
  const rocket = useRef<THREE.Group>(null);
  const marker = useRef<THREE.Sprite>(null);
  const stars = useRef<THREE.Points>(null);
  const sun = useRef<THREE.DirectionalLight>(null);
  const hemi = useRef<THREE.HemisphereLight>(null);
  const smoke = useRef<THREE.Group>(null);
  const timeRef = useMemo(() => ({ current: { T: 0, armed: false } }), []);

  const starGeom = useMemo(makeStars, []);
  const markerTex = useMemo(markerTexture, []);
  // Física (x, y, z) → three (x, z, −y): la misma dirección del Sol que usa la sombra de la Tierra.
  const sunDir = useMemo(() => {
    const [x, y, z] = sunDirection(profile);
    return new THREE.Vector3(x, z, -y).normalize();
  }, [profile]);
  const atmosphere = useMemo(
    () =>
      logDepthShader(
        `float rim = pow(1.0 - max(dot(vNormalW, vViewDir), 0.0), 2.4);
         float day = clamp(dot(vNormalW, uSun) * 1.4 + 0.45, 0.0, 1.0);
         gl_FragColor = vec4(uColor, rim * day * 1.1);`,
        { uColor: { value: new THREE.Color('#5fb0ff') }, uSun: { value: sunDir } },
      ),
    [sunDir],
  );

  // Trayectoria planificada: recorrida (brillante) y pendiente (tenue).
  const traj = useMemo(() => {
    const pts = trajectoryPolyline(profile, 2400);
    const arr = new Float32Array(pts.length * 3);
    pts.forEach((p, i) => arr.set([p.x, 0, -p.y], i * 3));
    const attr = new THREE.BufferAttribute(arr, 3);
    const g1 = new THREE.BufferGeometry().setAttribute('position', attr);
    const g2 = new THREE.BufferGeometry().setAttribute('position', attr);
    const past = new THREE.Line(g1, new THREE.LineBasicMaterial({ color: '#63e6f0', transparent: true, opacity: 0.95 }));
    const future = new THREE.Line(g2, new THREE.LineBasicMaterial({ color: '#63e6f0', transparent: true, opacity: 0.28 }));
    const ringPts = Array.from({ length: 721 }, (_, i) => {
      const a = (i / 720) * Math.PI * 2;
      return new THREE.Vector3(384400 * Math.cos(a), 0, -384400 * Math.sin(a));
    });
    const ring = new THREE.Line(new THREE.BufferGeometry().setFromPoints(ringPts), new THREE.LineBasicMaterial({ color: '#9fb3ff', transparent: true, opacity: 0.18 }));
    return { pts, past, future, ring };
  }, [profile]);

  // Plataforma: dirección del sitio en el marco de la Tierra (gira con ella).
  const padFrame = useMemo(() => {
    const d = dirOf(PAD_LON);
    const z = new THREE.Vector3(0, 1, 0);
    const x = new THREE.Vector3().crossVectors(d, z);
    const q = new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(x, d, z));
    return { q, pos: d.clone().multiplyScalar(profile.padRadiusKm) };
  }, [profile]);
  const capQ = useMemo(() => new THREE.Quaternion().setFromUnitVectors(UP, dirOf(PAD_LON)), []);
  const ground = useMemo(() => {
    const t = tex.ground.clone();
    t.needsUpdate = true;
    t.repeat.set(48, 6);
    return t;
  }, [tex]);

  // ── Cámara (estado propio; el ratón actúa sobre el lienzo) ──
  // Contenedores mutables (no provocan render).
  const ctl = useMemo(() => ({ current: defaults('external') }), []);
  const lastDist = useMemo(() => ({ current: 1 }), []);
  useEffect(() => {
    ctl.current = defaults(mode);
  }, [mode, resetKey, ctl]);
  useEffect(() => {
    const el = gl.domElement;
    let drag: { x: number; y: number; pan: boolean } | null = null;
    const down = (e: PointerEvent) => {
      drag = { x: e.clientX, y: e.clientY, pan: e.button === 2 || e.shiftKey };
      el.setPointerCapture(e.pointerId);
    };
    const move = (e: PointerEvent) => {
      if (!drag) return;
      const dx = e.clientX - drag.x;
      const dy = e.clientY - drag.y;
      drag.x = e.clientX;
      drag.y = e.clientY;
      const c = ctl.current;
      if (drag.pan && useFlightView.getState().mode === 'free') {
        const right = new THREE.Vector3().setFromMatrixColumn(cam.matrixWorld, 0);
        const up = new THREE.Vector3().setFromMatrixColumn(cam.matrixWorld, 1);
        const k = lastDist.current * 0.0016;
        c.pan.addScaledVector(right, -dx * k).addScaledVector(up, dy * k);
      } else {
        c.yaw -= dx * 0.006;
        c.pitch = Math.max(-1.45, Math.min(1.45, c.pitch + dy * 0.006));
      }
    };
    const up = (e: PointerEvent) => {
      drag = null;
      if (el.hasPointerCapture(e.pointerId)) el.releasePointerCapture(e.pointerId);
    };
    const wheel = (e: WheelEvent) => {
      e.preventDefault();
      const c = ctl.current;
      if (useFlightView.getState().mode === 'onboard') c.fov = Math.max(12, Math.min(95, c.fov * Math.exp(e.deltaY * 0.0009)));
      else c.dist = Math.max(0.05, Math.min(5e8, c.dist * Math.exp(e.deltaY * 0.0012)));
    };
    const ctx = (e: Event) => e.preventDefault();
    el.addEventListener('pointerdown', down);
    el.addEventListener('pointermove', move);
    el.addEventListener('pointerup', up);
    el.addEventListener('pointercancel', up);
    el.addEventListener('wheel', wheel, { passive: false });
    el.addEventListener('contextmenu', ctx);
    return () => {
      el.removeEventListener('pointerdown', down);
      el.removeEventListener('pointermove', move);
      el.removeEventListener('pointerup', up);
      el.removeEventListener('pointercancel', up);
      el.removeEventListener('wheel', wheel);
      el.removeEventListener('contextmenu', ctx);
    };
  }, [gl, cam, ctl, lastDist]);

  // ── Reloj visual ──
  const clock = useMemo(() => ({ current: { store: NaN, wall: 0 } }), []);
  const smooth = useMemo(() => ({ current: { focusY: 0, size: layout.heightM / 1000, orbAnchor: new THREE.Vector3(), orbBase: 25000, init: false } }), [layout]);
  const tmp = useMemo(
    () => ({
      P: new THREE.Vector3(),
      F: new THREE.Vector3(),
      M: new THREE.Vector3(),
      r: new THREE.Vector3(),
      e: new THREE.Vector3(),
      f: new THREE.Vector3(),
      d: new THREE.Vector3(),
      X: new THREE.Vector3(),
      Y: new THREE.Vector3(),
      Z: new THREE.Vector3(),
      C: new THREE.Vector3(),
      L: new THREE.Vector3(),
      o: new THREE.Vector3(),
      q: new THREE.Quaternion(),
      m: new THREE.Matrix4(),
      bg: new THREE.Color(),
    }),
    [],
  );
  const fog = useMemo(() => new THREE.Fog('#6fa6de', 40, 400), []);

  useFrame((state, delta) => {
    if (!world.current || !rocket.current) return;
    const now = state.clock.elapsedTime;
    const L = useGameStore.getState().launch;
    const cruising = L.phase === 'cruise' || L.phase === 'lunar-arrival';
    const storeT = cruising ? tl.endS + L.cruiseH * 3600 : L.t;
    const sim = useFlightSim.getState();
    const rate =
      L.phase === 'countdown' ? 1 : L.phase === 'flight' && L.running ? (storeT < 0 ? 1 : L.speed) : L.phase === 'cruise' && !sim.cruisePaused ? sim.cruiseSpeed * 3600 : 0;
    if (storeT !== clock.current.store) {
      clock.current.store = storeT;
      clock.current.wall = now;
    }
    const T = storeT + rate * Math.min(now - clock.current.wall, 0.12);
    const st = flightStateAt(profile, T);
    const { P, F, M, r, e, f, d, X, Y, Z, C, o, q, m, bg } = tmp;

    timeRef.current = { T, armed: L.phase !== 'ready' };
    const v = flightVisualAt(T, tl);

    // Cohete: posición física y eje según la actitud.
    v3(st.x, st.y, P);
    dirOf(st.att, d);
    X.crossVectors(d, UP);
    q.setFromRotationMatrix(m.makeBasis(X, d, UP));
    // Rescate: la orientación de la nave la lleva el jugador (guiñada y cabeceo del simulador).
    const rs = sim.rescue;
    if (rs && rescueInView()) {
      const { nose } = bodyAxes(rs.yaw, rs.pitch);
      d.set(nose[0], nose[1], nose[2]);
      X.crossVectors(d, Math.abs(d.y) > 0.98 ? Z.set(1, 0, 0) : UP).normalize();
      Z.crossVectors(X, d);
      q.setFromRotationMatrix(m.makeBasis(X, d, Z));
    }
    rocket.current.position.copy(P);
    rocket.current.quaternion.copy(q);

    // Punto a seguir: centro del cohete, de la etapa superior o de la nave.
    const sm = smooth.current;
    const craftSize = Math.max(0.003, (env ? Math.max(env.heightM, env.diameterM) : 2) / 1000);
    const targetY = v.stage2Sep > 0 ? layout.craftCenterY : v.fairingSep > 0 ? (layout.stage2.y0 + layout.fairing.y0) / 2 : layout.heightM / 2 - layout.engine.bellLen;
    const targetSize = v.stage2Sep > 0 ? craftSize : v.fairingSep > 0 ? (layout.fairing.y0 - layout.stage2.y0) / 1000 : layout.heightM / 1000;
    const k = 1 - Math.exp(-Math.min(delta, 0.1) * 3);
    sm.focusY += (targetY - sm.focusY) * k;
    sm.size += (targetSize - sm.size) * k;
    F.copy(d).multiplyScalar(sm.focusY / 1000).add(P);

    // Tierra, nubes, Luna.
    const earthRot = FLIGHT_GAME.padAngle0 - PAD_LON + st.earthAngle;
    if (earth.current) earth.current.rotation.y = earthRot;
    if (clouds.current) clouds.current.rotation.y = earthRot + T * 4e-6;
    v3(st.moonX, st.moonY, M);
    if (moon.current) {
      moon.current.position.copy(M);
      moon.current.rotation.y = st.moonAngle + Math.PI; // cara visible hacia la Tierra
    }

    // ── Cámara ──
    const c = ctl.current;
    const camMode = useFlightView.getState().mode;
    const sph = (dist: number) => o.set(Math.cos(c.pitch) * Math.sin(c.yaw) * dist, Math.sin(c.pitch) * dist, Math.cos(c.pitch) * Math.cos(c.yaw) * dist);
    const lookAt = tmp.L;
    if (camMode === 'onboard') {
      // Montada en el lateral de la etapa superior (o de la nave), mirando hacia atrás.
      const hullR = (v.fairingSep > 0 ? layout.r2 : layout.fairing.r) + 0.45;
      const mountY = v.stage2Sep > 0 ? layout.craftCenterY + 1.2 : v.fairingSep > 0 ? layout.stage2.y1 - 0.8 : layout.fairing.y0 - 0.8;
      C.copy(X).multiplyScalar((v.stage2Sep > 0 ? craftSize * 1000 * 0.7 + 0.4 : hullR) / 1000).addScaledVector(d, mountY / 1000).add(P);
      const look = f.copy(d).multiplyScalar(-1).addScaledVector(X, -0.16);
      look.applyAxisAngle(d, c.yaw);
      const side = Y.crossVectors(look, X).normalize();
      look.applyAxisAngle(side, c.pitch).normalize();
      lookAt.copy(C).add(look);
      cam.up.copy(X);
      lastDist.current = 0.05;
    } else if (camMode === 'target' && currentTarget(profile, T, F, tmp.L)) {
      // Cámara de observación: montada en la nave, apunta al objeto y ajusta el zoom a su tamaño.
      const tg = currentTarget(profile, T, F, tmp.L)!;
      const dir = f.copy(tmp.L);
      if (!tg.sky) dir.sub(F);
      const distKm = Math.max(1e-6, dir.length());
      dir.normalize();
      // Arriba de la imagen: la vertical local (desde la Luna si está cerca).
      if (st.moonDistanceKm < 30000) r.copy(F).sub(M).normalize();
      else r.copy(F).normalize();
      Y.copy(r).addScaledVector(dir, -dir.dot(r));
      if (Y.lengthSq() < 1e-6) Y.set(0, 1, 0);
      Y.normalize();
      X.crossVectors(dir, Y);
      const angDeg = tg.sky ? tg.skyDeg : (2 * Math.atan(tg.sizeKm / 2 / distKm) * 180) / Math.PI;
      const zoom = Math.max(0.15, Math.min(8, c.dist));
      const want = Math.max(0.01, Math.min(80, angDeg * (tg.sky ? 1.5 : 2.4) * zoom));
      c.fov += (want - c.fov) * Math.min(1, delta * 4);
      // Arrastrar mira un poco alrededor del objeto (proporcional al campo de visión).
      const k = (c.fov * Math.PI) / 180;
      C.copy(dir).multiplyScalar(craftSize * 0.8).add(F);
      lookAt.copy(dir).addScaledVector(X, -c.yaw * k * 0.5).addScaledVector(Y, c.pitch * k * 0.5).add(C);
      cam.up.copy(Y);
      lastDist.current = 0.05;
    } else {
      let anchor: THREE.Vector3;
      let dist: number;
      if (camMode === 'orbital') {
        // Ancla automática: Tierra al principio, sistema Tierra-Luna en el crucero, Luna al llegar.
        const near = st.moonDistanceKm < 70000;
        const target = near ? M : st.phase === 'cruise' || st.phase === 'approach' ? Y.copy(M).multiplyScalar(0.5) : Z.set(0, 0, 0);
        const base = near ? 16000 : st.phase === 'cruise' ? 520000 : 26000;
        if (!sm.init) {
          sm.orbAnchor.copy(target);
          sm.orbBase = base;
          sm.init = true;
        }
        sm.orbAnchor.lerp(target, 0.05);
        sm.orbBase += (base - sm.orbBase) * 0.05;
        anchor = e.copy(sm.orbAnchor);
        dist = sm.orbBase * Math.max(0.05, Math.min(8, c.dist));
        X.set(1, 0, 0);
        Y.set(0, 1, 0);
        Z.set(0, 0, 1);
      } else {
        dist = c.dist * sm.size;
        anchor = e.copy(F);
        if (camMode === 'free') {
          anchor.add(c.pan);
          X.set(1, 0, 0);
          Y.set(0, 1, 0);
          Z.set(0, 0, 1);
        } else {
          // Vertical local: desde la Luna si estamos cerca de ella; si no, desde la Tierra.
          if (st.moonDistanceKm < 30000) r.copy(F).sub(M).normalize();
          else r.copy(F).normalize();
          if (camMode === 'external') {
            X.crossVectors(UP, r).normalize();
            Y.copy(r);
            Z.crossVectors(X, Y);
          } else {
            // Seguimiento: detrás del cohete en el sentido del vuelo (al despegar, mirando al este).
            const east = X.crossVectors(UP, r).normalize();
            const s = st.phase === 'pad' ? 0 : Math.max(0, Math.min(1, (st.groundSpeedKmS - 0.08) / 0.25));
            f.copy(east).lerp(d, s).normalize();
            Y.copy(r).addScaledVector(f, -f.dot(r));
            if (Y.lengthSq() < 0.01) Y.copy(UP);
            Y.normalize();
            Z.copy(f).multiplyScalar(-1);
            X.crossVectors(Y, Z);
          }
        }
      }
      sph(dist);
      C.copy(anchor).addScaledVector(X, o.x).addScaledVector(Y, o.y).addScaledVector(Z, o.z);
      lookAt.copy(anchor);
      cam.up.copy(Y);
      lastDist.current = dist;
      // Nunca bajo el suelo ni dentro de la Luna.
      const rc = C.length();
      if (rc < R_EARTH + 0.02) C.multiplyScalar((R_EARTH + 0.02) / rc);
      const dm = C.distanceTo(M);
      if (dm < R_MOON + 1) C.sub(M).multiplyScalar((R_MOON + 1) / dm).add(M);
    }
    if (Math.abs(cam.fov - c.fov) > 0.01) {
      cam.fov = c.fov;
      cam.updateProjectionMatrix();
    }

    // Origen flotante: la cámara en (0,0,0).
    world.current.position.copy(C).multiplyScalar(-1);
    cam.position.set(0, 0, 0);
    cam.lookAt(lookAt.sub(C));

    // Cielo: azul dentro de la atmósfera iluminada, negro en el espacio.
    const camAlt = C.length() - R_EARTH;
    // El terreno detallado solo hace falta cerca del suelo (desde lejos se ve el mapa global).
    if (cap.current) cap.current.visible = camAlt < 600;
    const daylight = Math.max(0, Math.min(1, r.copy(C).normalize().dot(sunDir) * 3 + 0.4));
    const air = 1 - Math.max(0, Math.min(1, camAlt / 75));
    const skyK = air * daylight;
    bg.copy(SPACE).lerp(SKY_DAY, skyK);
    scene.background = bg;
    if (camAlt < 60 && skyK > 0.02) {
      fog.color.copy(bg);
      fog.near = 25 + camAlt * 6;
      fog.far = 260 + camAlt * 60;
      scene.fog = fog;
    } else scene.fog = null;
    if (stars.current) (stars.current.material as THREE.PointsMaterial).opacity = Math.max(0, 1 - skyK * 1.4);
    if (hemi.current) {
      // La luz del cielo viene de la vertical local de la cámara (no del eje Y del mundo).
      hemi.current.intensity = 0.15 + skyK * 0.75;
      hemi.current.position.copy(r);
    }
    if (sun.current) sun.current.position.copy(sunDir).multiplyScalar(1000);

    // Trayectoria y marcador: solo cuando la cámara está lejos.
    const far = lastDist.current > 60 || camMode === 'orbital';
    const pts = traj.pts;
    let lo = 0;
    let hi = pts.length - 1;
    while (hi - lo > 1) {
      const mid = (lo + hi) >> 1;
      if (pts[mid].t <= T) lo = mid;
      else hi = mid;
    }
    traj.past.geometry.setDrawRange(0, lo + 1);
    traj.future.geometry.setDrawRange(lo, pts.length - lo);
    const showTraj = useFlightView.getState().showTrajectory;
    traj.past.visible = traj.future.visible = far && showTraj;
    traj.ring.visible = far && showTraj && (camMode === 'orbital' || lastDist.current > 50000);
    if (marker.current) {
      marker.current.position.copy(F);
      marker.current.visible = lastDist.current > 300 || camMode === 'orbital';
    }

    // Humo del despegue (en el marco de la plataforma).
    if (smoke.current) {
      const ts = T + 3;
      const on = ts > 0 && T < 45 && L.phase !== 'ready';
      smoke.current.visible = on;
      if (on) {
        const fade = T < 25 ? 1 : Math.max(0, 1 - (T - 25) / 20);
        smoke.current.children.forEach((ch, i) => {
          const a = (i / smoke.current!.children.length) * Math.PI * 2 + (i % 2) * 0.3;
          const spread = (6 + Math.min(ts, 25) * 5.5) * (0.6 + (i % 3) * 0.25);
          const s = 6 + Math.min(ts, 30) * 2.2 * (0.7 + (i % 4) * 0.15);
          ch.position.set(Math.cos(a) * spread, -2 + s * 0.45 + (i % 5) * 1.5, Math.sin(a) * spread * 0.7);
          ch.scale.setScalar(s);
          ((ch as THREE.Mesh).material as THREE.MeshLambertMaterial).opacity = 0.55 * fade;
        });
      }
    }
  });

  const smokeMat = useMemo(() => Array.from({ length: 16 }, () => new THREE.MeshLambertMaterial({ color: '#d9d6d0', transparent: true, opacity: 0.5, depthWrite: false })), []);
  const smokeGeom = useMemo(() => new THREE.SphereGeometry(1, 14, 10), []);
  const padR = Math.max(layout.fairing.r, layout.r1);
  const bellDrop = layout.engine.bellLen + 1.2;

  return (
    <>
      <ambientLight intensity={0.035} />
      <hemisphereLight ref={hemi} args={['#bcd6ff', '#3a3326', 0.6]} />
      <directionalLight ref={sun} intensity={3} color="#fff4e6" />
      <points ref={stars} geometry={starGeom} frustumCulled={false}>
        <pointsMaterial size={1.7} sizeAttenuation={false} vertexColors transparent depthWrite={false} fog={false} />
      </points>

      <DiscoverySky />
      <group ref={world}>
        {/* Tierra */}
        <group ref={earth}>
          <mesh>
            <sphereGeometry args={[R_EARTH - 0.6, 256, 128]} />
            <meshStandardMaterial map={tex.earth.color} roughnessMap={tex.earth.roughness} roughness={1} metalness={0} />
          </mesh>
          {/* Terreno detallado alrededor de la plataforma (sin facetas a ras de suelo) */}
          <mesh ref={cap} quaternion={capQ}>
            <sphereGeometry args={[R_EARTH, 192, 96, 0, Math.PI * 2, 0, 0.022]} />
            <meshStandardMaterial map={ground} roughness={1} metalness={0} />
          </mesh>
          {/* Plataforma y torre */}
          <group position={padFrame.pos} quaternion={padFrame.q}>
            <group scale={0.001}>
              <LaunchPad height={layout.heightM} radius={padR} engineDrop={layout.engine.bellLen} />
              {/* zócalo de hormigón hasta el terreno y pararrayos */}
              <mesh position={[0, -bellDrop - 3, 0]}>
                <cylinderGeometry args={[padR * 2 + 14, padR * 2 + 18, 4, 48]} />
                <meshStandardMaterial color="#8d8a84" roughness={0.95} />
              </mesh>
              {[0, 1, 2, 3].map((i) => {
                const a = (i / 4) * Math.PI * 2 + Math.PI / 4;
                const R = padR * 2 + 40;
                return (
                  <mesh key={i} position={[Math.cos(a) * R, layout.heightM * 0.65 - bellDrop, Math.sin(a) * R]}>
                    <cylinderGeometry args={[0.35, 0.6, layout.heightM * 1.3, 8]} />
                    <meshStandardMaterial color="#c9ccd1" metalness={0.6} roughness={0.4} />
                  </mesh>
                );
              })}
              <group ref={smoke} position={[0, -bellDrop + 2, 0]} visible={false}>
                {smokeMat.map((mat, i) => (
                  <mesh key={i} geometry={smokeGeom} material={mat} />
                ))}
              </group>
            </group>
          </group>
        </group>
        <mesh ref={clouds} renderOrder={1}>
          <sphereGeometry args={[R_EARTH + 6, 192, 96]} />
          <meshStandardMaterial map={tex.earth.clouds} transparent depthWrite={false} side={THREE.DoubleSide} roughness={1} />
        </mesh>
        <mesh material={atmosphere} renderOrder={2}>
          <sphereGeometry args={[R_EARTH + 90, 128, 64]} />
        </mesh>

        {/* Luna */}
        <group ref={moon}>
          <mesh>
            <sphereGeometry args={[R_MOON, 192, 96]} />
            <meshStandardMaterial map={tex.moon.color} bumpMap={tex.moon.bump} bumpScale={3} roughness={1} metalness={0} />
          </mesh>
        </group>

        {/* Trayectoria */}
        <primitive object={traj.past} />
        <primitive object={traj.future} />
        <primitive object={traj.ring} />
        <sprite ref={marker} scale={[0.028, 0.028, 1]}>
          <spriteMaterial map={markerTex} sizeAttenuation={false} transparent depthWrite={false} toneMapped={false} />
        </sprite>

        {/* Descubrimientos y satélite del rescate */}
        <DiscoveryWorld profile={profile} timeRef={timeRef} craftRef={rocket} />

        {/* Cohete (modelo en metros) */}
        <group ref={rocket}>
          <group scale={0.001}>
            <Vehicle launcher={launcher} design={design} env={env} mass={mass} profile={profile} timeRef={timeRef} />
          </group>
        </group>
      </group>
    </>
  );
}

/** El cohete se vuelve a dibujar solo cuando cambia lo que se ve (separaciones, motores, paneles). */
function Vehicle({
  launcher,
  design,
  env,
  mass,
  profile,
  timeRef,
}: {
  launcher: Launcher;
  design: SpacecraftDesign;
  env: Envelope | null;
  mass: number;
  profile: FlightProfile;
  timeRef: { current: { T: number; armed: boolean } };
}) {
  const [vis, setVis] = useState<FlightVisual>(() => flightVisualAt(0, profile.tl));
  const cur = useMemo(() => ({ current: vis }), []); // eslint-disable-line react-hooks/exhaustive-deps
  useFrame(() => {
    const { T, armed } = timeRef.current;
    const v = flightVisualAt(T, profile.tl);
    // Con el cohete sujeto a la plataforma, los motores se encienden 3 s antes del despegue.
    if (T > -3 && T <= 0 && armed) v.plume = 1;
    const c = cur.current;
    if (
      v.plume !== c.plume ||
      v.deployed !== c.deployed ||
      Math.abs(v.stage1Sep - c.stage1Sep) > 0.05 ||
      Math.abs(v.stage2Sep - c.stage2Sep) > 0.05 ||
      Math.abs(v.fairingSep - c.fairingSep) > 0.05 ||
      Math.abs(v.boosterSep - c.boosterSep) > 0.05
    ) {
      cur.current = v;
      setVis(v);
    }
  });
  return <LaunchVehicle launcher={launcher} design={design} envelope={env} craftMassKg={mass} fairingMode="closed" exploded={false} labels={false} flight={vis} />;
}

function FlightContent() {
  const mission = useGameStore(selectActiveMission);
  const launcher = (mission?.plan && getLauncher(mission.plan.launcherId)) || LUNAR_LAUNCHERS[0];
  const profile = useFlightProfile(launcher, mission?.plan?.altitudeKm ?? 100);
  const [tex, setTex] = useState<FlightTextures | null>(null);
  useEffect(() => {
    let alive = true;
    loadFlightTextures().then((t) => alive && setTex(t));
    return () => {
      alive = false;
    };
  }, []);
  if (!profile || !tex) return null;
  return <FlightWorld profile={profile} tex={tex} />;
}

export default function LaunchScene() {
  return (
    <Canvas
      className="scene-canvas flight-canvas"
      dpr={[1, 1.75]}
      camera={{ fov: 50, near: 0.0003, far: 5e7, position: [0, 0, 0] }}
      gl={{ antialias: true, logarithmicDepthBuffer: true }}
      onCreated={({ gl }) => {
        gl.toneMapping = THREE.ACESFilmicToneMapping;
        gl.toneMappingExposure = 1.05;
      }}
    >
      <Suspense fallback={null}>
        <FlightContent />
      </Suspense>
    </Canvas>
  );
}
