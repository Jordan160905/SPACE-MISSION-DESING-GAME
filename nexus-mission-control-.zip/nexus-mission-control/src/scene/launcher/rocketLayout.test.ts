import { describe, expect, it } from 'vitest';
import { getComponent } from '../../data/components/catalog';
import { LAUNCHERS } from '../../data/launchers/launchers';
import { EMPTY_DESIGN, placePart, setChassis } from '../../sim/DesignSystem';
import { stowedEnvelope } from '../../sim/EnvelopeSystem';
import { computeRocketLayout } from './rocketLayout';

const L = getComponent;
const design = (() => {
  let d = setChassis(EMPTY_DESIGN, 'chassis-m', L).design;
  d = placePart(d, 'camera', 'bottom-0', L).design;
  d = placePart(d, 'antenna-hg', 'top-0', L).design;
  return d;
})();

describe('disposición del cohete', () => {
  for (const l of LAUNCHERS) {
    it(`${l.name}: las piezas se apilan sin huecos ni solapes`, () => {
      const r = computeRocketLayout(l, stowedEnvelope(design, L), false);
      expect(r.interstage.y0).toBe(r.stage1.y1);
      expect(r.stage2.y0).toBe(r.interstage.y1);
      expect(r.adapter.y0).toBe(r.stage2.y1);
      expect(r.fairing.tip).toBeGreaterThan(r.fairing.cylinderTop);
      // la cofia es al menos tan ancha como la segunda etapa
      expect(r.fairing.r).toBeGreaterThan(r.r2 - 1e-9);
      // el motor de vacío cabe dentro de la interetapa
      expect(r.vacuumEngine.bellLen).toBeLessThan(r.interstage.y1 - r.interstage.y0);
      // los motores del racimo no se solapan
      if (r.engine.count > 1) {
        const ring = r.engine.count - 1;
        const spacing = 2 * r.engine.ringR * Math.sin(Math.PI / ring);
        expect(2 * r.engine.bellR).toBeLessThan(spacing + 1e-9);
        expect(r.engine.ringR).toBeGreaterThan(2 * r.engine.bellR - 1e-9);
      }
      expect(r.explode.fairing).toBe(0);
    });
  }

  it('la vista explosionada separa los grupos en orden', () => {
    const r = computeRocketLayout(LAUNCHERS.find((l) => l.id === 'falcon-9')!, stowedEnvelope(design, L), true);
    expect(r.explode.interstage).toBeGreaterThan(0);
    expect(r.explode.fairing).toBeGreaterThan(r.explode.payload);
  });

  it('detecta si la nave plegada no cabe en la cofia', () => {
    let d = setChassis(EMPTY_DESIGN, 'chassis-m', L).design;
    d = placePart(d, 'radar', 'bottom-0', L).design; // Ø 1,85 m
    expect(computeRocketLayout(LAUNCHERS.find((l) => l.id === 'minotaur-i')!, stowedEnvelope(d, L), false).fitsFairing).toBe(false); // cofia útil 1,4 m
    expect(computeRocketLayout(LAUNCHERS.find((l) => l.id === 'minotaur-iv')!, stowedEnvelope(d, L), false).fitsFairing).toBe(true); // cofia útil 2,1 m
  });
});
