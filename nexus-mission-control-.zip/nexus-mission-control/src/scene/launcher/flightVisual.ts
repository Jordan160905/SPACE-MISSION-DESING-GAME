/**
 * Traduce el tiempo de misión del lanzamiento a lo que se ve (pura y probada).
 * Las piezas separadas se alejan con aceleración relativa de "juego": el cohete sigue acelerando
 * y lo que se suelta parece caer hacia atrás.
 */
import type { LaunchTimeline } from '../../sim/LaunchSystem';
import type { FlightVisual } from './LaunchVehicle';

const fallAway = (dt: number, accel: number, v0 = 0) => (dt <= 0 ? 0 : v0 * dt + 0.5 * accel * dt * dt);

export function flightVisualAt(t: number, tl: LaunchTimeline): FlightVisual {
  const ev = (id: string) => tl.events.find((e) => e.id === id)?.tS ?? Number.POSITIVE_INFINITY;
  const sesS = ev('ses');
  const plume: 0 | 1 | 2 =
    t > 0 && t <= tl.mecoS ? 1 : (t > sesS && t <= tl.secoS) || (t > tl.tliStartS && t <= tl.tliEndS) ? 2 : 0;
  return {
    boosterSep: tl.boosterSepS === null ? 0 : fallAway(t - tl.boosterSepS, 9, 2),
    stage1Sep: fallAway(t - ev('stage-sep'), 7, 1.5),
    fairingSep: fallAway(t - ev('fairing'), 1.5, 2),
    stage2Sep: fallAway(t - ev('sc-sep'), 0.02, 0.4),
    plume,
    deployed: t >= ev('deploy'),
  };
}
