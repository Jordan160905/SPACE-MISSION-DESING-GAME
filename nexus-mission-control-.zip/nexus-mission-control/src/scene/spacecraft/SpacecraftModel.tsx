/**
 * SpacecraftModel — dibuja EXACTAMENTE el diseño del jugador (chasis + piezas en sus sockets).
 * Reutilizable: el Lab lo usa en modo interactivo y las fases de lanzamiento/operaciones lo
 * reutilizarán en modo de solo lectura, garantizando que la nave lanzada es la construida.
 */
import { useLayoutEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import type { ThreeEvent } from '@react-three/fiber';
import * as THREE from 'three';
import { getComponent } from '../../data/components/catalog';
import type { SocketDef, SpacecraftDesign } from '../../data/schemas';
import { chassisHalf } from '../../sim/EnvelopeSystem';
import { ChassisModel, PART_MODELS } from './partModels';

const UP = new THREE.Vector3(0, 1, 0);

export function socketQuaternion(s: Pick<SocketDef, 'normal'>): THREE.Quaternion {
  return new THREE.Quaternion().setFromUnitVectors(UP, new THREE.Vector3(...s.normal).normalize());
}

/** Contorno de caja ajustado al contenido, en el espacio local del grupo padre. */
function Outline({ color, children }: { color: string; children: ReactNode }) {
  const outer = useRef<THREE.Group>(null);
  const inner = useRef<THREE.Group>(null);
  const [box, setBox] = useState<{ center: THREE.Vector3; size: THREE.Vector3 } | null>(null);

  useLayoutEffect(() => {
    if (!outer.current || !inner.current) return;
    outer.current.updateWorldMatrix(true, true);
    const inv = outer.current.matrixWorld.clone().invert();
    const b = new THREE.Box3();
    inner.current.traverse((o) => {
      const mesh = o as THREE.Mesh;
      if (!mesh.isMesh || !mesh.geometry) return;
      mesh.geometry.computeBoundingBox();
      const gb = mesh.geometry.boundingBox;
      if (gb) b.union(gb.clone().applyMatrix4(inv.clone().multiply(mesh.matrixWorld)));
    });
    if (b.isEmpty()) return;
    setBox({ center: b.getCenter(new THREE.Vector3()), size: b.getSize(new THREE.Vector3()).addScalar(0.04) });
    // Se calcula al montar: los modelos de pieza son estáticos.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const edges = useMemo(() => (box ? new THREE.EdgesGeometry(new THREE.BoxGeometry(box.size.x, box.size.y, box.size.z)) : null), [box]);

  return (
    <group ref={outer}>
      <group ref={inner}>{children}</group>
      {box && edges && (
        <lineSegments geometry={edges} position={box.center}>
          <lineBasicMaterial color={color} toneMapped={false} />
        </lineSegments>
      )}
    </group>
  );
}

export interface SpacecraftInteraction {
  selectedId: string | null;
  /** Piezas implicadas en problemas críticos (contorno rojo). */
  issueInstanceIds: Set<string>;
  onSelect: (id: string) => void;
}

interface Props {
  design: SpacecraftDesign;
  xray?: boolean;
  /** Configuración de lanzamiento: paneles plegados (para la vista dentro de la cofia). */
  stowed?: boolean;
  interaction?: SpacecraftInteraction;
}

const hoverOn = (e: ThreeEvent<PointerEvent>) => {
  e.stopPropagation();
  document.body.style.cursor = 'pointer';
};
const hoverOff = () => {
  document.body.style.cursor = '';
};

export function SpacecraftModel({ design, xray = false, stowed = false, interaction }: Props) {
  const chassis = design.chassisId ? getComponent(design.chassisId) : undefined;
  const half = useMemo(() => (chassis ? chassisHalf(chassis.sockets) : ([0, 0, 0] as [number, number, number])), [chassis]);
  if (!chassis) return null;

  const wrap = (id: string, node: ReactNode) => {
    if (!interaction) return node;
    const selected = interaction.selectedId === id;
    const issue = interaction.issueInstanceIds.has(id);
    return selected || issue ? <Outline color={selected ? '#63e6f0' : '#ff5d73'}>{node}</Outline> : node;
  };

  return (
    <group>
      <group
        onClick={
          interaction
            ? (e) => {
                e.stopPropagation();
                interaction.onSelect('chassis');
              }
            : undefined
        }
        onPointerOver={interaction ? hoverOn : undefined}
        onPointerOut={interaction ? hoverOff : undefined}
      >
        {wrap('chassis', <ChassisModel chassisId={chassis.id} half={half} xray={xray} />)}
      </group>
      {design.parts.map((p) => {
        const socket = chassis.sockets.find((s) => s.id === p.socketId);
        const Model = PART_MODELS[getComponent(p.componentId)?.model.key ?? ''];
        if (!socket || !Model) return null;
        return (
          <group
            key={p.instanceId}
            position={socket.position}
            quaternion={socketQuaternion(socket)}
            onClick={
              interaction
                ? (e) => {
                    e.stopPropagation();
                    interaction.onSelect(p.instanceId);
                  }
                : undefined
            }
            onPointerOver={interaction ? hoverOn : undefined}
            onPointerOut={interaction ? hoverOff : undefined}
          >
            {wrap(p.instanceId, <Model stowed={stowed} />)}
          </group>
        );
      })}
    </group>
  );
}
