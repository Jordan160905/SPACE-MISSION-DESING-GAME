/**
 * Materiales compartidos de la nave (creados una sola vez, de forma diferida).
 * Inspirados en acabados reales: mantas MLI doradas, pintura blanca térmica, células solares.
 */
import * as THREE from 'three';
import { createFoilBumpTexture, createGridPanelTexture, createRocketSkinTexture } from '../proceduralTextures';

let cache: ReturnType<typeof build> | null = null;

function build() {
  const std = (p: THREE.MeshStandardMaterialParameters) => new THREE.MeshStandardMaterial(p);
  const foil = createFoilBumpTexture();
  foil.repeat.set(1.5, 1.5);
  const skin = createRocketSkinTexture();
  return {
    // Manta MLI: el relieve arrugado y la rugosidad variable dan el aspecto de lámina real.
    goldFoil: std({ color: '#d4a548', metalness: 1, roughness: 0.38, bumpMap: foil, bumpScale: 2.2, roughnessMap: foil }),
    silverFoil: std({ color: '#c9d1da', metalness: 0.95, roughness: 0.3, bumpMap: foil, bumpScale: 1.6, roughnessMap: foil }),
    blackKapton: std({ color: '#1a1a1c', metalness: 0.5, roughness: 0.45, bumpMap: foil, bumpScale: 1.2 }),
    aluminum: std({ color: '#b9c0c8', metalness: 0.9, roughness: 0.35 }),
    solarBack: std({ color: '#8d949c', metalness: 0.6, roughness: 0.5 }),
    rocketWhite: std({ map: skin, color: '#ffffff', metalness: 0.15, roughness: 0.55 }),
    rocketBlack: std({ color: '#16181b', metalness: 0.35, roughness: 0.6 }),
    rocketGrey: std({ color: '#4c535b', metalness: 0.6, roughness: 0.45 }),
    engineBell: std({ color: '#2c2f34', metalness: 0.9, roughness: 0.35, side: THREE.DoubleSide }),
    engineCopper: std({ color: '#9a5b2e', metalness: 0.95, roughness: 0.3, side: THREE.DoubleSide }),
    fairing: std({ map: skin, color: '#ffffff', metalness: 0.1, roughness: 0.5, side: THREE.DoubleSide }),
    fairingGhost: std({ color: '#cfe8ff', metalness: 0.1, roughness: 0.2, transparent: true, opacity: 0.12, depthWrite: false, side: THREE.DoubleSide }),
    padConcrete: std({ color: '#3a3f46', metalness: 0.1, roughness: 0.9 }),
    frame: std({ color: '#2b3442', metalness: 0.75, roughness: 0.45 }),
    whitePaint: std({ color: '#e6e9ee', metalness: 0.05, roughness: 0.6 }),
    blackAnodized: std({ color: '#121519', metalness: 0.6, roughness: 0.45 }),
    titanium: std({ color: '#9aa3ad', metalness: 0.85, roughness: 0.3 }),
    copper: std({ color: '#b87333', metalness: 0.9, roughness: 0.35 }),
    nozzle: std({ color: '#3a3f47', metalness: 0.85, roughness: 0.4, side: THREE.DoubleSide }),
    nozzleInner: std({ color: '#5a2e14', emissive: '#ff6a1a', emissiveIntensity: 0.15, metalness: 0.6, roughness: 0.5, side: THREE.BackSide }),
    dish: std({ color: '#f1f3f6', metalness: 0.1, roughness: 0.45, side: THREE.DoubleSide }),
    glass: std({ color: '#62d6ff', metalness: 0.3, roughness: 0.05, transparent: true, opacity: 0.75, emissive: '#0a3a55', emissiveIntensity: 0.5 }),
    ledGreen: new THREE.MeshBasicMaterial({ color: '#4dff9a', toneMapped: false }),
    ledRed: new THREE.MeshBasicMaterial({ color: '#ff4d5e', toneMapped: false }),
    batteryBlue: std({ color: '#2d5b9a', metalness: 0.4, roughness: 0.4 }),
    solarBasic: std({
      map: createGridPanelTexture('#16306a', '#8ea6c9', 4, 6, '#23489a'),
      metalness: 0.5,
      roughness: 0.25,
      emissive: '#06122c',
    }),
    solarAdv: std({
      map: createGridPanelTexture('#1a1238', '#6f6fa8', 6, 8, '#2c2366'),
      metalness: 0.55,
      roughness: 0.2,
      emissive: '#0b0820',
    }),
    radarPanel: std({ map: createGridPanelTexture('#2a2e33', '#b87333', 8, 4), metalness: 0.6, roughness: 0.4 }),
  };
}

export function partMaterials() {
  if (!cache) cache = build();
  return cache;
}
