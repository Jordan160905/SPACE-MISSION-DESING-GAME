/**
 * Modelos 3D procedurales ORIGINALES de cada pieza (PROVISIONALES: sustituibles por GLB).
 *
 * Convención de cada modelo: el origen es el punto de anclaje y +Y apunta hacia fuera de la
 * superficie de montaje. SpacecraftModel rota cada modelo para alinear +Y con la normal del socket.
 * 1 unidad = 1 m.
 */
import { useMemo, type ReactElement } from 'react';
import * as THREE from 'three';
import { partMaterials } from './materials';

const M = partMaterials;

/** Props comunes: `stowed` = configuración de lanzamiento (apéndices plegados). */
export interface PartModelProps {
  stowed?: boolean;
}

function lathe(points: Array<[number, number]>, segments = 48): THREE.LatheGeometry {
  return new THREE.LatheGeometry(points.map(([r, y]) => new THREE.Vector2(r, y)), segments);
}

// ── ENERGÍA ────────────────────────────────────────────────

function SolarWing({ panels, length, width, advanced, stowed }: { panels: number; length: number; width: number; advanced: boolean; stowed?: boolean }) {
  const m = M();
  const cells = advanced ? m.solarAdv : m.solarBasic;
  if (stowed) {
    // Plegadas contra el costado: paneles apilados paralelos a la cara de montaje.
    const size = 0.42;
    return (
      <group>
        {Array.from({ length: panels }, (_, i) => (
          <group key={i} position={[0, 0.04 + i * 0.028, 0]}>
            <mesh material={i === panels - 1 ? cells : m.solarBack}>
              <boxGeometry args={[size, 0.02, size]} />
            </mesh>
          </group>
        ))}
        {/* soportes de retención (se liberan al desplegar) */}
        {[-1, 1].map((sx) => (
          <mesh key={sx} material={m.frame} position={[sx * (size / 2 + 0.015), 0.04 + panels * 0.014, 0]}>
            <boxGeometry args={[0.02, 0.03 + panels * 0.028, 0.06]} />
          </mesh>
        ))}
      </group>
    );
  }
  const boom = 0.22;
  const gap = 0.035;
  return (
    <group>
      {/* mecanismo de despliegue y brazo */}
      <mesh position={[0, 0.03, 0]} material={m.blackAnodized}>
        <cylinderGeometry args={[0.045, 0.05, 0.06, 16]} />
      </mesh>
      <mesh position={[0, boom / 2, 0]} material={m.aluminum}>
        <cylinderGeometry args={[0.016, 0.016, boom, 12]} />
      </mesh>
      {/* yugo en V */}
      {[-1, 1].map((sz) => (
        <mesh key={sz} material={m.aluminum} position={[0, boom - 0.02, sz * width * 0.18]} rotation={[sz * 0.6, 0, 0]}>
          <cylinderGeometry args={[0.01, 0.01, width * 0.42, 8]} />
        </mesh>
      ))}
      {Array.from({ length: panels }, (_, i) => {
        const y = boom + gap + length / 2 + i * (length + gap);
        return (
          <group key={i} position={[0, y, 0]}>
            {/* cara de células (+X) y cara trasera */}
            <mesh material={cells} position={[0.004, 0, 0]}>
              <boxGeometry args={[0.012, length, width]} />
            </mesh>
            <mesh material={m.solarBack} position={[-0.006, 0, 0]}>
              <boxGeometry args={[0.008, length, width]} />
            </mesh>
            {/* marco perimetral */}
            {[-1, 1].map((sz) => (
              <mesh key={sz} material={m.aluminum} position={[0, 0, (sz * width) / 2]}>
                <boxGeometry args={[0.024, length, 0.014]} />
              </mesh>
            ))}
            {[-1, 1].map((sy) => (
              <mesh key={sy} material={m.aluminum} position={[0, (sy * length) / 2, 0]}>
                <boxGeometry args={[0.024, 0.014, width]} />
              </mesh>
            ))}
            {/* bisagras entre paneles */}
            {i > 0 &&
              [-1, 1].map((sz) => (
                <mesh key={sz} material={m.blackAnodized} position={[0, -length / 2 - gap / 2, sz * width * 0.3]} rotation={[Math.PI / 2, 0, 0]}>
                  <cylinderGeometry args={[0.012, 0.012, 0.08, 10]} />
                </mesh>
              ))}
          </group>
        );
      })}
    </group>
  );
}

const SolarBasic = ({ stowed }: PartModelProps) => <SolarWing panels={1} length={0.9} width={0.6} advanced={false} stowed={stowed} />;
const SolarAdv = ({ stowed }: PartModelProps) => <SolarWing panels={3} length={0.55} width={0.75} advanced stowed={stowed} />;

function BatteryBasic() {
  const m = M();
  return (
    <group position={[0, 0.09, 0]}>
      <mesh material={m.batteryBlue}>
        <boxGeometry args={[0.24, 0.16, 0.18]} />
      </mesh>
      <mesh material={m.frame} position={[0, 0, 0]} scale={[1.02, 0.3, 1.02]}>
        <boxGeometry args={[0.24, 0.16, 0.18]} />
      </mesh>
      <mesh material={m.ledRed} position={[-0.06, 0.095, 0]}>
        <cylinderGeometry args={[0.015, 0.015, 0.03, 12]} />
      </mesh>
      <mesh material={m.blackAnodized} position={[0.06, 0.095, 0]}>
        <cylinderGeometry args={[0.015, 0.015, 0.03, 12]} />
      </mesh>
    </group>
  );
}

function BatteryAdv() {
  const m = M();
  const cells = useMemo(() => {
    const out: Array<[number, number]> = [[0, 0]];
    for (let i = 0; i < 6; i++) out.push([Math.cos((i * Math.PI) / 3) * 0.075, Math.sin((i * Math.PI) / 3) * 0.075]);
    return out;
  }, []);
  return (
    <group position={[0, 0.11, 0]}>
      {cells.map(([x, z], i) => (
        <mesh key={i} position={[x, 0, z]} material={m.titanium}>
          <cylinderGeometry args={[0.034, 0.034, 0.2, 16]} />
        </mesh>
      ))}
      <mesh material={m.batteryBlue}>
        <cylinderGeometry args={[0.122, 0.122, 0.06, 6]} />
      </mesh>
      <mesh material={m.frame} position={[0, -0.105, 0]}>
        <cylinderGeometry args={[0.13, 0.13, 0.015, 6]} />
      </mesh>
      <mesh material={m.ledGreen} position={[0, 0.105, 0]}>
        <sphereGeometry args={[0.012, 8, 8]} />
      </mesh>
    </group>
  );
}

// ── COMUNICACIONES ─────────────────────────────────────────

function AntennaBasic() {
  const m = M();
  return (
    <group>
      <mesh material={m.frame} position={[0, 0.01, 0]}>
        <cylinderGeometry args={[0.05, 0.06, 0.02, 16]} />
      </mesh>
      <mesh material={m.whitePaint} position={[0, 0.24, 0]}>
        <cylinderGeometry args={[0.01, 0.012, 0.46, 8]} />
      </mesh>
      {/* dipolos cruzados (turnstile) */}
      {[0, Math.PI / 2].map((r) => (
        <mesh key={r} material={m.copper} position={[0, 0.4, 0]} rotation={[0, r, Math.PI / 2]}>
          <cylinderGeometry args={[0.005, 0.005, 0.28, 6]} />
        </mesh>
      ))}
      <mesh material={m.whitePaint} position={[0, 0.48, 0]}>
        <sphereGeometry args={[0.02, 12, 12]} />
      </mesh>
    </group>
  );
}

function AntennaHighGain() {
  const m = M();
  const f = 0.16;
  const dishGeom = useMemo(() => {
    const pts: Array<[number, number]> = [];
    for (let i = 0; i <= 16; i++) {
      const r = (i / 16) * 0.38;
      pts.push([r, (r * r) / (4 * f)]);
    }
    return lathe(pts, 64);
  }, []);
  const base = 0.24;
  return (
    <group>
      <mesh material={m.frame} position={[0, 0.08, 0]}>
        <cylinderGeometry args={[0.03, 0.04, 0.16, 12]} />
      </mesh>
      {/* cardán */}
      <mesh material={m.blackAnodized} position={[0, 0.18, 0]}>
        <boxGeometry args={[0.1, 0.06, 0.1]} />
      </mesh>
      <mesh geometry={dishGeom} material={m.dish} position={[0, base, 0]} />
      <mesh material={m.frame} position={[0, base + 0.005, 0]}>
        <torusGeometry args={[0.38, 0.008, 6, 64]} />
      </mesh>
      {/* bocina en el foco y tres soportes */}
      {[0, 1, 2].map((i) => {
        const a = (i * Math.PI * 2) / 3;
        const x = Math.cos(a) * 0.19;
        const z = Math.sin(a) * 0.19;
        const yb = base + (0.19 * 0.19) / (4 * f);
        const top = new THREE.Vector3(0, base + f, 0);
        const bot = new THREE.Vector3(x, yb, z);
        const mid = top.clone().add(bot).multiplyScalar(0.5);
        const len = top.distanceTo(bot);
        const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), top.clone().sub(bot).normalize());
        return (
          <mesh key={i} material={m.frame} position={mid} quaternion={q}>
            <cylinderGeometry args={[0.004, 0.004, len, 6]} />
          </mesh>
        );
      })}
      <mesh material={m.goldFoil} position={[0, base + f, 0]}>
        <cylinderGeometry args={[0.02, 0.03, 0.06, 12]} />
      </mesh>
    </group>
  );
}

// ── PROPULSIÓN ─────────────────────────────────────────────

function Thruster() {
  const m = M();
  const bell = useMemo(
    () =>
      lathe(
        [
          [0.035, 0.12],
          [0.045, 0.15],
          [0.07, 0.22],
          [0.1, 0.3],
          [0.125, 0.38],
        ],
        40,
      ),
    [],
  );
  return (
    <group>
      <mesh material={m.frame} position={[0, 0.015, 0]}>
        <cylinderGeometry args={[0.09, 0.09, 0.03, 20]} />
      </mesh>
      <mesh material={m.titanium} position={[0, 0.07, 0]}>
        <cylinderGeometry args={[0.05, 0.04, 0.08, 20]} />
      </mesh>
      <mesh geometry={bell} material={m.nozzle} />
      <mesh geometry={bell} material={m.nozzleInner} scale={[0.96, 1, 0.96]} />
      {[-1, 1].map((s) => (
        <mesh key={s} material={m.copper} position={[s * 0.065, 0.06, 0]} rotation={[0, 0, s * 0.5]}>
          <cylinderGeometry args={[0.006, 0.006, 0.09, 6]} />
        </mesh>
      ))}
    </group>
  );
}

function PropTank() {
  const m = M();
  return (
    <group position={[0, 0.2, 0]}>
      <mesh material={m.titanium}>
        <sphereGeometry args={[0.19, 32, 24]} />
      </mesh>
      <mesh material={m.frame} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[0.192, 0.012, 8, 48]} />
      </mesh>
      <mesh material={m.copper} position={[0, 0.2, 0]}>
        <cylinderGeometry args={[0.015, 0.015, 0.04, 8]} />
      </mesh>
      {[0, 1, 2, 3].map((i) => (
        <mesh key={i} material={m.frame} position={[Math.cos((i * Math.PI) / 2) * 0.12, -0.15, Math.sin((i * Math.PI) / 2) * 0.12]}>
          <cylinderGeometry args={[0.008, 0.008, 0.1, 6]} />
        </mesh>
      ))}
    </group>
  );
}

// ── CONTROL ────────────────────────────────────────────────

function Obc() {
  const m = M();
  return (
    <group position={[0, 0.05, 0]}>
      <mesh material={m.blackAnodized}>
        <boxGeometry args={[0.26, 0.08, 0.2]} />
      </mesh>
      {Array.from({ length: 7 }, (_, i) => (
        <mesh key={i} material={m.frame} position={[-0.105 + i * 0.035, 0.055, 0]}>
          <boxGeometry args={[0.008, 0.03, 0.18]} />
        </mesh>
      ))}
      <mesh material={m.ledGreen} position={[0.11, 0.01, 0.101]}>
        <boxGeometry args={[0.012, 0.012, 0.004]} />
      </mesh>
      <mesh material={m.copper} position={[-0.08, -0.01, 0.105]}>
        <boxGeometry args={[0.06, 0.025, 0.012]} />
      </mesh>
    </group>
  );
}

function AttitudeSensor() {
  const m = M();
  return (
    <group>
      <mesh material={m.frame} position={[0, 0.02, 0]}>
        <boxGeometry args={[0.16, 0.04, 0.12]} />
      </mesh>
      {/* dos cabezales con parasol, inclinados (rastreador estelar doble) */}
      {[-1, 1].map((s) => (
        <group key={s} position={[s * 0.045, 0.04, 0]} rotation={[0, 0, -s * 0.35]}>
          <mesh material={m.blackAnodized} position={[0, 0.08, 0]}>
            <cylinderGeometry args={[0.045, 0.032, 0.16, 20, 1, true]} />
          </mesh>
          <mesh material={m.glass} position={[0, 0.02, 0]}>
            <cylinderGeometry args={[0.03, 0.03, 0.01, 20]} />
          </mesh>
        </group>
      ))}
    </group>
  );
}

function ReactionWheels() {
  const m = M();
  return (
    <group position={[0, 0.12, 0]}>
      <mesh material={m.frame}>
        <boxGeometry args={[0.2, 0.2, 0.2]} />
      </mesh>
      {/* tres volantes, uno por eje */}
      <mesh material={m.silverFoil} position={[0, 0.115, 0]}>
        <cylinderGeometry args={[0.085, 0.085, 0.03, 32]} />
      </mesh>
      <mesh material={m.silverFoil} position={[0.115, 0, 0]} rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.085, 0.085, 0.03, 32]} />
      </mesh>
      <mesh material={m.silverFoil} position={[0, 0, 0.115]} rotation={[Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[0.085, 0.085, 0.03, 32]} />
      </mesh>
    </group>
  );
}

// ── INSTRUMENTOS ───────────────────────────────────────────

function Camera() {
  const m = M();
  return (
    <group>
      <mesh material={m.frame} position={[0, 0.03, 0]}>
        <boxGeometry args={[0.26, 0.06, 0.26]} />
      </mesh>
      <mesh material={m.whitePaint} position={[0, 0.27, 0]}>
        <cylinderGeometry args={[0.11, 0.11, 0.42, 32]} />
      </mesh>
      {/* parasol abierto y lente */}
      <mesh material={m.blackAnodized} position={[0, 0.52, 0]}>
        <cylinderGeometry args={[0.135, 0.115, 0.09, 32, 1, true]} />
      </mesh>
      <mesh material={m.glass} position={[0, 0.48, 0]}>
        <cylinderGeometry args={[0.09, 0.09, 0.012, 32]} />
      </mesh>
      <mesh material={m.goldFoil} position={[0, 0.12, 0]}>
        <cylinderGeometry args={[0.115, 0.115, 0.06, 32]} />
      </mesh>
    </group>
  );
}

function Spectrometer() {
  const m = M();
  return (
    <group>
      <mesh material={m.goldFoil} position={[0, 0.12, 0]}>
        <boxGeometry args={[0.34, 0.22, 0.26]} />
      </mesh>
      {/* apertura cónica */}
      <mesh material={m.blackAnodized} position={[0.06, 0.29, 0]}>
        <cylinderGeometry args={[0.09, 0.035, 0.12, 24, 1, true]} />
      </mesh>
      <mesh material={m.glass} position={[0.06, 0.24, 0]}>
        <cylinderGeometry args={[0.035, 0.035, 0.01, 24]} />
      </mesh>
      {/* radiador del detector frío */}
      <mesh material={m.whitePaint} position={[-0.17, 0.2, 0]} rotation={[0, 0, 0.25]}>
        <boxGeometry args={[0.012, 0.24, 0.24]} />
      </mesh>
    </group>
  );
}

function Radar() {
  const m = M();
  return (
    <group>
      <mesh material={m.frame} position={[0, 0.07, 0]}>
        <cylinderGeometry args={[0.03, 0.03, 0.14, 12]} />
      </mesh>
      <mesh material={m.frame} position={[0, 0.15, 0]}>
        <boxGeometry args={[0.5, 0.03, 0.08]} />
      </mesh>
      <mesh material={m.radarPanel} position={[0, 0.19, 0]}>
        <boxGeometry args={[1.25, 0.035, 0.45]} />
      </mesh>
    </group>
  );
}

// ── PROTECCIÓN ─────────────────────────────────────────────

function Thermal() {
  const m = M();
  return (
    <group position={[0, 0.03, 0]}>
      <mesh material={m.whitePaint}>
        <boxGeometry args={[0.36, 0.04, 0.3]} />
      </mesh>
      {/* persianas térmicas */}
      {Array.from({ length: 6 }, (_, i) => (
        <mesh key={i} material={m.silverFoil} position={[-0.15 + i * 0.06, 0.03, 0]} rotation={[0, 0, 0.5]}>
          <boxGeometry args={[0.05, 0.006, 0.26]} />
        </mesh>
      ))}
      {/* tubos de calor */}
      {[-0.1, 0.1].map((z) => (
        <mesh key={z} material={m.copper} position={[0, -0.025, z]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.008, 0.008, 0.36, 8]} />
        </mesh>
      ))}
    </group>
  );
}

export const PART_MODELS: Record<string, (p: PartModelProps) => ReactElement> = {
  'solar-basic': SolarBasic,
  'solar-adv': SolarAdv,
  'battery-basic': BatteryBasic,
  'battery-adv': BatteryAdv,
  'antenna-basic': AntennaBasic,
  'antenna-hg': AntennaHighGain,
  thruster: Thruster,
  'prop-tank': PropTank,
  obc: Obc,
  'attitude-sensor': AttitudeSensor,
  'reaction-wheels': ReactionWheels,
  camera: Camera,
  spectrometer: Spectrometer,
  radar: Radar,
  thermal: Thermal,
};

// ── ESTRUCTURA ─────────────────────────────────────────────

const CHASSIS_SKIN: Record<string, 'goldFoil' | 'silverFoil'> = {
  'chassis-s': 'goldFoil',
  'chassis-m': 'goldFoil',
  'chassis-l': 'silverFoil',
};

/** Cuádruple de propulsores RCS (control de actitud) en una esquina superior. */
function RcsQuad({ position, yaw }: { position: [number, number, number]; yaw: number }) {
  const m = M();
  return (
    <group position={position} rotation={[0, yaw, 0]}>
      <mesh material={m.blackAnodized}>
        <boxGeometry args={[0.07, 0.05, 0.07]} />
      </mesh>
      {[
        [0.045, 0, 0, 0, 0, -Math.PI / 2],
        [0, 0, 0.045, Math.PI / 2, 0, 0],
        [0, 0.035, 0, 0, 0, 0],
        [0, -0.035, 0, Math.PI, 0, 0],
      ].map(([x, y, z, rx, ry, rz], i) => (
        <mesh key={i} material={m.engineBell} position={[x, y, z]} rotation={[rx, ry, rz]}>
          <cylinderGeometry args={[0.008, 0.016, 0.03, 10, 1, true]} />
        </mesh>
      ))}
    </group>
  );
}

export function ChassisModel({ chassisId, half, xray }: { chassisId: string; half: [number, number, number]; xray: boolean }) {
  const m = M();
  const [hx, hy, hz] = half;
  const skin = useMemo(() => m[CHASSIS_SKIN[chassisId] ?? 'goldFoil'].clone(), [chassisId, m]);
  const deck = useMemo(() => m.aluminum.clone(), [m]);
  for (const mat of [skin, deck]) {
    if (mat.transparent !== xray) {
      mat.transparent = xray;
      mat.opacity = xray ? 0.16 : 1;
      mat.depthWrite = !xray;
      mat.needsUpdate = true;
    }
  }

  const bar = 0.035;
  const edges = useMemo(() => {
    const out: Array<{ p: [number, number, number]; s: [number, number, number] }> = [];
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) out.push({ p: [sx * hx, 0, sz * hz], s: [bar, hy * 2 + bar, bar] });
    for (const sy of [-1, 1]) {
      for (const sz of [-1, 1]) out.push({ p: [0, sy * hy, sz * hz], s: [hx * 2 + bar, bar, bar] });
      for (const sx of [-1, 1]) out.push({ p: [sx * hx, sy * hy, 0], s: [bar, bar, hz * 2 + bar] });
    }
    return out;
  }, [hx, hy, hz]);

  const ringR = Math.min(hx, hz) * 0.9;
  const adapterH = 0.12;

  return (
    <group>
      {/* Cuerpo con manta MLI */}
      <mesh material={skin} castShadow receiveShadow>
        <boxGeometry args={[hx * 2 - 0.01, hy * 2 - 0.01, hz * 2 - 0.01]} />
      </mesh>
      {/* Cubiertas superior e inferior (paneles de panal de aluminio) */}
      {[-1, 1].map((sy) => (
        <mesh key={sy} material={deck} position={[0, sy * (hy - 0.004), 0]}>
          <boxGeometry args={[hx * 2 + 0.02, 0.012, hz * 2 + 0.02]} />
        </mesh>
      ))}
      {/* Largueros */}
      {edges.map((e, i) => (
        <mesh key={i} position={e.p} material={m.frame}>
          <boxGeometry args={e.s} />
        </mesh>
      ))}
      {/* Propulsores RCS en las cuatro esquinas superiores */}
      {[
        [1, 1],
        [-1, 1],
        [-1, -1],
        [1, -1],
      ].map(([sx, sz]) => (
        <RcsQuad key={`${sx}${sz}`} position={[sx * (hx + 0.02), hy - 0.06, sz * (hz + 0.02)]} yaw={Math.atan2(sx, sz) - Math.PI / 4} />
      ))}
      {/* Adaptador de separación: anillo con abrazadera (Marman) y pernos */}
      <group position={[0, -hy - adapterH / 2, 0]}>
        <mesh material={m.aluminum}>
          <cylinderGeometry args={[ringR, ringR, adapterH, 64, 1, true]} />
        </mesh>
        <mesh material={m.frame} position={[0, -adapterH / 2, 0]} rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[ringR, 0.022, 8, 64]} />
        </mesh>
        {Array.from({ length: 12 }, (_, i) => {
          const a = (i / 12) * Math.PI * 2;
          return (
            <mesh key={i} material={m.titanium} position={[Math.cos(a) * (ringR + 0.01), 0, Math.sin(a) * (ringR + 0.01)]}>
              <boxGeometry args={[0.03, 0.05, 0.03]} />
            </mesh>
          );
        })}
      </group>
    </group>
  );
}
