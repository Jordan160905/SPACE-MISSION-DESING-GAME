/**
 * Texturas procedurales originales (Canvas 2D → THREE.CanvasTexture).
 * PROVISIONAL: sustituibles por mapas reales (p. ej. mosaicos lunares de dominio público de NASA)
 * colocados en /public/textures — ver docs/ASSETS.md.
 */
import * as THREE from 'three';

/** PRNG determinista para que la Luna sea siempre la misma. */
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Ruido de valor 2D periódico en X (para texturas equirectangulares sin costura). */
function makeValueNoise(rand: () => number, gw: number, gh: number) {
  const grid = Array.from({ length: gw * gh }, rand);
  const at = (x: number, y: number) => grid[((y % gh) + gh) % gh * gw + (((x % gw) + gw) % gw)];
  const smooth = (t: number) => t * t * (3 - 2 * t);
  return (u: number, v: number) => {
    const x = u * gw;
    const y = v * gh;
    const x0 = Math.floor(x);
    const y0 = Math.floor(y);
    const fx = smooth(x - x0);
    const fy = smooth(y - y0);
    const a = at(x0, y0) * (1 - fx) + at(x0 + 1, y0) * fx;
    const b = at(x0, y0 + 1) * (1 - fx) + at(x0 + 1, y0 + 1) * fx;
    return a * (1 - fy) + b * fy;
  };
}

function fbm(noises: Array<(u: number, v: number) => number>, u: number, v: number): number {
  let sum = 0;
  let amp = 0.5;
  let norm = 0;
  for (const n of noises) {
    sum += n(u, v) * amp;
    norm += amp;
    amp *= 0.5;
  }
  return sum / norm;
}

function canvas(w: number, h: number): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const ctx = c.getContext('2d');
  if (!ctx) throw new Error('Canvas 2D no disponible');
  return [c, ctx];
}

export function createMoonTexture(size = 1024): THREE.CanvasTexture {
  const w = size;
  const h = size / 2;
  const rand = mulberry32(1969);
  const [c, ctx] = canvas(w, h);
  const noises = [4, 8, 16, 32, 64].map((g) => makeValueNoise(rand, g, g / 2));

  // Albedo base: tierras altas claras y "mares" (basalto) oscuros.
  const img = ctx.createImageData(w, h);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const u = x / w;
      const v = y / h;
      const n = fbm(noises, u, v);
      const maria = n < 0.44 ? (0.44 - n) * 2.2 : 0;
      const base = 150 + (n - 0.5) * 90 - maria * 120;
      const i = (y * w + x) * 4;
      img.data[i] = base;
      img.data[i + 1] = base * 0.98;
      img.data[i + 2] = base * 0.95;
      img.data[i + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);

  // Cráteres: interior oscuro, borde iluminado.
  for (let k = 0; k < 520; k++) {
    const r = Math.pow(rand(), 3) * 26 + 1.5;
    const x = rand() * w;
    const y = h * 0.06 + rand() * h * 0.88;
    const g = ctx.createRadialGradient(x - r * 0.15, y - r * 0.15, r * 0.1, x, y, r);
    g.addColorStop(0, 'rgba(40,40,44,0.45)');
    g.addColorStop(0.75, 'rgba(60,60,64,0.25)');
    g.addColorStop(0.9, 'rgba(235,235,230,0.35)');
    g.addColorStop(1, 'rgba(235,235,230,0)');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.ellipse(x, y, r, r, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.anisotropy = 4;
  return tex;
}

export function createEarthTexture(size = 1024): THREE.CanvasTexture {
  const w = size;
  const h = size / 2;
  const rand = mulberry32(1972);
  const [c, ctx] = canvas(w, h);
  const land = [3, 6, 12, 24, 48].map((g) => makeValueNoise(rand, g, Math.max(2, g / 2)));
  const cloud = [6, 12, 24, 48].map((g) => makeValueNoise(rand, g, g / 2));
  const img = ctx.createImageData(w, h);
  for (let y = 0; y < h; y++) {
    const lat = Math.abs(y / h - 0.5) * 2; // 0 ecuador, 1 polo
    for (let x = 0; x < w; x++) {
      const u = x / w;
      const v = y / h;
      const n = fbm(land, u, v);
      const cl = fbm(cloud, u, v);
      let r: number, g: number, b: number;
      if (lat > 0.88) {
        r = g = b = 235; // casquetes
      } else if (n > 0.53) {
        const dry = Math.max(0, 1 - lat * 1.6);
        r = 60 + dry * 110;
        g = 110 + dry * 50;
        b = 60 + dry * 30;
      } else {
        const depth = (0.53 - n) * 2;
        r = 10;
        g = 50 + (1 - depth) * 50;
        b = 110 + (1 - depth) * 70;
      }
      const cover = Math.max(0, (cl - 0.52) * 3.2);
      const i = (y * w + x) * 4;
      img.data[i] = r + (255 - r) * Math.min(1, cover);
      img.data[i + 1] = g + (255 - g) * Math.min(1, cover);
      img.data[i + 2] = b + (255 - b) * Math.min(1, cover);
      img.data[i + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  return tex;
}

/**
 * Mapa de relieve de manta térmica multicapa (MLI): arrugas largas y pliegues irregulares.
 * Se usa como bumpMap/roughnessMap para que el dorado no parezca plástico.
 */
export function createFoilBumpTexture(seed = 7): THREE.CanvasTexture {
  const [c, ctx] = canvas(512, 512);
  const rand = mulberry32(seed);
  ctx.fillStyle = '#808080';
  ctx.fillRect(0, 0, 512, 512);
  ctx.lineCap = 'round';
  for (let i = 0; i < 260; i++) {
    const x = rand() * 512;
    const y = rand() * 512;
    const len = 30 + rand() * 140;
    const a = (rand() - 0.5) * 1.2 + (rand() < 0.5 ? 0 : Math.PI / 2);
    const light = rand() < 0.5;
    ctx.strokeStyle = light ? `rgba(255,255,255,${0.15 + rand() * 0.3})` : `rgba(0,0,0,${0.15 + rand() * 0.3})`;
    ctx.lineWidth = 1 + rand() * 4;
    ctx.beginPath();
    ctx.moveTo(x, y);
    const cx = x + Math.cos(a) * len * 0.5 + (rand() - 0.5) * 30;
    const cy = y + Math.sin(a) * len * 0.5 + (rand() - 0.5) * 30;
    ctx.quadraticCurveTo(cx, cy, x + Math.cos(a) * len, y + Math.sin(a) * len);
    ctx.stroke();
  }
  // Costuras de la manta (cinta de unión)
  ctx.strokeStyle = 'rgba(255,255,255,0.55)';
  ctx.lineWidth = 3;
  for (const p of [128, 384]) {
    ctx.beginPath();
    ctx.moveTo(p, 0);
    ctx.lineTo(p, 512);
    ctx.stroke();
  }
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  return tex;
}

/** Textura para el fuselaje del cohete: paneles, remaches y franjas. */
export function createRocketSkinTexture(): THREE.CanvasTexture {
  const [c, ctx] = canvas(512, 1024);
  ctx.fillStyle = '#eef0f2';
  ctx.fillRect(0, 0, 512, 1024);
  // Juntas horizontales de paneles
  ctx.strokeStyle = 'rgba(80,90,100,0.35)';
  ctx.lineWidth = 2;
  for (let y = 0; y < 1024; y += 128) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(512, y);
    ctx.stroke();
  }
  // Juntas verticales
  for (let x = 0; x < 512; x += 128) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, 1024);
    ctx.stroke();
  }
  // Remaches
  ctx.fillStyle = 'rgba(90,100,110,0.35)';
  for (let y = 4; y < 1024; y += 128)
    for (let x = 0; x < 512; x += 8) {
      ctx.beginPath();
      ctx.arc(x, y, 1.2, 0, Math.PI * 2);
      ctx.fill();
    }
  // Ligera suciedad vertical (hollín y escarcha)
  const rand = mulberry32(5);
  for (let i = 0; i < 120; i++) {
    ctx.fillStyle = `rgba(120,120,120,${rand() * 0.05})`;
    ctx.fillRect(rand() * 512, rand() * 1024, 1 + rand() * 3, 40 + rand() * 200);
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.anisotropy = 4;
  return tex;
}

/** Rejilla de células solares (o de elementos de antena) para paneles. */
export function createGridPanelTexture(base: string, line: string, cols: number, rows: number, cellGlow?: string): THREE.CanvasTexture {
  const [c, ctx] = canvas(256, 256);
  ctx.fillStyle = base;
  ctx.fillRect(0, 0, 256, 256);
  const cw = 256 / cols;
  const ch = 256 / rows;
  if (cellGlow) {
    for (let i = 0; i < cols; i++)
      for (let j = 0; j < rows; j++) {
        const g = ctx.createLinearGradient(i * cw, j * ch, (i + 1) * cw, (j + 1) * ch);
        g.addColorStop(0, cellGlow);
        g.addColorStop(1, base);
        ctx.fillStyle = g;
        ctx.fillRect(i * cw + 1.5, j * ch + 1.5, cw - 3, ch - 3);
      }
  }
  ctx.strokeStyle = line;
  ctx.lineWidth = 2;
  for (let i = 0; i <= cols; i++) {
    ctx.beginPath();
    ctx.moveTo(i * cw, 0);
    ctx.lineTo(i * cw, 256);
    ctx.stroke();
  }
  for (let j = 0; j <= rows; j++) {
    ctx.beginPath();
    ctx.moveTo(0, j * ch);
    ctx.lineTo(256, j * ch);
    ctx.stroke();
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}

/** Pantalla de consola: título + líneas de telemetría decorativas generadas una vez. */
export function createConsoleScreenTexture(title: string, subtitle: string, accent: string): THREE.CanvasTexture {
  const [c, ctx] = canvas(512, 320);
  const g = ctx.createLinearGradient(0, 0, 0, 320);
  g.addColorStop(0, '#071423');
  g.addColorStop(1, '#030912');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 512, 320);
  ctx.strokeStyle = accent;
  ctx.globalAlpha = 0.18;
  for (let y = 0; y < 320; y += 4) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(512, y);
    ctx.stroke();
  }
  ctx.globalAlpha = 1;
  ctx.lineWidth = 3;
  ctx.strokeRect(10, 10, 492, 300);
  ctx.fillStyle = accent;
  ctx.font = '600 44px "Chakra Petch", "IBM Plex Sans", sans-serif';
  ctx.fillText(title.toUpperCase(), 30, 80);
  ctx.globalAlpha = 0.75;
  ctx.font = '400 24px "IBM Plex Mono", monospace';
  ctx.fillText(subtitle, 30, 120);
  // Gráfico ilustrativo de la pantalla (no representa datos de la misión).
  const rand = mulberry32(title.length * 97);
  ctx.globalAlpha = 0.9;
  ctx.lineWidth = 2;
  ctx.beginPath();
  for (let x = 0; x <= 452; x += 8) {
    const y = 240 + Math.sin(x / 40 + title.length) * 22 + (rand() - 0.5) * 18;
    if (x === 0) ctx.moveTo(30 + x, y);
    else ctx.lineTo(30 + x, y);
  }
  ctx.stroke();
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}
