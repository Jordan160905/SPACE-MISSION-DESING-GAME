import { useRef } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';
import type { CameraShot } from './layout';

const reduceMotion =
  typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches === true;

/**
 * Interpola suavemente la cámara hacia el encuadre de la sección activa y añade un leve
 * paralaje con el puntero. Respeta prefers-reduced-motion.
 */
export function CameraRig({ shot }: { shot: CameraShot }) {
  const { camera, pointer } = useThree();
  const target = useRef(new THREE.Vector3(...shot.target));
  const desiredPos = useRef(new THREE.Vector3());
  const desiredTarget = useRef(new THREE.Vector3());

  useFrame((state, dt) => {
    const k = reduceMotion ? 1 : 1 - Math.exp(-dt * 2.2);
    const drift = reduceMotion ? 0 : Math.sin(state.clock.elapsedTime * 0.15) * 0.08;
    desiredPos.current.set(shot.position[0] + pointer.x * 0.25 + drift, shot.position[1] + pointer.y * 0.12, shot.position[2]);
    desiredTarget.current.set(...shot.target);
    camera.position.lerp(desiredPos.current, k);
    target.current.lerp(desiredTarget.current, k);
    camera.lookAt(target.current);
  });

  return null;
}
