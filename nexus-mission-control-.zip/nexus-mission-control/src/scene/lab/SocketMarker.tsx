import { useRef, useState } from 'react';
import { useFrame, type ThreeEvent } from '@react-three/fiber';
import { Html } from '@react-three/drei';
import * as THREE from 'three';
import { socketLabel } from '../../data/components/catalog';
import type { SocketDef } from '../../data/schemas';
import { socketQuaternion } from '../spacecraft/SpacecraftModel';

export type MarkerState = 'idle' | 'compatible' | 'blocked';

interface Props {
  socket: SocketDef;
  state: MarkerState;
  /** Motivo por el que no se puede colocar la pieza armada aquí. */
  blockedReason?: string;
  dragging: boolean;
  onDrop: (socketId: string) => void;
}

const COLORS: Record<MarkerState, string> = { idle: '#2a8fa0', compatible: '#7ef0a8', blocked: '#ff5d73' };

/** Punto de anclaje: anillo orientado según la normal del socket. */
export function SocketMarker({ socket, state, blockedReason, dragging, onDrop }: Props) {
  const ring = useRef<THREE.Group>(null);
  const [hover, setHover] = useState(false);

  useFrame((s) => {
    if (!ring.current) return;
    const pulse = state === 'compatible' ? 1 + Math.sin(s.clock.elapsedTime * 5) * 0.12 : 1;
    const k = (hover ? 1.35 : 1) * pulse;
    ring.current.scale.setScalar(k);
  });

  const over = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    setHover(true);
    document.body.style.cursor = state === 'compatible' ? 'copy' : state === 'blocked' ? 'not-allowed' : 'pointer';
  };
  const out = () => {
    setHover(false);
    document.body.style.cursor = '';
  };
  const activate = (e: ThreeEvent<PointerEvent | MouseEvent>) => {
    e.stopPropagation();
    if (state === 'compatible') onDrop(socket.id);
  };

  const color = COLORS[state];
  const opacity = state === 'idle' ? 0.55 : state === 'blocked' ? 0.35 : 0.95;

  return (
    <group position={socket.position} quaternion={socketQuaternion(socket)}>
      <group
        ref={ring}
        position={[0, 0.012, 0]}
        onPointerOver={over}
        onPointerOut={out}
        onClick={activate}
        onPointerUp={dragging ? activate : undefined}
      >
        <mesh rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[0.07, 0.012, 8, 32]} />
          <meshBasicMaterial color={color} transparent opacity={opacity} toneMapped={false} depthTest={false} />
        </mesh>
        <mesh rotation={[-Math.PI / 2, 0, 0]}>
          <circleGeometry args={[0.055, 24]} />
          <meshBasicMaterial color={color} transparent opacity={opacity * 0.35} toneMapped={false} depthTest={false} side={THREE.DoubleSide} />
        </mesh>
        {/* Zona de impacto ampliada para facilitar el arrastre */}
        <mesh visible={false}>
          <sphereGeometry args={[0.13, 8, 8]} />
        </mesh>
      </group>
      {hover && (
        <Html center position={[0, 0.25, 0]} style={{ pointerEvents: 'none' }}>
          <div className="scene-tag" style={{ borderColor: color }}>
            {socketLabel(socket.id)} · {socket.type}
            {state === 'blocked' && blockedReason ? <div className="scene-tag__reason">{blockedReason}</div> : null}
          </div>
        </Html>
      )}
    </group>
  );
}
