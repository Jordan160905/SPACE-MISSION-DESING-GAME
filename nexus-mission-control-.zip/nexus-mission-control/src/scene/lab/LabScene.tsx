/**
 * Escena 3D del Spacecraft Lab: hangar de integración con la nave del jugador en el centro.
 * Lee el borrador del store y envía acciones (colocar, seleccionar). Las reglas están en sim/.
 */
import { Suspense, useEffect, useMemo } from 'react';
import { Canvas, useThree } from '@react-three/fiber';
import { Html, OrbitControls } from '@react-three/drei';
import * as THREE from 'three';
import { getComponent } from '../../data/components/catalog';
import { getLauncher, LAUNCHERS } from '../../data/launchers/launchers';
import { canPlace, designTotals, partAt, validateDesign } from '../../sim/DesignSystem';
import { stowedEnvelope } from '../../sim/EnvelopeSystem';
import { LaunchPad, LaunchVehicle } from '../launcher/LaunchVehicle';
import { computeRocketLayout } from '../launcher/rocketLayout';
import { selectLabObjectiveInstrument, useGameStore } from '../../state/useGameStore';
import { Starfield } from '../objects/Starfield';
import { SpacecraftModel } from '../spacecraft/SpacecraftModel';
import { SocketMarker, type MarkerState } from './SocketMarker';

const FLOOR_Y = -1.25;

function Hangar() {
  return (
    <group>
      <gridHelper args={[16, 32, '#1f6f7d', '#0f2a35']} position={[0, FLOOR_Y, 0]} />
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, FLOOR_Y - 0.01, 0]} receiveShadow>
        <circleGeometry args={[9, 64]} />
        <meshStandardMaterial color="#050a12" metalness={0.8} roughness={0.4} />
      </mesh>
      {/* cuna de integración */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, FLOOR_Y + 0.005, 0]}>
        <ringGeometry args={[1.6, 1.68, 96]} />
        <meshBasicMaterial color="#63e6f0" transparent opacity={0.6} toneMapped={false} />
      </mesh>
      <mesh position={[0, FLOOR_Y + 0.12, 0]}>
        <cylinderGeometry args={[0.55, 0.7, 0.24, 48]} />
        <meshStandardMaterial color="#0e1826" metalness={0.8} roughness={0.35} />
      </mesh>
      <mesh position={[0, FLOOR_Y + 0.24 + 0.4, 0]}>
        <cylinderGeometry args={[0.025, 0.025, 0.8, 8]} />
        <meshStandardMaterial color="#2b3442" metalness={0.8} roughness={0.4} />
      </mesh>
      {[0, 1, 2, 3, 4, 5].map((i) => {
        const a = (i / 6) * Math.PI * 2;
        return (
          <mesh key={i} position={[Math.cos(a) * 6.5, FLOOR_Y + 2, Math.sin(a) * 6.5]}>
            <boxGeometry args={[0.25, 4, 0.25]} />
            <meshStandardMaterial color="#0b1420" emissive="#0d3540" emissiveIntensity={0.6} />
          </mesh>
        );
      })}
    </group>
  );
}

/** Reencuadra la cámara al cambiar de vista (nave ↔ cohete) o de lanzador. */
function ViewFramer({ position, target }: { position: [number, number, number]; target: [number, number, number] }) {
  const camera = useThree((s) => s.camera);
  const controls = useThree((s) => s.controls) as unknown as { target: THREE.Vector3; update: () => void } | null;
  const key = [...position, ...target].map((n) => n.toFixed(2)).join(',');
  useEffect(() => {
    camera.position.set(...position);
    if (controls) {
      controls.target.set(...target);
      controls.update();
    } else {
      camera.lookAt(...target);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, controls]);
  return null;
}

function RocketContent() {
  const lab = useGameStore((s) => s.lab);
  const launcher = getLauncher(lab.rocket.launcherId) ?? LAUNCHERS.find((l) => l.id === 'falcon-9')!;
  const envelope = useMemo(() => stowedEnvelope(lab.draft, getComponent), [lab.draft]);
  const mass = useMemo(() => designTotals(lab.draft, getComponent).massWetKg, [lab.draft]);
  const layout = useMemo(() => computeRocketLayout(launcher, envelope, lab.rocket.exploded), [launcher, envelope, lab.rocket.exploded]);
  const H = layout.heightM * (lab.rocket.exploded ? 1.25 : 1);
  const lift = layout.engine.bellLen + 1.2; // la plataforma queda en y = 0
  const maxR = Math.max(layout.fairing.r, layout.r1 + (layout.boosters ? layout.boosters.offsetX : 0));
  const dist = Math.max(H * 1.5, 8);

  return (
    <>
      <color attach="background" args={['#04080f']} />
      <fog attach="fog" args={['#04080f', dist * 1.4, dist * 4]} />
      <ambientLight intensity={0.45} color="#9fb3ff" />
      <hemisphereLight args={['#4a6a9a', '#05070c', 0.6]} />
      <directionalLight position={[H * 0.6, H, H * 0.8]} intensity={2.6} color="#fff1dc" castShadow />
      <directionalLight position={[-H, H * 0.3, -H * 0.4]} intensity={0.7} color="#63e6f0" />
      <Starfield count={2500} radius={Math.max(200, H * 4)} />
      <gridHelper args={[Math.max(80, H * 3), 60, '#1f6f7d', '#0f2a35']} position={[0, 0.01, 0]} />
      <OrbitControls makeDefault enablePan={false} minDistance={2} maxDistance={dist * 2.5} maxPolarAngle={Math.PI * 0.62} enableDamping />
      <ViewFramer position={[dist * 0.55, H * 0.55, dist * 0.85]} target={[0, H * 0.48, 0]} />
      <group position={[0, lift, 0]}>
        {!lab.rocket.exploded && <LaunchPad height={layout.heightM} radius={maxR} engineDrop={layout.engine.bellLen} />}
        <LaunchVehicle
          launcher={launcher}
          design={lab.draft}
          envelope={envelope}
          craftMassKg={mass}
          fairingMode={lab.rocket.fairing}
          exploded={lab.rocket.exploded}
          labels={lab.rocket.labels}
        />
      </group>
    </>
  );
}

function LabContent() {
  const view = useGameStore((s) => s.lab.view);
  return view === 'rocket' ? <RocketContent /> : <CraftContent />;
}

function CraftContent() {
  const lab = useGameStore((s) => s.lab);
  const objectiveInstrument = useGameStore(selectLabObjectiveInstrument);
  const select = useGameStore((s) => s.labSelect);
  const dropOn = useGameStore((s) => s.labDropOn);
  const { draft, armed, dragging, selectedId } = lab;

  const chassis = draft.chassisId ? getComponent(draft.chassisId) : undefined;
  const issues = useMemo(() => validateDesign(draft, getComponent, { objectiveInstrumentId: objectiveInstrument }), [draft, objectiveInstrument]);
  const issueIds = useMemo(() => new Set(issues.filter((i) => i.severity === 'critical').flatMap((i) => i.instanceIds)), [issues]);

  const armedComp = armed ? getComponent(armed.componentId) : undefined;
  const selectedPart = draft.parts.find((p) => p.instanceId === selectedId);
  const selectedSocket = selectedPart && chassis?.sockets.find((s) => s.id === selectedPart.socketId);
  const xray =
    lab.xray || (armedComp?.mountsOn.includes('internal') ?? false) || selectedSocket?.type === 'internal';

  return (
    <>
      <color attach="background" args={['#03070e']} />
      <fog attach="fog" args={['#03070e', 9, 30]} />
      <ambientLight intensity={0.35} color="#9fb3ff" />
      <hemisphereLight args={['#3a5a8a', '#05070c', 0.5]} />
      <directionalLight position={[5, 8, 4]} intensity={2.2} color="#fff1dc" castShadow />
      <directionalLight position={[-6, 2, -3]} intensity={0.8} color="#63e6f0" />
      <spotLight position={[0, 6, 0]} angle={0.5} penumbra={0.6} intensity={18} color="#ffffff" />
      <Starfield count={1200} radius={60} />
      <Hangar />

      <OrbitControls makeDefault enablePan={false} minDistance={1.8} maxDistance={9} maxPolarAngle={Math.PI * 0.85} enableDamping />
      <ViewFramer position={[3.3, 2.1, 4.4]} target={[0, 0.1, 0]} />

      {chassis ? (
        <>
          <SpacecraftModel
            design={draft}
            xray={xray}
            interaction={{ selectedId, issueInstanceIds: issueIds, onSelect: (id) => select(id) }}
          />
          {chassis.sockets.map((s) => {
            if (partAt(draft, s.id) && partAt(draft, s.id)?.instanceId !== armed?.moveInstanceId) return null;
            if (s.type === 'internal' && !xray) return null;
            let state: MarkerState = 'idle';
            let reason: string | undefined;
            if (armed) {
              const check = canPlace(draft, armed.componentId, s.id, getComponent, armed.moveInstanceId);
              state = check.ok ? 'compatible' : 'blocked';
              reason = check.ok ? undefined : check.reason;
            }
            return <SocketMarker key={s.id} socket={s} state={state} blockedReason={reason} dragging={dragging} onDrop={dropOn} />;
          })}
        </>
      ) : (
        <Html center position={[0, 0.2, 0]} style={{ pointerEvents: 'none' }}>
          <div className="scene-tag scene-tag--big">Elige un chasis en el catálogo para empezar</div>
        </Html>
      )}
    </>
  );
}

export default function LabScene() {
  const select = useGameStore((s) => s.labSelect);
  return (
    <Canvas
      className="scene-canvas"
      shadows
      dpr={[1, 1.75]}
      camera={{ position: [3.3, 2.1, 4.4], fov: 40, near: 0.05, far: 2000 }}
      gl={{ antialias: true }}
      onCreated={({ gl }) => {
        gl.toneMapping = THREE.ACESFilmicToneMapping;
        gl.toneMappingExposure = 1.05;
      }}
      onPointerMissed={(e) => {
        if (e.type === 'click') select(null);
      }}
    >
      <Suspense fallback={null}>
        <LabContent />
      </Suspense>
    </Canvas>
  );
}
