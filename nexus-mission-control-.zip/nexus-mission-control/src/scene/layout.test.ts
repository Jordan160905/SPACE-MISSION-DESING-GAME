import { describe, expect, it } from 'vitest';
import { facingOrigin, OVERVIEW_SHOT, shotForScreen, stationShot, STATIONS } from './layout';

describe('layout del Mission Center', () => {
  it('cada consola mira hacia el centro', () => {
    for (const s of STATIONS) {
      const a = facingOrigin(s.position);
      // Dirección del frente (+Z rotado) debe apuntar al origen.
      const dir = [Math.sin(a), Math.cos(a)];
      const toOrigin = [-s.position[0], -s.position[2]];
      const len = Math.hypot(toOrigin[0], toOrigin[1]);
      expect(dir[0] * (toOrigin[0] / len) + dir[1] * (toOrigin[1] / len), s.id).toBeCloseTo(1, 6);
    }
  });

  it('el encuadre de una consola queda entre la consola y el centro', () => {
    for (const s of STATIONS) {
      const shot = stationShot(s.position);
      expect(Math.hypot(shot.position[0], shot.position[2])).toBeLessThan(Math.hypot(s.position[0], s.position[2]));
    }
  });

  it('cada sección tiene encuadre definido', () => {
    expect(shotForScreen('center', 'objectives')).toEqual(OVERVIEW_SHOT);
    for (const sc of ['briefing', 'planner', 'lab', 'archive', 'glossary'] as const) {
      expect(shotForScreen(sc, 'objectives').position.length).toBe(3);
    }
  });

  it('las consolas no se superponen', () => {
    for (let i = 0; i < STATIONS.length; i++)
      for (let j = i + 1; j < STATIONS.length; j++) {
        const a = STATIONS[i].position;
        const b = STATIONS[j].position;
        expect(Math.hypot(a[0] - b[0], a[2] - b[2])).toBeGreaterThan(1.5);
      }
  });
});
