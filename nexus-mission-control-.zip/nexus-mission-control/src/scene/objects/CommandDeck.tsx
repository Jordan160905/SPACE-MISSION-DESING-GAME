import { useMemo } from 'react';
import * as THREE from 'three';

/** Plataforma circular del centro de mando: suelo, anillos emisivos, radiales y pilares. */
export function CommandDeck() {
  const radialGeometry = useMemo(() => {
    const pts: number[] = [];
    const n = 24;
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2;
      pts.push(Math.cos(a) * 1.5, 0, Math.sin(a) * 1.5, Math.cos(a) * 7.5, 0, Math.sin(a) * 7.5);
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pts, 3));
    return g;
  }, []);

  const pillars = useMemo(() => {
    const n = 12;
    return Array.from({ length: n }, (_, i) => {
      const a = (i / n) * Math.PI * 2 + Math.PI / n;
      return { x: Math.cos(a) * 8.2, z: Math.sin(a) * 8.2, a };
    }).filter((p) => p.z < 3); // deja libre la vista hacia la cámara
  }, []);

  return (
    <group>
      <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <circleGeometry args={[8.6, 96]} />
        <meshStandardMaterial color="#070d16" metalness={0.85} roughness={0.32} />
      </mesh>
      {[1.5, 3.0, 4.9, 7.5].map((r, i) => (
        <mesh key={r} rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.004, 0]}>
          <ringGeometry args={[r, r + (i === 3 ? 0.05 : 0.018), 128]} />
          <meshBasicMaterial color={i === 3 ? '#ffb547' : '#2a8fa0'} transparent opacity={i === 3 ? 0.55 : 0.4} toneMapped={false} />
        </mesh>
      ))}
      <lineSegments geometry={radialGeometry} position={[0, 0.003, 0]}>
        <lineBasicMaterial color="#163a4a" transparent opacity={0.6} />
      </lineSegments>
      {pillars.map((p) => (
        <group key={p.a} position={[p.x, 0, p.z]} rotation={[0, -p.a, 0]}>
          <mesh position={[0, 2.2, 0]} castShadow>
            <boxGeometry args={[0.35, 4.4, 0.5]} />
            <meshStandardMaterial color="#0b1420" metalness={0.8} roughness={0.4} />
          </mesh>
          <mesh position={[-0.18, 2.2, 0]}>
            <boxGeometry args={[0.02, 3.6, 0.06]} />
            <meshBasicMaterial color="#63e6f0" transparent opacity={0.7} toneMapped={false} />
          </mesh>
        </group>
      ))}
    </group>
  );
}
