import { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { mulberry32 } from '../proceduralTextures';

/** Campo de estrellas sobre una esfera lejana, con brillo y color variables. */
export function Starfield({ count = 3500, radius = 180 }: { count?: number; radius?: number }) {
  const ref = useRef<THREE.Points>(null);
  const geometry = useMemo(() => {
    const rand = mulberry32(42);
    const pos = new Float32Array(count * 3);
    const col = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      const u = rand() * 2 - 1;
      const t = rand() * Math.PI * 2;
      const s = Math.sqrt(1 - u * u);
      const r = radius * (0.85 + rand() * 0.15);
      pos.set([r * s * Math.cos(t), r * u, r * s * Math.sin(t)], i * 3);
      const temp = rand();
      const b = 0.55 + rand() * 0.45;
      // Estrellas frías (azuladas) y cálidas (anaranjadas).
      col.set(temp < 0.15 ? [b, b * 0.85, b * 0.7] : temp > 0.85 ? [b * 0.8, b * 0.9, b] : [b, b, b], i * 3);
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    g.setAttribute('color', new THREE.BufferAttribute(col, 3));
    return g;
  }, [count, radius]);

  useFrame((_, dt) => {
    if (ref.current) ref.current.rotation.y += dt * 0.004;
  });

  return (
    <points ref={ref} geometry={geometry}>
      <pointsMaterial size={0.55} sizeAttenuation vertexColors transparent opacity={0.95} depthWrite={false} />
    </points>
  );
}
