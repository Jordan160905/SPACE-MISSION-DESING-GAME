import { useMemo, useRef, useState } from 'react';
import { useFrame, type ThreeEvent } from '@react-three/fiber';
import { Html } from '@react-three/drei';
import * as THREE from 'three';
import { createConsoleScreenTexture } from '../proceduralTextures';
import { facingOrigin, type StationDef } from '../layout';

interface ConsoleProps {
  station: StationDef;
  active: boolean;
  onActivate: () => void;
}

/** Puesto de control interactivo: pedestal, pantalla inclinada y tira de luz. */
export function Console({ station, active, onActivate }: ConsoleProps) {
  const [hover, setHover] = useState(false);
  const screenRef = useRef<THREE.MeshStandardMaterial>(null);
  const groupRef = useRef<THREE.Group>(null);
  const screenTex = useMemo(
    () => createConsoleScreenTexture(station.title, station.subtitle, station.accent),
    [station.title, station.subtitle, station.accent],
  );
  const accent = useMemo(() => new THREE.Color(station.accent), [station.accent]);
  const lit = hover || active;

  useFrame((_, dt) => {
    if (screenRef.current) {
      const target = lit ? 1.6 : 0.9;
      screenRef.current.emissiveIntensity += (target - screenRef.current.emissiveIntensity) * Math.min(1, dt * 6);
    }
    if (groupRef.current) {
      const s = hover ? 1.04 : 1;
      groupRef.current.scale.lerp(new THREE.Vector3(s, s, s), Math.min(1, dt * 8));
    }
  });

  const over = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    setHover(true);
    document.body.style.cursor = 'pointer';
  };
  const out = () => {
    setHover(false);
    document.body.style.cursor = '';
  };

  return (
    <group
      ref={groupRef}
      position={station.position}
      rotation={[0, facingOrigin(station.position), 0]}
      onPointerOver={over}
      onPointerOut={out}
      onClick={(e) => {
        e.stopPropagation();
        onActivate();
      }}
    >
      {/* Pedestal */}
      <mesh position={[0, 0.45, 0]} castShadow>
        <boxGeometry args={[1.3, 0.9, 0.55]} />
        <meshStandardMaterial color="#101b2a" metalness={0.75} roughness={0.4} />
      </mesh>
      <mesh position={[0, 0.91, 0.06]} rotation={[-0.35, 0, 0]}>
        <boxGeometry args={[1.32, 0.04, 0.5]} />
        <meshStandardMaterial color="#182638" metalness={0.6} roughness={0.5} />
      </mesh>
      {/* Tira de luz frontal */}
      <mesh position={[0, 0.2, 0.28]}>
        <boxGeometry args={[1.1, 0.025, 0.01]} />
        <meshBasicMaterial color={accent} toneMapped={false} />
      </mesh>
      {/* Brazo y pantalla */}
      <mesh position={[0, 1.15, -0.2]}>
        <boxGeometry args={[0.08, 0.5, 0.06]} />
        <meshStandardMaterial color="#0d1724" metalness={0.8} roughness={0.35} />
      </mesh>
      <group position={[0, 1.5, -0.12]} rotation={[-0.18, 0, 0]}>
        <mesh>
          <boxGeometry args={[1.25, 0.8, 0.05]} />
          <meshStandardMaterial color="#0a121d" metalness={0.7} roughness={0.3} />
        </mesh>
        <mesh position={[0, 0, 0.027]}>
          <planeGeometry args={[1.17, 0.73]} />
          <meshStandardMaterial ref={screenRef} map={screenTex} emissiveMap={screenTex} emissive="#ffffff" emissiveIntensity={0.9} toneMapped={false} />
        </mesh>
      </group>
      <pointLight position={[0, 1.4, 0.5]} color={accent} intensity={lit ? 2.2 : 0.8} distance={3} decay={2} />
      {hover && (
        <Html center position={[0, 2.2, 0]} style={{ pointerEvents: 'none' }}>
          <div className="scene-tag" style={{ borderColor: station.accent }}>
            Abrir · {station.title}
          </div>
        </Html>
      )}
    </group>
  );
}
