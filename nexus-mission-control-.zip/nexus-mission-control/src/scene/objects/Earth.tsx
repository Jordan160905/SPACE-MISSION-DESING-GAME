import { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { createEarthTexture } from '../proceduralTextures';

const atmosphereVertex = /* glsl */ `
  varying vec3 vNormal;
  varying vec3 vView;
  void main() {
    vec4 mv = modelViewMatrix * vec4(position, 1.0);
    vNormal = normalize(normalMatrix * normal);
    vView = normalize(-mv.xyz);
    gl_Position = projectionMatrix * mv;
  }
`;
const atmosphereFragment = /* glsl */ `
  uniform vec3 uColor;
  varying vec3 vNormal;
  varying vec3 vView;
  void main() {
    float rim = pow(1.0 - max(dot(vNormal, vView), 0.0), 2.6);
    gl_FragColor = vec4(uColor, rim * 0.9);
  }
`;

/** Tierra de fondo con atmósfera por efecto Fresnel. */
export function Earth({ position, radius }: { position: [number, number, number]; radius: number }) {
  const ref = useRef<THREE.Mesh>(null);
  const map = useMemo(() => createEarthTexture(1024), []);
  const atmosphere = useMemo(
    () =>
      new THREE.ShaderMaterial({
        vertexShader: atmosphereVertex,
        fragmentShader: atmosphereFragment,
        uniforms: { uColor: { value: new THREE.Color('#5fb4ff') } },
        transparent: true,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        side: THREE.FrontSide,
      }),
    [],
  );

  useFrame((_, dt) => {
    if (ref.current) ref.current.rotation.y += dt * 0.01;
  });

  return (
    <group position={position} rotation={[0.2, 0, 0.41]}>
      <mesh ref={ref}>
        <sphereGeometry args={[radius, 96, 64]} />
        <meshStandardMaterial map={map} roughness={0.85} metalness={0} />
      </mesh>
      <mesh material={atmosphere} scale={1.045}>
        <sphereGeometry args={[radius, 64, 48]} />
      </mesh>
    </group>
  );
}
