import { useMemo, useRef, useState } from 'react';
import { useFrame, type ThreeEvent } from '@react-three/fiber';
import { Html } from '@react-three/drei';
import * as THREE from 'three';
import { createMoonTexture, mulberry32 } from '../proceduralTextures';

const TABLE_TOP = 0.95;
const HOLO_CENTER = 1.75;
const MOON_R = 0.5;
/**
 * Radio visual de la órbita. EXAGERADO: a escala real, 50–100 km serían ~3–6 % del radio lunar.
 * Se mantiene la relación «más alto = más lejos» para que el cambio de altitud se perciba.
 */
function orbitRadius(altitudeKm: number): number {
  return MOON_R * (1.15 + Math.min(altitudeKm, 300) / 300);
}

interface HoloTableProps {
  /** Inclinación orbital mostrada en el holograma (grados). */
  inclinationDeg: number;
  altitudeKm: number;
  label: string;
  onActivate: () => void;
}

function RisingParticles({ count = 140 }: { count?: number }) {
  const ref = useRef<THREE.Points>(null);
  const { geometry, speeds } = useMemo(() => {
    const rand = mulberry32(7);
    const pos = new Float32Array(count * 3);
    const sp = new Float32Array(count);
    for (let i = 0; i < count; i++) {
      const a = rand() * Math.PI * 2;
      const r = Math.sqrt(rand()) * 0.85;
      pos.set([Math.cos(a) * r, TABLE_TOP + rand() * 1.6, Math.sin(a) * r], i * 3);
      sp[i] = 0.08 + rand() * 0.25;
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    return { geometry: g, speeds: sp };
  }, [count]);

  useFrame((_, dt) => {
    const attr = geometry.getAttribute('position') as THREE.BufferAttribute;
    for (let i = 0; i < count; i++) {
      let y = attr.getY(i) + speeds[i] * dt;
      if (y > TABLE_TOP + 1.7) y = TABLE_TOP;
      attr.setY(i, y);
    }
    attr.needsUpdate = true;
  });

  return (
    <points ref={ref} geometry={geometry}>
      <pointsMaterial color="#7befff" size={0.025} transparent opacity={0.7} blending={THREE.AdditiveBlending} depthWrite={false} />
    </points>
  );
}

export function HoloTable({ inclinationDeg, altitudeKm, label, onActivate }: HoloTableProps) {
  const ORBIT_R = orbitRadius(altitudeKm);
  const moonRef = useRef<THREE.Mesh>(null);
  const probeRef = useRef<THREE.Mesh>(null);
  const [hover, setHover] = useState(false);
  const moonMap = useMemo(() => createMoonTexture(1024), []);
  const incl = THREE.MathUtils.degToRad(inclinationDeg);

  useFrame((state, dt) => {
    if (moonRef.current) moonRef.current.rotation.y += dt * 0.12;
    if (probeRef.current) {
      const t = state.clock.elapsedTime * 0.7;
      probeRef.current.position.set(Math.cos(t) * ORBIT_R, 0, Math.sin(t) * ORBIT_R);
    }
  });

  const over = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    setHover(true);
    document.body.style.cursor = 'pointer';
  };
  const out = () => {
    setHover(false);
    document.body.style.cursor = '';
  };

  return (
    <group>
      {/* Base de la mesa */}
      <mesh position={[0, TABLE_TOP / 2, 0]} castShadow receiveShadow>
        <cylinderGeometry args={[1.05, 1.25, TABLE_TOP, 48]} />
        <meshStandardMaterial color="#0c1522" metalness={0.8} roughness={0.35} />
      </mesh>
      <mesh position={[0, TABLE_TOP + 0.005, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[0.92, 1.03, 96]} />
        <meshBasicMaterial color="#63e6f0" toneMapped={false} />
      </mesh>
      <mesh position={[0, TABLE_TOP + 0.003, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <circleGeometry args={[0.92, 64]} />
        <meshStandardMaterial color="#061019" emissive="#0b3946" emissiveIntensity={0.6} metalness={0.2} roughness={0.2} />
      </mesh>

      {/* Haz de proyección */}
      <mesh position={[0, TABLE_TOP + 0.75, 0]}>
        <cylinderGeometry args={[0.75, 0.9, 1.5, 48, 1, true]} />
        <meshBasicMaterial color="#38c8d8" transparent opacity={hover ? 0.11 : 0.06} side={THREE.DoubleSide} blending={THREE.AdditiveBlending} depthWrite={false} />
      </mesh>
      <RisingParticles />
      <pointLight position={[0, TABLE_TOP + 0.3, 0]} color="#4fd9ea" intensity={hover ? 9 : 6} distance={6} decay={2} />

      {/* Holograma lunar (interactivo) */}
      <group position={[0, HOLO_CENTER, 0]} onPointerOver={over} onPointerOut={out} onClick={(e) => { e.stopPropagation(); onActivate(); }}>
        <mesh ref={moonRef}>
          <sphereGeometry args={[MOON_R, 96, 64]} />
          <meshStandardMaterial map={moonMap} emissive="#1d6a78" emissiveIntensity={hover ? 0.45 : 0.25} roughness={0.95} />
        </mesh>
        <mesh scale={1.03}>
          <sphereGeometry args={[MOON_R, 32, 16]} />
          <meshBasicMaterial color="#63e6f0" wireframe transparent opacity={hover ? 0.22 : 0.1} depthWrite={false} />
        </mesh>
        {/* Órbita con la inclinación del objetivo elegido */}
        <group rotation={[0, 0, incl]}>
          <mesh rotation={[Math.PI / 2, 0, 0]}>
            <torusGeometry args={[ORBIT_R, 0.006, 8, 160]} />
            <meshBasicMaterial color="#ffb547" toneMapped={false} />
          </mesh>
          <mesh ref={probeRef}>
            <sphereGeometry args={[0.03, 16, 16]} />
            <meshBasicMaterial color="#fff2c8" toneMapped={false} />
          </mesh>
        </group>
        {/* Eje polar de referencia */}
        <mesh>
          <cylinderGeometry args={[0.003, 0.003, MOON_R * 3, 6]} />
          <meshBasicMaterial color="#63e6f0" transparent opacity={0.35} />
        </mesh>
        {/* Zona invisible ampliada para facilitar el clic */}
        <mesh visible={false}>
          <sphereGeometry args={[ORBIT_R * 1.1, 16, 16]} />
        </mesh>
        {hover && (
          <Html center position={[0, MOON_R + 0.45, 0]} style={{ pointerEvents: 'none' }}>
            <div className="scene-tag">{label}</div>
          </Html>
        )}
      </group>
    </group>
  );
}
