/**
 * Capa 3D de los descubrimientos (Fase 8.4) y del rescate (Fase 8.5) dentro de la escena del vuelo.
 *  - El objeto detectado se dibuja en la posición física que da sim/Discoveries (órbitas reales,
 *    paso de meteoroides y asteroides, puntos de la superficie lunar).
 *  - Las estrellas, constelaciones y nebulosas se dibujan en sus coordenadas celestes reales
 *    (física (x, y, z) → three (x, z, −y)), muy lejos y centradas en la cámara.
 *  - El satélite del rescate se coloca respecto de la nave con la posición relativa del simulador.
 */
import { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { discoveryById, objectPosition, skyCenter, skyDir, type DiscoveryDef } from '../../sim/Discoveries';
import { flightStateAt, type FlightProfile } from '../../sim/FlightDynamics';
import { useFlightSim } from '../../ui/flight/flightSim';
import { CubeSat, DiscoveryObject } from './DiscoveryModels';

const SKY_R = 9e6;
const RESCUE_VISIBLE = ['locate', 'observe', 'plan', 'approach', 'assist', 'done', 'failed'];

/** ¿Hay un rescate en curso con el satélite a la vista? */
export function rescueInView() {
  const s = useFlightSim.getState();
  return !!s.rescue && !s.rescueSettled && RESCUE_VISIBLE.includes(s.rescue.step);
}

/**
 * Objetivo de la cámara de observación. Para objetos con posición, `out` recibe su posición
 * absoluta (km, three); para objetos del cielo, su dirección unitaria.
 */
export function currentTarget(profile: FlightProfile, T: number, craft: THREE.Vector3, out: THREE.Vector3): { sizeKm: number; sky: boolean; skyDeg: number } | null {
  const s = useFlightSim.getState();
  const r = s.rescue;
  if (r && rescueInView() && r.step !== 'locate') {
    out.set(r.rel[0] / 1000, r.rel[1] / 1000, r.rel[2] / 1000).add(craft);
    return { sizeKm: 0.0007, sky: false, skyDeg: 0 };
  }
  const d = s.discovery;
  const def = d && discoveryById(d.sighting.id);
  if (!d || !def) return null;
  if (def.zone === 'sky') {
    const [x, y, z] = skyCenter(def);
    out.set(x, z, -y);
    return { sizeKm: 0, sky: true, skyDeg: def.skySizeDeg ?? 10 };
  }
  const o = objectPosition(profile, d.sighting, T);
  if (!o) return null;
  out.set(o[0], o[2], -o[1]);
  return { sizeKm: def.sizeKm, sky: false, skyDeg: 0 };
}

const toThree = (v: [number, number, number], k = 1) => new THREE.Vector3(v[0] * k, v[2] * k, -v[1] * k);

function glowTexture(inner: string, outer: string) {
  const c = document.createElement('canvas');
  c.width = c.height = 128;
  const ctx = c.getContext('2d')!;
  const g = ctx.createRadialGradient(64, 64, 0, 64, 64, 64);
  g.addColorStop(0, inner);
  g.addColorStop(0.35, outer);
  g.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 128, 128);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

/** Estrellas, líneas y nebulosa de un objeto del cielo (en el grupo centrado en la cámara). */
function SkyObject({ def }: { def: DiscoveryDef }) {
  const data = useMemo(() => {
    const stars = def.stars ?? [];
    const pts = stars.map(([ra, dec]) => toThree(skyDir(ra, dec), SKY_R));
    const starGeom = new THREE.BufferGeometry().setFromPoints(pts);
    const seg: THREE.Vector3[] = [];
    for (const [a, b] of def.lines ?? []) if (pts[a] && pts[b]) seg.push(pts[a], pts[b]);
    const lineGeom = seg.length ? new THREE.BufferGeometry().setFromPoints(seg) : null;
    const center = toThree(skyCenter(def), SKY_R);
    const size = 2 * SKY_R * Math.tan((((def.skySizeDeg ?? 3) * Math.PI) / 180) / 2);
    return { starGeom, lineGeom, center, size };
  }, [def]);
  const nebulaTex = useMemo(() => (def.kind === 'nebula' ? glowTexture('rgba(255,210,230,0.95)', 'rgba(230,90,140,0.45)') : def.kind === 'star' ? glowTexture('rgba(255,255,255,1)', 'rgba(170,200,255,0.5)') : null), [def.kind]);
  return (
    <group>
      <points geometry={data.starGeom} frustumCulled={false}>
        <pointsMaterial size={def.kind === 'star' ? 7 : 4.5} sizeAttenuation={false} color="#ffffff" fog={false} depthWrite={false} />
      </points>
      {data.lineGeom && (
        <lineSegments geometry={data.lineGeom} frustumCulled={false}>
          <lineBasicMaterial color="#63e6f0" transparent opacity={0.65} fog={false} depthWrite={false} />
        </lineSegments>
      )}
      {nebulaTex && (
        <sprite position={data.center} scale={[data.size * (def.kind === 'star' ? 0.25 : 1), data.size * (def.kind === 'star' ? 0.25 : 1), 1]}>
          <spriteMaterial map={nebulaTex} transparent depthWrite={false} fog={false} blending={THREE.AdditiveBlending} toneMapped={false} />
        </sprite>
      )}
    </group>
  );
}

/** Grupo centrado en la cámara (fuera del mundo desplazado): cielo del descubrimiento activo. */
export function DiscoverySky() {
  const id = useFlightSim((s) => s.discovery?.sighting.id ?? null);
  const def = id ? discoveryById(id) : undefined;
  if (!def || def.zone !== 'sky') return null;
  return <SkyObject def={def} />;
}

/** Dentro del mundo (km): objeto detectado, región lunar señalada y satélite del rescate. */
export function DiscoveryWorld({ profile, timeRef, craftRef }: { profile: FlightProfile; timeRef: { current: { T: number } }; craftRef: { current: THREE.Object3D | null } }) {
  const sighting = useFlightSim((s) => s.discovery?.sighting ?? null);
  const def = sighting ? discoveryById(sighting.id) : undefined;
  const rescueStep = useFlightSim((s) => (s.rescue && !s.rescueSettled ? s.rescue.step : null));
  const tumble = useFlightSim((s) => s.rescue?.tumble ?? 0.4);
  const obj = useRef<THREE.Group>(null);
  const ring = useRef<THREE.Mesh>(null);
  const sat = useRef<THREE.Group>(null);
  const tmp = useMemo(() => ({ v: new THREE.Vector3(), n: new THREE.Vector3(), z: new THREE.Vector3(0, 0, 1) }), []);
  const satMarker = useMemo(() => glowTexture('rgba(255,255,255,1)', 'rgba(255,120,90,0.8)'), []);

  useFrame(() => {
    const T = timeRef.current.T;
    if (obj.current && sighting && def && def.zone !== 'sky' && !def.lunar) {
      const o = objectPosition(profile, sighting, T);
      if (o) obj.current.position.set(o[0], o[2], -o[1]);
    }
    if (ring.current && sighting && def?.lunar) {
      const o = objectPosition(profile, sighting, T);
      if (o) {
        // Normal de la superficie: desde el centro de la Luna hacia el punto.
        tmp.v.set(o[0], o[2], -o[1]);
        const st = flightStateAt(profile, T);
        tmp.n.set(o[0] - st.moonX, o[2], -(o[1] - st.moonY)).normalize();
        ring.current.position.copy(tmp.v).addScaledVector(tmp.n, 3);
        ring.current.quaternion.setFromUnitVectors(tmp.z.set(0, 0, 1), tmp.n);
      }
    }
    if (sat.current && craftRef.current && useFlightSim.getState().rescue) {
      const r = useFlightSim.getState().rescue!;
      sat.current.position.copy(craftRef.current.position).add(tmp.v.set(r.rel[0] / 1000, r.rel[1] / 1000, r.rel[2] / 1000));
    }
  });

  return (
    <>
      {def && def.zone !== 'sky' && !def.lunar && def.model !== 'lunar' && (
        <group ref={obj}>
          <group scale={0.001}>
            <DiscoveryObject model={def.model} />
          </group>
        </group>
      )}
      {def?.lunar && (
        <mesh ref={ring}>
          <ringGeometry args={[def.sizeKm * 0.5, def.sizeKm * 0.5 + Math.max(8, def.sizeKm * 0.04), 96]} />
          <meshBasicMaterial color="#63e6f0" transparent opacity={0.85} side={THREE.DoubleSide} depthWrite={false} toneMapped={false} />
        </mesh>
      )}
      {rescueStep && RESCUE_VISIBLE.includes(rescueStep) && (
        <group ref={sat}>
          <group scale={0.001}>
            <CubeSat tumble={tumble} />
          </group>
          {/* Marca para encontrarlo desde lejos (no crece con la distancia) */}
          <sprite scale={[0.022, 0.022, 1]}>
            <spriteMaterial map={satMarker} sizeAttenuation={false} transparent depthWrite={false} toneMapped={false} />
          </sprite>
        </group>
      )}
    </>
  );
}
