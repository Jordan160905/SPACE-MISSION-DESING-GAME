/**
 * Modelos 3D de los descubrimientos (Fase 8.4) y del satélite del rescate (Fase 8.5).
 * Geometría procedural original, en METROS (el grupo que los contiene escala a km).
 * Proporciones reales donde se conocen: Estación Espacial ≈ 109 × 73 m, Hubble 13,2 m × 4,2 m,
 * CubeSat 6U ≈ 10 × 22 × 34 cm.
 */
import { useMemo, useRef, type ReactNode } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import type { DiscoveryModel } from '../../sim/Discoveries';
import { mulberry32 } from '../proceduralTextures';

const GOLD = { color: '#c9a24a', metalness: 0.6, roughness: 0.4 };
const PANEL = { color: '#1d3a7a', metalness: 0.3, roughness: 0.35, emissive: '#06122e' };
const WHITE = { color: '#e6e9ee', metalness: 0.2, roughness: 0.6 };
const GREY = { color: '#9aa3ad', metalness: 0.6, roughness: 0.45 };

/** Roca irregular: icosaedro con relieve aleatorio (reproducible). */
function rockGeometry(radius: number, detail: number, seed: number) {
  const g = new THREE.IcosahedronGeometry(radius, detail);
  const pos = g.attributes.position as THREE.BufferAttribute;
  const rand = mulberry32(seed);
  const bumps = Array.from({ length: 9 }, () => [rand() * 2 - 1, rand() * 2 - 1, rand() * 2 - 1, 0.15 + rand() * 0.35, rand() < 0.5 ? -1 : 1]);
  const v = new THREE.Vector3();
  for (let i = 0; i < pos.count; i++) {
    v.fromBufferAttribute(pos, i).normalize();
    let k = 1 + (rand() - 0.5) * 0.06;
    for (const [x, y, z, w, s] of bumps) {
      const d = v.distanceTo(new THREE.Vector3(x, y, z).normalize());
      if (d < w * 2) k += s * 0.12 * Math.cos((d / (w * 2)) * (Math.PI / 2));
    }
    v.multiplyScalar(radius * k * (1 + 0.25 * Math.sin(v.x * 3) * Math.cos(v.y * 2)));
    pos.setXYZ(i, v.x, v.y, v.z);
  }
  g.computeVertexNormals();
  return g;
}

function Spin({ rate = 0.05, children }: { rate?: number; children: ReactNode }) {
  const ref = useRef<THREE.Group>(null);
  useFrame((_, dt) => {
    if (ref.current) {
      ref.current.rotation.y += dt * rate;
      ref.current.rotation.x += dt * rate * 0.6;
    }
  });
  return <group ref={ref}>{children}</group>;
}

function ISS() {
  return (
    <group>
      <mesh>
        <boxGeometry args={[109, 2.2, 2.2]} />
        <meshStandardMaterial {...GREY} />
      </mesh>
      {[-46, -32, 32, 46].map((x) =>
        [-1, 1].map((s) => (
          <mesh key={`${x}${s}`} position={[x, 0, s * 19]}>
            <boxGeometry args={[11.6, 0.2, 34]} />
            <meshStandardMaterial {...GOLD} />
          </mesh>
        )),
      )}
      {[0, 12, -12, 24].map((z, i) => (
        <mesh key={i} position={[0, -3.5, z]} rotation={[Math.PI / 2, 0, 0]}>
          <cylinderGeometry args={[2.1, 2.1, 11, 20]} />
          <meshStandardMaterial {...WHITE} />
        </mesh>
      ))}
      {[-15, 15].map((x) => (
        <mesh key={x} position={[x, 4, 0]}>
          <boxGeometry args={[5, 0.15, 12]} />
          <meshStandardMaterial color="#f2f4f7" roughness={0.3} />
        </mesh>
      ))}
    </group>
  );
}

function Hubble() {
  return (
    <group rotation={[0, 0, Math.PI / 2]}>
      <mesh>
        <cylinderGeometry args={[2.1, 2.1, 13.2, 28]} />
        <meshStandardMaterial color="#d6d9de" metalness={0.8} roughness={0.25} />
      </mesh>
      <mesh position={[0, 6.8, 0]} rotation={[0.6, 0, 0]}>
        <cylinderGeometry args={[2.15, 2.15, 0.15, 28]} />
        <meshStandardMaterial {...GREY} />
      </mesh>
      {[-1, 1].map((s) => (
        <mesh key={s} position={[s * 4.2, -1, 0]}>
          <boxGeometry args={[5.6, 7.1, 0.1]} />
          <meshStandardMaterial {...PANEL} />
        </mesh>
      ))}
    </group>
  );
}

function SatBox({ size, wing, dish }: { size: [number, number, number]; wing: [number, number]; dish?: number }) {
  return (
    <group>
      <mesh>
        <boxGeometry args={size} />
        <meshStandardMaterial {...GOLD} />
      </mesh>
      {[-1, 1].map((s) => (
        <mesh key={s} position={[s * (size[0] / 2 + wing[0] / 2 + 0.5), 0, 0]}>
          <boxGeometry args={[wing[0], 0.08, wing[1]]} />
          <meshStandardMaterial {...PANEL} />
        </mesh>
      ))}
      {dish && (
        <mesh position={[0, 0, size[2] / 2 + 0.4]} rotation={[-Math.PI / 2, 0, 0]}>
          <coneGeometry args={[dish, dish * 0.5, 24, 1, true]} />
          <meshStandardMaterial {...WHITE} side={THREE.DoubleSide} />
        </mesh>
      )}
    </group>
  );
}

function Debris() {
  const shards = useMemo(() => {
    const r = mulberry32(77);
    return Array.from({ length: 4 }, (_, i) => ({ p: [(r() - 0.5) * 2, (r() - 0.5) * 1.5, (r() - 0.5) * 2] as [number, number, number], rot: [r() * 3, r() * 3, r() * 3] as [number, number, number], s: [0.6 + r() * 2, 0.08, 0.5 + r() * 1.5] as [number, number, number], i }));
  }, []);
  return (
    <Spin rate={0.4}>
      <mesh rotation={[0.3, 0.2, 0]}>
        <cylinderGeometry args={[0.8, 0.9, 2.4, 10, 1, true]} />
        <meshStandardMaterial color="#b9b2a4" metalness={0.5} roughness={0.6} side={THREE.DoubleSide} />
      </mesh>
      {shards.map((s) => (
        <mesh key={s.i} position={s.p} rotation={s.rot}>
          <boxGeometry args={s.s} />
          <meshStandardMaterial color="#8d8478" metalness={0.6} roughness={0.5} />
        </mesh>
      ))}
    </Spin>
  );
}

function Rock({ radius, detail, color, seed }: { radius: number; detail: number; color: string; seed: number }) {
  const g = useMemo(() => rockGeometry(radius, detail, seed), [radius, detail, seed]);
  return (
    <Spin rate={0.02}>
      <mesh geometry={g}>
        <meshStandardMaterial color={color} roughness={0.95} metalness={0} flatShading />
      </mesh>
    </Spin>
  );
}

/** Modelo de un descubrimiento, en metros. */
export function DiscoveryObject({ model }: { model: DiscoveryModel }) {
  switch (model) {
    case 'iss':
      return <ISS />;
    case 'hubble':
      return <Hubble />;
    case 'sat-gps':
      return <SatBox size={[2, 2, 2.4]} wing={[5.2, 2]} />;
    case 'sat-geo':
      return <SatBox size={[3, 3, 4]} wing={[12, 2.5]} dish={1.2} />;
    case 'debris':
      return <Debris />;
    case 'rock':
      return <Rock radius={3} detail={3} color="#6b5d50" seed={11} />;
    case 'asteroid':
      return <Rock radius={90} detail={4} color="#7a6e62" seed={23} />;
    default:
      return null;
  }
}

/** CubeSat 6U averiado que da vueltas (rescate). */
export function CubeSat({ tumble }: { tumble: number }) {
  const ref = useRef<THREE.Group>(null);
  useFrame((_, dt) => {
    if (ref.current) {
      ref.current.rotation.x += dt * tumble;
      ref.current.rotation.z += dt * tumble * 0.4;
    }
  });
  return (
    <group ref={ref}>
      <mesh>
        <boxGeometry args={[0.22, 0.34, 0.1]} />
        <meshStandardMaterial color="#c8ccd2" metalness={0.7} roughness={0.35} />
      </mesh>
      {[-1, 1].map((s) => (
        <mesh key={s} position={[s * 0.28, 0, 0]}>
          <boxGeometry args={[0.32, 0.34, 0.01]} />
          <meshStandardMaterial {...PANEL} />
        </mesh>
      ))}
      <mesh position={[0, 0.19, 0]}>
        <cylinderGeometry args={[0.004, 0.004, 0.25, 6]} />
        <meshStandardMaterial color="#e8e8e8" />
      </mesh>
      {/* luz de estado parpadeante (roja: fallo) */}
      <mesh position={[0.08, 0.15, 0.052]}>
        <sphereGeometry args={[0.01, 8, 8]} />
        <meshBasicMaterial color="#ff4040" toneMapped={false} />
      </mesh>
    </group>
  );
}
