/**
 * Estado de la vista del vuelo (Fase 8.1), compartido entre la escena 3D y el HUD:
 * cámara elegida, mapa esquemático y el perfil físico de la trayectoria (calculado en diferido
 * para no congelar la interfaz al abrir la pantalla).
 */
import { useEffect, useState } from 'react';
import { create } from 'zustand';
import type { Launcher } from '../../data/schemas';
import { getFlightProfile, type FlightProfile } from '../../sim/FlightDynamics';

/** 'target': cámara de observación (telescopio) hacia el descubrimiento o el satélite del rescate. */
export type CamMode = 'external' | 'onboard' | 'chase' | 'orbital' | 'free' | 'target';

export const CAM_MODES: Array<{ id: CamMode; label: string; hint: string }> = [
  { id: 'external', label: 'Externa', hint: 'Alrededor del cohete, con la Tierra siempre abajo' },
  { id: 'onboard', label: 'A bordo', hint: 'Cámara montada en el cohete, mirando hacia atrás' },
  { id: 'chase', label: 'Seguimiento', hint: 'Detrás del cohete, en la dirección del vuelo' },
  { id: 'orbital', label: 'Orbital', hint: 'Vista de la Tierra, la Luna y la trayectoria' },
  { id: 'free', label: 'Libre', hint: 'Gira, acerca y desplaza con el ratón' },
];

interface FlightViewState {
  mode: CamMode;
  /** Cambia al pulsar «Restablecer vista» (la escena vuelve al encuadre inicial del modo). */
  resetKey: number;
  showMap: boolean;
  /** Trayectoria dibujada en la escena 3D. */
  showTrajectory: boolean;
  setMode: (m: CamMode) => void;
  toggleTrajectory: () => void;
  reset: () => void;
  toggleMap: () => void;
}

export const useFlightView = create<FlightViewState>()((set) => ({
  mode: 'external',
  resetKey: 0,
  showMap: false,
  showTrajectory: true,
  toggleTrajectory: () => set((s) => ({ showTrajectory: !s.showTrajectory })),
  setMode: (mode) => set((s) => ({ mode, resetKey: s.resetKey + 1 })),
  reset: () => set((s) => ({ resetKey: s.resetKey + 1 })),
  toggleMap: () => set((s) => ({ showMap: !s.showMap })),
}));

const pending = new Map<string, Promise<FlightProfile>>();

/**
 * Perfil físico del vuelo. La primera vez se calcula fuera del render (≈ 0,3 s); mientras tanto
 * devuelve null. La escena y el HUD comparten la misma caché.
 */
export function useFlightProfile(launcher: Launcher | undefined, lunarAltitudeKm: number | undefined): FlightProfile | null {
  const key = launcher && lunarAltitudeKm !== undefined ? `${launcher.id}|${lunarAltitudeKm}` : '';
  const [profile, setProfile] = useState<{ key: string; p: FlightProfile } | null>(null);
  useEffect(() => {
    if (!launcher || lunarAltitudeKm === undefined) return;
    let alive = true;
    let pr = pending.get(key);
    if (!pr) {
      pr = new Promise<FlightProfile>((resolve) => window.setTimeout(() => resolve(getFlightProfile(launcher, lunarAltitudeKm)), 30));
      pending.set(key, pr);
    }
    pr.then((p) => alive && setProfile({ key, p }));
    return () => {
      alive = false;
    };
  }, [key, launcher, lunarAltitudeKm]);
  return profile && profile.key === key ? profile.p : null;
}
