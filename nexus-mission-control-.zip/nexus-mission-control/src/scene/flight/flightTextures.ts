/**
 * Texturas procedurales del vuelo (Fase 8.1): Tierra (continentes, océanos, rugosidad para el
 * brillo del Sol en el mar, nubes) y Luna (mares en su posición real aproximada, cráteres con relieve
 * y rayos). Se generan una sola vez en el navegador (Canvas 2D) y se guardan en caché.
 * Proyección equirectangular: u = (longitud + 180) / 360, v = (90 − latitud) / 180.
 */
import * as THREE from 'three';
import { mulberry32 } from '../proceduralTextures';
import { DRY, ICE, INLAND_WATER, LAND, MARIA, RAYED_CRATERS, type Poly } from './geography';

function noise2(rand: () => number, gw: number, gh: number) {
  const g = new Float32Array(gw * gh);
  for (let i = 0; i < g.length; i++) g[i] = rand();
  const at = (x: number, y: number) => g[(((y % gh) + gh) % gh) * gw + (((x % gw) + gw) % gw)];
  return (u: number, v: number) => {
    const x = u * gw;
    const y = v * gh;
    const x0 = Math.floor(x);
    const y0 = Math.floor(y);
    let fx = x - x0;
    let fy = y - y0;
    fx = fx * fx * (3 - 2 * fx);
    fy = fy * fy * (3 - 2 * fy);
    const a = at(x0, y0) + (at(x0 + 1, y0) - at(x0, y0)) * fx;
    const b = at(x0, y0 + 1) + (at(x0 + 1, y0 + 1) - at(x0, y0 + 1)) * fx;
    return a + (b - a) * fy;
  };
}

function fbmMaker(seed: number, grids: number[], aspect = 2) {
  const rand = mulberry32(seed);
  const ns = grids.map((g) => noise2(rand, g, Math.max(2, Math.round(g / aspect))));
  return (u: number, v: number) => {
    let s = 0;
    let a = 0.5;
    let n = 0;
    for (const f of ns) {
      s += f(u, v) * a;
      n += a;
      a *= 0.5;
    }
    return s / n;
  };
}

function canvas(w: number, h: number) {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const ctx = c.getContext('2d', { willReadFrequently: true });
  if (!ctx) throw new Error('Canvas 2D no disponible');
  return { c, ctx };
}

function drawPolys(ctx: CanvasRenderingContext2D, polys: Poly[], w: number, h: number, fill: string) {
  ctx.fillStyle = fill;
  for (const p of polys) {
    ctx.beginPath();
    p.forEach(([lon, lat], i) => {
      const x = ((lon + 180) / 360) * w;
      const y = ((90 - lat) / 180) * h;
      if (i) ctx.lineTo(x, y);
      else ctx.moveTo(x, y);
    });
    ctx.closePath();
    ctx.fill();
  }
}

/** Dibuja polígonos y devuelve el canal rojo suavizado (0–1). */
function polyField(polys: Poly[], w: number, h: number, blurPx: number, holes: Poly[] = []): Float32Array {
  const a = canvas(w, h);
  a.ctx.fillStyle = '#000';
  a.ctx.fillRect(0, 0, w, h);
  drawPolys(a.ctx, polys, w, h, '#fff');
  if (holes.length) drawPolys(a.ctx, holes, w, h, '#000');
  const b = canvas(w, h);
  b.ctx.filter = `blur(${blurPx}px)`;
  b.ctx.drawImage(a.c, 0, 0);
  // Algunos navegadores no aplican `filter`: entonces se usa la máscara nítida.
  let data = b.ctx.getImageData(0, 0, w, h).data;
  let any = false;
  for (let i = 0; i < data.length; i += 4 * 97) if (data[i] > 0) {
    any = true;
    break;
  }
  if (!any) data = a.ctx.getImageData(0, 0, w, h).data;
  const out = new Float32Array(w * h);
  for (let i = 0; i < out.length; i++) out[i] = data[i * 4] / 255;
  return out;
}

/** Color de la vegetación según la latitud: selva → sabana → templado → taiga → tundra. */
const BIOMES: Array<[number, [number, number, number]]> = [
  [0, [28, 74, 32]],
  [14, [36, 82, 34]],
  [24, [96, 108, 56]],
  [38, [66, 98, 48]],
  [52, [52, 84, 44]],
  [62, [42, 66, 42]],
  [70, [118, 112, 92]],
];
function latColor(lat: number): [number, number, number] {
  const a = Math.max(0, lat);
  for (let i = 1; i < BIOMES.length; i++) {
    if (a <= BIOMES[i][0]) {
      const [l0, c0] = BIOMES[i - 1];
      const [l1, c1] = BIOMES[i];
      const t = (a - l0) / (l1 - l0);
      return [c0[0] + (c1[0] - c0[0]) * t, c0[1] + (c1[1] - c0[1]) * t, c0[2] + (c1[2] - c0[2]) * t];
    }
  }
  return BIOMES[BIOMES.length - 1][1];
}

const smooth = (a: number, b: number, x: number) => {
  const t = Math.max(0, Math.min(1, (x - a) / (b - a)));
  return t * t * (3 - 2 * t);
};
const mix = (a: number, b: number, t: number) => a + (b - a) * t;

function tex(c: HTMLCanvasElement, srgb: boolean) {
  const t = new THREE.CanvasTexture(c);
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  t.wrapS = THREE.RepeatWrapping;
  t.anisotropy = 8;
  return t;
}

export interface EarthMaps {
  color: THREE.CanvasTexture;
  roughness: THREE.CanvasTexture;
  clouds: THREE.CanvasTexture;
}

function buildEarth(w = 2048): EarthMaps {
  const h = w / 2;
  const land = polyField(LAND, w, h, w / 512, INLAND_WATER);
  const dry = polyField(DRY, w, h, w / 128);
  const ice = polyField(ICE, w, h, w / 1024);
  const coast = fbmMaker(1972, [8, 16, 32, 64, 128]);
  const tone = fbmMaker(77, [10, 40, 160, 320]);
  const col = canvas(w, h);
  const rough = canvas(w, h);
  const ci = col.ctx.createImageData(w, h);
  const ri = rough.ctx.createImageData(w, h);
  for (let y = 0; y < h; y++) {
    const v = y / h;
    const lat = 90 - v * 180;
    const al = Math.abs(lat);
    for (let x = 0; x < w; x++) {
      const u = x / w;
      const i = y * w + x;
      const n = coast(u, v);
      const m = land[i] + (n - 0.5) * 0.5;
      let r: number, g: number, b: number;
      let rg: number;
      if (m > 0.5) {
        const k = tone(u, v);
        const d = Math.min(1, dry[i] * 1.3 + (k - 0.5) * 0.6);
        // Vegetación según la latitud (transiciones suaves, con irregularidad).
        const la = al + (k - 0.5) * 14;
        const veg = latColor(la);
        r = veg[0];
        g = veg[1];
        b = veg[2];
        // Desiertos y estepas.
        r = mix(r, 205, d * 0.92);
        g = mix(g, 170, d * 0.92);
        b = mix(b, 118, d * 0.92);
        const shade = 0.78 + k * 0.44;
        r *= shade;
        g *= shade;
        b *= shade;
        // Hielo y nieve.
        const snow = Math.max(smooth(0.35, 0.65, ice[i] + (k - 0.5) * 0.3), smooth(68, 76, al + (k - 0.5) * 8));
        r = mix(r, 236, snow);
        g = mix(g, 242, snow);
        b = mix(b, 248, snow);
        rg = mix(235, 170, snow);
      } else {
        const shallow = smooth(0.18, 0.5, m);
        const polar = smooth(50, 75, al);
        r = mix(8, 26, shallow);
        g = mix(32, 92, shallow) - polar * 8;
        b = mix(78, 138, shallow) - polar * 10;
        // Hielo marino alrededor de la Antártida y en el Ártico.
        const seaIce = smooth(74, 82, al + (n - 0.5) * 10);
        r = mix(r, 220, seaIce);
        g = mix(g, 230, seaIce);
        b = mix(b, 240, seaIce);
        rg = mix(58, 200, seaIce);
      }
      const o = i * 4;
      ci.data[o] = r;
      ci.data[o + 1] = g;
      ci.data[o + 2] = b;
      ci.data[o + 3] = 255;
      ri.data[o] = rg;
      ri.data[o + 1] = rg;
      ri.data[o + 2] = rg;
      ri.data[o + 3] = 255;
    }
  }
  col.ctx.putImageData(ci, 0, 0);
  rough.ctx.putImageData(ri, 0, 0);

  // Nubes: bandas reales de nubosidad (zona de convergencia ecuatorial y borrascas de latitudes
  // medias) y menos nubes en los anticiclones subtropicales.
  const cw = w / 2;
  const chh = cw / 2;
  const cloud = fbmMaker(4242, [20, 40, 80, 160, 320]);
  const detail = fbmMaker(4343, [256, 512]);
  const warp = fbmMaker(99, [6, 12]);
  const cl = canvas(cw, chh);
  const cd = cl.ctx.createImageData(cw, chh);
  for (let y = 0; y < chh; y++) {
    const v = y / chh;
    const lat = 90 - v * 180;
    const al = Math.abs(lat);
    const band = 0.07 * Math.exp(-(((lat - 6) / 7) ** 2)) + 0.06 * Math.exp(-(((al - 55) / 10) ** 2)) - 0.06 * Math.exp(-(((al - 25) / 7) ** 2));
    for (let x = 0; x < cw; x++) {
      const u = x / cw;
      // Remolinos: el ruido se desplaza con otro ruido, más estirado de este a oeste.
      const w = warp(u, v) - 0.5;
      const n = cloud(u + w * 0.06, v + w * 0.02);
      const a = smooth(0.54 - band, 0.68 - band, n) * (0.55 + 0.45 * detail(u, v));
      const o = (y * cw + x) * 4;
      cd.data[o] = 255;
      cd.data[o + 1] = 255;
      cd.data[o + 2] = 255;
      cd.data[o + 3] = a * 240;
    }
  }
  cl.ctx.putImageData(cd, 0, 0);
  return { color: tex(col.c, true), roughness: tex(rough.c, false), clouds: tex(cl.c, true) };
}

export interface MoonMaps {
  color: THREE.CanvasTexture;
  bump: THREE.CanvasTexture;
}

function buildMoon(w = 2048): MoonMaps {
  const h = w / 2;
  const rand = mulberry32(1969);
  const base = fbmMaker(1969, [8, 24, 72, 216, 432]);
  // Mares: elipses en su posición selenográfica.
  const mc = canvas(w, h);
  mc.ctx.fillStyle = '#000';
  mc.ctx.fillRect(0, 0, w, h);
  mc.ctx.fillStyle = '#fff';
  for (const [lon, lat, rl, rb] of MARIA) {
    const cx = ((lon + 180) / 360) * w;
    const cy = ((90 - lat) / 180) * h;
    const sx = ((rl / Math.max(0.35, Math.cos((lat * Math.PI) / 180))) / 360) * w;
    mc.ctx.beginPath();
    mc.ctx.ellipse(cx, cy, sx, (rb / 180) * h, 0, 0, Math.PI * 2);
    mc.ctx.fill();
  }
  const mb = canvas(w, h);
  mb.ctx.filter = `blur(${w / 90}px)`;
  mb.ctx.drawImage(mc.c, 0, 0);
  const md = mb.ctx.getImageData(0, 0, w, h).data;
  const col = canvas(w, h);
  const bump = canvas(w, h);
  const ci = col.ctx.createImageData(w, h);
  const bi = bump.ctx.createImageData(w, h);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const u = x / w;
      const v = y / h;
      const n = base(u, v);
      const i = y * w + x;
      const maria = smooth(0.2, 0.8, md[i * 4] / 255 + (n - 0.5) * 0.6);
      const a = 172 + (n - 0.5) * 80 - maria * 70;
      const o = i * 4;
      ci.data[o] = a;
      ci.data[o + 1] = a * 0.985;
      ci.data[o + 2] = a * 0.96;
      ci.data[o + 3] = 255;
      const hgt = 128 + (n - 0.5) * 60 - maria * 30;
      bi.data[o] = hgt;
      bi.data[o + 1] = hgt;
      bi.data[o + 2] = hgt;
      bi.data[o + 3] = 255;
    }
  }
  col.ctx.putImageData(ci, 0, 0);
  bump.ctx.putImageData(bi, 0, 0);

  // Cráteres: borde alto y claro, fondo bajo y oscuro (en el color y en el relieve).
  const crater = (x: number, y: number, r: number) => {
    const sx = r / Math.max(0.3, Math.sin((y / h) * Math.PI));
    for (const [ctx, floor, rim] of [
      [col.ctx, 'rgba(70,70,74,0.16)', 'rgba(235,232,225,0.14)'],
      [bump.ctx, 'rgba(0,0,0,0.5)', 'rgba(255,255,255,0.55)'],
    ] as const) {
      const g = ctx.createRadialGradient(x, y, 0, x, y, 1);
      g.addColorStop(0, floor);
      g.addColorStop(0.72, floor);
      g.addColorStop(0.86, rim);
      g.addColorStop(1, 'rgba(128,128,128,0)');
      ctx.save();
      ctx.translate(x, y);
      ctx.scale(sx, r);
      ctx.translate(-x, -y);
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(x, y, 1, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  };
  for (let k = 0; k < 2600; k++) {
    const r = Math.pow(rand(), 4.5) * (w / 60) + w / 2000;
    crater(rand() * w, h * 0.04 + rand() * h * 0.92, r);
  }
  // Cráteres jóvenes con rayos brillantes.
  for (const [lon, lat, rr] of RAYED_CRATERS) {
    const x = ((lon + 180) / 360) * w;
    const y = ((90 - lat) / 180) * h;
    const r = (rr / 180) * h;
    col.ctx.save();
    col.ctx.strokeStyle = 'rgba(245,242,235,0.10)';
    col.ctx.lineCap = 'round';
    for (let k = 0; k < 26; k++) {
      const a = rand() * Math.PI * 2;
      const len = r * (5 + rand() * 12);
      col.ctx.lineWidth = r * (0.15 + rand() * 0.3);
      col.ctx.beginPath();
      col.ctx.moveTo(x, y);
      col.ctx.lineTo(x + Math.cos(a) * len * 1.6, y + Math.sin(a) * len);
      col.ctx.stroke();
    }
    col.ctx.restore();
    crater(x, y, r);
  }
  return { color: tex(col.c, true), bump: tex(bump.c, false) };
}

/** Terreno cercano a la plataforma (vegetación costera tropical), en mosaico. */
function buildGround(size = 512): THREE.CanvasTexture {
  const f = fbmMaker(31, [8, 16, 32, 64], 1);
  const g = canvas(size, size);
  const im = g.ctx.createImageData(size, size);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const n = f(x / size, y / size);
      const o = (y * size + x) * 4;
      im.data[o] = 48 + n * 50;
      im.data[o + 1] = 78 + n * 50;
      im.data[o + 2] = 38 + n * 22;
      im.data[o + 3] = 255;
    }
  }
  g.ctx.putImageData(im, 0, 0);
  const t = tex(g.c, true);
  t.wrapT = THREE.RepeatWrapping;
  return t;
}

export interface FlightTextures {
  earth: EarthMaps;
  moon: MoonMaps;
  ground: THREE.CanvasTexture;
}
let cache: FlightTextures | null = null;
let pending: Promise<FlightTextures> | null = null;
const nextTick = () => new Promise<void>((r) => window.setTimeout(r, 16));

/**
 * Texturas del vuelo. Se generan una vez, por partes y entre fotogramas (Tierra, Luna, terreno),
 * para que la interfaz no se congele.
 */
export function loadFlightTextures(): Promise<FlightTextures> {
  if (cache) return Promise.resolve(cache);
  if (!pending)
    pending = (async () => {
      await nextTick();
      const earth = buildEarth();
      await nextTick();
      const moon = buildMoon();
      await nextTick();
      cache = { earth, moon, ground: buildGround() };
      return cache;
    })();
  return pending;
}

/** Versión síncrona (pruebas y herramientas). */
export function getFlightTextures(): FlightTextures {
  if (!cache) cache = { earth: buildEarth(), moon: buildMoon(), ground: buildGround() };
  return cache;
}
