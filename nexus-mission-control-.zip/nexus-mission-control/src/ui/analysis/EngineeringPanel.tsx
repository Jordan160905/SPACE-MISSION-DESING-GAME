/**
 * Engineering Analysis — muestra el informe del motor con su procedencia: cada bloque indica
 * la fórmula y los supuestos que producen el número. Nada se calcula aquí: todo sale de sim/.
 */
import { useMemo, type ReactNode } from 'react';
import { getComponent } from '../../data/components/catalog';
import { getMissionTemplate } from '../../data/missions/missions';
import type { Mission, SpacecraftDesign } from '../../data/schemas';
import { analysisInputForMission, analyzeEngineering, type EngineeringReport } from '../../sim/EngineeringAnalysis';
import { GROUND_STATION_HOURS_PER_DAY } from '../../sim/OrbitSystem';
import { BATTERY_CHARGE_EFFICIENCY, MAX_DOD, PANEL_EFFECTIVE_FACTOR, RECOMMENDED_DOD } from '../../sim/PowerSystem';
import { DRY_MASS_MARGIN } from '../../sim/MassSystem';
import { formatMUSD, round } from '../../sim/units';
import { getLauncher } from '../../data/launchers/launchers';
import { Meter } from '../components/Panel';
import { numLocale } from '../../i18n/lang';

export function useEngineeringReport(design: SpacecraftDesign, mission: Mission | null | undefined): EngineeringReport {
  return useMemo(
    () =>
      mission
        ? analyzeEngineering(analysisInputForMission(design, getComponent, mission, getMissionTemplate))
        : analyzeEngineering({ design, lookup: getComponent }),
    [design, mission],
  );
}

const fmt = (n: number, d = 1) => (Number.isFinite(n) ? round(n, d).toLocaleString(numLocale()) : '∞');
const pct = (x: number) => (Number.isFinite(x) ? `${Math.round(x * 100)} %` : '—');

function Block({ title, status, children, how }: { title: string; status?: 'ok' | 'warn' | 'bad'; children: ReactNode; how: ReactNode }) {
  return (
    <section className={`an-block ${status ? `an-block--${status}` : ''}`}>
      <h4 className="an-block__title">{title}</h4>
      {children}
      <details className="an-how">
        <summary>¿Cómo se calcula?</summary>
        <div className="small muted">{how}</div>
      </details>
    </section>
  );
}

function Row({ k, v, strong }: { k: string; v: string; strong?: boolean }) {
  return (
    <>
      <dt>{k}</dt>
      <dd style={strong ? { color: 'var(--text-hi)', fontWeight: 600 } : undefined}>{v}</dd>
    </>
  );
}

export function EngineeringPanel({ report }: { report: EngineeringReport }) {
  const { orbit, power, comms, data, mass, budget } = report;
  if (!power || !comms || !data || !mass) {
    return <p className="small muted">Instala un chasis para que el motor de simulación pueda analizar la nave.</p>;
  }
  const powerStatus = power.orbitBalanceWh < 0 || power.depthOfDischarge > MAX_DOD ? 'bad' : power.depthOfDischarge > RECOMMENDED_DOD ? 'warn' : 'ok';
  const dataStatus = data.targetGbit > 0 && !data.targetMet ? 'bad' : data.lostPerDayGbit > 0 || data.backlogGbitPerDay > 0 ? 'warn' : 'ok';
  const cheapest = mass.launchersThatFit[0] ? getLauncher(mass.launchersThatFit[0]) : undefined;

  return (
    <div className="analysis">
      <Block
        title={`Órbita de referencia · ${orbit.altitudeKm} km · ${orbit.inclinationDeg}°`}
        how={
          <>
            Periodo T = 2π·√(a³/μ) con a = R + h, R = 1 737,4 km y μ = 4 902,8 km³/s². Fracción de eclipse = asin(R/a)/π (sombra cilíndrica, peor
            caso con el Sol en el plano orbital). Se usa el punto medio de la órbita recomendada por tu objetivo; en la Fase 4 podrás elegirla.
          </>
        }
      >
        <dl className="kv">
          <Row k="Periodo" v={`${fmt(orbit.periodMin)} min (${fmt(orbit.orbitsPerDay)} órbitas/día)`} />
          <Row k="Velocidad" v={`${fmt(orbit.velocityKmS, 2)} km/s`} />
          <Row k="Iluminado / eclipse" v={`${fmt(orbit.sunlitMin)} / ${fmt(orbit.eclipseMin)} min`} />
          <Row k="Contacto con Tierra" v={`${fmt(comms.contactHoursPerDay)} h/día`} />
        </dl>
      </Block>

      <Block
        title="Energía por órbita"
        status={powerStatus}
        how={
          <>
            Generación efectiva = paneles × {PANEL_EFFECTIVE_FACTOR} (orientación y temperatura). Los instrumentos pasivos solo consumen con luz; la
            antena, solo en contacto; el propulsor, solo en maniobras. Energía de eclipse (Wh) = consumo en sombra (W) × duración (h). Se repone con
            eficiencia {BATTERY_CHARGE_EFFICIENCY}. Descarga = energía de eclipse ÷ batería (límite {pct(MAX_DOD)}, recomendado ≤ {pct(RECOMMENDED_DOD)}).
          </>
        }
      >
        <dl className="kv">
          <Row k="Generación iluminada" v={`${fmt(power.sunlitGenW)} W`} />
          <Row k="Consumo con luz / en sombra" v={`${fmt(power.sunlitLoadW)} / ${fmt(power.eclipseLoadW)} W`} />
          <Row k="Energía usada en eclipse" v={`${fmt(power.eclipseEnergyWh)} Wh`} />
          <Row k="Excedente para recargar" v={`${fmt(power.sunlitSurplusWh)} Wh (necesita ${fmt(power.rechargeNeededWh)})`} />
          <Row k="Balance por órbita" v={`${power.orbitBalanceWh >= 0 ? '+' : ''}${fmt(power.orbitBalanceWh)} Wh`} strong />
          <Row k="Descarga de batería" v={`${pct(power.depthOfDischarge)} de ${power.batteryWh} Wh`} strong />
          <Row k="Autonomía sin Sol" v={`${fmt(power.autonomyH)} h`} />
        </dl>
        {Number.isFinite(power.depthOfDischarge) && <Meter value={power.depthOfDischarge} warn={power.depthOfDischarge > MAX_DOD} label="Descarga de batería por órbita" />}
      </Block>

      <Block
        title="Datos y comunicaciones"
        status={dataStatus}
        how={
          <>
            Producción = Σ instrumentos × (fracción iluminada si son pasivos). Enlace = mejor antena (Mbps × 3,6 = Gbit/h) × horas de contacto. Contacto
            = (1 − ocultación de la Tierra) × {GROUND_STATION_HOURS_PER_DAY} h de estación al día. Durante las {orbit.maxGapH} h sin estación, los datos
            deben caber en la memoria; lo que no cabe se pierde. Llegan a Tierra = mín(enlace, producción − pérdidas).
          </>
        }
      >
        <dl className="kv">
          <Row k="Producción" v={`${fmt(data.genGbitPerDay)} Gbit/día`} />
          <Row k="Capacidad del enlace" v={`${fmt(comms.downlinkGbitPerDay)} Gbit/día (${comms.downlinkMbps} Mbps)`} />
          <Row k="Memoria / necesaria sin contacto" v={`${data.storageGbit} / ${fmt(data.bufferNeededGbit)} Gbit`} />
          <Row k="Perdidos por memoria" v={`${fmt(data.lostPerDayGbit)} Gbit/día`} />
          <Row k="Llegan a Tierra" v={`${fmt(data.deliveredGbitPerDay)} Gbit/día`} strong />
          {data.targetGbit > 0 && (
            <Row
              k={`Total en ${data.missionDays} días`}
              v={`${fmt(data.missionDeliveredGbit, 0)} / ${data.targetGbit.toLocaleString(numLocale())} Gbit`}
              strong
            />
          )}
          {data.targetGbit > 0 && <Row k="Objetivo alcanzado en" v={Number.isFinite(data.daysToTarget) ? `${fmt(data.daysToTarget)} días` : 'nunca'} />}
        </dl>
        {data.targetGbit > 0 && <Meter value={data.missionDeliveredGbit / data.targetGbit} warn={!data.targetMet} label="Datos frente al objetivo" />}
      </Block>

      <Block
        title="Masa"
        status={cheapest ? 'ok' : 'bad'}
        how={<>Masa húmeda = seca + propelente. Se añade un margen del {pct(DRY_MASS_MARGIN)} sobre la masa seca, como en misiones reales, porque los diseños crecen.</>}
      >
        <dl className="kv">
          <Row k="Seca + propelente" v={`${fmt(mass.dryKg)} + ${fmt(mass.propellantKg)} kg`} />
          <Row k="Con margen" v={`${fmt(mass.wetWithMarginKg)} kg`} strong />
          <Row k="Lanzador capaz más barato" v={cheapest ? `${cheapest.name} (${cheapest.payloadToTLIKg} kg)` : 'ninguno'} />
        </dl>
      </Block>

      {budget && (
        <Block
          title="Presupuesto"
          status={budget.overBudget ? 'bad' : 'ok'}
          how={<>Componentes + operación (días × costo diario de control y antenas) + lanzamiento (se elige en la Fase 4).</>}
        >
          <dl className="kv">
            {budget.lines.map((l) => (
              <Row key={l.id} k={l.label} v={l.amountMUSD === null ? 'pendiente' : formatMUSD(l.amountMUSD)} />
            ))}
            <Row k="Disponible para el lanzador" v={formatMUSD(budget.remainingMUSD)} strong />
          </dl>
        </Block>
      )}
    </div>
  );
}
