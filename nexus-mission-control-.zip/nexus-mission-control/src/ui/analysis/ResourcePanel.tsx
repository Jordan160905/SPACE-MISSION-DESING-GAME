/** Los seis recursos de la misión con barra, margen y los dos más críticos destacados. */
import type { ResourceReport } from '../../sim/ResourceSystem';

const STATE_TEXT = { ok: 'Con margen', tight: 'Justo', over: 'Excedido', unknown: 'Pendiente' } as const;

export function ResourcePanel({ report, compact = false }: { report: ResourceReport; compact?: boolean }) {
  const crit = report.resources.filter((r) => report.critical.includes(r.id));
  return (
    <div className="resources" data-testid="resources">
      {crit.length > 0 && (
        <p className="small resources__crit">
          <strong>Recursos más críticos para tu misión:</strong> {crit.map((r) => r.label).join(' y ')}. Son los que tienen menos margen: cualquier cambio de diseño debe
          vigilarlos primero.
        </p>
      )}
      <ul className="resources__list">
        {report.resources.map((r) => (
          <li key={r.id} className={`resource resource--${r.state} ${report.critical.includes(r.id) ? 'resource--critical' : ''}`}>
            <div className="resource__head">
              <strong>{r.label}</strong>
              {report.critical.includes(r.id) && <span className="badge badge--soft">crítico</span>}
              <span className={`resource__state small`}>{STATE_TEXT[r.state]}</span>
            </div>
            <div className="meter" role="meter" aria-label={`${r.label}: uso`} aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(Math.min(1, r.usedFraction) * 100)}>
              <div className={`meter__fill ${r.state === 'over' || r.state === 'tight' ? 'meter__fill--warn' : ''}`} style={{ width: `${Math.min(1, r.usedFraction) * 100}%` }} />
            </div>
            <span className="small mono">
              {r.used} / {r.available}
            </span>
            {!compact && (
              <>
                <span className="small muted resource__plain">{r.plain}</span>
                <span className="small resource__why">{r.why}</span>
              </>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}
