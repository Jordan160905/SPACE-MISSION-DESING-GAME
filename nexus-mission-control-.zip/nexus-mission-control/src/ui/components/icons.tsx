/** Iconos SVG originales de línea. */
import type { SVGProps } from 'react';

const base: SVGProps<SVGSVGElement> = {
  viewBox: '0 0 24 24',
  fill: 'none',
  stroke: 'currentColor',
  strokeWidth: 1.6,
  strokeLinecap: 'round',
  strokeLinejoin: 'round',
  'aria-hidden': true,
};

export const IconCenter = () => (
  <svg {...base}>
    <circle cx="12" cy="12" r="3.5" />
    <ellipse cx="12" cy="12" rx="9.5" ry="4" transform="rotate(-25 12 12)" />
  </svg>
);
export const IconLab = () => (
  <svg {...base}>
    <rect x="8" y="8" width="8" height="8" />
    <path d="M8 12H3M16 12h5M12 8V4M12 16v4M3 9v6M21 9v6" />
  </svg>
);
export const IconPlanner = () => (
  <svg {...base}>
    <circle cx="12" cy="12" r="4" />
    <path d="M12 2v3M12 19v3M2 12h3M19 12h3" />
    <circle cx="12" cy="12" r="8.5" strokeDasharray="2 2.5" />
  </svg>
);
export const IconReview = () => (
  <svg {...base}>
    <rect x="5" y="4" width="14" height="17" />
    <path d="M9 4V2.5h6V4M8.5 10l1.5 1.5 3-3M8.5 16l1.5 1.5 3-3M15 10.5h1.5M15 16.5h1.5" />
  </svg>
);
export const IconRocket = () => (
  <svg {...base}>
    <path d="M12 2c3 2.5 4.5 6 4.5 10v5h-9v-5C7.5 8 9 4.5 12 2z" />
    <circle cx="12" cy="10" r="1.6" />
    <path d="M7.5 14l-3 3v2h3M16.5 14l3 3v2h-3M10 19.5l2 2.5 2-2.5" />
  </svg>
);
export const IconArchive = () => (
  <svg {...base}>
    <rect x="3" y="4" width="18" height="5" />
    <path d="M5 9v11h14V9M10 13h4" />
  </svg>
);
export const IconBook = () => (
  <svg {...base}>
    <path d="M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2z" />
    <path d="M4 19V5M9 7h6" />
  </svg>
);
export const IconHelp = () => (
  <svg {...base}>
    <circle cx="12" cy="12" r="9" />
    <path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.7.3-1 .8-1 1.5V14M12 17.2v.1" />
  </svg>
);
export const IconLock = () => (
  <svg {...base} width="14" height="14">
    <rect x="5" y="11" width="14" height="9" />
    <path d="M8 11V8a4 4 0 0 1 8 0v3" />
  </svg>
);
export const IconClose = () => (
  <svg {...base} width="18" height="18">
    <path d="M6 6l12 12M18 6L6 18" />
  </svg>
);

export const NexusMark = () => (
  <svg className="brand__mark" viewBox="0 0 40 40" aria-hidden="true">
    <circle cx="20" cy="20" r="8" fill="#63e6f0" />
    <circle cx="20" cy="20" r="8" fill="url(#nx-shade)" />
    <ellipse cx="20" cy="20" rx="17" ry="6.5" fill="none" stroke="#ffb547" strokeWidth="1.8" transform="rotate(-25 20 20)" />
    <circle cx="35" cy="13" r="1.8" fill="#fff2c8" />
    <defs>
      <radialGradient id="nx-shade" cx="0.35" cy="0.35" r="0.7">
        <stop offset="0" stopColor="#ffffff" stopOpacity="0.5" />
        <stop offset="1" stopColor="#02040a" stopOpacity="0.55" />
      </radialGradient>
    </defs>
  </svg>
);
