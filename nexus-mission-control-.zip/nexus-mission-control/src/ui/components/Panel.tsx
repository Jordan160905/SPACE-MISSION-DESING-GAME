import type { ReactNode } from 'react';
import { IconClose } from './icons';

interface PanelProps {
  eyebrow?: string;
  title: ReactNode;
  aside?: ReactNode;
  onClose?: () => void;
  className?: string;
  children: ReactNode;
  footer?: ReactNode;
  tabs?: ReactNode;
  labelledBy?: string;
}

export function Panel({ eyebrow, title, aside, onClose, className = '', children, footer, tabs, labelledBy }: PanelProps) {
  const id = labelledBy ?? `panel-${typeof title === 'string' ? title.replace(/\W+/g, '-').toLowerCase() : 'x'}`;
  return (
    <section className={`panel ${className}`} aria-labelledby={id}>
      <header className="panel__head">
        <div>
          {eyebrow && <p className="eyebrow">{eyebrow}</p>}
          <h2 className="h3" id={id}>
            {title}
          </h2>
        </div>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          {aside}
          {onClose && (
            <button className="btn btn--ghost" style={{ padding: 6 }} onClick={onClose} aria-label="Cerrar">
              <IconClose />
            </button>
          )}
        </div>
      </header>
      {tabs}
      <div className="panel__body">{children}</div>
      {footer && <div className="footer-bar">{footer}</div>}
    </section>
  );
}

export function Meter({ value, warn = false, label }: { value: number; warn?: boolean; label: string }) {
  const pct = Math.max(0, Math.min(1, value)) * 100;
  return (
    <div className="meter" role="meter" aria-label={label} aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(pct)}>
      <div className={`meter__fill ${warn ? 'meter__fill--warn' : ''}`} style={{ width: `${pct}%` }} />
    </div>
  );
}
