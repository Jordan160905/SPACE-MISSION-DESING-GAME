/**
 * Glosario interactivo: palabras técnicas subrayadas que muestran una explicación sencilla al
 * pasar el cursor, al enfocarlas con el teclado o al tocarlas (móvil). La ventana usa posición
 * fija para no quedar recortada por paneles con desplazamiento.
 */
import { useEffect, useId, useRef, useState, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { glossSegments, tooltipById, type Tooltip } from '../../data/tooltips';
import { useGameStore } from '../../state/useGameStore';

export function Term({ tip, children }: { tip: Tooltip; children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const [pos, setPos] = useState<{ x: number; y: number; above: boolean }>({ x: 0, y: 0, above: false });
  const ref = useRef<HTMLSpanElement>(null);
  const popRef = useRef<HTMLSpanElement>(null);
  const hideTimer = useRef<number | null>(null);
  /** En táctil, el navegador emite «salidas» tras cada toque: ahí solo se cierra tocando fuera. */
  const touchRef = useRef(false);
  const id = useId();
  const cancelHide = () => {
    if (hideTimer.current !== null) window.clearTimeout(hideTimer.current);
    hideTimer.current = null;
  };
  // Al salir con el ratón se espera un instante: así se puede llegar a la ventana y pulsar su enlace.
  const hideSoon = () => {
    if (touchRef.current) return;
    cancelHide();
    hideTimer.current = window.setTimeout(() => setOpen(false), 160);
  };
  const navigate = useGameStore((s) => s.navigate);

  const place = () => {
    const r = ref.current?.getBoundingClientRect();
    if (!r) return;
    const above = r.bottom + 120 > window.innerHeight;
    setPos({ x: Math.min(Math.max(8, r.left), window.innerWidth - 288), y: above ? r.top - 8 : r.bottom + 8, above });
  };
  const show = () => {
    cancelHide();
    place();
    setOpen(true);
  };
  useEffect(() => cancelHide, []);

  useEffect(() => {
    if (!open) return;
    const close = (e: Event) => {
      if (e.type === 'keydown' && (e as KeyboardEvent).key !== 'Escape') return;
      if (e.type === 'pointerdown' && (ref.current?.contains(e.target as Node) || popRef.current?.contains(e.target as Node))) return;
      setOpen(false);
    };
    // Al desplazar el panel, la ventana acompaña a la palabra (no se cierra: en móvil el toque desplaza).
    const follow = () => place();
    window.addEventListener('pointerdown', close);
    window.addEventListener('keydown', close);
    window.addEventListener('scroll', follow, true);
    return () => {
      window.removeEventListener('pointerdown', close);
      window.removeEventListener('keydown', close);
      window.removeEventListener('scroll', follow, true);
    };
  }, [open]);

  return (
    <span
      ref={ref}
      className="gterm"
      tabIndex={0}
      role="button"
      aria-expanded={open}
      aria-describedby={open ? id : undefined}
      data-term={tip.id}
      onPointerDown={(e) => {
        touchRef.current = e.pointerType === 'touch';
      }}
      onMouseEnter={show}
      onMouseLeave={hideSoon}
      onFocus={show}
      onBlur={() => !touchRef.current && setOpen(false)}
      onClick={(e) => {
        // Tocar (móvil) o hacer clic siempre muestra la explicación; se cierra tocando fuera o con Escape.
        e.stopPropagation();
        show();
      }}
    >
      {children}
      {open &&
        createPortal(
        <span
          ref={popRef}
          id={id}
          role="tooltip"
          className={`term-pop ${pos.above ? 'term-pop--above' : ''}`}
          style={{ left: pos.x, top: pos.y }}
          onMouseDown={(e) => e.preventDefault()}
          onMouseEnter={cancelHide}
          onMouseLeave={hideSoon}
        >
          <strong>{tip.label}</strong>
          <span>{tip.simple}</span>
          {tip.glossaryTerm && (
            <button
              type="button"
              className="link-btn small"
              onClick={(e) => {
                e.stopPropagation();
                navigate('glossary');
              }}
            >
              Más en el glosario →
            </button>
          )}
        </span>,
          document.body,
        )}
    </span>
  );
}

/** Texto con los términos técnicos marcados (solo la primera vez que aparece cada uno en el texto). */
export function Glossed({ text }: { text: string }) {
  // Cálculo puro en cada render (sin estado compartido que mutar).
  return (
    <>
      {glossSegments(text).map((s, i) =>
        s.tip ? (
          <Term key={i} tip={s.tip}>
            {s.text}
          </Term>
        ) : (
          <span key={i}>{s.text}</span>
        ),
      )}
    </>
  );
}

/** Un término concreto por id (cuando el texto no es una frase). */
export function TermById({ id, children }: { id: string; children: ReactNode }) {
  const tip = tooltipById(id);
  return tip ? <Term tip={tip}>{children}</Term> : <>{children}</>;
}
