/**
 * Simulador de órbita elíptica (inspirado en NASA Mission Viz y en los elementos keplerianos de
 * GMAT). Herramienta de estudio del Planner: no cambia la órbita del plan (que es circular); sirve
 * para explorar alternativas y queda anotado en el registro de compromisos (CML 3).
 */
import { useEffect, useMemo, useRef, useState } from 'react';
import { REAL_MISSIONS } from '../../data/realMissions';
import {
  ellipsePath,
  fractionBelowAltitude,
  makeEllipse,
  MAX_APOAPSIS_ALT_KM,
  MIN_PERIAPSIS_ALT_KM,
  stateAt,
} from '../../sim/EllipticalOrbit';
import { MOON_RADIUS_KM } from '../../sim/OrbitSystem';
import { fmtNum } from '../../sim/units';
import { useGameStore } from '../../state/useGameStore';

const VIEW = 240; // semiancho del lienzo SVG en unidades de dibujo
const ALTITUDE_EXAGGERATION = 5;
const PRESETS = REAL_MISSIONS.filter((m) => !m.nonKeplerian);

export function EllipticalOrbitLab({ circularAltKm, usefulAltKm }: { circularAltKm: number; usefulAltKm: number }) {
  const note = useGameStore((s) => s.noteEllipticalStudy);
  const [peri, setPeri] = useState(Math.max(MIN_PERIAPSIS_ALT_KM, Math.round(circularAltKm * 0.6)));
  const [apo, setApo] = useState(Math.round(circularAltKm * 4));
  const [t, setT] = useState(0); // fracción del periodo
  const [playing, setPlaying] = useState(false);
  const [exaggerate, setExaggerate] = useState(true);
  const noted = useRef(false);
  const el = useMemo(() => makeEllipse({ periapsisAltKm: peri, apoapsisAltKm: Math.max(apo, peri) }), [peri, apo]);
  const st = stateAt(el, t * el.periodS);
  const useful = fractionBelowAltitude(el, usefulAltKm);
  const circ = makeEllipse({ periapsisAltKm: circularAltKm, apoapsisAltKm: circularAltKm });

  // Animación: un periodo cada 8 s reales (las velocidades relativas se conservan: 2.ª ley de Kepler).
  useEffect(() => {
    if (!playing) return;
    let raf = 0;
    let last = performance.now();
    const tick = (now: number) => {
      setT((v) => (v + (now - last) / 8000) % 1);
      last = now;
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [playing]);

  const study = () => {
    if (!noted.current) {
      noted.current = true;
      note();
    }
  };

  // Dibujo: la Luna en el origen (foco). Con «exagerar», la altitud se multiplica para que la forma
  // de una órbita baja se distinga de la superficie; la escala real se recupera desactivándolo.
  const exag = exaggerate ? ALTITUDE_EXAGGERATION : 1;
  const rDraw = (r: number) => MOON_RADIUS_KM + (r - MOON_RADIUS_KM) * exag;
  const k = VIEW / (rDraw(el.raKm) * 1.06);
  const toSvg = (x: number, y: number) => {
    const r = Math.hypot(x, y);
    const f = r > 0 ? rDraw(r) / r : 0;
    return [x * f * k, -y * f * k] as const;
  };
  const path = ellipsePath(el)
    .map(([x, y], i) => {
      const [px, py] = toSvg(x, y);
      return `${i ? 'L' : 'M'}${px.toFixed(1)},${py.toFixed(1)}`;
    })
    .join(' ');
  const [sx, sy] = toSvg(st.xKm, st.yKm);
  const [mx, my] = [0, 0];

  return (
    <div className="ellipse-lab">
      <p className="small muted">
        Una órbita elíptica pasa muy cerca en el periapsis (más detalle, más rápido) y lejos en el apoapsis (más lento). El plan del juego usa órbitas circulares; aquí puedes
        estudiar la alternativa.
      </p>
      <div className="ellipse-lab__presets" role="group" aria-label="Órbitas de misiones reales">
        {PRESETS.map((m) => (
          <button
            key={m.id}
            className="btn btn--ghost btn--sm"
            onClick={() => {
              setPeri(m.orbit.periapsisKm);
              setApo(m.orbit.apoapsisKm);
              setT(0);
              study();
            }}
            title={m.orbit.label}
          >
            {m.name.replace('Lunar Reconnaissance Orbiter (LRO)', 'LRO')}
          </button>
        ))}
      </div>
      <div className="ellipse-lab__body">
        <svg viewBox={`${-VIEW} ${-VIEW} ${VIEW * 2} ${VIEW * 2}`} className="ellipse-lab__svg" role="img" aria-label={`Órbita de ${peri} por ${apo} km; nave a ${fmtNum(st.altitudeKm, 0)} km`}>
          <circle cx={mx} cy={my} r={rDraw(circ.rpKm) * k} fill="none" stroke="var(--line-strong)" strokeDasharray="4 4" />
          <circle cx={mx} cy={my} r={MOON_RADIUS_KM * k} fill="#3a4250" stroke="#8b96a8" strokeWidth={0.8} />
          <path d={path} fill="none" stroke="var(--signal)" strokeWidth={1.4} />
          <line x1={mx} y1={my} x2={sx} y2={sy} stroke="var(--accent-dim)" strokeWidth={0.8} />
          <circle cx={toSvg(el.rpKm, 0)[0]} cy={0} r={3.5} fill="var(--ok)" />
          <circle cx={toSvg(-el.raKm, 0)[0]} cy={0} r={3.5} fill="var(--info)" />
          <circle cx={sx} cy={sy} r={5} fill="var(--accent)" />
        </svg>
        <div>
        <label className="small ellipse-lab__exag">
          <input type="checkbox" checked={exaggerate} onChange={(ev) => setExaggerate(ev.target.checked)} /> Altitud exagerada ×{ALTITUDE_EXAGGERATION} (para ver la forma)
        </label>
        <p className="small muted ellipse-lab__legend">
          <span style={{ color: 'var(--ok)' }}>●</span> periapsis · <span style={{ color: 'var(--info)' }}>●</span> apoapsis · <span style={{ color: 'var(--line-strong)' }}>- -</span> órbita circular del plan
        </p>
        </div>
        <dl className="kv">
          <dt>Excentricidad e</dt>
          <dd className="mono">{fmtNum(el.e, 3)}</dd>
          <dt>Semieje mayor a</dt>
          <dd className="mono">{fmtNum(el.aKm, 0)} km</dd>
          <dt>Periodo</dt>
          <dd className="mono">
            {fmtNum(el.periodS / 60, 1)} min (circular a {circularAltKm} km: {fmtNum(circ.periodS / 60, 1)})
          </dd>
          <dt>Velocidad periapsis / apoapsis</dt>
          <dd className="mono">
            {fmtNum(el.vPeriKmS, 3)} / {fmtNum(el.vApoKmS, 3)} km/s
          </dd>
          <dt>Ahora</dt>
          <dd className="mono" data-testid="ellipse-now">
            {fmtNum(st.altitudeKm, 0)} km · {fmtNum(st.speedKmS, 3)} km/s
          </dd>
          <dt>Tiempo por debajo de {usefulAltKm} km</dt>
          <dd className="mono">{Math.round(useful * 100)} % de cada órbita</dd>
        </dl>
      </div>
      <label className="slider">
        <span className="slider__head">
          <span>Periapsis</span>
          <strong className="mono">{peri} km</strong>
        </span>
        <input
          type="range"
          min={MIN_PERIAPSIS_ALT_KM}
          max={500}
          step={5}
          value={peri}
          onChange={(ev) => {
            const v = Number(ev.target.value);
            setPeri(v);
            if (apo < v) setApo(v);
            study();
          }}
          aria-label="Altitud del periapsis (km)"
        />
      </label>
      <label className="slider">
        <span className="slider__head">
          <span>Apoapsis</span>
          <strong className="mono">{apo} km</strong>
        </span>
        <input
          type="range"
          min={peri}
          max={Math.min(MAX_APOAPSIS_ALT_KM, 5000)}
          step={10}
          value={Math.max(apo, peri)}
          onChange={(ev) => {
            setApo(Number(ev.target.value));
            study();
          }}
          aria-label="Altitud del apoapsis (km)"
        />
      </label>
      <div className="ellipse-lab__time">
        <button className="btn btn--sm" onClick={() => setPlaying((p) => !p)} aria-pressed={playing}>
          {playing ? 'Pausa' : 'Reproducir'}
        </button>
        <input type="range" min={0} max={1000} value={Math.round(t * 1000)} onChange={(ev) => setT(Number(ev.target.value) / 1000)} aria-label="Tiempo dentro de la órbita" />
        <span className="small mono">t = {fmtNum((t * el.periodS) / 60, 1)} min</span>
      </div>
      <details className="an-how">
        <summary>¿Cómo se calcula?</summary>
        <div className="small muted">
          a = (r_p + r_a)/2, e = (r_a − r_p)/(r_a + r_p), periodo T = 2π√(a³/μ). La posición en cada instante sale de la ecuación de Kepler M = E − e·sen E (Newton-Raphson) y la
          velocidad de la ecuación vis-viva v = √(μ(2/r − 1/a)). Modelo de dos cuerpos: no incluye los mascons ni la gravedad de la Tierra, por eso órbitas como la NRHO de
          CAPSTONE no se pueden simular aquí.
        </div>
      </details>
    </div>
  );
}
