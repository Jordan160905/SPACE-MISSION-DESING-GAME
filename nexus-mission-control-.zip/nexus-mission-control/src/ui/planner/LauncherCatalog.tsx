/**
 * Catálogo de vehículos de lanzamiento del Planner: los 8 cohetes estadounidenses de la figura 7 de
 * «CubeSat 101» (NASA, 2017) que ya habían volado CubeSats.
 *
 * Cada tarjeta muestra nombre, silueta a escala, altura, carga útil, tipo de lanzamiento, estado
 * actual y compatibilidad con la misión. La ficha del vehículo enfocado separa los DATOS REALES
 * (con fuentes) de los VALORES DEL JUEGO y compara lo que necesita la misión con lo que ofrece el
 * vehículo. Un vehículo incompatible no se puede elegir: su tarjeta explica el motivo.
 */
import { useMemo, useState } from 'react';
import { CUBESAT101_MANIFEST_ONLY, LAUNCHERS, STATUS_LABEL } from '../../data/launchers/launchers';
import type { Launcher } from '../../data/schemas';
import { launcherCompatibility, type LauncherCompatibility } from '../../sim/LauncherCompatibility';
import type { PlanReport } from '../../sim/PlanningSystem';
import { fmtNum } from '../../sim/units';
import { useGameStore } from '../../state/useGameStore';
import { numLocale } from '../../i18n/lang';

const MAX_H = Math.max(...LAUNCHERS.map((l) => l.real.heightM)); // escala común de las siluetas

/** Silueta esquemática a escala de altura (representación, no el modelo exacto del cohete). */
function Silhouette({ l }: { l: Launcher }) {
  const h = (l.real.heightM / MAX_H) * 60 + 6;
  const core = Math.max(3, Math.min(l.real.diameterM, 4.5) * 1.6);
  const b = l.boosters;
  const bh = b ? h * Math.min(1, b.lengthM / l.real.heightM) : 0;
  return (
    <svg viewBox="0 0 30 70" className="lv-silhouette" role="img" aria-label={`Silueta a escala: ${fmtNum(l.real.heightM, 1)} m de altura`}>
      <line x1="0" y1="68.5" x2="30" y2="68.5" stroke="var(--line-strong)" strokeWidth="0.6" />
      {b && b.count > 0 && (
        <>
          <rect x={15 - core / 2 - core * 0.55} y={68 - bh} width={core * 0.5} height={bh} fill="var(--text-lo)" />
          <rect x={15 + core / 2 + core * 0.05} y={68 - bh} width={core * 0.5} height={bh} fill="var(--text-lo)" />
        </>
      )}
      <rect x={15 - core / 2} y={68 - h * 0.86} width={core} height={h * 0.86} fill="var(--text-md)" />
      <path d={`M${15 - core / 2} ${68 - h * 0.86} L15 ${68 - h} L${15 + core / 2} ${68 - h * 0.86} Z`} fill="var(--accent)" />
    </svg>
  );
}

function Card({ l, compat, selected, focused, onClick }: { l: Launcher; compat: LauncherCompatibility; selected: boolean; focused: boolean; onClick: () => void }) {
  return (
    <button
      role="radio"
      aria-checked={selected}
      aria-disabled={!compat.compatible}
      aria-describedby={`lv-why-${l.id}`}
      className={`lv-card ${compat.compatible ? '' : 'lv-card--off'} ${focused ? 'lv-card--focus' : ''} ${selected ? 'lv-card--sel' : ''}`}
      onClick={onClick}
      data-launcher={l.id}
    >
      <Silhouette l={l} />
      <span className="lv-card__body">
        <span className="lv-card__head">
          <strong>{l.name}</strong>
          {l.costMUSD !== null && <span className="mono small">{fmtNum(l.costMUSD, 1)} MUSD</span>}
        </span>
        <span className="lv-card__badges">
          <span className={`badge ${l.real.status === 'operational' ? 'badge--ok' : 'badge--lock'}`}>{STATUS_LABEL[l.real.status]}</span>
          <span className="badge badge--info" title="Según la figura 7 de «CubeSat 101» (2017)">
            Ya había volado CubeSats (2017)
          </span>
        </span>
        <span className="small muted lv-card__spec">
          {fmtNum(l.real.heightM, 1)} m · {l.real.leoKg ? `${l.real.leoKg.toLocaleString(numLocale())} kg a órbita baja` : 'carga sin dato'}
        </span>
        <span className="small muted lv-card__type">{l.real.launchType}</span>
        <span id={`lv-why-${l.id}`} className={`small lv-card__why ${compat.compatible ? 'ok' : 'bad'}`}>
          {compat.compatible ? (selected ? '✓ Elegido · compatible con tu misión' : '✓ Compatible con tu misión') : `✗ No seleccionable: ${compat.reason}`}
        </span>
      </span>
    </button>
  );
}

export function LauncherCatalog({ report, onChoose }: { report: PlanReport; onChoose: (id: string) => void }) {
  const current = report.launcher;
  const [focusId, setFocusId] = useState(current.id);
  const navigate = useGameStore((s) => s.navigate);
  const setView = useGameStore((s) => s.labSetView);
  const setRocket = useGameStore((s) => s.labSetRocket);
  const budgetForLauncher = report.engineering.budget ? report.engineering.budget.remainingMUSD + (current.costMUSD ?? 0) : null;
  const orbit = { altitudeKm: report.engineering.orbit.altitudeKm, inclinationDeg: report.engineering.orbit.inclinationDeg };
  const rows = useMemo(
    () =>
      LAUNCHERS.map((l) => ({
        l,
        compat: launcherCompatibility(l, { massWithMarginKg: report.massWithMarginKg, envelope: report.envelope, budgetForLauncherMUSD: budgetForLauncher, orbit }),
      })).sort((a, b) => Number(b.compat.compatible) - Number(a.compat.compatible)),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [report.massWithMarginKg, report.envelope, budgetForLauncher, orbit.altitudeKm, orbit.inclinationDeg],
  );
  const focus = rows.find((x) => x.l.id === focusId) ?? rows[0];
  const nCompat = rows.filter((x) => x.compat.compatible).length;
  const f = focus.l;

  return (
    <div className="lv-catalog">
      <p className="small muted">
        Los 8 vehículos estadounidenses de la figura 7 de <em>CubeSat 101</em> (NASA, 2017) que ya habían lanzado CubeSats. Estar en esa lista no significa
        estar en servicio hoy: cada tarjeta indica su estado actual. {nCompat} {nCompat === 1 ? 'es compatible' : 'son compatibles'} con tu nave y tu presupuesto.
      </p>
      <div className="lv-grid" role="radiogroup" aria-label="Vehículo de lanzamiento">
        {rows.map(({ l, compat }) => (
          <Card
            key={l.id}
            l={l}
            compat={compat}
            selected={l.id === current.id}
            focused={l.id === focus.l.id}
            onClick={() => {
              setFocusId(l.id);
              if (compat.compatible) onChoose(l.id);
            }}
          />
        ))}
      </div>
      <p className="small muted lv-footnote">
        En la misma figura aparecían con * {CUBESAT101_MANIFEST_ONLY.join(', ')}: en 2017 aún no habían volado CubeSats y solo los tenían en manifiestos de
        vuelos futuros, por eso no forman parte de este catálogo.
      </p>

      <section className="lv-detail" aria-label={`Ficha de ${f.name}`} aria-live="polite">
        <div className="lv-detail__head">
          <div>
            <strong>{f.name}</strong> <span className="small muted">· {f.real.operator}</span>
          </div>
          <button
            className="btn btn--sm btn--ghost"
            onClick={() => {
              setRocket({ launcherId: f.id });
              navigate('lab');
              setView('rocket');
            }}
          >
            Ver en 3D
          </button>
        </div>
        <p className="small">{f.description}</p>

        <p className="eyebrow">Compatibilidad con tu misión</p>
        <table className="lv-compare">
          <thead>
            <tr>
              <th scope="col">Requisito</th>
              <th scope="col">Tu misión necesita</th>
              <th scope="col">{f.name} ofrece</th>
              <th scope="col">
                <span className="sr-only">Resultado</span>
              </th>
            </tr>
          </thead>
          <tbody>
            {focus.compat.checks.map((c) => (
              <tr key={c.id} className={c.ok ? 'ok' : 'bad'} title={c.detail}>
                <th scope="row">{c.label}</th>
                <td>{c.need}</td>
                <td>{c.offer}</td>
                <td aria-label={c.ok ? 'Cumple' : 'No cumple'}>{c.ok ? '✓' : '✗'}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {!focus.compat.compatible && <p className="small bad">No se puede elegir: {focus.compat.reason}</p>}

        <div className="lv-detail__cols">
          <div>
            <p className="eyebrow">Datos reales</p>
            <dl className="kv">
              <dt>Altura</dt>
              <dd>{fmtNum(f.real.heightM, 1)} m</dd>
              <dt>Diámetro</dt>
              <dd>{fmtNum(f.real.diameterM, 2)} m</dd>
              <dt>Carga a órbita baja</dt>
              <dd>{f.real.leoKg ? `${f.real.leoKg.toLocaleString(numLocale())} kg${f.real.leoNote ? ` (${f.real.leoNote})` : ''}` : 'sin dato verificado'}</dd>
              <dt>Tipo de lanzamiento</dt>
              <dd>{f.real.launchType}</dd>
              <dt>Primer vuelo</dt>
              <dd>{f.real.firstFlight}</dd>
              <dt>Estado actual</dt>
              <dd>
                {STATUS_LABEL[f.real.status]}: {f.real.statusNote}
              </dd>
              <dt>Historial</dt>
              <dd>
                {f.real.record.approx ? '≈ ' : ''}
                {f.real.record.successes} éxitos en {f.real.record.flights} vuelos ({f.real.record.asOf})
              </dd>
              <dt>Precio publicado</dt>
              <dd>{f.real.priceMUSD ? `${fmtNum(f.real.priceMUSD, 1)} MUSD${f.real.priceNote ? ` (${f.real.priceNote})` : ''}` : (f.real.priceNote ?? 'sin dato')}</dd>
            </dl>
            <ul className="small lv-facts">
              {f.real.facts.map((x) => (
                <li key={x}>{x}</li>
              ))}
            </ul>
          </div>
          <div>
            <p className="eyebrow">En NEXUS (valores simplificados del juego)</p>
            <dl className="kv">
              <dt>Hacia la Luna</dt>
              <dd>{f.payloadToTLIKg > 0 ? `${f.payloadToTLIKg.toLocaleString(numLocale())} kg` : 'no llega en el juego'}</dd>
              <dt>Costo en el juego</dt>
              <dd>{f.costMUSD !== null ? `${fmtNum(f.costMUSD, 1)} MUSD` : 'no se puede contratar'}</dd>
              <dt>Fiabilidad estimada</dt>
              <dd title="Regla de Laplace: (éxitos + 1) / (vuelos + 2). Con pocos vuelos, la estimación es prudente.">{Math.round(f.reliability * 100)} %</dd>
              <dt>Cofia útil</dt>
              <dd>
                Ø {fmtNum(f.fairing.innerDiameterM, 2)} × {fmtNum(f.fairing.heightM, 1)} m
              </dd>
            </dl>
            <p className="small muted">{f.gameNote}</p>
          </div>
        </div>
        <p className="small muted">
          Fuentes:{' '}
          {f.real.sources.map((s, i) => (
            <span key={s.url}>
              {i > 0 && ' · '}
              <a href={s.url} target="_blank" rel="noreferrer">
                {s.title}
              </a>
            </span>
          ))}
        </p>
      </section>
    </div>
  );
}
