/**
 * Estado de las actividades en la superficie de la Luna (Fases 8.8 y 8.9).
 * La física está en sim/Lander y sim/Rover; aquí solo se guarda el estado del juego y se
 * avanza con los mandos del jugador. La escena 3D lee este estado.
 */
import { create } from 'zustand';
import { landingPoints, newLander, stepLander, type LanderInput, type LanderState, type Touchdown } from '../../sim/Lander';
import { getTerrain } from '../../sim/LunarTerrain';
import { answerInvestigation, newRover, stepRover, type RoverInput, type RoverState } from '../../sim/Rover';
import { fmtNum } from '../../sim/units';
import { useFlightSim } from '../flight/flightSim';

export type SurfaceMode = null | 'landing' | 'rover';
export type LandingPhase = 'brief' | 'flying' | 'paused' | 'cinematic' | 'result';
export type RoverCam = 'follow' | 'onboard' | 'top';
export type LandingCam = 'chase' | 'ground' | 'top';

const GOALS_KEY = 'nexus-landing-goal';

function loadGoals(): Record<string, boolean> {
  try {
    const raw = JSON.parse(localStorage.getItem(GOALS_KEY) ?? '{}') as unknown;
    return raw && typeof raw === 'object' ? (raw as Record<string, boolean>) : {};
  } catch {
    return {};
  }
}

interface SurfaceState {
  /** Objetivo del vuelo elegido por misión: aterrizar en la Luna. */
  goals: Record<string, boolean>;
  setGoal: (missionId: string, on: boolean) => void;
  mode: SurfaceMode;
  missionId: string | null;
  // ── Aterrizaje ──
  phase: LandingPhase;
  attempt: number;
  lander: LanderState | null;
  history: Touchdown[];
  landed: Touchdown | null;
  landingCam: LandingCam;
  // ── Rover ──
  rover: RoverState | null;
  roverCam: RoverCam;
  startLanding: (missionId: string) => void;
  beginDescent: () => void;
  setPaused: (paused: boolean) => void;
  stepLanding: (input: LanderInput, dt: number) => void;
  endCinematic: () => void;
  retryLanding: () => void;
  setLandingCam: (c: LandingCam) => void;
  startRover: () => void;
  stepRoverSim: (input: RoverInput, dt: number) => void;
  answerQuiz: (i: number) => void;
  setRoverCam: (c: RoverCam) => void;
  /** Sale de la superficie y deja el resumen para el registro de operaciones. */
  leave: () => void;
}

export const useSurface = create<SurfaceState>()((set, get) => ({
  goals: loadGoals(),
  setGoal: (missionId, on) => {
    const goals = { ...get().goals, [missionId]: on };
    set({ goals });
    try {
      localStorage.setItem(GOALS_KEY, JSON.stringify(goals));
    } catch {
      /* sin almacenamiento */
    }
  },
  mode: null,
  missionId: null,
  phase: 'brief',
  attempt: 0,
  lander: null,
  history: [],
  landed: null,
  landingCam: 'chase',
  rover: null,
  roverCam: 'follow',

  startLanding: (missionId) => set({ mode: 'landing', missionId, phase: 'brief', attempt: 0, lander: newLander(getTerrain(), 0), history: [], landed: null, rover: null }),
  beginDescent: () => {
    if (get().phase === 'brief') set({ phase: 'flying' });
  },
  setPaused: (paused) => {
    const p = get().phase;
    if (paused && p === 'flying') set({ phase: 'paused' });
    if (!paused && p === 'paused') set({ phase: 'flying' });
  },
  stepLanding: (input, dt) => {
    const s = get();
    if (s.phase !== 'flying' || !s.lander) return;
    const t = getTerrain();
    let l = s.lander;
    let left = dt;
    while (left > 1e-9 && !l.done) {
      const h = Math.min(0.05, left);
      l = stepLander(t, l, input, h);
      left -= h;
    }
    if (l.done && l.touchdown) {
      const td = l.touchdown;
      set({ lander: l, history: [...s.history, td], landed: td.success ? td : s.landed, phase: td.success ? 'cinematic' : 'result' });
      return;
    }
    set({ lander: l });
  },
  endCinematic: () => {
    if (get().phase === 'cinematic') set({ phase: 'result' });
  },
  retryLanding: () => {
    const attempt = get().attempt + 1;
    set({ attempt, lander: newLander(getTerrain(), attempt), phase: 'flying' });
  },
  setLandingCam: (landingCam) => set({ landingCam }),

  startRover: () => {
    const td = get().landed;
    if (!td) return;
    set({ mode: 'rover', rover: newRover(td.x, td.z), roverCam: 'follow' });
  },
  stepRoverSim: (input, dt) => {
    const s = get();
    if (!s.rover || !s.landed) return;
    const t = getTerrain();
    let r = s.rover;
    let left = dt;
    while (left > 1e-9 && !r.finished && !r.quizPending) {
      const h = Math.min(0.1, left);
      r = stepRover(t, r, input, h, { x: s.landed.x, z: s.landed.z });
      left -= h;
    }
    set({ rover: r });
  },
  answerQuiz: (i) => {
    const r = get().rover;
    if (r?.quizPending) set({ rover: answerInvestigation(r, i) });
  },
  setRoverCam: (roverCam) => set({ roverCam }),

  leave: () => {
    const s = get();
    const parts: string[] = [];
    if (s.landed) parts.push(`aterrizaje ${s.landed.inSafe ? 'en la zona segura' : 'en una zona aceptable'} (+${landingPoints(s.landed)} puntos, ${s.history.length} intento(s))`);
    else if (s.history.length) parts.push(`aterrizaje no completado (${s.history.length} intento(s))`);
    const r = s.rover;
    if (r) parts.push(`rover: ${r.mission} de 6 misiones, ${fmtNum(r.distanceM, 0)} m recorridos (+${r.points} puntos)`);
    const fs = useFlightSim.getState();
    if (parts.length && fs.vars) {
      const gbit = r?.gbit ?? 0;
      useFlightSim.setState({
        surfaceSummary: `Superficie lunar: ${parts.join('; ')}.`,
        vars: { ...fs.vars, scienceGbit: fs.vars.scienceGbit + gbit },
      });
    }
    set({ mode: null });
  },
}));
