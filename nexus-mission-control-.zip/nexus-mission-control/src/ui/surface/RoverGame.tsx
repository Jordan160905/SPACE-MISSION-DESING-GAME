/**
 * Minijuego del rover lunar (Fase 8.9): conducción, energía, mapa de exploración y misiones.
 * Mandos: W/↑ adelante, S/↓ atrás, A/← y D/→ girar, E acción (mantener), C cambiar de cámara.
 */
import { useEffect, useMemo, useState, type PointerEvent as RPointerEvent } from 'react';
import { heightAt, getTerrain, slopeAt, TERRAIN } from '../../sim/LunarTerrain';
import { exploredPct, INVESTIGATION, missionTarget, ROVER, ROVER_MISSIONS, roverReadout, type RoverInput, type RoverMissionId } from '../../sim/Rover';
import { fmtNum } from '../../sim/units';
import { useGameStore } from '../../state/useGameStore';
import { NpcAvatar } from '../review/ReviewArt';
import { useSurface, type RoverCam } from './surfaceStore';

type Ctl = 'fwd' | 'back' | 'left' | 'right' | 'act';
const KEYS: Record<string, Ctl> = { KeyW: 'fwd', ArrowUp: 'fwd', KeyS: 'back', ArrowDown: 'back', KeyA: 'left', ArrowLeft: 'left', KeyD: 'right', ArrowRight: 'right', KeyE: 'act' };
const CAMS: Array<{ id: RoverCam; label: string }> = [
  { id: 'follow', label: 'Seguimiento' },
  { id: 'onboard', label: 'Desde el rover' },
  { id: 'top', label: 'Desde arriba' },
];
const ACTION_LABEL: Partial<Record<RoverMissionId, string>> = { sample: 'Recoger (E)', investigate: 'Medir (E)', send: 'Enviar (E)' };
const ICON: Record<RoverMissionId, string> = { rock: '🪨', crater: '◯', sample: '⚗', hill: '⛰', investigate: '🔬', send: '📡' };

const MAP_HALF = 400;
const MAP_PX = 240;

function Hold({ ctl, label, title, held, set, className = '' }: { ctl: Ctl; label: string; title: string; held: Record<string, boolean>; set: (c: Ctl, v: boolean) => void; className?: string }) {
  const on = (e: RPointerEvent<HTMLButtonElement>) => {
    e.currentTarget.setPointerCapture(e.pointerId);
    set(ctl, true);
  };
  const off = () => set(ctl, false);
  return (
    <button className={`sf-pad ${held[ctl] ? 'sf-pad--on' : ''} ${className}`} onPointerDown={on} onPointerUp={off} onPointerCancel={off} onLostPointerCapture={off} title={title} aria-label={title} aria-pressed={!!held[ctl]}>
      {label}
    </button>
  );
}

/** Relieve sombreado del mapa (se calcula una vez). */
function useRelief(cx: number, cz: number) {
  return useMemo(() => {
    if (typeof document === 'undefined') return '';
    const n = 120;
    const c = document.createElement('canvas');
    c.width = c.height = n;
    const ctx = c.getContext('2d');
    if (!ctx) return '';
    const img = ctx.createImageData(n, n);
    const t = getTerrain();
    for (let j = 0; j < n; j++)
      for (let i = 0; i < n; i++) {
        const x = cx - MAP_HALF + ((i + 0.5) / n) * 2 * MAP_HALF;
        const z = cz - MAP_HALF + ((j + 0.5) / n) * 2 * MAP_HALF;
        const s = slopeAt(t, x, z);
        // Luz desde el oeste-noroeste (como el Sol bajo de la escena).
        const shade = 0.55 + Math.max(-0.4, Math.min(0.4, (-s.gx * 0.8 - s.gz * 0.4) * 3));
        const h = heightAt(t, x, z);
        const v = Math.max(0, Math.min(255, (shade + h * 0.006) * 150));
        const k = (j * n + i) * 4;
        img.data[k] = v;
        img.data[k + 1] = v;
        img.data[k + 2] = v * 1.04;
        img.data[k + 3] = 255;
      }
    ctx.putImageData(img, 0, 0);
    return c.toDataURL();
  }, [cx, cz]);
}

function ExplorationMap({ lander }: { lander: { x: number; z: number } }) {
  const r = useSurface((s) => s.rover);
  const relief = useRelief(lander.x, lander.z);
  if (!r) return null;
  const t = getTerrain();
  const px = (x: number) => ((x - (lander.x - MAP_HALF)) / (2 * MAP_HALF)) * MAP_PX;
  const pz = (z: number) => ((z - (lander.z - MAP_HALF)) / (2 * MAP_HALF)) * MAP_PX;
  const cellPx = (ROVER.cell / (2 * MAP_HALF)) * MAP_PX;
  const cur = ROVER_MISSIONS[r.mission];
  const sites = ROVER_MISSIONS.map((m, i) => ({ m, i, tg: missionTarget(t, m.id, lander) }));
  const pct = exploredPct(r, lander);
  return (
    <div className="rvr-map-wrap">
      <svg viewBox={`0 0 ${MAP_PX} ${MAP_PX}`} className="rvr-map" role="img" aria-label={`Mapa de exploración: ${fmtNum(pct, 0)} % explorado`}>
        <defs>
          <mask id="rvr-fog">
            <rect width={MAP_PX} height={MAP_PX} fill="#555" />
            {r.explored.map((k) => {
              const [gx, gz] = k.split(',').map(Number);
              return <rect key={k} x={px(gx * ROVER.cell)} y={pz(gz * ROVER.cell)} width={cellPx + 0.5} height={cellPx + 0.5} fill="#fff" />;
            })}
          </mask>
        </defs>
        {relief && <image href={relief} width={MAP_PX} height={MAP_PX} mask="url(#rvr-fog)" preserveAspectRatio="none" />}
        <circle cx={px(TERRAIN.safe.x)} cy={pz(TERRAIN.safe.z)} r={(TERRAIN.safe.r / (2 * MAP_HALF)) * MAP_PX} className="rvr-map__safe" />
        {sites
          .filter((s, i, a) => a.findIndex((o) => o.tg.x === s.tg.x && o.tg.z === s.tg.z) === i)
          .map(({ m, i, tg }) => {
            const done = i < r.mission;
            const active = cur && (cur.id === m.id || (missionTarget(t, cur.id, lander).x === tg.x && missionTarget(t, cur.id, lander).z === tg.z));
            return (
              <g key={m.id} className={`rvr-map__site ${done ? 'done' : ''} ${active ? 'active' : ''}`}>
                <circle cx={px(tg.x)} cy={pz(tg.z)} r={Math.max(4, (tg.r / (2 * MAP_HALF)) * MAP_PX)} />
                <text x={px(tg.x)} y={pz(tg.z) + 3} textAnchor="middle">
                  {done ? '✓' : String(i + 1)}
                </text>
                <title>{m.title}</title>
              </g>
            );
          })}
        <g transform={`translate(${px(lander.x)} ${pz(lander.z)})`} className="rvr-map__lander">
          <rect x={-4} y={-4} width={8} height={8} />
          <title>Módulo de descenso</title>
        </g>
        <g transform={`translate(${px(r.x)} ${pz(r.z)}) rotate(${(r.heading * 180) / Math.PI})`} className="rvr-map__rover">
          <path d="M7 0 L-5 5 L-2 0 L-5 -5 Z" />
        </g>
      </svg>
      <p className="small muted">{`Explorado: ${fmtNum(pct, 0)} % de la zona · ${fmtNum(r.distanceM, 0)} m recorridos`}</p>
    </div>
  );
}

function Quiz() {
  const answer = useSurface((s) => s.answerQuiz);
  return (
    <div className="sf-overlay" role="dialog" aria-modal="true" aria-labelledby="rvr-quiz">
      <div className="sf-card">
        <p className="eyebrow">Misión 5 · Investigación</p>
        <h2 className="h2" id="rvr-quiz">
          ¿Qué dicen los datos?
        </h2>
        <p>{INVESTIGATION.question}</p>
        <ul className="fev__opts">
          {INVESTIGATION.options.map((o, i) => (
            <li key={o}>
              <button className="fev__opt" onClick={() => answer(i)}>
                <strong>{o}</strong>
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

function Briefing({ onClose }: { onClose: () => void }) {
  return (
    <div className="sf-overlay" role="dialog" aria-modal="true" aria-labelledby="rvr-brief">
      <div className="sf-card ld-brief">
        <p className="eyebrow">Minijuego · Exploración con el rover</p>
        <h2 className="h2" id="rvr-brief">
          ¡A explorar la Luna!
        </h2>
        <div className="fev__msg">
          <NpcAvatar mood="happy" />
          <p className="fev__bubble">
            <strong>Centro de control:</strong> El rover ya bajó del módulo. Tenemos 6 misiones para ti: sigue los objetivos y el mapa.
          </p>
        </div>
        <div className="ld-brief__grid">
          <section>
            <h3 className="section-title">Mandos</h3>
            <ul className="small ld-keys">
              <li>
                <kbd className="rtut-key">W</kbd>
                <kbd className="rtut-key">S</kbd> o <kbd className="rtut-key">↑</kbd>
                <kbd className="rtut-key">↓</kbd> adelante y atrás
              </li>
              <li>
                <kbd className="rtut-key">A</kbd>
                <kbd className="rtut-key">D</kbd> o <kbd className="rtut-key">←</kbd>
                <kbd className="rtut-key">→</kbd> girar
              </li>
              <li>
                <kbd className="rtut-key">E</kbd> mantener para recoger, medir o enviar · <kbd className="rtut-key">C</kbd> cambiar de cámara
              </li>
            </ul>
          </section>
          <section>
            <h3 className="section-title">Ten en cuenta</h3>
            <ul className="small">
              <li>{`Las cuestas de más de ${ROVER.maxClimbDeg}° no se pueden subir: rodéalas.`}</li>
              <li>Las rocas grandes bloquean el paso.</li>
              <li>Conducir gasta energía; parado, los paneles solares la recargan.</li>
              <li>El mapa se va descubriendo por donde pasas.</li>
            </ul>
          </section>
        </div>
        <button className="btn btn--primary" onClick={onClose}>
          Empezar a conducir
        </button>
      </div>
    </div>
  );
}

export function RoverGame() {
  const rover = useSurface((s) => s.rover);
  const landed = useSurface((s) => s.landed);
  const cam = useSurface((s) => s.roverCam);
  const setCam = useSurface((s) => s.setRoverCam);
  const leave = useSurface((s) => s.leave);
  const finishFlight = useGameStore((s) => s.launchFinish);
  const [brief, setBrief] = useState(true);
  const [held, setHeld] = useState<Record<string, boolean>>({});
  const live = useMemo(() => ({ current: {} as Record<string, boolean> }), []);
  const setCtl = (c: Ctl, v: boolean) => {
    live.current = { ...live.current, [c]: v };
    setHeld(live.current);
  };
  const [toast, setToast] = useState<RoverMissionId | null>(null);
  const running = !!rover && !brief && !rover.finished && !rover.quizPending;

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
      if (e.code === 'KeyC' && e.type === 'keydown') {
        const i = CAMS.findIndex((c) => c.id === useSurface.getState().roverCam);
        setCam(CAMS[(i + 1) % CAMS.length].id);
        return;
      }
      const c = KEYS[e.code];
      if (!c) return;
      e.preventDefault();
      const down = e.type === 'keydown';
      if (!!live.current[c] !== down) {
        live.current = { ...live.current, [c]: down };
        setHeld(live.current);
      }
    };
    window.addEventListener('keydown', onKey);
    window.addEventListener('keyup', onKey);
    return () => {
      window.removeEventListener('keydown', onKey);
      window.removeEventListener('keyup', onKey);
    };
  }, [live, setCam]);

  useEffect(() => {
    if (!running) return;
    const id = window.setInterval(() => {
      const h = live.current;
      const input: RoverInput = { drive: (h.fwd ? 1 : 0) - (h.back ? 1 : 0), turn: (h.right ? 1 : 0) - (h.left ? 1 : 0), action: !!h.act };
      useSurface.getState().stepRoverSim(input, 0.05);
    }, 50);
    return () => window.clearInterval(id);
  }, [running, live]);

  // Aviso de misión completada.
  const lastDone = rover?.lastDone ?? null;
  const missionIdx = rover?.mission ?? 0;
  useEffect(() => {
    if (!lastDone) return;
    setToast(lastDone);
    const id = window.setTimeout(() => setToast(null), 6000);
    return () => window.clearTimeout(id);
  }, [lastDone, missionIdx]);

  if (!rover || !landed) return null;
  const lander = { x: landed.x, z: landed.z };
  const t = getTerrain();
  const rd = roverReadout(t, rover, lander);
  const m = rd.mission;
  const turnHint = Math.abs(rd.bearingDeg) < 10 ? 'de frente' : rd.bearingDeg > 0 ? `${fmtNum(Math.abs(rd.bearingDeg), 0)}° a la derecha` : `${fmtNum(Math.abs(rd.bearingDeg), 0)}° a la izquierda`;
  const warnText =
    rover.warn === 'steep'
      ? `¡Demasiado empinado! El rover no sube cuestas de más de ${ROVER.maxClimbDeg}°: busca otro camino.`
      : rover.warn === 'rock'
        ? 'Una roca bloquea el paso: retrocede y rodéala.'
        : rover.warn === 'energy'
          ? rover.energy <= 0
            ? 'Batería agotada: espera parado a que los paneles solares la recarguen.'
            : 'Batería baja: para un momento para recargar con los paneles solares.'
          : rover.warn === 'edge'
            ? 'Has llegado al límite de la zona explorable.'
            : null;
  const doneDef = toast ? ROVER_MISSIONS.find((x) => x.id === toast) : null;

  return (
    <div className="sf-hud rvr-hud">
      <section className="sf-panel sf-left" aria-label="Misiones del rover" data-mission={rover.mission} data-warn={rover.warn ?? ''} data-speed={rover.speed.toFixed(2)}>
        <p className="eyebrow">{`Rover lunar · ${rover.points} puntos`}</p>
        <ol className="rvr-missions">
          {ROVER_MISSIONS.map((x, i) => (
            <li key={x.id} className={i < rover.mission ? 'done' : i === rover.mission ? 'cur' : ''}>
              <span aria-hidden="true">{i < rover.mission ? '✓' : ICON[x.id]}</span> {x.title}
              <span className="rvr-missions__pts mono">{`+${x.points}`}</span>
            </li>
          ))}
        </ol>
        {m ? (
          <div className="rvr-goal">
            <p className="small">
              <strong>{`Misión ${rover.mission + 1}:`}</strong> {m.goal}
            </p>
            <p className="mono small" data-testid="rvr-target" data-dist={rd.distanceM.toFixed(1)} data-bearing={rd.bearingDeg.toFixed(1)} data-in={rd.inTarget ? '1' : '0'}>{rd.inTarget ? '¡Estás en el sitio!' : `Objetivo a ${fmtNum(rd.distanceM, 0)} m · ${turnHint}`}</p>
            <div className="rvr-compass" aria-hidden="true">
              <span style={{ transform: `rotate(${rd.bearingDeg}deg)` }}>↑</span>
            </div>
            {m.holdS > 0 && rd.inTarget && (
              <div className="tm-row">
                <span>{ACTION_LABEL[m.id]}</span>
                <span className="tm-bar" role="img" aria-label="Progreso">
                  <span style={{ width: `${Math.min(100, (rover.holdT / m.holdS) * 100)}%` }} />
                </span>
                <span className="mono">{`${Math.min(100, Math.round((rover.holdT / m.holdS) * 100))} %`}</span>
              </div>
            )}
          </div>
        ) : null}
      </section>

      <section className="sf-panel sf-right" aria-label="Mapa de exploración">
        <h3 className="section-title">Mapa de exploración</h3>
        <ExplorationMap lander={lander} />
        {!rover.finished && (
          <button
            className="chip chip--neutral rvr-leave"
            onClick={() => {
              leave();
              finishFlight();
            }}
          >
            Terminar la exploración y volver a la órbita
          </button>
        )}
      </section>

      {warnText && (
        <p className="sf-warn" role="alert">
          {warnText}
        </p>
      )}
      {doneDef && (
        <div className="rvr-toast" role="status">
          <strong>{`✓ ${doneDef.title} · +${doneDef.points} puntos`}</strong>
          <span className="small">{doneDef.done}</span>
          {doneDef.id === 'investigate' && rover.quizAnswer !== null && (
            <span className="small">{`${rover.quizAnswer === INVESTIGATION.correct ? `¡Respuesta correcta! +${INVESTIGATION.bonus} puntos.` : 'No era esa.'} ${INVESTIGATION.explain}`}</span>
          )}
        </div>
      )}

      <section className="sf-panel sf-bottom" aria-label="Mandos del rover">
        <div className="sf-ctl">
          <div className="sf-ctl__group rvr-status">
            <span className="small muted">Energía</span>
            <span className={`tm-bar ${rover.energy < 20 ? 'tm-bar--warn' : ''}`} role="img" aria-label={`Energía ${Math.round(rover.energy)} %`}>
              <span style={{ width: `${rover.energy}%` }} />
            </span>
            <span className="mono small" data-testid="rvr-energy">{`${Math.round(rover.energy)} %${Math.abs(rover.speed) < 0.05 && rover.energy < 100 ? ' · cargando ☀' : ''}`}</span>
            <span className="mono small">{`${fmtNum(Math.abs(rover.speed), 1)} m/s · pendiente ${fmtNum(rd.grade, 0)}°`}</span>
          </div>
          <div className="sf-ctl__group" role="group" aria-label="Conducir">
            <span className="small muted">Conducir</span>
            <div className="sf-grid">
              <span />
              <Hold ctl="fwd" label="W ↑" title="Adelante (W)" held={held} set={setCtl} />
              <span />
              <Hold ctl="left" label="A ←" title="Girar a la izquierda (A)" held={held} set={setCtl} />
              <Hold ctl="act" label="E" title={m && ACTION_LABEL[m.id] ? ACTION_LABEL[m.id]! : 'Acción (E)'} held={held} set={setCtl} />
              <Hold ctl="right" label="D →" title="Girar a la derecha (D)" held={held} set={setCtl} />
              <span />
              <Hold ctl="back" label="S ↓" title="Atrás (S)" held={held} set={setCtl} />
              <span />
            </div>
          </div>
          <div className="sf-ctl__group" role="group" aria-label="Cámara">
            <span className="small muted">Cámara (C)</span>
            <span className="segmented">
              {CAMS.map((c) => (
                <button key={c.id} aria-pressed={cam === c.id} onClick={() => setCam(c.id)}>
                  {c.label}
                </button>
              ))}
            </span>
            {m && ACTION_LABEL[m.id] && (
              <Hold ctl="act" label={`Mantener: ${ACTION_LABEL[m.id]}`} title={ACTION_LABEL[m.id]!} held={held} set={setCtl} className="rvr-act" />
            )}
            <button className="chip chip--neutral" onClick={() => setBrief(true)}>
              ❓ Mandos
            </button>
          </div>
        </div>
      </section>

      {brief && <Briefing onClose={() => setBrief(false)} />}
      {rover.quizPending && <Quiz />}
      {rover.finished && (
        <div className="sf-overlay" role="dialog" aria-modal="true" aria-labelledby="rvr-end">
          <div className="sf-card ld-result ld-result--ok">
            <p className="eyebrow">Exploración completada</p>
            <h2 className="h2" id="rvr-end">
              ¡Resultados enviados al centro de control!
            </h2>
            <p className="ld-result__pts mono">{`+${rover.points} puntos · ${fmtNum(rover.gbit, 1)} Gbit de ciencia`}</p>
            <ul className="small">
              <li>{`Distancia recorrida: ${fmtNum(rover.distanceM, 0)} m`}</li>
              <li>{`Zona explorada: ${fmtNum(exploredPct(rover, lander), 0)} %`}</li>
              <li>{`Investigación: ${rover.quizAnswer === INVESTIGATION.correct ? 'respuesta correcta' : 'respuesta incorrecta'}`}</li>
            </ul>
            <button
              className="btn btn--primary"
              onClick={() => {
                leave();
                finishFlight();
              }}
            >
              Volver a la órbita y empezar las operaciones
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
