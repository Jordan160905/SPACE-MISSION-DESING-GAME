/** Interfaz de la superficie lunar: aterrizaje (8.8) o rover (8.9). */
import { LandingGame } from './LandingGame';
import { RoverGame } from './RoverGame';
import { useSurface } from './surfaceStore';

export function SurfaceHUD() {
  const mode = useSurface((s) => s.mode);
  if (mode === 'landing') return <LandingGame />;
  if (mode === 'rover') return <RoverGame />;
  return null;
}
