/**
 * Votación del equipo (modo equipo, misma computadora). Cada integrante ve la meta de su rol con
 * los números actuales y vota por turnos. Gana la mayoría; en empate decide la dirección.
 */
import { useMemo, useState } from 'react';
import type { TeamRole } from '../../data/schemas';
import { roleDef, roleGoals, tallyVotes } from '../../sim/TeamSystem';
import { selectActiveMission, useGameStore } from '../../state/useGameStore';
import { reviewInputFor } from '../review/reviewInput';

export function TeamVote() {
  const req = useGameStore((s) => s.teamVote);
  const mission = useGameStore(selectActiveMission);
  const submit = useGameStore((s) => s.submitTeamVote);
  const cancel = useGameStore((s) => s.cancelTeamVote);
  const [votes, setVotes] = useState<Partial<Record<TeamRole, string>>>({});
  const goals = useMemo(() => {
    const input = mission ? reviewInputFor(mission) : null;
    return input ? roleGoals(input.engineering, input.plan) : [];
  }, [mission]);
  if (!req || !mission?.team) return null;
  const members = mission.team.members;
  const all = members.every((m) => votes[m.role]);
  const preview = all ? tallyVotes(members.map((m) => ({ role: m.role, choice: votes[m.role]! }))) : null;

  return (
    <div className="modal-backdrop team-vote-backdrop">
      <div className="panel team-vote" role="dialog" aria-modal="true" aria-labelledby="team-vote-title">
        <div className="panel__body">
          <p className="eyebrow">Votación de {mission.team.name}</p>
          <h2 className="h3" id="team-vote-title">
            {req.label}
          </h2>
          <p className="small muted">
            Pasen la computadora: cada persona revisa la meta de su rol y vota. Si no están de acuerdo, negocien con los números antes de votar.
          </p>
          <div className="team-vote__grid">
            {members.map((m) => {
              const g = goals.find((x) => x.role === m.role);
              return (
                <section key={m.role} className="team-card">
                  <strong>{m.name}</strong>
                  <span className="small muted"> · {roleDef(m.role).label}</span>
                  {g && (
                    <p className={`small team-card__goal ${g.met ? 'ok' : 'bad'}`}>
                      {g.met ? '✓' : '✗'} {g.goal}
                      <br />
                      <span className="mono">{g.status}</span>
                    </p>
                  )}
                  <div className="team-card__opts" role="radiogroup" aria-label={`Voto de ${m.name}`}>
                    {req.options.map((o) => (
                      <button
                        key={o.id}
                        role="radio"
                        aria-checked={votes[m.role] === o.id}
                        className="seg__btn"
                        onClick={() => setVotes({ ...votes, [m.role]: o.id })}
                      >
                        {o.label}
                      </button>
                    ))}
                  </div>
                </section>
              );
            })}
          </div>
          <div className="team-vote__foot">
            <span className="small">
              {preview
                ? `Resultado: ${req.options.find((o) => o.id === preview.outcome)?.label}${preview.unanimous ? ' · unanimidad' : preview.tieBrokenByDirector ? ' · empate, decide la dirección' : ' · mayoría'}`
                : `Faltan ${members.filter((m) => !votes[m.role]).length} voto(s)`}
            </span>
            <span style={{ display: 'flex', gap: 8 }}>
              {req.kind !== 'event' && (
                <button className="btn btn--ghost" onClick={cancel}>
                  Volver
                </button>
              )}
              <button
                className="btn btn--primary"
                disabled={!all}
                onClick={() => {
                  submit(members.map((m) => ({ role: m.role, choice: votes[m.role]! })));
                  setVotes({});
                }}
              >
                Contar votos
              </button>
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
