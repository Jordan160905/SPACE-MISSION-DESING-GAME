/**
 * Vista de integración: en el centro solo se ve el cohete (escena 3D); toda la información y los
 * controles están en la pestaña «Cohete» de la columna derecha (`LabRocketPanel`).
 * Muestra si la masa y el tamaño (plegada) caben. La elección definitiva se hace en el Planner.
 */
import { getComponent } from '../../data/components/catalog';
import { LAUNCHERS } from '../../data/launchers/launchers';
import { designTotals } from '../../sim/DesignSystem';
import { stowedEnvelope } from '../../sim/EnvelopeSystem';
import { fmtNum } from '../../sim/units';
import { selectActiveMission, useGameStore } from '../../state/useGameStore';
import { STAGE_ORDER } from '../../state/missionLogic';
import { numLocale } from '../../i18n/lang';

const FAIRING_LABEL = { closed: 'Cerrada', cutaway: 'Corte', open: 'Abierta' } as const;

export function LabViewSwitch() {
  const view = useGameStore((s) => s.lab.view);
  const setView = useGameStore((s) => s.labSetView);
  return (
    <div className="segmented" role="tablist" aria-label="Vista del laboratorio">
      <button role="tab" aria-selected={view === 'craft'} onClick={() => setView('craft')}>
        Nave
      </button>
      <button role="tab" aria-selected={view === 'rocket'} onClick={() => setView('rocket')}>
        Cohete
      </button>
    </div>
  );
}

export function LabRocketPanel() {
  const lab = useGameStore((s) => s.lab);
  const setRocket = useGameStore((s) => s.labSetRocket);
  const mission = useGameStore(selectActiveMission);
  const navigate = useGameStore((s) => s.navigate);
  const plannerUpdate = useGameStore((s) => s.plannerUpdate);
  const goAnalyze = useGameStore((s) => s.labGoAnalyze);
  const { rocket, draft } = lab;
  const mass = designTotals(draft, getComponent).massWetKg;
  const env = stowedEnvelope(draft, getComponent);
  const launcher = LAUNCHERS.find((l) => l.id === rocket.launcherId) ?? LAUNCHERS.find((l) => l.id === 'falcon-9')!;
  const massOk = mass <= launcher.payloadToTLIKg;
  const sizeOk = !env || (env.diameterM <= launcher.fairing.innerDiameterM && env.heightM <= launcher.fairing.heightM);

  // Aprobar el lanzamiento: fija este vehículo en el plan y lleva al Planner.
  function approveLaunch() {
    if (!mission) return null;
    const stageIdx = STAGE_ORDER.indexOf(mission.stage);
    if (stageIdx < STAGE_ORDER.indexOf('PLANNING') || !mission.plan) {
      return (
        <div className="rocket-approve">
          <p className="small muted">Para lanzar, primero analiza y aprueba el diseño de tu nave.</p>
          <button className="btn" onClick={goAnalyze}>
            Ir al análisis del diseño →
          </button>
        </div>
      );
    }
    if (stageIdx > STAGE_ORDER.indexOf('LAUNCH')) return null;
    const plan = mission.plan;
    const canFly = launcher.lunarCapable && massOk && sizeOk;
    const reason = !launcher.lunarCapable ? `${launcher.name} no está disponible para ir a la Luna.` : !massOk ? 'Tu nave pesa más de lo que este cohete puede llevar a la Luna.' : !sizeOk ? 'Tu nave plegada no cabe en la cofia de este cohete.' : '';
    return (
      <div className="rocket-approve">
        <button
          className="btn btn--primary"
          disabled={!canFly}
          onClick={() => {
            if (plan.launcherId !== launcher.id) plannerUpdate({ launcherId: launcher.id });
            navigate('planner');
          }}
        >
          {`Aprobar lanzamiento en ${launcher.name} → Planner`}
        </button>
        {canFly ? <p className="small muted">Se guarda en tu plan de vuelo; en el Planner verás si todo lo demás encaja.</p> : <p className="small bad">{reason}</p>}
      </div>
    );
  }

  return (
    <div className="rocket-panel" role="region" aria-label="Vista de integración en el cohete">
      <h3 className="section-title">Vehículo</h3>
      <div className="rocket-panel__row rocket-panel__launchers">
        {LAUNCHERS.map((l) => (
          <button key={l.id} className="launcher-chip" aria-pressed={l.id === launcher.id} onClick={() => setRocket({ launcherId: l.id })}>
            <strong>{l.name}</strong>
            <span>{l.lunarCapable ? `${l.payloadToTLIKg.toLocaleString(numLocale())} kg a la Luna · ${l.costMUSD} MUSD` : `${l.real.heightM} m · solo para ver`}</span>
          </button>
        ))}
      </div>
      <h3 className="section-title">Vista</h3>
      <div className="rocket-panel__row">
        <span className="small muted">Cofia:</span>
        {(['closed', 'cutaway', 'open'] as const).map((f) => (
          <button key={f} className="chip chip--neutral" aria-pressed={rocket.fairing === f} onClick={() => setRocket({ fairing: f })}>
            {FAIRING_LABEL[f]}
          </button>
        ))}
        <button className="chip chip--neutral" aria-pressed={rocket.exploded} onClick={() => setRocket({ exploded: !rocket.exploded })}>
          Vista explosionada
        </button>
        <button className="chip chip--neutral" aria-pressed={rocket.labels} onClick={() => setRocket({ labels: !rocket.labels })}>
          Etiquetas en 3D
        </button>
      </div>
      <h3 className="section-title">¿Cabe tu nave?</h3>
      <div className="rocket-panel__checks">
        <span className={`badge ${massOk ? 'badge--ok' : 'badge--hard'}`}>
          {launcher.lunarCapable ? `Masa ${fmtNum(mass)} / ${launcher.payloadToTLIKg.toLocaleString(numLocale())} kg ${massOk ? '✓' : '✗'}` : 'No disponible para ir a la Luna ✗'}
        </span>
        <span className={`badge ${sizeOk ? 'badge--ok' : 'badge--hard'}`}>
          {env ? `Plegada Ø ${fmtNum(env.diameterM, 2)} × ${fmtNum(env.heightM, 2)} m` : 'Sin nave'} · cofia Ø {fmtNum(launcher.fairing.innerDiameterM, 2)} × {fmtNum(launcher.fairing.heightM, 2)} m{' '}
          {sizeOk ? '✓' : '✗'}
        </span>
      </div>
      <p className="small muted" style={{ margin: '10px 0 0' }}>
        {launcher.description} {launcher.lunarCapable ? '' : `${launcher.unavailableReason} `}Los paneles solares viajan plegados y se despliegan en órbita. La elección
        definitiva del vehículo se hace en el Mission Planner.
      </p>
      {approveLaunch()}
    </div>
  );
}
