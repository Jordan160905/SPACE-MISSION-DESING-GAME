/**
 * Panel derecho del LAB.
 *
 *  · Construcción (Fase 3 de la mejora de experiencia): estado general del diseño, parámetros
 *    críticos interactivos, recursos (presupuesto, masa, energía), restricciones de la misión,
 *    problemas con «Solucionar problema» y piezas instaladas. Lo técnico completo sigue disponible
 *    en «Detalles técnicos».
 *  · Análisis: el análisis de ingeniería completo (detalle técnico). La aprobación se hace en la
 *    pantalla de análisis (Fase 4), a la que llevan los botones «Siguiente: Analizar diseño».
 *
 * Todos los números salen de sim/EngineeringAnalysis (vía sim/LabGuidance) y sim/DesignSystem: la
 * interfaz no valida nada por su cuenta. Sin incidencias críticas ⇒ diseño viable.
 */
import { useMemo, useState } from 'react';
import { CATEGORY_LABELS, COMPONENT_CATALOG, getComponent, socketLabel } from '../../data/components/catalog';
import { LUNAR_LAUNCHERS } from '../../data/launchers/launchers';
import { templateForMission } from '../../data/missions/missions';
import { designTotals, type DesignIssue } from '../../sim/DesignSystem';
import { constraintChecks, fixFor, labParameters, PARAM_STATE_LABEL, type FixTarget, type LabParameter, type ParamState } from '../../sim/LabGuidance';
import { MAX_DOD } from '../../sim/PowerSystem';
import { fmtNum, formatMUSD, round } from '../../sim/units';
import { STAGE_INFO } from '../../state/missionLogic';
import { selectLabObjectiveInstrument, useGameStore } from '../../state/useGameStore';
import { EngineeringPanel, useEngineeringReport } from '../analysis/EngineeringPanel';
import { Meter } from '../components/Panel';
import { specRows } from './componentSpecs';
import { LabRocketPanel } from './LabRocketPanel';

function Stat({ label, value, sub, warn }: { label: string; value: string; sub?: string; warn?: boolean }) {
  return (
    <div className={`stat ${warn ? 'stat--warn' : ''}`}>
      <span className="stat__label">{label}</span>
      <span className="stat__value">{value}</span>
      {sub && <span className="stat__sub">{sub}</span>}
    </div>
  );
}

/** Problema en la pestaña Análisis (igual que antes: clic selecciona la pieza afectada). */
function IssueItem({ issue }: { issue: DesignIssue }) {
  const select = useGameStore((s) => s.labSelect);
  const clickable = issue.instanceIds.length > 0;
  return (
    <li className={`issue issue--${issue.severity}`}>
      <button className="issue__btn" disabled={!clickable} onClick={() => clickable && select(issue.instanceIds[0])} title={clickable ? 'Seleccionar pieza afectada' : undefined}>
        <span className={`badge ${issue.severity === 'critical' ? 'badge--hard' : 'badge--soft'}`}>{issue.severity === 'critical' ? 'Crítico' : 'Optimizar'}</span>
        <strong>{issue.title}</strong>
      </button>
      <p className="small muted">{issue.explanation}</p>
    </li>
  );
}

function Selection() {
  const lab = useGameStore((s) => s.lab);
  const armMove = useGameStore((s) => s.labArmMove);
  const remove = useGameStore((s) => s.labRemove);
  const setChassis = useGameStore((s) => s.labSetChassis);
  const select = useGameStore((s) => s.labSelect);
  const { selectedId, draft } = lab;
  if (!selectedId) return null;

  const isChassis = selectedId === 'chassis';
  const part = draft.parts.find((p) => p.instanceId === selectedId);
  const comp = isChassis ? (draft.chassisId ? getComponent(draft.chassisId) : undefined) : part ? getComponent(part.componentId) : undefined;
  if (!comp) return null;

  return (
    <div className="selection selection-card">
      <div className="selection-card__head">
        <div>
          <p className="eyebrow">Seleccionado · {CATEGORY_LABELS[comp.category]}</p>
          <h3 className="h3" style={{ margin: '2px 0 4px' }}>
            {comp.name}
          </h3>
        </div>
        <button className="icon-btn" aria-label="Cerrar selección" onClick={() => select(null)}>
          ×
        </button>
      </div>
      {part && <p className="small mono" style={{ margin: '0 0 8px', color: 'var(--text-lo)' }}>Anclaje: {socketLabel(part.socketId)}</p>}
      <dl className="kv">
        {specRows(comp).map(([k, v]) => (
          <div key={k} style={{ display: 'contents' }}>
            <dt>{k}</dt>
            <dd>{v}</dd>
          </div>
        ))}
      </dl>
      {comp.requires.length > 0 && (
        <p className="small" style={{ marginBottom: 0 }}>
          <span className="badge badge--info">Requiere</span> {comp.requires.map((id) => getComponent(id)?.name).join(', ')}
        </p>
      )}
      {comp.incompatibleWith.length > 0 && (
        <p className="small" style={{ marginBottom: 0 }}>
          <span className="badge badge--hard">Incompatible</span> {comp.incompatibleWith.map((id) => getComponent(id)?.name).join(', ')}
        </p>
      )}
      <p className="small">
        <strong>Nota de ingeniería:</strong> {comp.engineeringNote}
      </p>
      <div className="row-actions">
        {part ? (
          <>
            <button className="btn" onClick={() => armMove(part.instanceId)}>
              Mover
            </button>
            <button className="btn btn--danger" onClick={() => remove(part.instanceId)}>
              Eliminar
            </button>
          </>
        ) : (
          <button className="btn btn--danger" onClick={() => setChassis(null)}>
            Retirar chasis y piezas
          </button>
        )}
      </div>
      {isChassis && <p className="small muted">Para cambiar de chasis, elige otro en Estructura: las piezas se conservan o reubican si caben.</p>}
    </div>
  );
}

const PARAM_PATH: Record<LabParameter['id'], string> = {
  mass: 'M4 18h16l-3-9H7zM9 9a3 3 0 0 1 6 0',
  budget: 'M12 3v18M16 7.5c0-1.7-1.8-2.5-4-2.5s-4 .9-4 2.8c0 4.2 8 2.4 8 6.7 0 1.9-1.8 2.9-4 2.9s-4-.9-4-2.6',
  energy: 'M13 2 5 14h6l-1 8 8-12h-6z',
  comms: 'M5 19 12 9l7 10M12 9V5M7 6a7 7 0 0 1 10 0M9 8a4 4 0 0 1 6 0',
  propulsion: 'M12 2c3 3 4 7 4 11l-2 4h-4l-2-4c0-4 1-8 4-11zM10 17l-1 4M14 17l1 4',
  instrument: 'M3 8h4l2-3h6l2 3h4v11H3zM12 17a4 4 0 1 0 0-8 4 4 0 0 0 0 8z',
};
const STATE_MARK: Record<ParamState, string> = { ok: '✓', missing: '…', fail: '✗' };

function ParamChip({ p }: { p: LabParameter }) {
  const focus = useGameStore((s) => s.labFocusCatalog);
  const cat = CATEGORY_LABELS[p.fix.category];
  return (
    <button
      className={`param param--${p.state}`}
      onClick={() => focus(p.fix.category, p.state === 'ok' ? [] : p.fix.componentIds)}
      title={`${p.why} ${p.state !== 'ok' ? p.fix.action : ''}`.trim()}
      aria-label={`${p.label}: ${p.value}. ${PARAM_STATE_LABEL[p.state]}. ${p.why} Abrir piezas de ${cat}`}
      data-param={p.id}
    >
      <svg className="param__icon" viewBox="0 0 24 24" aria-hidden="true">
        <path d={PARAM_PATH[p.id]} fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" strokeLinecap="round" />
      </svg>
      <span className="param__label">{p.label}</span>
      <span className="param__value mono">{p.value}</span>
      <span className="param__state">
        {STATE_MARK[p.state]} {PARAM_STATE_LABEL[p.state]}
      </span>
    </button>
  );
}

/** Un problema: qué pasa, por qué, qué hacer y dónde (botón que abre la categoría del catálogo). */
function ProblemItem({ issue, fix }: { issue: DesignIssue; fix: FixTarget | null }) {
  const focus = useGameStore((s) => s.labFocusCatalog);
  const select = useGameStore((s) => s.labSelect);
  return (
    <li className={`issue issue--${issue.severity} problem`}>
      <strong className="small">{issue.title}</strong>
      <p className="small muted problem__why">
        <span className="problem__tag">Por qué:</span> {issue.explanation}
      </p>
      {fix && (
        <p className="small problem__how">
          <span className="problem__tag">Cómo:</span> {fix.action}
        </p>
      )}
      <span className="row-actions">
        {fix && (
          <button className="btn btn--sm btn--primary" onClick={() => focus(fix.category, fix.componentIds)}>
            Solucionar problema → {CATEGORY_LABELS[fix.category]}
          </button>
        )}
        {issue.instanceIds.length > 0 && (
          <button className="btn btn--sm btn--ghost" onClick={() => select(issue.instanceIds[0])}>
            Ver pieza afectada
          </button>
        )}
      </span>
    </li>
  );
}

/** Barra horizontal: valor frente a un máximo, con marca de límite opcional. */
function Bar({ value, max, tone, label }: { value: number; max: number; tone: 'ok' | 'warn' | 'bad' | 'info'; label: string }) {
  const pct = max > 0 ? Math.max(0, Math.min(1, value / max)) * 100 : 0;
  return (
    <div className="rbar" role="meter" aria-label={label} aria-valuemin={0} aria-valuemax={Math.round(max)} aria-valuenow={Math.round(value)}>
      <div className={`rbar__fill rbar__fill--${tone}`} style={{ width: `${pct}%` }} />
    </div>
  );
}

function stateTone(s: ParamState): 'ok' | 'warn' | 'bad' {
  return s === 'ok' ? 'ok' : s === 'missing' ? 'warn' : 'bad';
}

export function LabInspector() {
  const lab = useGameStore((s) => s.lab);
  const missions = useGameStore((s) => s.missions);
  const save = useGameStore((s) => s.labSave);
  const goAnalysis = useGameStore((s) => s.labGoAnalyze);
  const focus = useGameStore((s) => s.labFocusCatalog);
  const objective = useGameStore(selectLabObjectiveInstrument);
  const [localTab, setLocalTab] = useState<'build' | 'analysis'>('build');
  const setView = useGameStore((s) => s.labSetView);
  // La pestaña «Cohete» va unida a la vista del cohete en el centro.
  const tab: 'build' | 'analysis' | 'rocket' = lab.view === 'rocket' ? 'rocket' : localTab;
  const setTab = (t: 'build' | 'analysis' | 'rocket') => {
    if (t === 'rocket') return setView('rocket');
    setLocalTab(t);
    if (lab.view === 'rocket') setView('craft');
  };
  const revert = useGameStore((s) => s.labRevert);
  const toggleXray = useGameStore((s) => s.labToggleXray);
  const select = useGameStore((s) => s.labSelect);

  const mission = missions.find((m) => m.id === lab.missionId);
  const template = mission ? templateForMission(mission) : undefined;
  const totals = useMemo(() => designTotals(lab.draft, getComponent), [lab.draft]);
  const report = useEngineeringReport(lab.draft, mission);
  const issues = report.issues;
  const budget = report.budget;
  const critical = issues.filter((i) => i.severity === 'critical');
  const optim = issues.filter((i) => i.severity === 'optimization');
  const powerMargin = totals.powerGenW > 0 ? (totals.powerGenW - totals.powerDrawW) / totals.powerGenW : null;

  const ctx = { design: lab.draft, lookup: getComponent, catalog: COMPONENT_CATALOG, objectiveInstrumentId: objective, difficulty: mission?.difficulty };
  const params = useMemo(() => labParameters(report, ctx), [report, objective, mission?.difficulty]); // eslint-disable-line react-hooks/exhaustive-deps
  const checks = template ? constraintChecks(template, report, params) : [];
  const fix = (i: DesignIssue) => fixFor(i, { ...ctx, schedule: report.schedule });
  const paramState = Object.fromEntries(params.map((p) => [p.id, p.state])) as Record<LabParameter['id'], ParamState>;

  const inDesign = mission?.stage === 'DESIGN';
  const ready = !!mission && report.viable;
  // Fase 4: guarda y abre la pantalla de análisis y aprobación.
  const goAnalyze = () => mission && goAnalysis();
  const firstProblem = critical[0];
  const firstFix = firstProblem ? fix(firstProblem) : null;

  // Estado de cada pieza instalada según los problemas del análisis.
  const partState = (id: string) =>
    critical.some((i) => i.instanceIds.includes(id)) ? 'bad' : optim.some((i) => i.instanceIds.includes(id)) ? 'warn' : 'ok';
  const rows = lab.draft.chassisId
    ? [
        { id: 'chassis', name: getComponent(lab.draft.chassisId)?.name ?? '', where: 'Estructura' },
        ...lab.draft.parts.map((p) => ({ id: p.instanceId, name: getComponent(p.componentId)?.name ?? p.componentId, where: socketLabel(p.socketId) })),
      ]
    : [];

  const p = report.power;
  const m = report.mass;
  const maxCapacity = Math.max(...LUNAR_LAUNCHERS.map((l) => l.payloadToTLIKg));

  return (
    <section className="panel lab-inspector" aria-label="Estado del diseño">
      <header className="panel__head">
        <div>
          <p className="eyebrow">{mission ? mission.name : 'Modo libre · sin misión'}</p>
          <h2 className="h3">
            Diseño{' '}
            {lab.dirty ? <span className="badge badge--soft">Sin guardar</span> : mission ? <span className="badge badge--ok">Guardado</span> : null}
          </h2>
        </div>
      </header>
      <div className="lab-inspector__actions">
        <button className="btn btn--primary" disabled={!mission || !lab.dirty} onClick={save} title={mission ? undefined : 'Crea una misión para poder guardar'}>
          Guardar diseño
        </button>
        <button className="btn btn--ghost" disabled={!lab.dirty} onClick={revert}>
          Descartar
        </button>
        <button className="btn btn--ghost" aria-pressed={lab.xray} onClick={toggleXray} title="Ver las bahías internas">
          Vista interna
        </button>
      </div>

      <div className="tabs" role="tablist">
        <button role="tab" className="tab" aria-selected={tab === 'build'} onClick={() => setTab('build')}>
          Construcción
        </button>
        <button role="tab" className="tab" aria-selected={tab === 'analysis'} onClick={() => setTab('analysis')}>
          Análisis {critical.length > 0 ? <span className="badge badge--hard">{critical.length}</span> : <span className="badge badge--ok">✓</span>}
        </button>
        <button role="tab" className="tab" aria-selected={tab === 'rocket'} onClick={() => setTab('rocket')}>
          Cohete
        </button>
      </div>

      {tab === 'rocket' ? (
        <div className="panel__body lab-inspector__body">
          <LabRocketPanel />
        </div>
      ) : tab === 'analysis' ? (
        <div className="panel__body lab-inspector__body">
          <div className={`verdict ${report.viable ? 'verdict--ok' : 'verdict--bad'}`}>
            <strong>{report.viable ? 'Diseño viable' : 'Diseño no viable'}</strong>
            <span className="small">
              {report.viable
                ? `Sin problemas críticos${optim.length ? ` · ${optim.length} ${optim.length === 1 ? 'optimización posible' : 'optimizaciones posibles'}` : ''}.`
                : `${critical.length} problema(s) crítico(s): corrígelos para poder analizar y aprobar el diseño.`}
            </span>
            {mission && (
              <span className="small muted">
                Etapa actual: {STAGE_INFO[mission.stage].label}
              </span>
            )}
            {mission && (
              <button className="btn btn--primary" disabled={!report.viable} onClick={goAnalyze} title={report.viable ? undefined : 'Resuelve los problemas críticos para continuar'}>
                {mission.stage === 'DESIGN' ? 'Siguiente: Analizar diseño →' : 'Ver análisis del diseño →'}
              </button>
            )}
          </div>
          {issues.length > 0 && (
            <ul className="issues" style={{ marginBottom: 16 }}>
              {[...critical, ...optim].map((i) => (
                <IssueItem key={i.id} issue={i} />
              ))}
            </ul>
          )}
          <EngineeringPanel report={report} />
        </div>
      ) : (
        <div className="panel__body lab-inspector__body">
          {/* ── Estado general del diseño ── */}
          <div className={`design-status ${ready ? 'design-status--ok' : lab.draft.chassisId ? 'design-status--bad' : 'design-status--start'}`} role="status" aria-live="polite">
            {!mission ? (
              <>
                <strong>Modo libre</strong>
                <span className="small">Puedes experimentar con las piezas. Para analizar el diseño y avanzar necesitas una misión.</span>
              </>
            ) : !lab.draft.chassisId ? (
              <>
                <strong>Empieza por el chasis</strong>
                <span className="small">Es la estructura donde se anclan todas las piezas: sin él no hay nave que evaluar.</span>
                <button className="btn btn--sm btn--primary" onClick={() => focus('STRUCTURE', fix({ id: 'no-chassis' } as DesignIssue)?.componentIds ?? [])}>
                  Solucionar problema → {CATEGORY_LABELS.STRUCTURE}
                </button>
              </>
            ) : ready ? (
              <>
                <strong>¡Diseño listo!</strong>
                <span className="small">Has cumplido los requisitos de construcción de esta misión.</span>
              </>
            ) : (
              <>
                <strong>
                  Aún no puedes avanzar: {critical.length} {critical.length === 1 ? 'requisito pendiente' : 'requisitos pendientes'}
                </strong>
                {firstProblem && (
                  <span className="small">
                    Siguiente paso: {firstProblem.title.toLowerCase()}. {firstFix?.action}
                  </span>
                )}
              </>
            )}
            {mission && (
              <button
                className={`btn btn--primary ${ready && inDesign ? 'btn--glow' : ''}`}
                disabled={!ready}
                onClick={goAnalyze}
                title={ready ? undefined : 'Resuelve los requisitos pendientes para poder analizar el diseño'}
              >
                {inDesign ? 'Siguiente: Analizar diseño →' : 'Ver análisis del diseño →'}
              </button>
            )}
          </div>

          {/* ── Parámetros críticos ── */}
          <h3 className="section-title">Parámetros críticos</h3>
          <div className="params" role="group" aria-label="Parámetros críticos">
            {params.map((x) => (
              <ParamChip key={x.id} p={x} />
            ))}
          </div>
          <p className="small muted params__legend">
            <span className="plegend plegend--ok">✓ Correcto</span> <span className="plegend plegend--missing">… Falta para estar correcto</span>{' '}
            <span className="plegend plegend--fail">✗ Incumple una restricción</span> · Pulsa uno para ver las piezas que lo resuelven.
          </p>

          {/* ── Recursos ── */}
          <h3 className="section-title">Recursos</h3>
          <div className="resources-mini">
            <div className="rmini">
              <span className="rmini__label">Presupuesto disponible</span>
              <span className="rmini__value mono">{budget ? formatMUSD(budget.remainingMUSD) : lab.draft.chassisId ? 'sin tope' : '—'}</span>
              {budget && <Bar value={budget.committedMUSD} max={budget.capMUSD} tone={stateTone(paramState.budget)} label="Presupuesto comprometido" />}
              {budget && (
                <span className="rmini__sub small muted">
                  Comprometido {formatMUSD(budget.committedMUSD)} de {formatMUSD(budget.capMUSD)} · nave {formatMUSD(totals.costMUSD)} + operación
                </span>
              )}
            </div>
            <div className="rmini">
              <span className="rmini__label">Masa total (con propelente y margen)</span>
              <span className="rmini__value mono">{m ? `${fmtNum(m.wetWithMarginKg)} kg` : '—'}</span>
              {m && <Bar value={m.wetWithMarginKg} max={maxCapacity} tone={stateTone(paramState.mass)} label="Masa frente al lanzador más capaz" />}
              {m && (
                <span className="rmini__chips">
                  {LUNAR_LAUNCHERS.map((l) => (
                    <span key={l.id} className={`mini-chip ${l.payloadToTLIKg >= m.wetWithMarginKg ? 'mini-chip--ok' : 'mini-chip--bad'}`} title={`${l.name}: lleva hasta ${l.payloadToTLIKg} kg a la Luna`}>
                      {l.name} {fmtNum(l.payloadToTLIKg)} kg {l.payloadToTLIKg >= m.wetWithMarginKg ? '✓' : '✗'}
                    </span>
                  ))}
                </span>
              )}
            </div>
            <div className="rmini">
              <span className="rmini__label">Energía: generación y consumo</span>
              <span className="rmini__value mono">
                {totals.powerGenW} W / {p ? fmtNum(p.sunlitLoadW, 0) : totals.powerDrawW} W
              </span>
              <span className="rmini__row small">
                <span className="rmini__k">Genera</span>
                <Bar value={totals.powerGenW} max={Math.max(totals.powerGenW, p?.sunlitLoadW ?? totals.powerDrawW, 1)} tone="info" label="Potencia generada" />
              </span>
              <span className="rmini__row small">
                <span className="rmini__k">Consume</span>
                <Bar value={p?.sunlitLoadW ?? totals.powerDrawW} max={Math.max(totals.powerGenW, p?.sunlitLoadW ?? totals.powerDrawW, 1)} tone={stateTone(paramState.energy)} label="Potencia consumida" />
              </span>
              {p && p.batteryWh > 0 && (
                <span className="rmini__sub small muted">
                  Batería {p.batteryWh} Wh · se descarga {Math.round(p.depthOfDischarge * 100)} % en cada eclipse (máx. {Math.round(MAX_DOD * 100)} %) · balance {p.orbitBalanceWh >= 0 ? '+' : ''}
                  {fmtNum(p.orbitBalanceWh)} Wh/órbita
                </span>
              )}
            </div>
          </div>

          {/* ── Restricciones de la misión ── */}
          {checks.length > 0 && (
            <>
              <h3 className="section-title">Cumplimiento de la misión</h3>
              <ul className="checks">
                {checks.map((c) => (
                  <li key={c.id} className={`check-row check-row--${c.state}`} title={c.detail}>
                    <span className="check-row__mark" role="img" aria-label={PARAM_STATE_LABEL[c.state]}>
                      {STATE_MARK[c.state]}
                    </span>
                    <span className="check-row__label">{c.label}</span>
                    <span className={`badge ${c.severity === 'hard' ? 'badge--hard' : 'badge--soft'}`}>{c.severity === 'hard' ? 'Obligatoria' : 'Recomendada'}</span>
                  </li>
                ))}
              </ul>
            </>
          )}

          {/* ── Problemas ── */}
          {critical.length > 0 && (
            <>
              <h3 className="section-title">
                Por resolver <span className="badge badge--hard">{critical.length}</span>
              </h3>
              <ul className="issues">
                {critical.map((i) => (
                  <ProblemItem key={i.id} issue={i} fix={fix(i)} />
                ))}
              </ul>
            </>
          )}

          {/* ── Selección y piezas instaladas ── */}
          <Selection />
          {rows.length > 0 && (
            <details className="lab-details parts-list" open>
              <summary className="section-title">Componentes instalados ({rows.length})</summary>
              <ul>
                {rows.map((row) => {
                  const st = partState(row.id);
                  return (
                    <li key={row.id}>
                      <button className="part-row" aria-pressed={lab.selectedId === row.id} onClick={() => select(row.id)}>
                        <span className={`pdot pdot--${st}`} aria-label={st === 'ok' ? 'Sin problemas' : st === 'bad' ? 'Con un problema crítico' : 'Se puede mejorar'} />
                        <span>{row.name}</span>
                        <span className="mono muted">{row.where}</span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            </details>
          )}

          {optim.length > 0 && (
            <details className="lab-details">
              <summary className="section-title">Mejoras opcionales ({optim.length})</summary>
              <ul className="issues">
                {optim.map((i) => (
                  <ProblemItem key={i.id} issue={i} fix={fix(i)} />
                ))}
              </ul>
            </details>
          )}

          <details className="lab-details">
            <summary className="section-title">Detalles técnicos</summary>
            <div className="stats-grid">
              <Stat label="Masa húmeda" value={`${round(totals.massWetKg)} kg`} sub={`seca ${round(totals.massDryKg)} + propelente ${round(totals.propellantKg)}`} />
              <Stat
                label="Costo de la nave"
                value={formatMUSD(totals.costMUSD)}
                sub={budget ? `quedan ${formatMUSD(budget.remainingMUSD)} de ${formatMUSD(budget.capMUSD)}` : 'sin tope (modo libre)'}
                warn={budget?.overBudget}
              />
              <Stat label="Potencia generada" value={`${totals.powerGenW} W`} sub="con iluminación directa" />
              <Stat
                label="Potencia consumida"
                value={`${totals.powerDrawW} W`}
                sub={powerMargin === null ? 'sin generación' : `margen ${Math.round(powerMargin * 100)} %`}
                warn={powerMargin !== null && powerMargin < 0}
              />
              <Stat label="Batería" value={`${totals.energyStorageWh} Wh`} />
              <Stat label="Datos generados" value={`${totals.dataGenGbitPerH} Gbit/h`} sub={`memoria ${totals.dataStorageGbit} Gbit`} />
              <Stat label="Enlace" value={`${totals.downlinkMbps} Mbps`} sub={`${round(totals.downlinkGbitPerH)} Gbit/h en contacto`} />
              <Stat label="Anclajes" value={`${totals.socketsUsed}/${totals.socketsTotal}`} />
            </div>
            {budget && <Meter value={budget.usedFraction} warn={budget.overBudget} label="Presupuesto comprometido por la nave" />}
            <p className="small muted">
              Valores nominales. El balance por órbita (eclipse, autonomía, contacto con Tierra) está en la pestaña <strong>Análisis</strong>.
            </p>
          </details>
        </div>
      )}
    </section>
  );
}
