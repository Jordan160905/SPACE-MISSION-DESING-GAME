/**
 * Catálogo del Lab. Cada tarjeta admite:
 *  - clic: arma la pieza (luego se elige un anclaje en 3D o en la lista accesible);
 *  - arrastrar con ratón: suelta la pieza sobre un anclaje verde de la escena 3D.
 * Los chasis se instalan con un clic o soltándolos en cualquier punto de la escena.
 */
import { useEffect, useMemo, useRef, type PointerEvent as ReactPointerEvent } from 'react';
import { CATEGORY_LABELS, COMPONENT_CATALOG, getComponent } from '../../data/components/catalog';
import { catalogAdvice } from '../../sim/CatalogAdvisor';
import { isComponentAllowed } from '../../data/difficulty';
import type { ComponentCategory, ComponentDef } from '../../data/schemas';
import { selectLabObjectiveInstrument, useGameStore } from '../../state/useGameStore';
import { specSummary } from './componentSpecs';

const CATEGORIES = Object.keys(CATEGORY_LABELS) as ComponentCategory[];
const DRAG_THRESHOLD_PX = 6;

function CatalogCard({ c, objective, hinted }: { c: ComponentDef; objective: boolean; hinted: boolean }) {
  const lab = useGameStore((s) => s.lab);
  const arm = useGameStore((s) => s.labArm);
  const startDrag = useGameStore((s) => s.labStartDrag);
  const start = useRef<{ x: number; y: number; dragged: boolean } | null>(null);

  const installed = c.category === 'STRUCTURE' && lab.draft.chassisId === c.id;
  const armed = lab.armed?.componentId === c.id && !lab.armed.moveInstanceId;
  const count = lab.draft.parts.filter((p) => p.componentId === c.id).length;
  const difficulty = useGameStore((s) => s.missions.find((m) => m.id === s.lab.missionId)?.difficulty);
  const advice = useMemo(
    () => (count > 0 && isComponentAllowed(c, difficulty) ? { kind: 'ok' as const, label: '', reason: '' } : catalogAdvice(c, lab.draft, getComponent, difficulty)),
    [c, lab.draft, count, difficulty],
  );

  const onPointerDown = (e: ReactPointerEvent) => {
    if (e.pointerType !== 'mouse' || e.button !== 0) return; // en táctil: tocar para armar
    start.current = { x: e.clientX, y: e.clientY, dragged: false };
    const move = (ev: PointerEvent) => {
      if (!start.current || start.current.dragged) return;
      if (Math.hypot(ev.clientX - start.current.x, ev.clientY - start.current.y) > DRAG_THRESHOLD_PX) {
        start.current.dragged = true;
        startDrag(c.id);
      }
    };
    const up = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };

  return (
    <button
      className={`lab-card ${hinted ? 'lab-card--hint' : ''}`}
      data-component={c.id}
      aria-pressed={armed || installed}
      onPointerDown={onPointerDown}
      onClick={() => {
        if (start.current?.dragged) {
          start.current = null;
          return;
        }
        start.current = null;
        arm(c.id);
      }}
    >
      <span className="lab-card__top">
        <strong>{c.name}</strong>
        {count > 0 && <span className="badge badge--info">×{count}</span>}
        {installed && <span className="badge badge--ok">Instalado</span>}
      </span>
      {objective && <span className="badge badge--ok">Tu objetivo</span>}
      {hinted && <span className="badge badge--info lab-card__fix">Soluciona el problema</span>}
      {advice.kind !== 'ok' && (
        <span className={`badge ${advice.kind === 'blocked' ? 'badge--hard' : 'badge--soft'} lab-card__advice`} title={advice.reason}>
          {advice.label}
        </span>
      )}
      <span className="lab-card__specs">{specSummary(c)}</span>
      {advice.kind !== 'ok' && <span className="sr-only">{advice.reason}</span>}
    </button>
  );
}

export function LabCatalog() {
  const cat = useGameStore((s) => s.lab.catalogCategory);
  const highlight = useGameStore((s) => s.lab.highlight);
  const focus = useGameStore((s) => s.labFocusCatalog);
  const setCat = (c: ComponentCategory) => focus(c, []);
  const listRef = useRef<HTMLDivElement>(null);
  // Al enfocar desde un problema, lleva a la vista la primera pieza recomendada.
  useEffect(() => {
    if (!highlight.length) return;
    // Desplaza solo la lista del catálogo (nunca la página) hasta la primera pieza marcada.
    const list = listRef.current;
    const card = list?.querySelector<HTMLElement>('.lab-card--hint');
    if (!list || !card) return;
    const top = card.offsetTop - list.offsetTop;
    if (top < list.scrollTop || top + card.offsetHeight > list.scrollTop + list.clientHeight) list.scrollTo({ top: Math.max(0, top - 8), behavior: 'smooth' });
  }, [highlight, cat]);
  const objective = useGameStore(selectLabObjectiveInstrument);
  const hasChassis = useGameStore((s) => s.lab.draft.chassisId !== null);
  const items = COMPONENT_CATALOG.filter((c) => c.category === cat);

  return (
    <section className="panel lab-catalog" aria-label="Catálogo de componentes">
      <header className="panel__head">
        <div>
          <p className="eyebrow">Catálogo</p>
          <h2 className="h3">Componentes</h2>
        </div>
      </header>
      <div className="lab-cats" role="tablist" aria-label="Categorías">
        {CATEGORIES.map((c) => (
          <button key={c} role="tab" aria-selected={cat === c} className="lab-cat" onClick={() => setCat(c)}>
            {CATEGORY_LABELS[c]}
          </button>
        ))}
      </div>
      <div className="panel__body lab-catalog__list" ref={listRef}>
        {highlight.length > 0 && (
          <p className="lab-fixnote small" role="status">
            <span>Las piezas marcadas solucionan el problema. Arrástrala a la nave o haz clic en ella.</span>
            <button className="link-btn" onClick={() => setCat(cat)}>
              Quitar marca
            </button>
          </p>
        )}
        {!hasChassis && cat !== 'STRUCTURE' && (
          <p className="small" style={{ color: 'var(--signal)', marginTop: 0 }}>
            Primero instala un chasis (categoría Estructura).
          </p>
        )}
        {items.map((c) => (
          <CatalogCard key={c.id} c={c} objective={c.id === objective} hinted={highlight.includes(c.id)} />
        ))}
        <p className="hint">Arrastra una pieza hasta un anclaje verde de la nave · o haz clic en la pieza y luego en el anclaje.</p>
      </div>
    </section>
  );
}
