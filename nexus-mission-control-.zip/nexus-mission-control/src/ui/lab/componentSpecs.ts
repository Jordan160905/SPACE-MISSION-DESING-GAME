import type { ComponentDef } from '../../data/schemas';
import { mbpsToGbitPerHour } from '../../sim/units';

/** Propiedades distintas de cero de un componente, con unidades, para mostrar en la UI. */
export function specRows(c: ComponentDef): Array<[string, string]> {
  const rows: Array<[string, string]> = [
    ['Masa', `${c.massKg} kg`],
    ['Precio', `${c.costMUSD} MUSD`],
  ];
  if (c.powerDrawW) rows.push(['Consumo', `${c.powerDrawW} W`]);
  if (c.powerGenW) rows.push(['Generación (iluminado)', `${c.powerGenW} W`]);
  if (c.energyStorageWh) rows.push(['Almacenamiento de energía', `${c.energyStorageWh} Wh`]);
  if (c.dataGenGbitPerH) rows.push(['Datos generados', `${c.dataGenGbitPerH} Gbit/h`]);
  if (c.scienceValue) rows.push(['Valor científico', `${'★'.repeat(c.scienceValue)}${'☆'.repeat(5 - c.scienceValue)} (${c.scienceValue}/5)`]);
  rows.push(['Madurez', `${c.heritage === 'flight-proven' ? 'con herencia de vuelo' : c.heritage === 'modified' ? 'modificado' : 'desarrollo nuevo'} · gama ${c.tier === 'advanced' ? 'avanzada' : 'simple'}`]);
  if (c.dataStorageGbit) rows.push(['Memoria de datos', `${c.dataStorageGbit} Gbit`]);
  if (c.downlinkMbps) rows.push(['Enlace descendente', `${c.downlinkMbps} Mbps (${mbpsToGbitPerHour(c.downlinkMbps)} Gbit/h)`]);
  if (c.propellantKg) rows.push(['Propelente', `${c.propellantKg} kg`]);
  if (c.sockets.length) rows.push(['Puntos de anclaje', `${c.sockets.length}`]);
  if (c.mountsOn.length) rows.push(['Se monta en', c.mountsOn.join(', ')]);
  return rows;
}

/** Resumen corto para tarjetas del catálogo. */
export function specSummary(c: ComponentDef): string {
  const bits = [`${c.massKg} kg`, `${c.costMUSD} MUSD`];
  if (c.powerGenW) bits.push(`+${c.powerGenW} W`);
  if (c.powerDrawW) bits.push(`−${c.powerDrawW} W`);
  if (c.energyStorageWh) bits.push(`${c.energyStorageWh} Wh`);
  if (c.downlinkMbps) bits.push(`${c.downlinkMbps} Mbps`);
  if (c.dataGenGbitPerH) bits.push(`${c.dataGenGbitPerH} Gbit/h`);
  if (c.sockets.length) bits.push(`${c.sockets.length} anclajes`);
  if (c.scienceValue) bits.push(`ciencia ${c.scienceValue}/5`);
  return bits.join(' · ');
}
