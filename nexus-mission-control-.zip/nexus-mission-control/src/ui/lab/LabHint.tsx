/**
 * Tutorial visual del LAB: una mano toma un componente del catálogo, lo lleva al área de
 * construcción y lo suelta.
 *
 *  - Aparece al entrar al LAB mientras el jugador no haya colocado nunca una pieza
 *    (`profile.labHintSeen`, que se marca con la primera pieza colocada).
 *  - Repite la demostración hasta HINT_CYCLES veces y luego desaparece.
 *  - Desaparece en cuanto el jugador toca algo (pulsa, arrastra o usa el teclado).
 *  - En pantallas táctiles enseña el gesto real: tocar la pieza y después el anclaje.
 *  - Se puede volver a ver con «¿Cómo se construye?».
 */
import { useEffect, useLayoutEffect, useRef, useState, type CSSProperties } from 'react';
import { useGameStore } from '../../state/useGameStore';

export const HINT_CYCLE_MS = 3200;
export const HINT_CYCLES = 3;

export function LabHint({ replay }: { replay: number }) {
  const seen = useGameStore((s) => s.profile.labHintSeen);
  const markSeen = useGameStore((s) => s.markLabHintSeen);
  const pieces = useGameStore((s) => (s.lab.draft.chassisId ? 1 : 0) + s.lab.draft.parts.length);
  const busy = useGameStore((s) => s.lab.dragging || s.lab.armed !== null);
  const [active, setActive] = useState(!seen);
  const [pts, setPts] = useState<{ fx: number; fy: number; tx: number; ty: number } | null>(null);
  const startPieces = useRef(pieces);
  const touch = typeof window !== 'undefined' && !!window.matchMedia?.('(pointer: coarse)').matches;

  useEffect(() => {
    if (replay > 0) setActive(true);
  }, [replay]);

  // La primera pieza colocada demuestra que ya sabe construir: no volver a mostrarla sola.
  useEffect(() => {
    if (pieces > (startPieces.current ?? pieces)) markSeen();
    startPieces.current = pieces;
  }, [pieces, markSeen]);

  // Empezar a arrastrar o elegir una pieza la oculta al instante.
  useEffect(() => {
    if (busy) setActive(false);
  }, [busy]);

  // Cualquier toque, clic o tecla del jugador la oculta.
  useEffect(() => {
    if (!active) return;
    const stop = () => setActive(false);
    // Se registra en el siguiente ciclo para no capturar el clic que abrió el LAB.
    const t = window.setTimeout(() => {
      window.addEventListener('pointerdown', stop, true);
      window.addEventListener('keydown', stop, true);
      window.addEventListener('wheel', stop, { capture: true, passive: true });
    }, 0);
    const end = window.setTimeout(stop, HINT_CYCLE_MS * HINT_CYCLES + 200);
    return () => {
      window.clearTimeout(t);
      window.clearTimeout(end);
      window.removeEventListener('pointerdown', stop, true);
      window.removeEventListener('keydown', stop, true);
      window.removeEventListener('wheel', stop, true);
    };
  }, [active]);

  // Origen: la primera pieza del catálogo visible. Destino: el centro del área de construcción.
  useLayoutEffect(() => {
    if (!active) return;
    const measure = () => {
      const card = document.querySelector('.lab-catalog .lab-card');
      const center = document.querySelector('.lab-center');
      if (!card || !center) return setPts(null);
      const a = card.getBoundingClientRect();
      const b = center.getBoundingClientRect();
      setPts({ fx: a.left + a.width * 0.6, fy: a.top + a.height * 0.5, tx: b.left + b.width * 0.5, ty: b.top + b.height * 0.45 });
    };
    measure();
    window.addEventListener('resize', measure);
    return () => window.removeEventListener('resize', measure);
  }, [active]);

  if (!active || !pts) return null;
  const style = {
    '--fx': `${pts.fx}px`,
    '--fy': `${pts.fy}px`,
    '--tx': `${pts.tx}px`,
    '--ty': `${pts.ty}px`,
    '--hint-ms': `${HINT_CYCLE_MS}ms`,
    '--hint-n': HINT_CYCLES,
  } as CSSProperties;
  return (
    <div className="lab-hint" style={style} role="status" aria-live="polite" data-testid="lab-hint">
      <div className="lab-hint__msg">
        <strong>¡Construye tu nave!</strong>{' '}
        {touch
          ? 'Toca un componente del catálogo y después un anclaje verde de la nave para comenzar.'
          : 'Arrastra los componentes del catálogo hacia el área de construcción para comenzar.'}
      </div>
      <div className={`lab-hint__ghost ${touch ? 'lab-hint__ghost--tap' : ''}`} aria-hidden="true">
        <span className="lab-hint__chip">Componente</span>
      </div>
      <svg className={`lab-hint__hand ${touch ? 'lab-hint__hand--tap' : ''}`} viewBox="0 0 40 48" aria-hidden="true">
        <path
          d="M14 22V7a3 3 0 0 1 6 0v12V5a3 3 0 0 1 6 0v14V8a3 3 0 0 1 6 0v18c0 9-5 16-13 16-6 0-9-3-12-9l-4-8a3 3 0 0 1 5-3l4 5"
          fill="#f2f5fa"
          stroke="#0a1320"
          strokeWidth="2"
          strokeLinejoin="round"
        />
      </svg>
    </div>
  );
}
