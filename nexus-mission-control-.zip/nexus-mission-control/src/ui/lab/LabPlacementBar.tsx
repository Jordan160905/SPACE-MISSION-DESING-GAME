/**
 * Barra de colocación (pieza armada) + capa de arrastre.
 * La lista de anclajes compatibles es la alternativa accesible (teclado / táctil) al 3D.
 */
import { useEffect, useState } from 'react';
import { getComponent, socketLabel } from '../../data/components/catalog';
import { compatibleSockets } from '../../sim/DesignSystem';
import { useGameStore } from '../../state/useGameStore';

export function LabPlacementBar() {
  const lab = useGameStore((s) => s.lab);
  const arm = useGameStore((s) => s.labArm);
  const dropOn = useGameStore((s) => s.labDropOn);
  const { armed, draft, dragging } = lab;
  if (!armed || dragging) return null;
  const comp = getComponent(armed.componentId);
  if (!comp) return null;
  const sockets = compatibleSockets(draft, armed.componentId, getComponent, armed.moveInstanceId);

  return (
    <div className="panel placement-bar" role="region" aria-label="Colocación de pieza">
      <div className="placement-bar__head">
        <span>
          <span className="eyebrow">{armed.moveInstanceId ? 'Moviendo' : 'Colocando'}</span> <strong>{comp.name}</strong>
        </span>
        <button className="btn btn--ghost" onClick={() => arm(null)}>
          Cancelar (Esc)
        </button>
      </div>
      {sockets.length === 0 ? (
        <p className="small" style={{ color: 'var(--critical)', margin: 0 }}>
          No queda ningún anclaje libre de tipo {comp.mountsOn.join(' / ')} en este chasis. Libera uno o usa un chasis mayor.
        </p>
      ) : (
        <div className="placement-bar__sockets">
          <span className="small muted">Anclajes compatibles ({comp.mountsOn.join(' / ')}):</span>
          {sockets.map((s) => (
            <button key={s.id} className="chip" onClick={() => dropOn(s.id)}>
              {socketLabel(s.id)}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

/** Fantasma que sigue al cursor durante el arrastre y cancela al soltar fuera de un anclaje. */
export function LabDragLayer() {
  const dragging = useGameStore((s) => s.lab.dragging);
  const armed = useGameStore((s) => s.lab.armed);
  const endDrag = useGameStore((s) => s.labEndDrag);
  const [pos, setPos] = useState<{ x: number; y: number } | null>(null);

  useEffect(() => {
    if (!dragging) {
      setPos(null);
      return;
    }
    const move = (e: PointerEvent) => setPos({ x: e.clientX, y: e.clientY });
    // Burbujeo: el anclaje 3D (si lo hay) procesa el pointerup antes que window.
    const up = () => endDrag();
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
    document.body.classList.add('is-dragging');
    return () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
      document.body.classList.remove('is-dragging');
    };
  }, [dragging, endDrag]);

  if (!dragging || !armed || !pos) return null;
  return (
    <div className="drag-ghost" style={{ transform: `translate(${pos.x + 14}px, ${pos.y + 14}px)` }}>
      {getComponent(armed.componentId)?.name}
    </div>
  );
}

/** Atajos: Esc cancela la colocación o la selección; Supr elimina la pieza seleccionada. */
export function useLabShortcuts() {
  const arm = useGameStore((s) => s.labArm);
  const select = useGameStore((s) => s.labSelect);
  const remove = useGameStore((s) => s.labRemove);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (target && ['INPUT', 'TEXTAREA'].includes(target.tagName)) return;
      const { lab } = useGameStore.getState();
      if (e.key === 'Escape') {
        if (lab.armed) arm(null);
        else select(null);
      } else if ((e.key === 'Delete' || e.key === 'Backspace') && lab.selectedId && lab.selectedId !== 'chassis') {
        e.preventDefault();
        remove(lab.selectedId);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [arm, select, remove]);
}
