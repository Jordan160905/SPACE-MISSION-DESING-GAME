import { useEffect } from 'react';
import { useGameStore } from '../../state/useGameStore';
import { IconClose } from '../components/icons';

export function Toast() {
  const notice = useGameStore((s) => s.notice);
  const dismiss = useGameStore((s) => s.dismissNotice);

  useEffect(() => {
    if (!notice) return;
    const id = window.setTimeout(dismiss, notice.kind === 'error' ? 9000 : 6000);
    return () => window.clearTimeout(id);
  }, [notice, dismiss]);

  if (!notice) return null;
  return (
    <div className={`panel toast ${notice.kind === 'error' ? 'toast--error' : ''}`} role={notice.kind === 'error' ? 'alert' : 'status'}>
      <span>{notice.text}</span>
      <button className="btn btn--ghost" style={{ padding: 6 }} onClick={dismiss} aria-label="Cerrar aviso">
        <IconClose />
      </button>
    </div>
  );
}
