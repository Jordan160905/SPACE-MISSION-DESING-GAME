import { useGameStore } from '../../state/useGameStore';

const STEPS = [
  {
    title: 'Bienvenida, directora o director',
    body: 'En NEXUS diriges una agencia espacial. No vas a ver una presentación: vas a diseñar, lanzar y operar tu propia misión.',
  },
  {
    title: 'La sala es interactiva',
    body: 'Pulsa el holograma lunar para elegir misión. Las consolas abren el Spacecraft Lab, el Archivo, las Finanzas y la Biblioteca. También tienes la barra de navegación a la izquierda.',
  },
  {
    title: 'Todo está conectado',
    body: 'Diseño → Planificación → Lanzamiento → Operaciones → Informe. Lo que construyas determina cuánta energía tendrás, cuántos datos podrás transmitir y si la misión es viable.',
  },
  {
    title: 'Primera misión: LUNA-01',
    body: 'Un orbitador lunar de reconocimiento. Elige un objetivo científico y empieza a diseñar.',
  },
];

export function Tutorial() {
  const step = useGameStore((s) => s.tutorialStep);
  const setStep = useGameStore((s) => s.setTutorialStep);
  const complete = useGameStore((s) => s.completeTutorial);
  const openSelect = useGameStore((s) => s.openMissionSelect);
  const navigate = useGameStore((s) => s.navigate);
  if (step === null) return null;
  const s = STEPS[step];
  const last = step === STEPS.length - 1;

  return (
    <aside className="panel tutorial" aria-label="Tutorial" aria-live="polite">
      <div className="panel__body">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
          <p className="eyebrow">
            Guía {step + 1}/{STEPS.length}
          </p>
          <div className="tutorial__dots" aria-hidden="true">
            {STEPS.map((_, i) => (
              <i key={i} className={i <= step ? 'on' : ''} />
            ))}
          </div>
        </div>
        <h3 className="h3">{s.title}</h3>
        <p className="small muted">{s.body}</p>
        <div style={{ display: 'flex', gap: 8, justifyContent: 'space-between' }}>
          <button className="btn btn--ghost" onClick={complete}>
            Saltar
          </button>
          <span style={{ display: 'flex', gap: 8 }}>
            {step > 0 && (
              <button className="btn" onClick={() => setStep(step - 1)}>
                Atrás
              </button>
            )}
            <button
              className="btn btn--primary"
              onClick={() => {
                if (!last) return setStep(step + 1);
                complete();
                navigate('center');
                openSelect(true);
              }}
            >
              {last ? 'Elegir misión' : 'Siguiente'}
            </button>
          </span>
        </div>
      </div>
    </aside>
  );
}
