import { useEffect, useState } from 'react';
import { templateForMission } from '../../data/missions/missions';
import { STAGE_INFO } from '../../state/missionLogic';
import { selectActiveMission, useGameStore } from '../../state/useGameStore';
import { NexusMark } from '../components/icons';
import { LANGS, numLocale, setLang } from '../../i18n/lang';
import { useLang } from '../../i18n/useLang';

function useNow(intervalMs = 1000): Date {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), intervalMs);
    return () => window.clearInterval(id);
  }, [intervalMs]);
  return now;
}

/** Tiempo transcurrido desde la creación de la misión (tiempo real, no simulado). */
function formatElapsed(fromIso: string, now: Date): string {
  const s = Math.max(0, Math.floor((now.getTime() - new Date(fromIso).getTime()) / 1000));
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  const ss = s % 60;
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d}d ${p(h)}:${p(m)}:${p(ss)}`;
}

export function TopBar() {
  const now = useNow();
  const mission = useGameStore(selectActiveMission);
  const xp = useGameStore((s) => s.profile.xp);
  const navigate = useGameStore((s) => s.navigate);
  const template = mission ? templateForMission(mission) : undefined;
  const lang = useLang();

  return (
    <header className="topbar">
      <button className="brand" onClick={() => navigate('center')} aria-label="NEXUS: ir al Mission Center">
        <NexusMark />
        <span>
          <span className="brand__name">NEXUS</span>
          <span className="brand__sub">MISSION CONTROL</span>
        </span>
      </button>
      <div className="topbar__spacer" />
      <div className="readout">
        <span className="readout__label">Misión activa</span>
        <span className="readout__value readout__value--accent">
          {mission ? `${template?.code ?? '—'} · ${STAGE_INFO[mission.stage].label}` : 'Ninguna'}
        </span>
      </div>
      {mission && (
        <div className="readout readout--optional" title="Tiempo real transcurrido desde que se creó la misión">
          <span className="readout__label">T+ creación</span>
          <span className="readout__value">{formatElapsed(mission.createdAt, now)}</span>
        </div>
      )}
      <div className="readout readout--optional">
        <span className="readout__label">Experiencia agencia</span>
        <span className="readout__value">{xp.toLocaleString(numLocale())} XP</span>
      </div>
      <div className="readout readout--utc">
        <span className="readout__label">UTC</span>
        <span className="readout__value">{now.toISOString().slice(11, 19)}</span>
      </div>
      <div className="readout lang-switch" role="group" aria-label="Idioma">
        <span className="readout__label">Idioma</span>
        <span className="lang-switch__btns" data-no-translate>
          {LANGS.map((l) => (
            <button key={l.id} aria-pressed={lang === l.id} aria-label={l.name} title={l.name} onClick={() => setLang(l.id)}>
              {l.label}
            </button>
          ))}
        </span>
      </div>
    </header>
  );
}
