/**
 * Spacecraft Lab — constructor modular 3D.
 * Izquierda: catálogo · Centro: escena 3D (LabScene, en la capa de fondo) · Derecha: propiedades y estadísticas.
 */
import { useState } from 'react';
import { useGameStore } from '../../state/useGameStore';
import { LabCatalog } from '../lab/LabCatalog';
import { LabHint } from '../lab/LabHint';
import { LabInspector } from '../lab/LabInspector';
import { LabDragLayer, LabPlacementBar, useLabShortcuts } from '../lab/LabPlacementBar';
import { LabViewSwitch } from '../lab/LabRocketPanel';

export function LabScreen() {
  useLabShortcuts();
  const hasMission = useGameStore((s) => s.lab.missionId !== null);
  const navigate = useGameStore((s) => s.navigate);
  // En la vista del cohete solo importa el cohete: sin catálogo ni guía de arrastre.
  const rocketView = useGameStore((s) => s.lab.view === 'rocket');
  const [replay, setReplay] = useState(0);

  return (
    <div className={`lab-screen${rocketView ? ' lab-screen--rocket' : ''}`}>
      {!rocketView && <LabCatalog />}
      <div className="lab-center">
        <LabViewSwitch />
        {!hasMission && (
          <div className="notice-band lab-free-note" role="note">
            <span className="badge badge--soft">Modo libre</span>
            <span>
              Puedes experimentar, pero para guardar el diseño necesitas una misión.{' '}
              <button className="link-btn" onClick={() => navigate('center')}>
                Ir al Mission Center
              </button>
            </span>
          </div>
        )}
        {!rocketView && <LabPlacementBar />}
        <p className="lab-help">
          {rocketView ? (
            'Arrastra para rotar · rueda para acercar'
          ) : (
            <>
              Arrastra para rotar · rueda para acercar · clic en una pieza para seleccionarla ·{' '}
              <button className="link-btn" onClick={() => window.setTimeout(() => setReplay((n) => n + 1), 0)}>
                ¿Cómo se construye?
              </button>
            </>
          )}
        </p>
      </div>
      <LabInspector />
      {!rocketView && <LabDragLayer />}
      {!rocketView && <LabHint replay={replay} />}
    </div>
  );
}
