/**
 * Junta de revisión, en versión de juego para estudiantes: cuatro pasos guiados por la directora de
 * vuelo (nivel de madurez, poderes de la nave, peligros y despegue), con lenguaje sencillo y
 * divulgación progresiva. Las tablas técnicas de la NASA (recursos, STM, MEL, matriz 5 × 5, ciclo de
 * vida, votos) siguen disponibles en los desplegables «Para expertos».
 * Todo se calcula en sim/ConceptReview y en ui/review/reviewGame; esta pantalla solo lo presenta.
 */
import { useMemo, useState } from 'react';
import { CATEGORY_LABELS } from '../../data/components/catalog';
import {
  conceptMaturity,
  CML_AREA_LABEL,
  CML_DEFINITIONS,
  CML_PASS_FRACTION,
  CUBESAT_1U,
  equipmentList,
  HERITAGE_LABEL,
  LIFECYCLE,
  riskRegister,
  traceabilityMatrix,
  type CmlStatus,
  type Risk,
  type TraceStatus,
} from '../../sim/ConceptReview';
import { DRY_MASS_MARGIN } from '../../sim/MassSystem';
import { fmtNum, formatMUSD } from '../../sim/units';
import { stageStatus } from '../../state/missionLogic';
import { selectActiveMission, useGameStore } from '../../state/useGameStore';
import type { Mission } from '../../data/schemas';
import { Panel } from '../components/Panel';
import { reviewInputFor } from '../review/reviewInput';
import { CML_KID_NAME, flightGate, FUN_FACTS, npcLines, powerCards, stars, type PowerCard, type PowerState } from '../review/reviewGame';
import { LevelBadge, Meteor, NpcAvatar, PowerIcon, RocketHero } from '../review/ReviewArt';
import { ResourcePanel } from '../analysis/ResourcePanel';
import { missionResources } from '../../sim/ResourceSystem';
import { coordination, roleDef, roleGoals } from '../../sim/TeamSystem';
import { difficultyDef } from '../../data/difficulty';

type Step = 'level' | 'powers' | 'risks' | 'launch';
const STEPS: Array<{ id: Step; label: string; heading: string }> = [
  { id: 'level', label: 'Nivel', heading: '¿Qué tan lista está tu idea?' },
  { id: 'powers', label: 'Poderes de la nave', heading: 'Los poderes de tu nave' },
  { id: 'risks', label: 'Peligros', heading: '¿Qué podría salir mal?' },
  { id: 'launch', label: '¡Despegue!', heading: 'Decisión de la junta' },
];

const STATUS_TEXT: Record<CmlStatus, string> = { G: 'Completado', Y: 'En progreso', R: 'Sin empezar' };
const TRACE_TEXT: Record<TraceStatus, string> = { met: 'Cumple', 'at-risk': 'Justo', 'not-met': 'No cumple', pending: 'Pendiente' };
const RISK_TEXT = { low: 'Peligro bajo', medium: 'Peligro medio', high: 'Peligro alto' } as const;
const STATE_TEXT: Record<PowerState, string> = { ok: 'Listo', warn: 'Justo', fail: 'Falla', pending: 'Pendiente' };
const STATE_MARK: Record<PowerState, string> = { ok: '✓', warn: '!', fail: '✗', pending: '…' };

function RiskMatrix({ risks }: { risks: Risk[] }) {
  return (
    <div className="risk-matrix" role="img" aria-label="Matriz de riesgos: probabilidad en vertical, consecuencia en horizontal">
      <span className="risk-matrix__ylabel small muted">Probabilidad →</span>
      <div className="risk-matrix__grid">
        {[5, 4, 3, 2, 1].map((l) =>
          [1, 2, 3, 4, 5].map((c) => {
            const here = risks.filter((r) => r.likelihood === l && r.consequence === c);
            const s = l * c;
            return (
              <div key={`${l}-${c}`} className={`risk-cell risk-cell--${s >= 15 ? 'high' : s >= 6 ? 'medium' : 'low'}`} title={here.map((r) => r.title).join(', ')}>
                {here.length > 0 && <span className="risk-cell__n mono">{here.length}</span>}
              </div>
            );
          }),
        )}
      </div>
      <span className="risk-matrix__xlabel small muted">Consecuencia →</span>
    </div>
  );
}

function Pips({ n, label }: { n: number; label: string }) {
  return (
    <span className="rv-pips" role="img" aria-label={`${label}: ${n} de 5`}>
      <span className="rv-pips__label small">{label}</span>
      {[1, 2, 3, 4, 5].map((k) => (
        <i key={k} className={k <= n ? `on on--${n >= 4 ? 'high' : n >= 3 ? 'mid' : 'low'}` : ''} />
      ))}
    </span>
  );
}

function PowerBar({ c }: { c: PowerCard }) {
  if (c.fill === null) return <div className="rv-bar rv-bar--empty" aria-hidden="true" />;
  // El límite queda al 80 % del ancho: así se ve si te pasas o te quedas corto.
  const w = Math.max(0, Math.min(c.fill / 1.25, 1)) * 100;
  return (
    <div className={`rv-bar rv-bar--${c.state}`} role="img" aria-label={`${c.title}: ${c.value}`}>
      <span className="rv-bar__fill" style={{ width: `${w}%` }} />
      <span className="rv-bar__limit" title={c.limit} />
    </div>
  );
}

/** Las tablas técnicas originales, para quien quiera profundizar. */
function ExpertTables({ mission, data }: { mission: Mission; data: NonNullable<ReturnType<typeof useReviewData>> }) {
  const [view, setView] = useState<'res' | 'stm' | 'mel'>('res');
  const { stm, mel, resources } = data;
  return (
    <details className="rv-expert">
      <summary>Para expertos: tablas de la NASA (recursos, trazabilidad, equipos)</summary>
      <div className="segmented rv-expert__switch" role="group" aria-label="Tabla">
        {(
          [
            ['res', 'Recursos'],
            ['stm', 'Trazabilidad'],
            ['mel', 'Equipos (MEL)'],
          ] as const
        ).map(([id, label]) => (
          <button key={id} aria-pressed={view === id} onClick={() => setView(id)}>
            {label}
          </button>
        ))}
      </div>
      {view === 'res' && (
        <>
          <p className="small muted">
            Dificultad: <strong>{difficultyDef(mission.difficulty).label}</strong>. Estos son los recursos que el equipo de misión administra; las barras usan los números del
            análisis de ingeniería y del plan de vuelo.
          </p>
          <ResourcePanel report={resources} />
        </>
      )}
      {view === 'stm' && (
        <>
          <p className="small muted">
            Matriz de trazabilidad científica: cada requisito de la misión existe porque lo exige una medición del objetivo, y cada uno se verifica por análisis, inspección,
            prueba o demostración. Objetivo: <strong>{stm.scienceObjective}</strong>.
          </p>
          <div className="table-wrap">
            <table className="data-table" aria-label="Matriz de trazabilidad científica">
              <thead>
                <tr>
                  <th>Medición</th>
                  <th>Requisito del instrumento</th>
                  <th>Requisito de misión</th>
                  <th>Previsto</th>
                  <th>Verificación</th>
                  <th>Estado</th>
                </tr>
              </thead>
              <tbody>
                {stm.rows.map((r) => (
                  <tr key={r.id}>
                    <td>{r.measurement}</td>
                    <td>{r.instrumentRequirement}</td>
                    <td>{r.missionRequirement}</td>
                    <td className="mono">{r.predicted}</td>
                    <td>{r.method}</td>
                    <td>
                      <span className={`badge trace--${r.status}`}>{TRACE_TEXT[r.status]}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
      {view === 'mel' && (
        <>
          <p className="small muted">
            Master Equipment List: la masa actual estimada (CBE) de cada pieza más una contingencia según su madurez — 5 % con herencia de vuelo, 15 % modificada, 30 % nueva.
            NEXUS aplica un margen plano del {DRY_MASS_MARGIN * 100} % sobre la masa seca: la MEL muestra si alcanza.
          </p>
          {mel.rows.length === 0 ? (
            <p className="muted">La nave no tiene piezas todavía.</p>
          ) : (
            <div className="table-wrap">
              <table className="data-table" aria-label="Master Equipment List">
                <thead>
                  <tr>
                    <th>Pieza</th>
                    <th>Subsistema</th>
                    <th>Cant.</th>
                    <th>CBE (kg)</th>
                    <th>Madurez</th>
                    <th>Cont.</th>
                    <th>MEV (kg)</th>
                    <th>Potencia (W)</th>
                    <th>Costo</th>
                  </tr>
                </thead>
                <tbody>
                  {mel.rows.map((r) => (
                    <tr key={r.componentId}>
                      <td>{r.name}</td>
                      <td>{CATEGORY_LABELS[r.category]}</td>
                      <td className="mono">{r.qty}</td>
                      <td className="mono">{fmtNum(r.cbeKg, 1)}</td>
                      <td>{HERITAGE_LABEL[r.heritage]}</td>
                      <td className="mono">{Math.round(r.contingency * 100)} %</td>
                      <td className="mono">{fmtNum(r.mevKg, 1)}</td>
                      <td className="mono">{r.powerW}</td>
                      <td className="mono">{formatMUSD(r.costMUSD)}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr>
                    <td colSpan={3}>Total seco</td>
                    <td className="mono">{fmtNum(mel.cbeKg, 1)}</td>
                    <td />
                    <td className="mono">{Math.round(mel.effectiveContingency * 100)} %</td>
                    <td className="mono">{fmtNum(mel.mevKg, 1)}</td>
                    <td colSpan={2} />
                  </tr>
                </tfoot>
              </table>
            </div>
          )}
          {mel.rows.length > 0 && (
            <dl className="kv" style={{ marginTop: 12 }}>
              <dt>Propelente</dt>
              <dd>{fmtNum(mel.propellantKg)} kg</dd>
              <dt>Contingencia por madurez</dt>
              <dd className={mel.flatMarginCovers ? 'ok' : 'bad'}>
                {fmtNum(mel.contingencyKg, 1)} kg ({Math.round(mel.effectiveContingency * 100)} %) —{' '}
                {mel.flatMarginCovers ? `cubierta por el margen del ${DRY_MASS_MARGIN * 100} %` : `supera el margen del ${DRY_MASS_MARGIN * 100} %: usa piezas con herencia o deja reserva en el lanzador`}
              </dd>
              <dt>Escala CubeSat</dt>
              <dd>
                Una CubeSat 1U es un cubo de {CUBESAT_1U.edgeCm} cm de {fmtNum(CUBESAT_1U.minKg, 0)}–{fmtNum(CUBESAT_1U.maxKg, 2)} kg: tu nave seca pesa como ~
                {Math.round(mel.cbeKg / CUBESAT_1U.maxKg)} de ellas.
              </dd>
            </dl>
          )}
        </>
      )}
    </details>
  );
}

function useReviewData(mission: Mission | null) {
  return useMemo(() => {
    const input = mission ? reviewInputFor(mission) : null;
    if (!input || !mission) return null;
    const stm = traceabilityMatrix(input);
    const risks = riskRegister(input);
    const mel = equipmentList(mission.design, input.lookup);
    const cml = conceptMaturity(input, stm, risks, mel);
    const cards = powerCards(input);
    return {
      input,
      stm,
      risks,
      mel,
      cml,
      cards,
      resources: missionResources(input.engineering, input.plan),
      goals: roleGoals(input.engineering, input.plan),
    };
  }, [mission]);
}

export function ReviewScreen() {
  const mission = useGameStore(selectActiveMission);
  const navigate = useGameStore((s) => s.navigate);
  const [stepIdx, setStepIdx] = useState(0);
  const [visited, setVisited] = useState<Set<number>>(() => new Set([0]));
  const [showFact, setShowFact] = useState(false);
  const [openLevel, setOpenLevel] = useState<number | null>(null);
  const [allRisks, setAllRisks] = useState(false);
  const data = useReviewData(mission);

  if (!mission || !data) {
    return (
      <Panel className="side-panel" eyebrow="Junta de revisión" title="Sin misión activa" onClose={() => navigate('center')}>
        <p className="muted">Crea o carga una misión: la junta revisa si tu idea está lista para volar.</p>
      </Panel>
    );
  }
  const { cml, risks, cards, goals } = data;
  const step = STEPS[stepIdx];
  const gate = flightGate(mission.stage);
  const npc = npcLines(cml, cards, risks, gate)[step.id];
  const st = stars(cards);
  const levelDef = CML_DEFINITIONS.find((d) => d.level === cml.level);
  const shownLevel = openLevel ?? Math.min(Math.max(cml.next?.level ?? cml.level, 2), 5);
  const go = (i: number) => {
    const k = Math.max(0, Math.min(STEPS.length - 1, i));
    setStepIdx(k);
    setVisited((v) => new Set(v).add(k));
    setShowFact(false);
    document.querySelector('.review .panel__body')?.scrollTo({ top: 0 });
  };
  const coord = coordination(mission.teamLog);
  const highRisks = risks.filter((r) => r.level === 'high').length;
  const shownRisks = allRisks ? risks : risks.slice(0, 3);

  const flightButton =
    gate === 'ready' || gate === 'flown' ? (
      <button className="btn btn--primary btn--glow" onClick={() => navigate('flight')}>
        {gate === 'ready' ? '🚀 Ir al vuelo' : 'Ver el vuelo →'}
      </button>
    ) : gate === 'plan' ? (
      <button className="btn btn--primary" onClick={() => navigate('planner')}>
        Ir al Planner a confirmar el plan →
      </button>
    ) : (
      <button className="btn btn--primary" onClick={() => navigate('lab')}>
        Volver al LAB →
      </button>
    );

  return (
    <Panel
      className="wide-panel review review--game"
      eyebrow={`Junta de revisión · ${mission.name}`}
      title="¿Lista para volar?"
      onClose={() => navigate('center')}
      aside={
        <>
          <span className="badge rv-stars" aria-label={`${st.earned} de ${st.total} estrellas`}>
            ★ {st.earned}/{st.total}
          </span>
          <span className="badge badge--info" data-testid="cml-level">
            CML {cml.level}
          </span>
        </>
      }
      tabs={
        <ol className="rv-steps" role="tablist" aria-label="Pasos de la revisión">
          {STEPS.map((s, k) => (
            <li key={s.id}>
              <button
                role="tab"
                aria-selected={k === stepIdx}
                className={`rv-step ${visited.has(k) && k !== stepIdx ? 'rv-step--seen' : ''}`}
                onClick={() => go(k)}
              >
                <span className="rv-step__n mono">{visited.has(k) && k !== stepIdx ? '✓' : k + 1}</span>
                <span>{s.label}</span>
              </button>
            </li>
          ))}
        </ol>
      }
      footer={
        <>
          <button className="btn btn--ghost" disabled={stepIdx === 0} onClick={() => go(stepIdx - 1)}>
            ← Anterior
          </button>
          <span className="small muted">{`Paso ${stepIdx + 1} de ${STEPS.length}`}</span>
          {stepIdx < STEPS.length - 1 ? (
            <button className="btn btn--primary" onClick={() => go(stepIdx + 1)}>
              Siguiente: {STEPS[stepIdx + 1].label} →
            </button>
          ) : (
            flightButton
          )}
        </>
      }
    >
      <div className="rv-layout">
        <aside className="rv-npc" aria-label="Directora de vuelo">
          <NpcAvatar mood={npc.mood} />
          <div className="rv-npc__who">
            <strong>Directora Vega</strong>
            <span className="small muted">Control de misión</span>
          </div>
          <p className={`rv-bubble rv-bubble--${npc.mood}`} key={`${step.id}-${npc.text}`} aria-live="polite">
            {npc.text}
          </p>
          <button className="rv-fact-btn" aria-expanded={showFact} onClick={() => setShowFact((v) => !v)}>
            💡 ¿Sabías que…?
          </button>
          {showFact && <p className="rv-fact small">{FUN_FACTS[step.id]}</p>}
        </aside>

        <div className="rv-main" role="tabpanel" aria-label={step.heading} key={step.id}>
          <h3 className="rv-heading">{step.heading}</h3>

          {step.id === 'level' && (
            <>
              <p className="small muted rv-lead">
                La NASA no construye una nave apenas tiene la idea: primero comprueba, nivel por nivel, que la idea funciona. Cada nivel es como pasar de pantalla en un juego.
              </p>
              <div className="rv-xp">
                <span className="rv-xp__lvl mono">{`Nivel ${cml.level}`}</span>
                <div className="rv-xp__bar" role="img" aria-label={cml.next ? `Progreso al nivel ${cml.next.level}: ${cml.next.green} de ${cml.next.total}` : 'Nivel máximo del juego'}>
                  <span style={{ width: `${cml.next ? Math.round(cml.next.fraction * 100) : 100}%` }} />
                </div>
                <span className="small">{cml.next ? `${cml.next.green}/${cml.next.total} para el nivel ${cml.next.level}` : '¡Nivel máximo del juego!'}</span>
              </div>
              <ol className="rv-levels" aria-label="Niveles de la misión">
                {[1, 2, 3, 4, 5].map((l) => {
                  const done = l <= cml.level;
                  const current = l === cml.level + 1;
                  const locked = l > cml.level + 1;
                  const score = cml.scores.find((s) => s.level === l);
                  return (
                    <li key={l}>
                      <button
                        className={`rv-level ${done ? 'rv-level--done' : current ? 'rv-level--current' : 'rv-level--locked'} ${shownLevel === l ? 'rv-level--open' : ''}`}
                        aria-pressed={shownLevel === l}
                        onClick={() => setOpenLevel(l)}
                      >
                        <LevelBadge level={l} done={done} current={current} locked={locked} />
                        <strong className="small">{CML_KID_NAME[l]}</strong>
                        <span className="rv-level__official small muted">
                          CML {l} · {CML_DEFINITIONS[l - 1].name}
                        </span>
                        {score && current && <span className="rv-level__pct mono small">{Math.round(score.fraction * 100)} %</span>}
                      </button>
                    </li>
                  );
                })}
              </ol>
              <div className="rv-checklist" aria-live="polite">
                <p className="small">
                  <strong>{`Nivel ${shownLevel} · ${CML_KID_NAME[shownLevel]}`}</strong>{' '}
                  <span className="muted">— {CML_DEFINITIONS[shownLevel - 1].description}</span>
                </p>
                {shownLevel === 1 ? (
                  <p className="small">{cml.level >= 1 ? '✓ Ya elegiste el objetivo científico: ¡tu idea existe!' : 'Elige un objetivo científico en el Briefing.'}</p>
                ) : (
                  <ul className="cml-items">
                    {cml.items
                      .filter((x) => x.level === shownLevel)
                      .map((x) => (
                        <li key={x.id} className={`cml-item cml-item--${x.status}`}>
                          <span className="cml-item__dot" aria-label={STATUS_TEXT[x.status]} title={STATUS_TEXT[x.status]}>
                            {x.status === 'G' ? '✓' : x.status === 'Y' ? '!' : '✗'}
                          </span>
                          <span className="small">
                            <span className="muted">{CML_AREA_LABEL[x.area]} · </span>
                            {x.label}
                            {x.key && <span className="badge badge--info cml-key">clave</span>}
                          </span>
                          <span className="small mono muted cml-item__detail">{x.detail}</span>
                        </li>
                      ))}
                  </ul>
                )}
                <p className="small muted">{`Se sube de nivel con el ${Math.round(CML_PASS_FRACTION * 100)} % de la lista en verde y sin que falte nada «clave».`}</p>
              </div>
              <details className="rv-expert">
                <summary>Para expertos: la escala completa de la NASA (9 niveles)</summary>
                <ol className="cml-spine" aria-label="Escala CML">
                  {CML_DEFINITIONS.map((d) => (
                    <li key={d.level} className={`cml-step ${d.level <= cml.level ? 'cml-step--done' : ''} ${d.inGame ? '' : 'cml-step--out'}`} aria-current={d.level === cml.level ? 'step' : undefined}>
                      <span className="cml-step__n mono">{d.level}</span>
                      <span>
                        <strong className="small">{d.name}</strong>
                        <span className="small muted cml-step__desc">{d.description}</span>
                        <span className="small cml-step__game">{d.inGame ? `En NEXUS: ${d.inGame}` : 'Fuera del alcance del juego'}</span>
                      </span>
                    </li>
                  ))}
                </ol>
                {levelDef && (
                  <p className="small muted">
                    Nivel actual: CML {cml.level} · {levelDef.name}.
                  </p>
                )}
              </details>
            </>
          )}

          {step.id === 'powers' && (
            <>
              <p className="small muted rv-lead">Cada tarjeta en verde te da una estrella. Toca «¿Por qué importa?» para descubrir qué hace cada sistema.</p>
              <div className="rv-stars-row" aria-hidden="true">
                {cards.map((c) => (
                  <span key={c.id} className={c.state === 'ok' ? 'on' : ''}>
                    ★
                  </span>
                ))}
              </div>
              <ul className="rv-powers">
                {cards.map((c) => (
                  <li key={c.id} className={`rv-power rv-power--${c.state}`} data-power={c.id}>
                    <div className="rv-power__head">
                      <PowerIcon id={c.id} state={c.state} />
                      <div>
                        <strong>{c.title}</strong>
                        <span className="small muted rv-power__tech">{c.tech}</span>
                      </div>
                      <span className={`rv-chip rv-chip--${c.state}`}>
                        <span aria-hidden="true">{STATE_MARK[c.state]}</span> {STATE_TEXT[c.state]}
                      </span>
                    </div>
                    <PowerBar c={c} />
                    <p className="small rv-power__value">{c.value}</p>
                    <details className="rv-why">
                      <summary>¿Por qué importa?</summary>
                      <p className="small">{c.why}</p>
                      {c.state !== 'ok' && (
                        <p className="small">
                          <strong>Cómo mejorarlo:</strong> {c.tip}
                        </p>
                      )}
                      <p className="small muted">La rayita de la barra marca el límite: {c.limit}.</p>
                    </details>
                  </li>
                ))}
              </ul>
              <ExpertTables mission={mission} data={data} />
            </>
          )}

          {step.id === 'risks' && (
            <>
              <p className="small muted rv-lead">
                Cada peligro es un meteorito: cuanto más grande y rojo, más cuidado. Se mide cuántas posibilidades hay de que pase y cuánto daño haría. Tu escudo es la forma de
                evitarlo.
              </p>
              {risks.length === 0 ? (
                <p className="muted">Sin datos suficientes: diseña la nave primero.</p>
              ) : (
                <>
                  <ul className="rv-risks">
                    {shownRisks.map((r) => (
                      <li key={r.id} className={`rv-risk rv-risk--${r.level}`}>
                        <Meteor level={r.level} />
                        <div className="rv-risk__body">
                          <span className={`rv-chip rv-chip--${r.level === 'high' ? 'fail' : r.level === 'medium' ? 'warn' : 'ok'}`}>{RISK_TEXT[r.level]}</span>
                          <strong className="rv-risk__title">{r.title}</strong>
                          <div className="rv-risk__pips">
                            <Pips n={r.likelihood} label="Posibilidad" />
                            <Pips n={r.consequence} label="Daño" />
                          </div>
                          <p className="small muted">Por qué: {r.driver}.</p>
                          <p className="small">
                            🛡️ <strong>Escudo:</strong> {r.mitigation}
                          </p>
                        </div>
                      </li>
                    ))}
                  </ul>
                  {risks.length > 3 && (
                    <button className="link-btn rv-more" onClick={() => setAllRisks((v) => !v)}>
                      {allRisks ? 'Ver solo los 3 más importantes' : `Ver todos los peligros (${risks.length})`}
                    </button>
                  )}
                  <details className="rv-expert">
                    <summary>Para expertos: mapa de riesgos 5 × 5</summary>
                    <p className="small muted">
                      Cada riesgo se puntúa por probabilidad (1–5) y consecuencia (1–5). La probabilidad sale de los márgenes calculados: cuanto menos margen, más fácil que el
                      problema ocurra.
                    </p>
                    <RiskMatrix risks={risks} />
                  </details>
                </>
              )}
            </>
          )}

          {step.id === 'launch' && (
            <>
              <div className={`rv-verdict rv-verdict--${gate === 'ready' || gate === 'flown' ? 'go' : 'nogo'}`}>
                <RocketHero go={gate === 'ready' || gate === 'flown'} />
                <div>
                  <p className={`rv-stamp ${gate === 'ready' || gate === 'flown' ? 'rv-stamp--go' : 'rv-stamp--nogo'}`}>{gate === 'ready' || gate === 'flown' ? '¡LISTA PARA DESPEGAR!' : 'AÚN NO'}</p>
                  <ul className="rv-summary">
                    <li>
                      <span className="rv-summary__k">Nivel de la misión</span>
                      <strong>
                        {cml.level} · {CML_KID_NAME[cml.level] ?? levelDef?.name ?? '—'}
                      </strong>
                    </li>
                    <li>
                      <span className="rv-summary__k">Estrellas</span>
                      <strong>{`★ ${st.earned} de ${st.total}`}</strong>
                    </li>
                    <li>
                      <span className="rv-summary__k">Peligros grandes</span>
                      <strong className={highRisks ? 'bad' : 'ok'}>{highRisks}</strong>
                    </li>
                  </ul>
                  <p className="small muted">
                    Las estrellas y los peligros no bloquean el despegue: lo que cuenta es que el plan esté confirmado. Pero cada estrella que falta es un problema que podría aparecer
                    durante el vuelo.
                  </p>
                </div>
              </div>
              {cards.some((c) => c.state === 'ok') && (
                <>
                  <p className="eyebrow">Insignias ganadas</p>
                  <ul className="rv-badges">
                    {cards
                      .filter((c) => c.state === 'ok')
                      .map((c) => (
                        <li key={c.id} className="rv-badge">
                          <PowerIcon id={c.id} state="ok" />
                          <span className="small">{c.title}</span>
                        </li>
                      ))}
                  </ul>
                </>
              )}
              <details className="rv-expert">
                <summary>Para expertos: el ciclo de vida de una misión de la NASA</summary>
                <p className="small muted">
                  Las misiones de NASA avanzan por fases separadas por revisiones formales. NEXUS comprime años de trabajo en minutos; la columna CubeSat muestra los plazos típicos
                  de una misión pequeña.
                </p>
                <div className="table-wrap">
                  <table className="data-table" aria-label="Ciclo de vida de la misión">
                    <thead>
                      <tr>
                        <th>Fase de NASA</th>
                        <th>Revisión</th>
                        <th>En NEXUS</th>
                        <th>Ruta CubeSat</th>
                        <th>Estado</th>
                      </tr>
                    </thead>
                    <tbody>
                      {LIFECYCLE.map((l) => {
                        const s = l.stage ? stageStatus(mission, l.stage) : 'locked';
                        return (
                          <tr key={l.id}>
                            <td>{l.nasaPhase}</td>
                            <td>{l.review}</td>
                            <td>{l.game}</td>
                            <td>{l.cubesat}</td>
                            <td>
                              <span className={`badge ${s === 'done' ? 'badge--ok' : s === 'current' ? 'badge--info' : 'badge--lock'}`}>
                                {s === 'done' ? 'Superada' : s === 'current' ? 'En curso' : 'Pendiente'}
                              </span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </details>
              {mission.team && (
                <details className="rv-expert">
                  <summary>El equipo: roles y votos</summary>
                  <div className="briefing-grid">
                    <div>
                      <h3 className="section-title">{mission.team.name}</h3>
                      <ul className="issues">
                        {mission.team.members.map((m) => {
                          const g = goals.find((x) => x.role === m.role)!;
                          return (
                            <li key={m.role} className={`issue ${g.met ? 'issue--ok' : 'issue--optimization'}`}>
                              <strong className="small">
                                {m.name} · {roleDef(m.role).label}
                              </strong>
                              <p className="small muted">{roleDef(m.role).priority}</p>
                              <p className={`small ${g.met ? 'ok' : 'bad'}`}>
                                {g.met ? '✓' : '✗'} {g.goal} — <span className="mono">{g.status}</span>
                              </p>
                            </li>
                          );
                        })}
                      </ul>
                    </div>
                    <div>
                      <h3 className="section-title">Decisiones votadas</h3>
                      <p className="small">
                        Coordinación: <strong className="mono">{coord.index}/100</strong> — {coord.verdict}
                      </p>
                      {mission.teamLog.length === 0 ? (
                        <p className="small muted">Aún no han votado ninguna decisión.</p>
                      ) : (
                        <ul className="issues">
                          {mission.teamLog.map((d, k) => (
                            <li key={k} className={`issue ${d.unanimous ? 'issue--ok' : 'issue--optimization'}`}>
                              <strong className="small">{d.label}</strong>
                              <p className="small muted">
                                {d.votes.map((v) => `${roleDef(v.role).label}: ${v.choice}`).join(' · ')} → <strong>{d.outcome}</strong>
                                {d.unanimous ? ' (unanimidad)' : ''}
                                {d.bestShare !== undefined ? ` · ${Math.round(d.bestShare * 100)} % votó la mejor opción` : ''}
                              </p>
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>
                  </div>
                </details>
              )}
            </>
          )}
        </div>
      </div>
    </Panel>
  );
}
