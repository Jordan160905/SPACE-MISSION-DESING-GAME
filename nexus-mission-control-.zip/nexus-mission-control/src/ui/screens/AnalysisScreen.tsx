/**
 * Fase 4 — Análisis y aprobación del diseño.
 *
 * La nave en 3D (escena del LAB, desplazada a la izquierda) y, a la derecha, el análisis de
 * ingeniería resumido en tarjetas, gráficos e indicadores. La viabilidad es la MISMA que usa todo
 * el juego: `analyzeEngineering` sobre el diseño guardado de la misión, interpretada por
 * `LabGuidance` (los mismos estados que ve el jugador en el LAB). Si cumple todas las restricciones
 * obligatorias se muestra «DISEÑO APROBADO» y el botón aprueba el diseño (con votación si se juega
 * en equipo) y abre el Planner. Si no, se listan las correcciones y cada una vuelve al LAB con la
 * categoría del catálogo y las piezas que la resuelven.
 */
import { useMemo, type ReactNode } from 'react';
import { CATEGORY_LABELS, COMPONENT_CATALOG, getComponent } from '../../data/components/catalog';
import { getLauncher, LUNAR_LAUNCHERS } from '../../data/launchers/launchers';
import { templateForMission } from '../../data/missions/missions';
import { designComponents, designTotals } from '../../sim/DesignSystem';
import { constraintChecks, fixFor, labParameters, PARAM_STATE_LABEL, type LabParameter, type ParamState } from '../../sim/LabGuidance';
import { MAX_DOD, RECOMMENDED_DOD } from '../../sim/PowerSystem';
import { G0 } from '../../sim/TrajectorySystem';
import { fmtNum } from '../../sim/units';
import { selectActiveMission, useGameStore } from '../../state/useGameStore';
import { useEngineeringReport } from '../analysis/EngineeringPanel';
import { Panel } from '../components/Panel';

const MARK: Record<ParamState, string> = { ok: '✓', missing: '…', fail: '✗' };

/** Barra de uso frente a un límite, con la marca del límite. */
function LimitBar({ value, max, label, state, unit }: { value: number; max: number; label: string; state: ParamState; unit: string }) {
  const scale = 1.15;
  const f = max > 0 ? Math.min(scale, value / max) : scale;
  return (
    <div className="an-bar">
      <div className="an-bar__track" role="meter" aria-label={label} aria-valuemin={0} aria-valuemax={Math.round(max)} aria-valuenow={Math.round(value)}>
        <div className={`an-bar__fill an-bar__fill--${state}`} style={{ width: `${(f / scale) * 100}%` }} />
        <div className="an-bar__limit" style={{ left: `${(1 / scale) * 100}%` }} title={`Límite: ${fmtNum(max)} ${unit}`} />
      </div>
      <span className="small mono an-bar__txt">
        {fmtNum(value)} / {fmtNum(max)} {unit}
      </span>
    </div>
  );
}

function ACard({ title, state, children, wide }: { title: string; state: ParamState; children: ReactNode; wide?: boolean }) {
  return (
    <section className={`an-card an-card--${state} ${wide ? 'an-card--wide' : ''}`} aria-label={`${title}: ${PARAM_STATE_LABEL[state]}`}>
      <header>
        <span className="eyebrow">{title}</span>
        <span className="an-card__state small">
          {MARK[state]} {PARAM_STATE_LABEL[state]}
        </span>
      </header>
      {children}
    </section>
  );
}

/** Indicador circular: cuántos parámetros críticos son correctos. */
function Gauge({ ok, total, viable }: { ok: number; total: number; viable: boolean }) {
  const r = 34;
  const c = 2 * Math.PI * r;
  return (
    <svg className={`an-gauge ${viable ? 'an-gauge--ok' : 'an-gauge--bad'}`} viewBox="0 0 84 84" role="img" aria-label={`${ok} de ${total} parámetros críticos correctos`}>
      <circle cx="42" cy="42" r={r} className="an-gauge__bg" />
      <circle cx="42" cy="42" r={r} className="an-gauge__fg" strokeDasharray={`${(ok / total) * c} ${c}`} transform="rotate(-90 42 42)" />
      <text x="42" y="40" textAnchor="middle" className="an-gauge__num">
        {ok}/{total}
      </text>
      <text x="42" y="54" textAnchor="middle" className="an-gauge__lbl">
        correctos
      </text>
    </svg>
  );
}

export function AnalysisScreen() {
  const mission = useGameStore(selectActiveMission);
  const navigate = useGameStore((s) => s.navigate);
  const focus = useGameStore((s) => s.labFocusCatalog);
  const approveDesign = useGameStore((s) => s.approveDesign);
  const requestDecision = useGameStore((s) => s.requestDecision);
  const labSave = useGameStore((s) => s.labSave);
  const labDirty = useGameStore((s) => s.lab.dirty && s.lab.missionId === s.activeMissionId);
  const design = mission?.design ?? { chassisId: null, parts: [] };
  const report = useEngineeringReport(design, mission);
  const totals = useMemo(() => designTotals(design, getComponent), [design]);
  const template = mission ? templateForMission(mission) : undefined;
  const objective = template?.objectives.find((o) => o.id === mission?.objectiveId);
  const ctx = { design, lookup: getComponent, catalog: COMPONENT_CATALOG, objectiveInstrumentId: objective?.primaryInstrumentId, difficulty: mission?.difficulty };
  const params = useMemo(() => labParameters(report, ctx), [report]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!mission || !template) {
    return (
      <Panel className="side-panel" title="Sin misión activa" onClose={() => navigate('center')}>
        <p className="muted">Crea una misión y construye una nave para analizarla.</p>
      </Panel>
    );
  }

  const st = Object.fromEntries(params.map((p) => [p.id, p.state])) as Record<LabParameter['id'], ParamState>;
  const pm = (id: LabParameter['id']) => params.find((p) => p.id === id)!;
  const checks = constraintChecks(template, report, params);
  const hardChecks = checks.filter((c) => c.severity === 'hard');
  const critical = report.issues.filter((i) => i.severity === 'critical');
  const optional = report.issues.filter((i) => i.severity === 'optimization');
  const viable = report.viable && !!design.chassisId;
  const approved = mission.stage !== 'DESIGN';
  const comps = designComponents(design, getComponent);
  const m = report.mass;
  const cheapest = m?.launchersThatFit[0] ? getLauncher(m.launchersThatFit[0]) : undefined;
  const plannedLauncher = mission.plan ? getLauncher(mission.plan.launcherId) : undefined;
  const p = report.power;
  const b = report.budget;
  const d = report.data;
  const instruments = comps.filter((c) => c.category === 'INSTRUMENT');
  const antennas = comps.filter((c) => c.downlinkMbps > 0);
  const engines = comps.filter((c) => c.ispS > 0);
  // Δv disponible (Tsiolkovsky) con el motor instalado: Isp · g0 · ln(masa húmeda / masa seca).
  const isp = engines[0]?.ispS ?? 0;
  const dvAvail = isp > 0 && totals.massDryKg > 0 && totals.propellantKg > 0 ? isp * G0 * Math.log(totals.massWetKg / totals.massDryKg) : 0;
  const okCount = params.filter((x) => x.state === 'ok').length;

  // Presupuesto: líneas reales; si aún no hay lanzador elegido, se estima con el más barato capaz.
  const launcherForBudget = plannedLauncher ?? cheapest;
  const launchLine = b?.lines.find((l) => l.id === 'launch');
  const launchCost = launchLine?.amountMUSD ?? launcherForBudget?.costMUSD ?? 0;
  const launchEstimated = launchLine?.amountMUSD == null && !!launcherForBudget;
  const segs = b
    ? [
        { id: 'components', label: 'Nave', v: b.lines.find((l) => l.id === 'components')?.amountMUSD ?? 0, cls: 'c1' },
        { id: 'operations', label: 'Operación', v: b.lines.find((l) => l.id === 'operations')?.amountMUSD ?? 0, cls: 'c2' },
        { id: 'launch', label: launchEstimated ? `Lanzador (estimado: ${launcherForBudget?.name})` : 'Lanzador', v: launchCost, cls: 'c3' },
      ]
    : [];
  const used = segs.reduce((s, x) => s + x.v, 0);
  const free = b ? b.capMUSD - used : 0;

  const goPlanner = () =>
    approved
      ? navigate('planner')
      : requestDecision(
          { kind: 'design', label: '¿Aprobamos este diseño y pasamos a planificar el lanzamiento?', options: [{ id: 'approve', label: 'Aprobar' }, { id: 'reject', label: 'Seguir diseñando' }] },
          () => {
            approveDesign();
            if (useGameStore.getState().missions.find((x) => x.id === mission.id)?.stage === 'PLANNING') navigate('planner');
          },
        );

  return (
    <Panel
      className="analysis-panel"
      eyebrow={`Análisis del diseño · ${mission.name}`}
      title={viable ? 'DISEÑO APROBADO' : 'El diseño necesita correcciones'}
      onClose={() => navigate('lab')}
      footer={
        <>
          <button className="btn btn--ghost" onClick={() => navigate('lab')}>
            ← Volver al LAB
          </button>
          {viable ? (
            <button className="btn btn--primary btn--glow an-go" onClick={goPlanner} disabled={labDirty} title={labDirty ? 'Guarda los cambios del LAB antes de continuar' : undefined}>
              Continuar con la planificación de lanzamiento →
            </button>
          ) : (
            <span className="small an-foot-msg">
              Corrige {critical.length} {critical.length === 1 ? 'aspecto' : 'aspectos'} en el LAB para continuar.
            </span>
          )}
        </>
      }
    >
      {labDirty && (
        <div className="notice-band an-dirty" role="note">
          <span className="small">Tienes cambios sin guardar en el LAB. Este análisis muestra el último diseño guardado.</span>
          <button className="btn btn--sm btn--primary" onClick={labSave}>
            Guardar cambios y analizar
          </button>
        </div>
      )}

      {/* ── Estado general de la misión ── */}
      <div className={`an-verdict ${viable ? 'an-verdict--ok' : 'an-verdict--bad'}`} role="status">
        <Gauge ok={okCount} total={params.length} viable={viable} />
        <div className="an-verdict__txt">
          <span className="an-verdict__stamp">{viable ? 'DISEÑO APROBADO' : 'NO APROBADO'}</span>
          <span className="small">
            {viable
              ? `Cumple las ${hardChecks.length} restricciones obligatorias de ${template.code}${optional.length ? ` · ${optional.length} ${optional.length === 1 ? 'mejora opcional' : 'mejoras opcionales'}` : ''}.`
              : `${critical.length} ${critical.length === 1 ? 'aspecto necesita' : 'aspectos necesitan'} corrección. Cada uno te lleva al LAB con las piezas que lo resuelven.`}
          </span>
          <span className="small muted">
            Objetivo: {objective?.title ?? '—'} · Etapa: {approved ? 'diseño aprobado, en planificación' : 'Diseño'}
          </span>
        </div>
      </div>

      {/* ── Lo que hay que corregir ── */}
      {!viable && (
        <>
          <h3 className="section-title">Aspectos que necesitan corrección</h3>
          <ul className="issues">
            {critical.map((i) => {
              const fix = fixFor(i, { ...ctx, schedule: report.schedule });
              return (
                <li key={i.id} className="issue issue--critical problem">
                  <strong className="small">{i.title}</strong>
                  <p className="small muted">
                    <span className="problem__tag">Por qué:</span> {i.explanation}
                  </p>
                  {fix && (
                    <p className="small problem__how">
                      <span className="problem__tag">Cómo:</span> {fix.action}
                    </p>
                  )}
                  <span className="row-actions">
                    {fix ? (
                      <button className="btn btn--sm btn--primary" onClick={() => focus(fix.category, fix.componentIds)}>
                        Solucionar en el LAB → {CATEGORY_LABELS[fix.category]}
                      </button>
                    ) : (
                      <button className="btn btn--sm btn--primary" onClick={() => navigate('lab')}>
                        Solucionar en el LAB
                      </button>
                    )}
                  </span>
                </li>
              );
            })}
          </ul>
        </>
      )}

      <div className="an-grid">
        {/* Masa */}
        <ACard title="Masa total" state={st.mass}>
          <div className="an-big">{m ? `${fmtNum(m.wetWithMarginKg)} kg` : '—'}</div>
          <span className="small muted">
            Seca {fmtNum(totals.massDryKg)} + propelente {fmtNum(totals.propellantKg)} + margen {m ? fmtNum(m.marginKg) : '—'} kg
          </span>
          {m && (
            <div className="an-launchers">
              {LUNAR_LAUNCHERS.map((l) => (
                <LimitBar key={l.id} value={m.wetWithMarginKg} max={l.payloadToTLIKg} label={`Masa frente a la capacidad del ${l.name}`} state={l.payloadToTLIKg >= m.wetWithMarginKg ? 'ok' : 'fail'} unit={`kg · ${l.name}`} />
              ))}
            </div>
          )}
          <span className="small">{pm('mass').why}</span>
        </ACard>

        {/* Presupuesto */}
        <ACard title="Presupuesto" state={st.budget}>
          {b ? (
            <>
              <div className="an-big">
                {fmtNum(used, 1)} usados · {fmtNum(free, 1)} libres <span className="small muted">MUSD</span>
              </div>
              <div className="an-stack" role="img" aria-label={`Presupuesto de ${b.capMUSD} MUSD: ${segs.map((x) => `${x.label} ${fmtNum(x.v, 1)}`).join(', ')}, libre ${fmtNum(free, 1)}`}>
                {segs.map((x) => (
                  <span key={x.id} className={`an-stack__seg an-stack__seg--${x.cls}`} style={{ width: `${Math.max(0, (x.v / b.capMUSD) * 100)}%` }} />
                ))}
              </div>
              <ul className="an-lines small">
                {segs.map((x) => (
                  <li key={x.id}>
                    <span>
                      <span className={`an-key an-key--${x.cls}`} aria-hidden="true" /> {x.label}
                    </span>
                    <span className="mono">{fmtNum(x.v, 1)} MUSD</span>
                  </li>
                ))}
                <li>
                  <span>
                    <span className="an-key" aria-hidden="true" /> Libre (de {b.capMUSD} MUSD)
                  </span>
                  <span className={`mono ${free < 0 ? 'bad' : ''}`}>{fmtNum(free, 1)} MUSD</span>
                </li>
              </ul>
            </>
          ) : (
            <span className="small muted">Sin presupuesto (modo libre).</span>
          )}
        </ACard>

        {/* Consumo energético */}
        <ACard title="Consumo energético" state={st.energy}>
          {p ? (
            <>
              <div className="an-big">
                {fmtNum(p.sunlitLoadW, 0)} W de {fmtNum(p.nominalGenW, 0)} W
              </div>
              <LimitBar value={p.sunlitLoadW} max={p.nominalGenW} label="Consumo frente a la generación al sol" state={p.sunlitLoadW > p.nominalGenW ? 'fail' : st.energy} unit="W" />
              <span className="small muted">
                Balance por órbita: {p.orbitBalanceWh >= 0 ? '+' : ''}
                {fmtNum(p.orbitBalanceWh)} Wh (debe ser positivo). En eclipse consume {fmtNum(p.eclipseLoadW, 0)} W.
              </span>
            </>
          ) : (
            <span className="small">{pm('energy').why}</span>
          )}
        </ACard>

        {/* Capacidad energética */}
        <ACard title="Capacidad energética" state={st.energy}>
          {p && p.batteryWh > 0 ? (
            <>
              <div className="an-big">{fmtNum(p.batteryWh)} Wh de batería</div>
              <LimitBar value={p.depthOfDischarge * 100} max={MAX_DOD * 100} label="Descarga de la batería en cada eclipse" state={p.depthOfDischarge > MAX_DOD ? 'fail' : st.energy} unit="% de descarga" />
              <span className="small muted">
                Eclipse de {fmtNum(p.eclipseH * 60, 0)} min · autonomía en sombra {Number.isFinite(p.autonomyH) ? `${fmtNum(p.autonomyH, 1)} h` : 'sin límite'} · recomendado ≤ {Math.round(RECOMMENDED_DOD * 100)} %, máximo {Math.round(MAX_DOD * 100)} %.
              </span>
              <span className="small muted">Paneles: {fmtNum(p.nominalGenW, 0)} W al sol.</span>
            </>
          ) : (
            <span className="small">{pm('energy').why}</span>
          )}
        </ACard>

        {/* Comunicaciones */}
        <ACard title="Sistemas de comunicación" state={st.comms}>
          <div className="an-big">{antennas.map((a) => a.name).join(', ') || 'Sin antena'}</div>
          {report.comms && antennas.length > 0 && (
            <span className="small muted">
              {fmtNum(report.comms.downlinkMbps)} Mbps · {fmtNum(report.comms.contactHoursPerDay, 1)} h de contacto al día · {fmtNum(report.comms.downlinkGbitPerDay, 0)} Gbit/día
            </span>
          )}
          {d && d.targetGbit > 0 && antennas.length > 0 && (
            <LimitBar value={d.missionDeliveredGbit} max={d.targetGbit} label="Datos que llegarán frente a los exigidos" state={d.targetMet ? 'ok' : 'fail'} unit="Gbit exigidos" />
          )}
          <span className="small">{pm('comms').why}</span>
        </ACard>

        {/* Instrumentos */}
        <ACard title="Instrumentos científicos" state={st.instrument}>
          {instruments.length ? (
            <ul className="an-lines small">
              {instruments.map((c, k) => (
                <li key={`${c.id}-${k}`}>
                  <span>
                    {c.name}
                    {c.id === objective?.primaryInstrumentId && (
                      <span className="badge badge--ok" style={{ marginLeft: 6 }}>
                        Tu objetivo
                      </span>
                    )}
                  </span>
                  <span className="mono" title={`Valor científico ${c.scienceValue}/5`} aria-label={`Valor científico ${c.scienceValue} de 5`}>
                    {'★'.repeat(c.scienceValue)}
                    {'☆'.repeat(5 - c.scienceValue)}
                  </span>
                </li>
              ))}
            </ul>
          ) : (
            <span className="small">No hay instrumentos instalados.</span>
          )}
          <span className="small muted">Generan {fmtNum(totals.dataGenGbitPerH, 1)} Gbit/h al observar.</span>
          <span className="small">{pm('instrument').why}</span>
        </ACard>

        {/* Propulsión */}
        <ACard title="Propulsión" state={st.propulsion}>
          <div className="an-big">{dvAvail > 0 ? `${fmtNum(dvAvail, 0)} m/s de Δv` : 'Sin capacidad de maniobra'}</div>
          <span className="small muted">
            {comps.filter((c) => c.category === 'PROPULSION').map((c) => c.name).join(' + ') || 'Sin motor ni tanque'} · {fmtNum(totals.propellantKg)} kg de propelente
            {isp > 0 ? ` · Isp ${isp} s` : ''}
          </span>
          <span className="small muted">Δv = Isp · g₀ · ln(masa húmeda / masa seca). El Planner comprobará si alcanza para frenar en la Luna y mantener la órbita elegida.</span>
        </ACard>

        {/* Restricciones */}
        <ACard title="Cumplimiento de restricciones" state={hardChecks.every((c) => c.state === 'ok') ? 'ok' : hardChecks.some((c) => c.state === 'fail') ? 'fail' : 'missing'} wide>
          <ul className="an-constraints">
            {checks.map((c) => (
              <li key={c.id} className={`an-con an-con--${c.state}`}>
                <span className="an-con__mark" role="img" aria-label={PARAM_STATE_LABEL[c.state]}>
                  {MARK[c.state]}
                </span>
                <span>
                  <strong className="small">{c.label}</strong>
                  <span className="small muted an-con__detail">{c.detail}</span>
                </span>
                <span className={`badge ${c.severity === 'hard' ? 'badge--hard' : 'badge--soft'}`}>{c.severity === 'hard' ? 'Obligatoria' : 'Recomendada'}</span>
              </li>
            ))}
          </ul>
        </ACard>
      </div>
    </Panel>
  );
}
