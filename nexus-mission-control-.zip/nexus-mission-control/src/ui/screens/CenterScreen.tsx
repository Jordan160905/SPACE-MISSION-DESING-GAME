import { getComponent } from '../../data/components/catalog';
import { getMissionTemplate, templateForMission, LUNA_01 } from '../../data/missions/missions';
import type { Mission, MissionTemplate } from '../../data/schemas';
import { budgetSummary } from '../../sim/BudgetSystem';
import { analysisInputForMission, analyzeEngineering } from '../../sim/EngineeringAnalysis';
import { formatMUSD } from '../../sim/units';
import { STAGE_INFO, STAGE_ORDER, stageStatus } from '../../state/missionLogic';
import { selectActiveMission, useGameStore, type CenterTab } from '../../state/useGameStore';
import { Meter, Panel } from '../components/Panel';
import { MissionSelect } from './MissionSelect';
import { numLocale } from '../../i18n/lang';

const TABS: Array<{ id: CenterTab; label: string }> = [
  { id: 'objectives', label: 'Objetivos' },
  { id: 'budget', label: 'Presupuesto' },
  { id: 'progress', label: 'Progreso' },
];

function ObjectivesTab({ mission, template }: { mission: Mission; template: MissionTemplate }) {
  const chosen = template.objectives.find((o) => o.id === mission.objectiveId);
  const others = template.objectives.filter((o) => o.id !== mission.objectiveId);
  const instrument = chosen ? getComponent(chosen.primaryInstrumentId) : undefined;
  return (
    <>
      <p className="muted small">{template.tagline}</p>
      {chosen && (
        <div className="objective objective--chosen">
          <p className="eyebrow">Objetivo principal</p>
          <h3 className="h3" style={{ margin: '4px 0 8px' }}>
            {chosen.title}
          </h3>
          <p className="small muted" style={{ marginTop: 0 }}>
            {chosen.summary}
          </p>
          <dl className="kv">
            <dt>Instrumento necesario</dt>
            <dd>{instrument?.name ?? chosen.primaryInstrumentId}</dd>
            <dt>Datos a transmitir</dt>
            <dd>{chosen.dataTargetGbit.toLocaleString(numLocale())} Gbit</dd>
            <dt>Altitud recomendada</dt>
            <dd>
              {chosen.recommendedOrbit.altitudeKm[0]}–{chosen.recommendedOrbit.altitudeKm[1]} km
            </dd>
            <dt>Inclinación recomendada</dt>
            <dd>
              {chosen.recommendedOrbit.inclinationDeg[0]}–{chosen.recommendedOrbit.inclinationDeg[1]}°
            </dd>
          </dl>
          <p className="small" style={{ marginBottom: 0 }}>
            <strong>¿Por qué esa órbita?</strong> {chosen.recommendedOrbit.rationale}
          </p>
        </div>
      )}
      {others.length > 0 && (
        <>
          <p className="eyebrow" style={{ marginTop: 16 }}>
            Objetivos secundarios · +{template.rewards.xpPerExtraObjective} XP c/u
          </p>
          {others.map((o) => (
            <div key={o.id} className="objective">
              <strong>{o.title}</strong>
              <p className="small muted" style={{ margin: '4px 0 0' }}>
                Requiere {getComponent(o.primaryInstrumentId)?.name.toLowerCase()} · {o.dataTargetGbit.toLocaleString(numLocale())} Gbit
              </p>
            </div>
          ))}
        </>
      )}
      <p className="eyebrow" style={{ marginTop: 16 }}>
        Restricciones
      </p>
      {template.constraints.map((c) => (
        <div key={c.id} className="constraint">
          <span className={`badge ${c.severity === 'hard' ? 'badge--hard' : 'badge--soft'}`}>{c.severity === 'hard' ? 'Crítica' : 'Optimización'}</span>
          <span>
            <strong>{c.label}</strong>
            <br />
            <span className="muted">{c.description}</span>
          </span>
        </div>
      ))}
      <p className="eyebrow" style={{ marginTop: 16 }}>
        Recompensas
      </p>
      <p className="small muted" style={{ marginTop: 4 }}>
        {template.rewards.xp} XP base. {template.rewards.description}
      </p>
    </>
  );
}

function BudgetTab({ template, mission }: { template: MissionTemplate; mission: Mission | null }) {
  // Con misión: el mismo presupuesto que el análisis (incluye lanzador y duración del plan, si lo hay).
  // Sin misión: tope de la plantilla con la operación prevista; el lanzamiento queda pendiente.
  const summary =
    (mission ? analyzeEngineering(analysisInputForMission(mission.design, getComponent, mission, getMissionTemplate)).budget : null) ??
    budgetSummary(template, mission?.design ?? { chassisId: null, parts: [] }, getComponent, null, template.durationDays * template.opsCostPerDayMUSD);
  return (
    <>
      <p className="small muted" style={{ marginTop: 0 }}>
        Tope de {template.code}: todo lo que gastes en componentes, lanzamiento y operación sale de aquí.
      </p>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
        <span className="h2 mono">{formatMUSD(summary.remainingMUSD)}</span>
        <span className="small muted">para el lanzador, de {formatMUSD(summary.capMUSD)}</span>
      </div>
      <div style={{ margin: '10px 0 18px' }}>
        <Meter value={summary.usedFraction} warn={summary.overBudget} label="Presupuesto comprometido" />
      </div>
      <dl className="kv">
        {summary.lines.map((l) => (
          <div key={l.id} style={{ display: 'contents' }}>
            <dt>
              {l.label}
              <br />
              <span className="small" style={{ color: 'var(--text-lo)' }}>
                {l.note}
              </span>
            </dt>
            <dd>{l.amountMUSD === null ? <span className="badge badge--lock">Pendiente</span> : formatMUSD(l.amountMUSD)}</dd>
          </div>
        ))}
      </dl>
      <p className="small" style={{ marginTop: 18 }}>
        <strong>Relación de ingeniería:</strong> cada kilogramo extra no solo cuesta su precio; también puede obligarte a elegir un lanzador más grande y
        caro. El presupuesto y la masa están acoplados.
      </p>
      {!mission && <p className="small muted">Crea una misión para empezar a comprometer presupuesto.</p>}
    </>
  );
}

function DesignStatus({ mission }: { mission: Mission }) {
  const navigate = useGameStore((s) => s.navigate);
  const report = analyzeEngineering(analysisInputForMission(mission.design, getComponent, mission, getMissionTemplate));
  const issues = report.issues;
  const critical = issues.filter((i) => i.severity === 'critical').length;
  const pieces = mission.design.parts.length + (mission.design.chassisId ? 1 : 0);
  return (
    <div className="objective" style={{ marginBottom: 12 }}>
      <p className="eyebrow">Diseño guardado</p>
      <p className="small" style={{ margin: '6px 0 0' }}>
        {pieces === 0 ? 'Todavía no hay nave. ' : `${pieces} piezas · `}
        <span className={`badge ${critical ? 'badge--hard' : 'badge--ok'}`}>{critical} problemas críticos</span>{' '}
        <span className="badge badge--soft">{issues.length - critical} optimizaciones</span>
      </p>
      {mission.stage === 'DESIGN' && (
        <button className="btn" style={{ marginTop: 10 }} disabled={!mission.design.chassisId} onClick={() => navigate('analysis')} title={mission.design.chassisId ? undefined : 'Construye la nave en el Spacecraft Lab'}>
          Analizar y aprobar el diseño →
        </button>
      )}
    </div>
  );
}

function ProgressTab({ mission }: { mission: Mission }) {
  const navigate = useGameStore((s) => s.navigate);
  return (
    <>
      <DesignStatus mission={mission} />
      <ol className="stages">
        {STAGE_ORDER.filter((s) => s !== 'COMPLETE').map((stage, i) => {
          const st = stageStatus(mission, stage);
          const info = STAGE_INFO[stage];
          return (
            <li key={stage} className={`stage-item stage-item--${st}`}>
              <span className="stage-item__dot">{st === 'done' ? '✓' : i + 1}</span>
              <span>
                <strong>{info.label}</strong>
                <br />
                <span className="small muted">{info.description}</span>
              </span>
              <span className={`badge ${st === 'current' ? 'badge--ok' : st === 'done' ? 'badge--info' : 'badge--lock'}`}>
                {st === 'current' ? 'En curso' : st === 'done' ? 'Hecho' : 'Bloqueada'}
              </span>
            </li>
          );
        })}
      </ol>
      <p className="small muted">Cada etapa se desbloquea al superar la anterior: no se puede lanzar una nave que no supere el análisis de ingeniería.</p>
      {mission.stage === 'DESIGN' && (
        <button className="btn btn--primary btn--glow" onClick={() => navigate('lab')}>
          Siguiente: Construir nave →
        </button>
      )}
      {mission.stage === 'PLANNING' && (
        <button className="btn btn--primary" onClick={() => navigate('planner')}>
          Abrir Mission Planner
        </button>
      )}
      {mission.stage === 'LAUNCH' && (
        <button className="btn btn--primary" onClick={() => navigate('flight')}>
          Ir a Launch Control
        </button>
      )}
      {mission.stage === 'OPERATIONS' && (
        <button className="btn btn--primary" onClick={() => navigate('flight')}>
          Ir a Operaciones
        </button>
      )}
      {(mission.stage === 'DEBRIEF' || mission.stage === 'COMPLETE') && (
        <button className="btn btn--primary" onClick={() => navigate('flight')}>
          Ver informe de la misión
        </button>
      )}
    </>
  );
}

export function CenterScreen() {
  const mission = useGameStore(selectActiveMission);
  const tab = useGameStore((s) => s.centerTab);
  const setTab = useGameStore((s) => s.setCenterTab);
  const selectOpen = useGameStore((s) => s.missionSelectOpen);
  const openMissionSelect = useGameStore((s) => s.openMissionSelect);
  const navigate = useGameStore((s) => s.navigate);
  const savedCount = useGameStore((s) => s.missions.length);
  const template = mission ? templateForMission(mission) : undefined;
  const showPanel = !!mission || tab === 'budget';

  return (
    <>
      <div className="hero">
        {mission && template ? (
          <>
            <p className="eyebrow">Misión activa · {STAGE_INFO[mission.stage].label}</p>
            <h1 className="h1" style={{ fontSize: 'clamp(1.6rem, 3vw, 2.4rem)', marginTop: 6 }}>
              {mission.name}
            </h1>
            <p className="muted">{template.name}</p>
            <div className="hero__actions">
              {mission.stage === 'DESIGN' ? (
                <button className="btn btn--primary btn--glow" onClick={() => navigate('lab')}>
                  Siguiente: Construir nave →
                </button>
              ) : (
                <button className="btn btn--primary" onClick={() => navigate('lab')}>
                  Spacecraft Lab
                </button>
              )}
              <button className="btn" onClick={() => openMissionSelect(true)}>
                Nueva misión
              </button>
            </div>
          </>
        ) : (
          <>
            <p className="eyebrow">Agencia espacial · Centro de operaciones</p>
            <h1 className="h1" style={{ marginTop: 8 }}>
              NEXUS
              <br />
              Mission Control
            </h1>
            <p className="hero__motto">DESIGN · BUILD · LAUNCH · DISCOVER</p>
            <p className="muted">
              Diriges una agencia espacial. Diseña una nave, planifica su órbita, lánzala y opérala. Cada decisión de ingeniería tiene consecuencias en vuelo.
            </p>
            <div className="hero__actions">
              <button className="btn btn--primary" onClick={() => openMissionSelect(true)}>
                Nueva misión
              </button>
              <button className="btn" onClick={() => navigate('archive')}>
                Misiones guardadas ({savedCount})
              </button>
            </div>
          </>
        )}
        <p className="hint">La sala es interactiva: pulsa el holograma lunar o cualquier consola.</p>
      </div>

      {showPanel && (
        <Panel
          className="side-panel"
          eyebrow={template ? `${template.code} · Expediente` : 'Finanzas'}
          title={template ? template.name : 'Presupuesto de misión'}
          onClose={mission ? undefined : () => setTab('objectives')}
          tabs={
            mission ? (
              <div className="tabs" role="tablist">
                {TABS.map((t) => (
                  <button key={t.id} role="tab" className="tab" aria-selected={tab === t.id} onClick={() => setTab(t.id)}>
                    {t.label}
                  </button>
                ))}
              </div>
            ) : undefined
          }
        >
          {mission && template ? (
            tab === 'objectives' ? (
              <ObjectivesTab mission={mission} template={template} />
            ) : tab === 'budget' ? (
              <BudgetTab mission={mission} template={template} />
            ) : (
              <ProgressTab mission={mission} />
            )
          ) : (
            <BudgetTab mission={null} template={LUNA_01} />
          )}
        </Panel>
      )}

      {selectOpen && <MissionSelect />}
    </>
  );
}
