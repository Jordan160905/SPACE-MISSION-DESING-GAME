import { useEffect } from 'react';
import { MISSION_TEMPLATES } from '../../data/missions/missions';
import { useGameStore } from '../../state/useGameStore';
import { IconLock } from '../components/icons';
import { Panel } from '../components/Panel';

const TARGET_LABEL = { MOON: 'Luna', MARS: 'Marte', EARTH: 'Tierra' } as const;

export function MissionSelect() {
  const openBriefing = useGameStore((s) => s.openBriefing);
  const close = useGameStore((s) => s.openMissionSelect);
  const completed = useGameStore((s) => s.profile.completedMissionIds);
  const missions = useGameStore((s) => s.missions);
  // Una misión se desbloquea cuando otra con éxito la incluye en sus recompensas.
  const unlocked = new Set(
    MISSION_TEMPLATES.filter((t) => missions.some((m) => m.templateId === t.id && completed.includes(m.id))).flatMap((t) => t.rewards.unlocks),
  );

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && close(false);
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [close]);

  return (
    <div className="modal-backdrop" onClick={() => close(false)}>
      <div className="modal" role="dialog" aria-modal="true" aria-label="Seleccionar misión" onClick={(e) => e.stopPropagation()}>
        <Panel eyebrow="Nueva misión" title="Selecciona un escenario" onClose={() => close(false)}>
          <div className="mission-grid">
            {MISSION_TEMPLATES.map((m) => (
              <button
                key={m.id}
                className="mission-card"
                aria-disabled={!m.available}
                onClick={() => m.available && openBriefing(m.id)}
                title={m.available ? `Abrir briefing de ${m.code}` : m.lockReason}
              >
                <span style={{ display: 'flex', justifyContent: 'space-between', width: '100%' }}>
                  <span className="badge badge--info">{TARGET_LABEL[m.target]}</span>
                  {!m.available && (
                    <span className="badge badge--lock">
                      <IconLock /> Bloqueada
                    </span>
                  )}
                </span>
                <span className="mission-card__code">{m.code}</span>
                <strong>{m.name}</strong>
                <span className="small muted">{m.tagline}</span>
                <span className="small" style={{ marginTop: 'auto', color: m.available ? 'var(--accent)' : 'var(--text-lo)' }}>
                  {m.available
                    ? `Presupuesto ${m.budgetCapMUSD} MUSD · ${m.durationDays} días →`
                    : unlocked.has(m.id)
                      ? '¡Desbloqueada! Escenario en preparación para una próxima versión.'
                      : m.lockReason}
                </span>
              </button>
            ))}
          </div>
        </Panel>
      </div>
    </div>
  );
}
