import { useState } from 'react';
import { GLOSSARY } from '../../data/glossary';
import { useGameStore } from '../../state/useGameStore';
import { Panel } from '../components/Panel';

function normalize(s: string): string {
  return s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
}

export function GlossaryScreen() {
  const navigate = useGameStore((s) => s.navigate);
  const [q, setQ] = useState('');
  const nq = normalize(q.trim());
  const results = GLOSSARY.filter((g) => !nq || normalize(`${g.term} ${g.short} ${g.tags.join(' ')}`).includes(nq));

  return (
    <Panel className="side-panel" eyebrow="Biblioteca" title="Glosario espacial" onClose={() => navigate('center')}>
      <input className="search" type="search" placeholder="Buscar término o tema (p. ej. energía, órbita)…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Buscar en el glosario" />
      {results.length === 0 && <p className="muted">Sin resultados para “{q}”.</p>}
      {results.map((g) => (
        <article key={g.term} className="term">
          <h3 className="h3" style={{ fontSize: 'var(--fs-md)' }}>
            {g.term}
            {g.unit && <span className="term__unit">{g.unit}</span>}
          </h3>
          <p className="small" style={{ margin: '4px 0' }}>
            {g.short}
          </p>
          <p className="small muted" style={{ margin: 0 }}>
            {g.detail}
          </p>
        </article>
      ))}
    </Panel>
  );
}
