/**
 * Mission Planner, organizado en cuatro ventanas:
 *  1. Vehículo de lanzamiento (catálogo real de «CubeSat 101») junto a los recursos de la misión.
 *  2. Órbita lunar (altitud, inclinación, duración) con el simulador de órbita elíptica.
 *  3. Ventana de lanzamiento (calendario).
 *  4. Verificaciones, presupuesto de Δv y problemas → confirmar el plan.
 * Cada cambio se guarda y se verifica al momento con sim/PlanningSystem; nada se calcula aquí.
 * El holograma del Mission Center (detrás) muestra la órbita elegida.
 */
import { useEffect, useMemo, useState } from 'react';
import { getComponent } from '../../data/components/catalog';
import { templateForMission } from '../../data/missions/missions';
import type { MissionPlan } from '../../data/schemas';
import { analyzePlan, type PlanReport } from '../../sim/PlanningSystem';
import { coverageFraction, windowInfo } from '../../sim/TrajectorySystem';
import { fmtNum, formatMUSD } from '../../sim/units';
import { STAGE_ORDER } from '../../state/missionLogic';
import { selectActiveMission, useGameStore } from '../../state/useGameStore';
import { Meter, Panel } from '../components/Panel';
import { EllipticalOrbitLab } from '../planner/EllipticalOrbitLab';
import { LauncherCatalog } from '../planner/LauncherCatalog';
import { ResourcePanel } from '../analysis/ResourcePanel';
import { missionResources } from '../../sim/ResourceSystem';
import { numLocale } from '../../i18n/lang';

// Se crea al formatear para seguir el idioma elegido.
const DATE_FMT = { format: (d: Date) => new Intl.DateTimeFormat(numLocale(), { day: 'numeric', month: 'short', timeZone: 'UTC' }).format(d) };

function orbitExplanation(i: number, h: number): string {
  const type =
    i >= 85
      ? 'Órbita polar: la Luna gira bajo la nave y, con el tiempo, toda la superficie pasa por debajo, polos incluidos.'
      : i < 15
        ? 'Órbita casi ecuatorial: siempre sobrevuela las mismas latitudes bajas; nunca verás los polos.'
        : `Órbita inclinada: sobrevuela latitudes entre −${i}° y +${i}°, pero no los polos.`;
  const alt =
    h < 50
      ? ' Muy baja: máximo detalle, pero los mascons (concentraciones de masa) la deforman rápido y mantenerla gasta propelente.'
      : h > 150
        ? ' Alta: órbita estable y barata de mantener, eclipses más cortos, pero los instrumentos ven con menos detalle.'
        : ' Altitud intermedia: buen equilibrio entre detalle y estabilidad.';
  return type + alt;
}

function Check({ ok, warn, label, value }: { ok: boolean; warn?: boolean; label: string; value: string }) {
  return (
    <li className={`check ${ok ? (warn ? 'check--warn' : 'check--ok') : 'check--bad'}`}>
      <span className="check__icon" aria-hidden="true">
        {ok ? (warn ? '!' : '✓') : '✗'}
      </span>
      <span className="check__label">{label}</span>
      <span className="check__value">{value}</span>
    </li>
  );
}

function DeltaVBar({ r }: { r: PlanReport }) {
  const d = r.deltaV;
  const total = Math.max(d.availableMS, Number.isFinite(d.requiredMS) ? d.requiredMS : 0, 1);
  const seg = (v: number) => `${(Math.max(0, v) / total) * 100}%`;
  return (
    <div className="dv">
      <div className="dv__bar" role="img" aria-label={`Δv necesario ${fmtNum(d.requiredMS, 0)} m/s de ${fmtNum(d.availableMS, 0)} disponibles`}>
        <span className="dv__seg dv__seg--loi" style={{ width: seg(d.loiMS) }} title="Inserción en órbita lunar" />
        <span className="dv__seg dv__seg--sk" style={{ width: seg(d.stationKeepingMS) }} title="Mantenimiento orbital" />
        <span className="dv__seg dv__seg--tcm" style={{ width: seg(d.tcmMS) }} title="Correcciones de trayectoria" />
        {Number.isFinite(d.windowPenaltyMS) && d.windowPenaltyMS > 0 && <span className="dv__seg dv__seg--win" style={{ width: seg(d.windowPenaltyMS) }} title="Fuera de ventana óptima" />}
        <span className="dv__avail" style={{ left: seg(d.availableMS) }} />
      </div>
      <div className="dv__legend small">
        <span><i className="dv__dot dv__seg--loi" />Inserción {fmtNum(d.loiMS, 0)}</span>
        <span><i className="dv__dot dv__seg--sk" />Mantenimiento {fmtNum(d.stationKeepingMS, 0)}</span>
        <span><i className="dv__dot dv__seg--tcm" />Correcciones {d.tcmMS}</span>
        {d.windowPenaltyMS > 0 && Number.isFinite(d.windowPenaltyMS) && <span><i className="dv__dot dv__seg--win" />Ventana {fmtNum(d.windowPenaltyMS, 0)}</span>}
        <span><i className="dv__dot dv__dot--avail" />Disponible {fmtNum(d.availableMS, 0)} m/s</span>
      </div>
      <details className="an-how">
        <summary>¿Cómo se calcula?</summary>
        <div className="small muted">
          Disponible (Tsiolkovsky) = Isp · g₀ · ln(masa húmeda / masa seca) = {d.ispS} s · 9,807 · ln({fmtNum(d.wetKg)} / {fmtNum(d.dryKg)}).
          Inserción = √(v∞² + 2μ/r) − √(μ/r), con llegada a v∞ = 0,8 km/s. Mantenimiento = 0,4 m/s/día a 50 km, escalado (50/h)^1,5 (las órbitas bajas
          se degradan más). Correcciones de trayectoria: 30 m/s.
        </div>
      </details>
    </div>
  );
}

export function PlannerScreen() {
  const mission = useGameStore(selectActiveMission);
  const navigate = useGameStore((s) => s.navigate);
  const update = useGameStore((s) => s.plannerUpdate);
  const confirmPlan = useGameStore((s) => s.confirmPlan);
  const requestDecision = useGameStore((s) => s.requestDecision);
  // Confirmar el plan lleva a la Revisión (la junta revisa antes del vuelo).
  const toReview = () => {
    confirmPlan();
    const st = selectActiveMission(useGameStore.getState())?.stage;
    if (st && STAGE_ORDER.indexOf(st) >= STAGE_ORDER.indexOf('LAUNCH')) navigate('review');
  };
  const confirm = () =>
    requestDecision(
      { kind: 'plan', label: '¿Confirmamos este plan de vuelo para el lanzamiento?', options: [{ id: 'approve', label: 'Confirmar' }, { id: 'reject', label: 'Seguir ajustando' }] },
      toReview,
    );
  const setView = useGameStore((s) => s.labSetView);
  const [win, setWin] = useState(0);
  // Cada ventana empieza arriba: no se hereda el desplazamiento de la anterior.
  useEffect(() => {
    document.querySelector('.planner .panel__body')?.scrollTo({ top: 0 });
  }, [win]);
  const template = mission ? templateForMission(mission) : undefined;
  const objective = template?.objectives.find((o) => o.id === mission?.objectiveId);

  const report = useMemo(
    () =>
      mission?.plan && template
        ? analyzePlan({ design: mission.design, lookup: getComponent, template, objectiveId: mission.objectiveId, plan: mission.plan, difficulty: mission.difficulty })
        : null,
    [mission, template],
  );

  if (!mission || !template) {
    return (
      <Panel className="side-panel" eyebrow="Mission Planner" title="Sin misión activa" onClose={() => navigate('center')}>
        <p className="muted">Crea o carga una misión para planificar su vuelo.</p>
      </Panel>
    );
  }
  if (STAGE_ORDER.indexOf(mission.stage) < STAGE_ORDER.indexOf('PLANNING') || !mission.plan || !report) {
    return (
      <Panel className="side-panel" eyebrow="Mission Planner" title="Primero, aprueba el diseño" onClose={() => navigate('center')}>
        <p className="muted">
          No se puede planificar el vuelo de una nave que no ha superado el análisis de ingeniería. Termina el diseño en el Spacecraft Lab y apruébalo en el
          análisis del diseño.
        </p>
        <button className="btn btn--primary" onClick={() => navigate('analysis')}>
          Ir al análisis del diseño
        </button>
      </Panel>
    );
  }

  const plan: MissionPlan = mission.plan;
  const r = report;
  const e = r.engineering;
  const critical = r.issues.filter((i) => i.severity === 'critical');
  const optim = r.issues.filter((i) => i.severity === 'optimization');
  const [hMin, hMax] = objective?.recommendedOrbit.altitudeKm ?? [50, 100];
  const [iMin, iMax] = objective?.recommendedOrbit.inclinationDeg ?? [85, 95];
  const confirmed = mission.stage !== 'PLANNING';

  // Estado de cada ventana con las mismas verificaciones del plan.
  const winOk = [
    r.massFits && r.fairingFits && !!e.budget && !e.budget.overBudget,
    !!e.power?.sustainable && (!e.data || e.data.targetGbit === 0 || e.data.targetMet) && r.deltaV.ok,
    r.window.status !== 'closed',
    r.ready,
  ];
  const winWarn = [false, r.deltaV.marginFraction < 0.1, r.window.status === 'marginal', optim.length > 0];
  const WINDOWS = ['Vehículo de lanzamiento', 'Órbita lunar', 'Ventana de lanzamiento', 'Verificaciones y Δv'];
  const go = (i: number) => setWin(Math.max(0, Math.min(WINDOWS.length - 1, i)));

  return (
    <Panel
      className="wide-panel planner"
      eyebrow={`Mission Planner · ${mission.name}`}
      title="Plan de vuelo"
      onClose={() => navigate('center')}
      aside={confirmed ? <span className="badge badge--ok">Confirmado</span> : undefined}
      footer={
        <>
          <span className="small">
            {r.ready ? (
              <span style={{ color: 'var(--ok)' }}>Plan viable{optim.length ? ` · ${optim.length} ${optim.length === 1 ? 'optimización' : 'optimizaciones'}` : ''}</span>
            ) : (
              <span style={{ color: 'var(--critical)' }}>{critical.length} problema(s) crítico(s)</span>
            )}
          </span>
          <span className="pl-foot">
            <button className="btn btn--ghost" disabled={win === 0} onClick={() => go(win - 1)}>
              ← Anterior
            </button>
            {win < WINDOWS.length - 1 && (
              <button className="btn" onClick={() => go(win + 1)}>
                Siguiente: {WINDOWS[win + 1]} →
              </button>
            )}
            <button
              className="btn btn--ghost"
              onClick={() => {
                navigate('lab');
                setView('rocket');
              }}
            >
              Ver en el cohete
            </button>
            {win === WINDOWS.length - 1 ? (
              <button
                className={`btn btn--primary ${confirmed || r.ready ? 'btn--glow' : ''}`}
                disabled={!confirmed && !r.ready}
                title={!confirmed && !r.ready ? 'Resuelve los problemas críticos para continuar' : undefined}
                onClick={() => (confirmed ? navigate('review') : confirm())}
              >
                Siguiente: Revisión →
              </button>
            ) : (
              !confirmed && (
                <button className="btn btn--primary" disabled={!r.ready} onClick={confirm}>
                  Confirmar plan → Revisión
                </button>
              )
            )}
          </span>
        </>
      }
    >
      <div className="pl-tabs" role="tablist" aria-label="Ventanas del plan de vuelo">
        {WINDOWS.map((w, i) => (
          <button
            key={w}
            id={`pl-tab-${i}`}
            role="tab"
            aria-selected={win === i}
            aria-controls={`pl-win-${i}`}
            className={`pl-tab ${winOk[i] ? (winWarn[i] ? 'pl-tab--warn' : 'pl-tab--ok') : 'pl-tab--bad'}`}
            onClick={() => go(i)}
          >
            <span className="pl-tab__n">{i + 1}</span>
            <span className="pl-tab__label">{w}</span>
            <span className="pl-tab__state" aria-label={winOk[i] ? (winWarn[i] ? 'con avisos' : 'correcto') : 'con problemas'}>
              {winOk[i] ? (winWarn[i] ? '!' : '✓') : '✗'}
            </span>
          </button>
        ))}
      </div>

      {win === 0 && (
        <div className="pl-window" role="tabpanel" id={`pl-win-${win}`} aria-labelledby={`pl-tab-${win}`}>
          <div className="pl-split">
            <div>
              <p className="eyebrow">1 · Vehículo de lanzamiento</p>
              <LauncherCatalog report={r} onChoose={(id) => update({ launcherId: id })} />
            </div>
            <div>
              <p className="eyebrow">Recursos de la misión</p>
              <ResourcePanel report={missionResources(e, r)} compact />
            </div>
          </div>
        </div>
      )}

      {win === 1 && (
        <div className="pl-window" role="tabpanel" id={`pl-win-${win}`} aria-labelledby={`pl-tab-${win}`}>
          <div className="pl-split">
            <div>
              <p className="eyebrow">2 · Órbita lunar</p>
              <label className="slider">
                <span className="slider__head">
                  <span>Altitud</span>
                  <strong className="mono">{plan.altitudeKm} km</strong>
                </span>
                <input type="range" min={20} max={300} step={5} value={plan.altitudeKm} onChange={(ev) => update({ altitudeKm: Number(ev.target.value) })} aria-label="Altitud de la órbita (km)" />
                <span className="slider__hint small muted">
                  Recomendada para tu objetivo: {hMin}–{hMax} km
                </span>
              </label>
              <label className="slider">
                <span className="slider__head">
                  <span>Inclinación</span>
                  <strong className="mono">{plan.inclinationDeg}°</strong>
                </span>
                <input type="range" min={0} max={90} step={1} value={plan.inclinationDeg} onChange={(ev) => update({ inclinationDeg: Number(ev.target.value) })} aria-label="Inclinación de la órbita (grados)" />
                <span className="slider__hint small muted">
                  Recomendada: {iMin}–{Math.min(90, iMax)}° · cobertura {Math.round(coverageFraction(plan.inclinationDeg) * 100)} % de la superficie
                </span>
              </label>
              <p className="small orbit-note">{orbitExplanation(plan.inclinationDeg, plan.altitudeKm)}</p>
              <dl className="kv">
                <dt>Periodo · velocidad</dt>
                <dd>
                  {fmtNum(e.orbit.periodMin)} min · {fmtNum(e.orbit.velocityKmS, 2)} km/s
                </dd>
                <dt>Eclipse por órbita</dt>
                <dd>
                  {fmtNum(e.orbit.eclipseMin)} min ({Math.round(e.orbit.eclipseFraction * 100)} %)
                </dd>
                <dt>Energía en esta órbita</dt>
                <dd className={e.power?.sustainable ? 'ok' : 'bad'}>{e.power ? `${e.power.orbitBalanceWh >= 0 ? '+' : ''}${fmtNum(e.power.orbitBalanceWh)} Wh/órbita` : '—'}</dd>
                <dt>Datos del objetivo</dt>
                <dd className={!e.data || e.data.targetGbit === 0 || e.data.targetMet ? 'ok' : 'bad'}>
                  {e.data ? `${fmtNum(e.data.missionDeliveredGbit, 0)} / ${e.data.targetGbit.toLocaleString(numLocale())} Gbit` : '—'}
                </dd>
              </dl>
              <p className="eyebrow" style={{ marginTop: 16 }}>
                Duración de la campaña
              </p>
              <label className="slider">
                <span className="slider__head">
                  <span>Campaña de observación</span>
                  <strong className="mono">{plan.durationDays} días</strong>
                </span>
                <input type="range" min={30} max={120} step={5} value={plan.durationDays} onChange={(ev) => update({ durationDays: Number(ev.target.value) })} aria-label="Duración de la misión (días)" />
                <span className="slider__hint small muted">
                  Más días: más datos, pero más operación ({formatMUSD(template.opsCostPerDayMUSD)}/día) y más propelente de mantenimiento.
                </span>
              </label>
            </div>
            <div>
              <p className="eyebrow">Simulador de órbita elíptica</p>
              <EllipticalOrbitLab circularAltKm={plan.altitudeKm} usefulAltKm={hMax} />
            </div>
          </div>
        </div>
      )}

      {win === 2 && (
        <div className="pl-window" role="tabpanel" id={`pl-win-${win}`} aria-labelledby={`pl-tab-${win}`}>
          <p className="eyebrow">3 · Ventana de lanzamiento</p>
          <div className="calendar calendar--big" role="radiogroup" aria-label="Día de lanzamiento">
            {Array.from({ length: 60 }, (_, d) => {
              const w = windowInfo(d);
              return (
                <button
                  key={d}
                  role="radio"
                  aria-checked={plan.launchDay === d}
                  aria-label={`Día ${d}: ${DATE_FMT.format(w.date)}, ventana ${w.status === 'optimal' ? 'óptima' : w.status === 'marginal' ? 'marginal' : 'cerrada'}`}
                  className={`cal-day cal-day--${w.status}`}
                  onClick={() => update({ launchDay: d })}
                  title={DATE_FMT.format(w.date)}
                >
                  {w.date.getUTCDate()}
                </button>
              );
            })}
          </div>
          <div className={`pl-window-info pl-window-info--${r.window.status}`}>
            <strong>
              Ventana {r.window.status === 'optimal' ? 'óptima' : r.window.status === 'marginal' ? 'marginal' : 'cerrada'} · lanzamiento {DATE_FMT.format(r.window.date)} · llegada{' '}
              {DATE_FMT.format(r.window.arrivalDate)}
            </strong>
            <span className="small">
              {r.window.status === 'optimal'
                ? 'La Luna está en buena posición: no hace falta propelente extra.'
                : r.window.status === 'marginal'
                  ? `Se puede lanzar, pero corregir la trayectoria cuesta ${fmtNum(r.deltaV.windowPenaltyMS, 0)} m/s de Δv extra.`
                  : 'La geometría Tierra–Luna no permite llegar este día: elige otro.'}
            </span>
          </div>
          <p className="small muted" style={{ marginTop: 6 }}>
            4 días de viaje. <span className="cal-legend cal-day--optimal">óptima</span> <span className="cal-legend cal-day--marginal">marginal (+Δv)</span>{' '}
            <span className="cal-legend cal-day--closed">cerrada</span>. Las ventanas se repiten cada mes lunar (29,5 días).
          </p>
        </div>
      )}

      {win === 3 && (
        <div className="pl-window" role="tabpanel" id={`pl-win-${win}`} aria-labelledby={`pl-tab-${win}`}>
          <div className="pl-split">
            <div>
              <p className="eyebrow">4 · Verificaciones</p>
              <ul className="checks">
                <Check ok={r.massFits} label="Masa frente al lanzador" value={`${fmtNum(r.massWithMarginKg)} / ${r.launcher.payloadToTLIKg.toLocaleString(numLocale())} kg`} />
                <Check
                  ok={r.fairingFits}
                  label="Nave plegada en la cofia"
                  value={r.envelope ? `Ø ${fmtNum(r.envelope.diameterM, 2)} / ${fmtNum(r.launcher.fairing.innerDiameterM, 2)} m` : '—'}
                />
                <Check ok={r.deltaV.ok && r.window.status !== 'closed'} warn={r.deltaV.marginFraction < 0.1} label="Propelente (Δv)" value={`${fmtNum(r.deltaV.availableMS, 0)} / ${Number.isFinite(r.deltaV.requiredMS) ? fmtNum(r.deltaV.requiredMS, 0) : '∞'} m/s`} />
                <Check ok={r.window.status !== 'closed'} warn={r.window.status === 'marginal'} label="Ventana de lanzamiento" value={r.window.status === 'optimal' ? 'óptima' : r.window.status === 'marginal' ? 'marginal' : 'cerrada'} />
                <Check ok={!!e.power?.sustainable} label="Energía en esta órbita" value={e.power ? `${e.power.orbitBalanceWh >= 0 ? '+' : ''}${fmtNum(e.power.orbitBalanceWh)} Wh/órbita` : '—'} />
                <Check
                  ok={!!e.data && (e.data.targetGbit === 0 || e.data.targetMet)}
                  label="Datos del objetivo"
                  value={e.data ? `${fmtNum(e.data.missionDeliveredGbit, 0)} / ${e.data.targetGbit.toLocaleString(numLocale())} Gbit` : '—'}
                />
                <Check
                  ok={!!e.budget && !e.budget.overBudget}
                  label="Presupuesto total"
                  value={e.budget ? `${fmtNum(e.budget.committedMUSD)} / ${e.budget.capMUSD} MUSD` : '—'}
                />
              </ul>
              {e.budget && <Meter value={e.budget.usedFraction} warn={e.budget.overBudget} label="Presupuesto comprometido" />}
            </div>
            <div>
              <p className="eyebrow">Presupuesto de Δv</p>
              <DeltaVBar r={r} />
              {r.issues.length > 0 ? (
                <>
                  <p className="eyebrow" style={{ marginTop: 16 }}>
                    Problemas
                  </p>
                  <ul className="issues">
                    {[...critical, ...optim].map((i) => (
                      <li key={i.id} className={`issue issue--${i.severity}`}>
                        <span className={`badge ${i.severity === 'critical' ? 'badge--hard' : 'badge--soft'}`}>{i.severity === 'critical' ? 'Crítico' : 'Optimizar'}</span>{' '}
                        <strong className="small">{i.title}</strong>
                        <p className="small muted">{i.explanation}</p>
                      </li>
                    ))}
                  </ul>
                </>
              ) : (
                <p className="small ok" style={{ marginTop: 16 }}>
                  Sin problemas: el plan está listo para confirmarse.
                </p>
              )}
              {critical.some((i) => !i.id.startsWith('plan-') && !i.id.startsWith('budget') && !i.id.startsWith('energy') && !i.id.startsWith('battery') && !i.id.startsWith('data')) && (
                <button className="btn" style={{ marginTop: 12 }} onClick={() => navigate('lab')}>
                  Corregir el diseño en el Lab
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </Panel>
  );
}
