/**
 * Pantalla de vuelo (Fase 5). Según la etapa de la misión muestra:
 *  - LAUNCH      → Launch Control (verificación GO/NO-GO, cuenta regresiva, ascenso, separación, crucero y
 *                  llegada). Fase 8.1: HUD que deja libre el centro de la escena 3D, cinco cámaras y
 *                  telemetría de la trayectoria física (sim/FlightDynamics).
 *  - OPERATIONS  → consola de operaciones (sistemas, instrumentos, tiempo, telemetría, registro).
 *  - DEBRIEF     → resumen de la campaña (el informe completo llega en la Fase 6).
 * Todos los números salen de sim/ (LaunchSystem, MissionSystem, PlanningSystem).
 */
import { useEffect, useMemo, useState } from 'react';
import { getComponent } from '../../data/components/catalog';
import { templateForMission } from '../../data/missions/missions';
import type { Mission } from '../../data/schemas';
import { buildFlightModel, snapshot } from '../../sim/MissionSystem';
import { fmtNum } from '../../sim/units';
import { STAGE_ORDER } from '../../state/missionLogic';
import { selectActiveMission, useGameStore, type OpsSample } from '../../state/useGameStore';
import { Meter, Panel } from '../components/Panel';
import { TrajectoryMap } from '../flight/TrajectoryMap';
import { EventDecision } from '../flight/EventDecision';
import { DebriefScreen } from './DebriefScreen';
import { trajectoryAt } from '../flight/trajectory';
import { numLocale } from '../../i18n/lang';
import { LaunchControlCenter } from '../flight/LaunchControlCenter';
import { SurfaceHUD } from '../surface/SurfaceHUD';
import { useSurface } from '../surface/surfaceStore';

// ───────────────────────── Operaciones ─────────────────────────

function Sparkline({ samples, pick, color, label }: { samples: OpsSample[]; pick: (s: OpsSample) => number; color: string; label: string }) {
  const pts = samples.slice(-400);
  if (pts.length < 2) return <div className="spark spark--empty small muted">Sin datos todavía</div>;
  const t0 = pts[0].tH;
  const t1 = pts[pts.length - 1].tH || 1;
  const d = pts.map((s, i) => `${i ? 'L' : 'M'}${(((s.tH - t0) / Math.max(1e-9, t1 - t0)) * 100).toFixed(2)},${(40 - pick(s) * 38).toFixed(2)}`).join(' ');
  return (
    <svg className="spark" viewBox="0 0 100 42" preserveAspectRatio="none" role="img" aria-label={label}>
      <line x1="0" x2="100" y1="2" y2="2" className="spark__grid" />
      <line x1="0" x2="100" y1="40" y2="40" className="spark__grid" />
      <path d={d} fill="none" stroke={color} strokeWidth="1.2" vectorEffect="non-scaling-stroke" />
    </svg>
  );
}

/** Referencia estable: un selector que devuelve `[]` nuevo cada vez provoca un bucle infinito de renders. */
const NO_SAMPLES: OpsSample[] = [];

const SPEEDS = [
  { label: '1 órbita/s', hours: 2 },
  { label: '6 h/s', hours: 6 },
  { label: '1 día/s', hours: 24 },
];

function OpsConsole({ mission }: { mission: Mission }) {
  const advance = useGameStore((s) => s.opsAdvance);
  const setInstrument = useGameStore((s) => s.opsSetInstrument);
  const history = useGameStore((s) => (s.opsHistory.missionId === mission.id ? s.opsHistory.samples : NO_SAMPLES));
  const [playing, setPlaying] = useState(false);
  const [speed, setSpeed] = useState(SPEEDS[0].hours);
  const template = templateForMission(mission)!;
  const objective = template.objectives.find((o) => o.id === mission.objectiveId);
  const model = useMemo(
    () => (mission.plan ? buildFlightModel(mission.design, getComponent, mission.plan, objective?.dataTargetGbit ?? 0) : null),
    [mission.design, mission.plan, objective],
  );
  const f = mission.flight;
  const done = mission.stage !== 'OPERATIONS';
  const pending = !!f?.pendingEventId;

  useEffect(() => {
    if (!playing || done || pending) return;
    const id = window.setInterval(() => advance(speed / 4), 250);
    return () => window.clearInterval(id);
  }, [playing, speed, advance, done, pending]);
  useEffect(() => {
    if (done || pending) setPlaying(false);
  }, [done, pending]);

  if (!model || !f) return null;
  const s = snapshot(model, f);
  const day = Math.floor(f.elapsedH / 24);
  const hours = f.elapsedH - day * 24;
  const progress = f.elapsedH / model.durationH;
  const target = objective?.dataTargetGbit ?? 0;

  return (
    <div className="flight-layout">
      <Panel className="flight-left" eyebrow={`Operaciones · ${mission.name}`} title="Estado de sistemas">
        {f.safeMode && (
          <div className="notice-band" style={{ borderColor: 'var(--critical)' }} role="alert">
            <span className="badge badge--hard">Modo seguro</span>
            <span>Batería agotada: instrumentos apagados hasta recuperar el 60 %. Reduce el consumo o espera a la luz.</span>
          </div>
        )}
        <h3 className="section-title">Energía</h3>
        <div className="sys-row">
          <span>Batería</span>
          <strong className="mono">{Math.round(s.batteryFraction * 100)} %</strong>
        </div>
        <Meter value={s.batteryFraction} warn={s.batteryFraction < 0.3} label="Batería" />
        <dl className="kv" style={{ marginTop: 8 }}>
          <dt>Generación / consumo</dt>
          <dd>
            {fmtNum(s.genW)} / {fmtNum(s.loadW)} W
          </dd>
          <dt>Posición</dt>
          <dd>{s.sunlit ? '☀ Iluminada' : '● Eclipse'}</dd>
        </dl>

        <h3 className="section-title">Comunicaciones y datos</h3>
        <dl className="kv">
          <dt>Enlace con Tierra</dt>
          <dd>{s.contact ? `En contacto · ${fmtNum(model.downlinkGbitPerH)} Gbit/h` : !s.stationAvailable ? `Sin estación (vuelve en ${fmtNum(s.nextStationH)} h)` : 'Tierra oculta por la Luna'}</dd>
          <dt>Memoria</dt>
          <dd>
            {fmtNum(f.storageGbit)} / {model.storageCapacityGbit} Gbit
          </dd>
          <dt>Perdidos (memoria llena)</dt>
          <dd>{fmtNum(f.lostGbit)} Gbit</dd>
        </dl>
        <Meter value={s.storageFraction} warn={s.storageFraction > 0.95} label="Memoria" />

        <h3 className="section-title">Instrumentos</h3>
        {model.instruments.length === 0 && <p className="small muted">La nave no lleva instrumentos.</p>}
        {model.instruments.map((i) => {
          const on = !f.instrumentsOff.includes(i.instanceId);
          const working = s.activeInstrumentIds.includes(i.instanceId);
          return (
            <div key={i.instanceId} className="instr">
              <span>
                <strong>{i.name}</strong>
                <br />
                <span className="small muted">
                  {i.drawW} W · {i.dataGbitPerH} Gbit/h · {i.requiresSunlight ? 'solo con luz' : 'también en sombra'}
                  {on && !working ? (f.safeMode ? ' · bloqueado (modo seguro)' : ' · en espera (eclipse)') : ''}
                </span>
              </span>
              <button
                className={`switch ${on ? 'switch--on' : ''}`}
                role="switch"
                aria-checked={on}
                aria-label={`${i.name}: ${on ? 'encendido' : 'apagado'}`}
                disabled={done}
                onClick={() => setInstrument(i.instanceId, !on)}
              >
                <span />
              </button>
            </div>
          );
        })}

        <h3 className="section-title">Propulsión</h3>
        <dl className="kv">
          <dt>Propelente</dt>
          <dd>{fmtNum(f.propellantKg)} kg</dd>
          <dt>Δv restante</dt>
          <dd>{fmtNum(s.deltaVLeftMS, 0)} m/s</dd>
        </dl>
      </Panel>

      <div className="flight-center">
        <div className="panel met">
          <span className="met__label">Día de campaña</span>
          <span className="met__value" data-testid="ops-time">
            D{day} · {String(Math.floor(hours)).padStart(2, '0')}:{String(Math.floor((hours % 1) * 60)).padStart(2, '0')}
          </span>
          <span className="met__event">
            {done ? 'Campaña completada' : `${Math.round(progress * 100)} % de ${mission.plan?.durationDays} días`}
          </span>
        </div>
        <TrajectoryMap point={trajectoryAt({ kind: 'orbit', orbitPhase: s.orbitPhase })} contact={s.contact} />
        {(s.genFactor < 1 || s.stationOutage || s.offlineInstrumentIds.length > 0) && (
          <div className="panel effects" role="status">
            <span className="eyebrow">Efectos activos</span>
            {s.genFactor < 1 && <span className="badge badge--soft">Generación al {Math.round(s.genFactor * 100)} %</span>}
            {s.stationOutage && <span className="badge badge--soft">Estación caída</span>}
            {s.offlineInstrumentIds.length > 0 && <span className="badge badge--soft">{s.offlineInstrumentIds.length} instrumento(s) fuera de servicio</span>}
          </div>
        )}
      </div>
      {pending && !done && <EventDecision mission={mission} />}

      <Panel className="flight-right" eyebrow="Control de tiempo" title={done ? 'Campaña completada' : 'Avance de la simulación'}>
        <div className="time-controls">
          {[
            { label: '+1 órbita', h: model.periodH },
            { label: '+6 h', h: 6 },
            { label: '+1 día', h: 24 },
            { label: '+1 semana', h: 168 },
          ].map((b) => (
            <button key={b.label} className="chip chip--neutral" disabled={done || pending} onClick={() => advance(b.h)}>
              {b.label}
            </button>
          ))}
        </div>
        <div className="time-controls">
          <button className="chip chip--neutral" aria-pressed={playing} disabled={done || pending} onClick={() => setPlaying(!playing)}>
            {playing ? '⏸ Pausa' : '▶ Reproducir'}
          </button>
          {SPEEDS.map((sp) => (
            <button key={sp.label} className="chip chip--neutral" aria-pressed={speed === sp.hours} onClick={() => setSpeed(sp.hours)}>
              {sp.label}
            </button>
          ))}
        </div>

        <h3 className="section-title">Progreso científico</h3>
        <div className="sys-row">
          <span>Datos en Tierra</span>
          <strong className="mono">
            {fmtNum(f.deliveredGbit, 0)} / {target.toLocaleString(numLocale())} Gbit
          </strong>
        </div>
        <Meter value={target ? f.deliveredGbit / target : 0} label="Datos frente al objetivo" />

        <h3 className="section-title">Telemetría</h3>
        <span className="small muted">Batería (%)</span>
        <Sparkline samples={history} pick={(x) => x.battery} color="#7ef0a8" label="Historial de batería" />
        <span className="small muted">Memoria ocupada (%)</span>
        <Sparkline samples={history} pick={(x) => x.storage} color="#ffb547" label="Historial de memoria" />

        <h3 className="section-title">Registro de la misión</h3>
        <ol className="flight-log">
          {[...f.log].reverse().slice(0, 30).map((e, k) => (
            <li key={k} className={`log log--${e.level}`}>
              <span className="mono">D{Math.floor(e.tH / 24)} {String(Math.floor(e.tH % 24)).padStart(2, '0')}h</span> {e.text}
            </li>
          ))}
        </ol>
      </Panel>
    </div>
  );
}

// ───────────────────────── Pantalla ─────────────────────────

export function FlightScreen() {
  const mission = useGameStore(selectActiveMission);
  const navigate = useGameStore((s) => s.navigate);
  const surfaceMode = useSurface((s) => s.mode);

  if (!mission) {
    return (
      <Panel className="side-panel" eyebrow="Vuelo" title="Sin misión activa" onClose={() => navigate('center')}>
        <p className="muted">Crea o carga una misión.</p>
      </Panel>
    );
  }
  if (STAGE_ORDER.indexOf(mission.stage) < STAGE_ORDER.indexOf('LAUNCH')) {
    return (
      <Panel className="side-panel" eyebrow="Launch Control" title="Todavía no hay plan confirmado" onClose={() => navigate('center')}>
        <p className="muted">Para lanzar necesitas un diseño aprobado y un plan de vuelo confirmado en el Mission Planner.</p>
        <button className="btn btn--primary" onClick={() => navigate(mission.stage === 'DESIGN' ? 'lab' : 'planner')}>
          {mission.stage === 'DESIGN' ? 'Ir al Spacecraft Lab' : 'Ir al Mission Planner'}
        </button>
      </Panel>
    );
  }
  if (mission.stage === 'LAUNCH') return surfaceMode ? <SurfaceHUD /> : <LaunchControlCenter mission={mission} />;
  if (mission.stage === 'DEBRIEF' || mission.stage === 'COMPLETE') return <DebriefScreen mission={mission} />;
  return <OpsConsole mission={mission} />;
}
