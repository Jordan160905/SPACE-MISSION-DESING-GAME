/**
 * Descubrimientos espaciales (Fase 8.4): aviso de objeto detectado, observación con la cámara,
 * identificación, ficha científica, registro en el diario y mapa de lo descubierto.
 */
import { useEffect, useState } from 'react';
import { discoveryById, distanceTo, discoveryPoints, type DiscoveryDef, type DiscoveryZone } from '../../sim/Discoveries';
import { EARTH_MOON_KM, flightStateAt, R_EARTH } from '../../sim/FlightDynamics';
import { formatMET } from '../../sim/LaunchSystem';
import { fmtNum } from '../../sim/units';
import { useFlightView } from '../../scene/flight/flightView';
import { NpcAvatar } from '../review/ReviewArt';
import { useFlightSim, type DiaryEntry } from './flightSim';
import { FloatPanel, usePanelLayout } from './FloatPanel';

/** Lo que dicen los sensores antes de identificar el objeto. */
const SIGNAL: Record<DiscoveryZone, string> = {
  leo: 'Los sensores detectan un objeto metálico en una órbita cercana a la nuestra.',
  gps: 'Al cruzar una órbita alta, el radar detecta un objeto que refleja la luz del Sol.',
  geo: 'Estamos cruzando el anillo de los satélites geoestacionarios: hay un objeto cerca.',
  cruise: 'El radar detecta un objeto pequeño que se cruza con nuestra ruta.',
  approach: 'La cámara apunta a una zona de la Luna que llama la atención.',
  sky: 'Fuera de la atmósfera el cielo es negro y muy nítido: el buscador de estrellas marca algo interesante.',
};

const KIND_ICON: Record<string, string> = {
  satellite: '🛰',
  debris: '⚠',
  rock: '☄',
  asteroid: '☄',
  lunar: '🌕',
  constellation: '✦',
  star: '★',
  nebula: '☁',
};

function distanceText(km: number) {
  if (!Number.isFinite(km)) return '—';
  return km < 1 ? `${fmtNum(km * 1000, 0)} m` : `${fmtNum(km, km < 100 ? 1 : 0)} km`;
}

export function DiscoveryAlert() {
  const d = useFlightSim((s) => s.discovery);
  const profile = useFlightSim((s) => s.profile);
  const t = useFlightSim((s) => s.lastT);
  const observe = useFlightSim((s) => s.observeDiscovery);
  const identify = useFlightSim((s) => s.identifyDiscovery);
  const register = useFlightSim((s) => s.registerDiscovery);
  const close = useFlightSim((s) => s.closeDiscovery);
  const camMode = useFlightView((s) => s.mode);
  const setMode = useFlightView((s) => s.setMode);
  const front = usePanelLayout((s) => s.front);
  const setMin = usePanelLayout((s) => s.setMin);
  const [scanning, setScanning] = useState(false);

  useEffect(() => {
    if (d) {
      front('discovery');
      setMin('discovery', false);
    }
  }, [d?.sighting.id, front, setMin]); // eslint-disable-line react-hooks/exhaustive-deps

  // Con la cámara apuntando, el análisis de la imagen tarda un momento.
  useEffect(() => {
    if (!d?.observed || d.identified) return;
    setScanning(true);
    const id = window.setTimeout(() => {
      setScanning(false);
      identify();
    }, 2500);
    return () => window.clearTimeout(id);
  }, [d?.observed, d?.identified, identify]);

  if (!d) return null;
  const def = discoveryById(d.sighting.id);
  if (!def) return null;
  const dist = profile && def.zone !== 'sky' ? distanceTo(profile, d.sighting, t) : null;
  const pts = discoveryPoints(def, d.observed);
  const watching = camMode === 'target';

  return (
    <FloatPanel id="discovery" reserveBottom={110} className="fev fev--discovery dsc" eyebrow={<span className="fev__badge">{d.identified ? 'DESCUBRIMIENTO' : '¡OBJETO DETECTADO!'}</span>} title={d.identified ? def.name : 'Señal sin identificar'}>
      <div className="fev__msg">
        <NpcAvatar mood="happy" />
        <p className="fev__bubble">
          <strong>Centro de control:</strong> {d.identified ? `¡Lo tenemos! Es: ${def.typeLabel.toLowerCase()}.` : SIGNAL[def.zone]}
        </p>
      </div>

      <div className="dsc__meta">
        <span className="dsc__icon" aria-hidden="true">
          {d.identified ? KIND_ICON[def.kind] : '?'}
        </span>
        <dl className="dsc__dl">
          <div>
            <dt>Tipo</dt>
            <dd>{d.identified ? def.typeLabel : 'Desconocido'}</dd>
          </div>
          <div>
            <dt>{def.zone === 'sky' ? 'Distancia' : 'Distancia a la nave'}</dt>
            <dd className="mono">{dist !== null ? distanceText(dist) : 'Muy lejos (fuera del sistema solar)'}</dd>
          </div>
          <div>
            <dt>Hora del hallazgo</dt>
            <dd className="mono">{formatMET(d.sighting.t)}</dd>
          </div>
        </dl>
      </div>

      {!d.identified && (
        <>
          {scanning ? (
            <div className="dsc__scan" role="status">
              <span className="dsc__scanbar" aria-hidden="true">
                <span />
              </span>
              <span className="small">Analizando la imagen de la cámara…</span>
            </div>
          ) : (
            <ul className="fev__opts">
              <li>
                <button className="fev__opt" onClick={observe}>
                  <strong>📷 Observar con la cámara</strong>
                  <span className="small muted">{`Apuntamos la cámara y la identificamos · vale +50 % de puntos`}</span>
                </button>
              </li>
              <li>
                <button className="fev__opt" onClick={identify}>
                  <strong>Identificar con los datos del radar</strong>
                  <span className="small muted">Más rápido, pero sin foto</span>
                </button>
              </li>
              <li>
                <button className="fev__opt" onClick={close}>
                  <strong>Ignorar y seguir el vuelo</strong>
                  <span className="small muted">No suma puntos</span>
                </button>
              </li>
            </ul>
          )}
          <p className="small muted">El tiempo está en pausa mientras observas.</p>
        </>
      )}

      {d.identified && (
        <>
          <h3 className="section-title">¿Qué es?</h3>
          <ul className="dsc__facts">
            {def.facts.map((f) => (
              <li key={f} className="small">
                {f}
              </li>
            ))}
          </ul>
          {def.simulated && <p className="small muted dsc__sim">Objeto simulado: es típico de su clase, pero no es un objeto real catalogado.</p>}
          <div className="dsc__actions">
            <button className="chip chip--neutral" aria-pressed={watching} onClick={() => setMode(watching ? 'external' : 'target')}>
              {watching ? 'Volver a la vista exterior' : '📷 Ver con la cámara'}
            </button>
            {!d.registered ? (
              <button className="btn btn--primary" onClick={register}>
                {`Registrar en el diario (+${pts} puntos)`}
              </button>
            ) : (
              <span className="badge badge--soft" role="status">
                {`En el diario · +${pts} puntos`}
              </span>
            )}
          </div>
          <button className="btn dsc__go" onClick={close}>
            Continuar el vuelo
          </button>
          {watching && <p className="small muted">Usa la rueda del ratón para acercar o alejar la cámara.</p>}
        </>
      )}
    </FloatPanel>
  );
}

// ───────────────────────── Diario y mapa ─────────────────────────

const MAP_R = 132;
const LOG_SPAN = Math.log10(450000 / R_EARTH);
/** Escala logarítmica: los satélites cercanos y la Luna caben en el mismo mapa. */
function rpx(rKm: number) {
  if (rKm <= R_EARTH) return (rKm / R_EARTH) * 12;
  return 12 + (MAP_R - 12) * (Math.log10(rKm / R_EARTH) / LOG_SPAN);
}
function mapXY(x: number, y: number): [number, number] {
  const r = Math.hypot(x, y);
  const a = Math.atan2(y, x);
  const p = rpx(r);
  return [150 + p * Math.cos(a), 150 - p * Math.sin(a)];
}

const RINGS: Array<[number, string]> = [
  [R_EARTH + 2000, '2 000 km'],
  [R_EARTH + 35786, 'Geoestacionaria'],
  [100000, '100 000 km'],
  [EARTH_MOON_KM, 'Órbita de la Luna'],
];

function JournalMap({ entries }: { entries: DiaryEntry[] }) {
  const profile = useFlightSim((s) => s.profile);
  const t = useFlightSim((s) => s.lastT);
  const st = profile ? flightStateAt(profile, t) : null;
  const placed = entries.filter((e) => e.pos);
  return (
    <svg viewBox="0 0 300 300" className="dsc-map" role="img" aria-label={`Mapa de los descubrimientos: ${placed.length} objetos con posición`}>
      <defs>
        <radialGradient id="dsc-earth" cx="0.35" cy="0.35" r="0.75">
          <stop offset="0" stopColor="#7fc4ff" />
          <stop offset="1" stopColor="#1b4d8f" />
        </radialGradient>
      </defs>
      {RINGS.map(([r, label]) => (
        <g key={label}>
          <circle cx={150} cy={150} r={rpx(r)} className="dsc-map__ring" />
          <text x={150} y={150 - rpx(r) - 3} className="dsc-map__label" textAnchor="middle">
            {label}
          </text>
        </g>
      ))}
      <circle cx={150} cy={150} r={12} fill="url(#dsc-earth)" />
      {st && (
        <>
          <circle cx={mapXY(st.moonX, st.moonY)[0]} cy={mapXY(st.moonX, st.moonY)[1]} r={6} className="dsc-map__moon">
            <title>Luna</title>
          </circle>
          <g transform={`translate(${mapXY(st.x, st.y).join(' ')})`}>
            <path d="M0 -6 L5 5 L0 2 L-5 5 Z" className="dsc-map__craft">
              <title>Tu nave</title>
            </path>
          </g>
        </>
      )}
      {placed.map((e, i) => {
        const [x, y] = mapXY(e.pos![0], e.pos![1]);
        return (
          <g key={`${e.id}${i}`} className="dsc-map__obj">
            <circle cx={x} cy={y} r={5} />
            <text x={x} y={y + 3} textAnchor="middle">
              {i + 1}
            </text>
            <title>{`${e.name} · ${e.typeLabel}`}</title>
          </g>
        );
      })}
    </svg>
  );
}

/** Carta del cielo (ascensión recta y declinación) con lo registrado. */
function JournalSky({ entries }: { entries: DiaryEntry[] }) {
  const defs = entries.map((e) => discoveryById(e.id)).filter((d): d is DiscoveryDef => !!d && d.zone === 'sky');
  const W = 360;
  const H = 180;
  const px = (ra: number, dec: number): [number, number] => [((24 - ra) / 24) * W, ((80 - dec) / 160) * H];
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="dsc-sky" role="img" aria-label={`Carta del cielo: ${defs.length} objetos registrados`}>
      <rect width={W} height={H} className="dsc-sky__bg" />
      <line x1={0} x2={W} y1={H / 2} y2={H / 2} className="dsc-sky__eq" />
      <text x={6} y={H / 2 - 4} className="dsc-map__label">
        Ecuador celeste (plano de nuestro vuelo)
      </text>
      {defs.map((d) => {
        const pts = (d.stars ?? []).map(([ra, dec]) => px(ra, dec));
        // Una línea no cruza el borde de 0 h / 24 h.
        return (
          <g key={d.id}>
            {(d.lines ?? []).map(([a, b]) =>
              pts[a] && pts[b] && Math.abs(pts[a][0] - pts[b][0]) < W / 2 ? <line key={`${a}-${b}`} x1={pts[a][0]} y1={pts[a][1]} x2={pts[b][0]} y2={pts[b][1]} className="dsc-sky__line" /> : null,
            )}
            {pts.map(([x, y], i) => (
              <circle key={i} cx={x} cy={y} r={d.kind === 'nebula' ? 5 : d.kind === 'star' ? 3.2 : 1.8} className={d.kind === 'nebula' ? 'dsc-sky__neb' : 'dsc-sky__star'}>
                <title>{d.stars?.[i]?.[2] ?? d.name}</title>
              </circle>
            ))}
            {pts[0] && (
              <text x={pts[0][0] + 6} y={pts[0][1] - 5} className="dsc-sky__name">
                {d.name}
              </text>
            )}
          </g>
        );
      })}
      {defs.length === 0 && (
        <text x={W / 2} y={H / 2 + 22} textAnchor="middle" className="dsc-map__label">
          Aún no has registrado estrellas, constelaciones ni nebulosas.
        </text>
      )}
    </svg>
  );
}

export function ExplorationJournal() {
  const diary = useFlightSim((s) => s.diary);
  const points = useFlightSim((s) => s.points);
  const [tab, setTab] = useState<'list' | 'map' | 'sky'>('list');
  return (
    <FloatPanel id="journal" eyebrow={`${diary.length} registros · ${points} puntos`} title="Diario de exploración" reserveBottom={6}>
      <div className="segmented dsc-tabs" role="tablist" aria-label="Vista del diario">
        {(
          [
            ['list', 'Registros'],
            ['map', 'Mapa'],
            ['sky', 'Cielo'],
          ] as const
        ).map(([id, label]) => (
          <button key={id} role="tab" aria-selected={tab === id} aria-pressed={tab === id} onClick={() => setTab(id)}>
            {label}
          </button>
        ))}
      </div>
      {tab === 'list' &&
        (diary.length === 0 ? (
          <p className="small muted">Todavía no hay registros. Durante el viaje aparecerán objetos interesantes: obsérvalos y regístralos aquí.</p>
        ) : (
          <ol className="dsc-list">
            {diary.map((e, i) => (
              <li key={`${e.id}${i}`}>
                <span className="dsc-list__n mono">{i + 1}</span>
                <span>
                  <strong>{e.name}</strong>
                  <br />
                  <span className="small muted">
                    {e.typeLabel} · {formatMET(e.t)}
                    {e.distanceKm !== null && ` · ${distanceText(e.distanceKm)}`}
                    {e.observed && !e.rescue && ' · 📷'}
                  </span>
                </span>
                <span className="mono dsc-list__pts">{`+${e.points}`}</span>
              </li>
            ))}
          </ol>
        ))}
      {tab === 'map' && (
        <>
          <JournalMap entries={diary} />
          <p className="small muted">Escala logarítmica: cada anillo está mucho más lejos que el anterior. Los números son los del diario. Las estrellas están en la pestaña «Cielo».</p>
        </>
      )}
      {tab === 'sky' && (
        <>
          <JournalSky entries={diary} />
          <p className="small muted">Posiciones reales en el cielo (ascensión recta y declinación).</p>
        </>
      )}
      <p className="dsc-total">
        Puntos de descubrimiento: <strong className="mono">{points}</strong>
      </p>
    </FloatPanel>
  );
}

