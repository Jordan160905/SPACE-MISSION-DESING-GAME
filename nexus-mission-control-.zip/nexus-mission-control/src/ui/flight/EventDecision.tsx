/**
 * Panel de decisión ante un acontecimiento. Muestra qué pasó, por qué importa (relación de
 * ingeniería) y cada alternativa con su PREVISIÓN calculada por el motor hasta el final de la
 * campaña. La simulación queda en pausa hasta que el jugador decide.
 */
import { useMemo } from 'react';
import type { Mission } from '../../data/schemas';
import { eventDefinition, previewOptions } from '../../sim/EventSystem';
import { fmtNum } from '../../sim/units';
import { flightContextOf, useGameStore } from '../../state/useGameStore';
import { numLocale } from '../../i18n/lang';

export function EventDecision({ mission }: { mission: Mission }) {
  const resolve = useGameStore((s) => s.opsResolveEvent);
  const requestDecision = useGameStore((s) => s.requestDecision);
  const team = mission.team;
  const data = useMemo(() => {
    const f = mission.flight;
    const fc = flightContextOf(mission);
    const ev = f?.scheduledEvents.find((e) => e.id === f.pendingEventId);
    if (!f || !fc || !ev) return null;
    const def = eventDefinition(ev.type, fc.ctx, f);
    const previews = previewOptions(fc.ctx, f, def);
    return { def, previews, target: fc.objective.dataTargetGbit, day: f.elapsedH / 24 };
  }, [mission]);
  if (!data) return null;
  const { def, previews, target, day } = data;

  return (
    <div className="modal-backdrop event-backdrop">
      <div className="panel event" role="dialog" aria-modal="true" aria-labelledby="event-title">
        <div className="panel__body">
          <p className="eyebrow event__eyebrow">Acontecimiento · día {fmtNum(day, 1)} · simulación en pausa</p>
          <h2 className="h2" id="event-title">
            {def.title}
          </h2>
          <p>{def.description}</p>
          <p className="small event__why">
            <strong>Por qué importa:</strong> {def.engineering}
          </p>
          <p className="eyebrow" style={{ marginTop: 14 }}>
            Opciones · previsión del motor hasta el final de la campaña
          </p>
          <div className="event__options">
            {def.options.map((o) => {
              const p = previews.find((x) => x.optionId === o.id);
              return (
                <div key={o.id} className={`event-opt ${o.available ? '' : 'event-opt--off'}`}>
                  <strong>{o.label}</strong>
                  <p className="small muted" style={{ margin: '4px 0 8px' }}>
                    {o.description}
                  </p>
                  {o.available && p ? (
                    <dl className="kv event-opt__kv">
                      <dt>Datos en Tierra al final</dt>
                      <dd className={p.meetsTarget ? 'ok' : 'bad'}>
                        {fmtNum(p.finalDeliveredGbit, 0)} / {target.toLocaleString(numLocale())} Gbit
                      </dd>
                      <dt>Datos perdidos</dt>
                      <dd>{fmtNum(p.lostGbit, 0)} Gbit</dd>
                      <dt>Batería mínima</dt>
                      <dd className={p.safeModeEntries ? 'bad' : ''}>
                        {Math.round(p.minBatteryFraction * 100)} %{p.safeModeEntries ? ` · ${p.safeModeEntries}× modo seguro` : ''}
                      </dd>
                      <dt>Propelente final</dt>
                      <dd>{fmtNum(p.propellantKg)} kg</dd>
                      <dt>Costo</dt>
                      <dd>{p.costMUSD ? `${fmtNum(p.costMUSD)} MUSD` : '—'}</dd>
                    </dl>
                  ) : (
                    <p className="small" style={{ color: 'var(--critical)' }}>
                      No disponible: {o.unavailableReason}
                    </p>
                  )}
                  {!team && (
                    <button className="btn btn--primary" disabled={!o.available} onClick={() => resolve(o.id)} aria-label={`Elegir: ${o.label}`}>
                      Elegir
                    </button>
                  )}
                </div>
              );
            })}
          </div>
          {team && (
            <button
              className="btn btn--primary"
              style={{ marginTop: 12 }}
              onClick={() => {
                const avail = def.options.filter((o) => o.available);
                const best = [...previews].filter((p) => avail.some((o) => o.id === p.optionId)).sort((a, b) => b.value - a.value)[0];
                requestDecision(
                  { kind: 'event', label: def.title, options: avail.map((o) => ({ id: o.id, label: o.label })), bestOptionId: best?.optionId },
                  () => undefined,
                );
              }}
            >
              Votar en equipo ({team.members.length} integrantes)
            </button>
          )}
          <p className="small muted" style={{ marginTop: 10 }}>
            La previsión no incluye futuros acontecimientos. Tu decisión cuenta en la puntuación final.
          </p>
        </div>
      </div>
    </div>
  );
}
