import { describe, expect, it } from 'vitest';
import { LAUNCHERS } from '../../data/launchers/launchers';
import { launchTimeline } from '../../sim/LaunchSystem';
import { CRUISE_HOURS, MAP, trajectoryAt, transferEnd, transferPoint, transferStart } from './trajectory';

const tl = launchTimeline(LAUNCHERS[1]);

describe('mini mapa de trayectoria', () => {
  it('la transferencia empieza en la órbita de aparcamiento y termina en la órbita lunar', () => {
    expect(transferPoint(0)).toEqual(transferStart());
    const e = transferPoint(1);
    expect(e.x).toBeCloseTo(transferEnd().x, 9);
    expect(Math.hypot(e.x - MAP.moon.x, e.y - MAP.moon.y)).toBeCloseTo(MAP.lunarOrbitR, 9);
  });

  it('las etapas se suceden sin saltos: final del ascenso = inicio del aparcamiento, etc.', () => {
    const a = trajectoryAt({ kind: 'launch', t: tl.secoS, tl });
    const b = trajectoryAt({ kind: 'launch', t: tl.secoS + 1e-6, tl });
    expect(Math.hypot(a.x - b.x, a.y - b.y)).toBeLessThan(0.01);
    const c = trajectoryAt({ kind: 'launch', t: tl.tliStartS, tl });
    expect(Math.hypot(c.x - transferStart().x, c.y - transferStart().y)).toBeLessThan(0.01);
    const d = trajectoryAt({ kind: 'launch', t: tl.endS, tl });
    const e = trajectoryAt({ kind: 'cruise', hours: 0 });
    expect(Math.hypot(d.x - e.x, d.y - e.y)).toBeLessThan(0.01);
  });

  it('el progreso del crucero avanza de forma monótona hasta la Luna', () => {
    let last = -1;
    for (let h = 0; h <= CRUISE_HOURS; h += 8) {
      const p = trajectoryAt({ kind: 'cruise', hours: h });
      expect(p.progress).toBeGreaterThan(last);
      last = p.progress;
    }
    expect(trajectoryAt({ kind: 'cruise', hours: CRUISE_HOURS }).distanceFromEarthKm).toBe(384400);
    expect(trajectoryAt({ kind: 'cruise', hours: 999 }).progress).toBe(1);
  });

  it('en órbita lunar la nave gira alrededor de la Luna', () => {
    for (const ph of [0, 0.25, 0.5, 0.75]) {
      const p = trajectoryAt({ kind: 'orbit', orbitPhase: ph });
      expect(Math.hypot(p.x - MAP.moon.x, p.y - MAP.moon.y)).toBeCloseTo(MAP.lunarOrbitR, 9);
    }
  });
});
