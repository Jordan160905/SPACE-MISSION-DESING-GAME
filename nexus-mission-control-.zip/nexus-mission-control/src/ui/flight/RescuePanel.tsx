/**
 * Misión de rescate espacial (Fase 8.5): una actividad JUGABLE y opcional.
 * El jugador gira la nave, la acerca y frena con los propulsores (botones o teclado) mirando los
 * indicadores de distancia, velocidad relativa y orientación. La física es la de sim/Rescue
 * (movimiento relativo en línea recta + empuje; combustible por la ecuación del cohete).
 */
import { useEffect, useMemo, useState, type PointerEvent as RPointerEvent } from 'react';
import { bodyAxes, canAssist, readout, RESCUE, returnDv, rescuePoints, speedLimit, type RescueInput, type RescuePlan, type RescueState } from '../../sim/Rescue';
import { fmtNum } from '../../sim/units';
import { useFlightView } from '../../scene/flight/flightView';
import { NpcAvatar } from '../review/ReviewArt';
import { useFlightSim } from './flightSim';
import { FloatPanel, usePanelLayout } from './FloatPanel';
import { markTutorialSeen, RescueTutorial, tutorialSeen } from './RescueTutorial';

type Ctl = 'main' | 'fwd+' | 'fwd-' | 'right+' | 'right-' | 'up+' | 'up-' | 'yaw+' | 'yaw-' | 'pitch+' | 'pitch-';

const KEYS: Record<string, Ctl> = {
  KeyW: 'fwd+',
  KeyS: 'fwd-',
  KeyD: 'right+',
  KeyA: 'right-',
  KeyR: 'up+',
  KeyF: 'up-',
  ArrowRight: 'yaw+',
  ArrowLeft: 'yaw-',
  ArrowUp: 'pitch+',
  ArrowDown: 'pitch-',
  Space: 'main',
};

const STEPS: Array<{ id: RescueState['step'][]; label: string }> = [
  { id: ['offer'], label: 'Recibir la solicitud' },
  { id: ['locate'], label: 'Localizar el satélite' },
  { id: ['observe'], label: 'Observar su posición y movimiento' },
  { id: ['plan'], label: 'Planificar la aproximación' },
  { id: ['approach'], label: 'Controlar distancia y velocidad' },
  { id: ['assist'], label: 'Ejecutar la asistencia' },
  { id: ['done'], label: 'Objetivo completado' },
];

const PLANS: Array<{ id: RescuePlan; title: string; text: string }> = [
  { id: 'safe', title: 'Aproximación segura (recomendada)', text: 'Velocidad máxima: la distancia ÷ 100, hasta 3 m/s. Equilibrio entre tiempo y combustible.' },
  { id: 'slow', title: 'Aproximación lenta', text: 'Velocidad máxima: la distancia ÷ 200, hasta 1,5 m/s. Muy segura, pero tarda más.' },
  { id: 'fast', title: 'Aproximación rápida', text: 'Velocidad máxima: la distancia ÷ 40, hasta 8 m/s. Llega antes, pero hay que frenar mucho más (más combustible y más riesgo).' },
];

const ACTIVE: RescueState['step'][] = ['locate', 'observe', 'approach', 'assist'];

function dist(m: number) {
  return m >= 1000 ? `${fmtNum(m / 1000, 2)} km` : `${fmtNum(m, 0)} m`;
}
function speed(ms: number) {
  return `${fmtNum(ms, 2)} m/s`;
}

/** Radar visto desde arriba de la nave: el morro apunta hacia arriba del dibujo. */
function Radar({ r }: { r: RescueState }) {
  const { nose, right, up } = bodyAxes(r.yaw, r.pitch);
  const dot = (a: number[], b: number[]) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  const bx = dot(r.rel, right);
  const by = dot(r.rel, nose);
  const bz = dot(r.rel, up);
  const d = Math.hypot(bx, by) || 1;
  const scale = (m: number) => (95 * Math.log10(1 + m / 10)) / Math.log10(1 + 6000 / 10);
  const rp = scale(d);
  const sx = 110 + (bx / d) * rp;
  const sy = 110 - (by / d) * rp;
  const vx = dot(r.relVel, right);
  const vy = dot(r.relVel, nose);
  const vl = Math.hypot(vx, vy);
  const k = vl > 1e-3 ? Math.min(40, 14 + vl * 10) / vl : 0;
  const rd = readout(r);
  return (
    <svg viewBox="0 0 220 220" className="rsc-radar" role="img" aria-label={`Radar: satélite a ${dist(rd.distanceM)}, ${bx >= 0 ? 'a la derecha' : 'a la izquierda'} y ${by >= 0 ? 'delante' : 'detrás'}`}>
      <circle cx={110} cy={110} r={105} className="rsc-radar__bg" />
      {[
        [RESCUE.assistDistM, '120 m'],
        [1000, '1 km'],
        [5000, '5 km'],
      ].map(([m, label]) => (
        <g key={label}>
          <circle cx={110} cy={110} r={scale(m as number)} className={m === RESCUE.assistDistM ? 'rsc-radar__zone' : 'rsc-radar__ring'} />
          <text x={112} y={110 - scale(m as number) - 2} className="rsc-radar__label">
            {label}
          </text>
        </g>
      ))}
      <line x1={110} y1={110} x2={110} y2={8} className="rsc-radar__nose" />
      <path d="M110 100 L117 118 L110 113 L103 118 Z" className="rsc-radar__craft" />
      {vl > 1e-3 && <line x1={sx} y1={sy} x2={sx + vx * k} y2={sy - vy * k} className="rsc-radar__vel" markerEnd="url(#rsc-arrow)" />}
      <defs>
        <marker id="rsc-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse">
          <path d="M0 0 L10 5 L0 10 z" className="rsc-radar__arrow" />
        </marker>
      </defs>
      <circle cx={sx} cy={sy} r={5} className="rsc-radar__sat" />
      <text x={6} y={214} className="rsc-radar__label">
        {`Altura: ${bz >= 0 ? '+' : '−'}${dist(Math.abs(bz))}`}
      </text>
    </svg>
  );
}

/** Ángulos (rad) del satélite respecto del morro: a la derecha (ax) y hacia arriba (ay). */
function aim(r: RescueState) {
  const { nose, right, up } = bodyAxes(r.yaw, r.pitch);
  const d = Math.hypot(...r.rel) || 1;
  const u = r.rel.map((v) => v / d);
  const f = u[0] * nose[0] + u[1] * nose[1] + u[2] * nose[2];
  return { ax: Math.atan2(u[0] * right[0] + u[1] * right[1] + u[2] * right[2], f), ay: Math.atan2(u[0] * up[0] + u[1] * up[1] + u[2] * up[2], f) };
}

/** Mira de orientación: dónde está el satélite respecto del morro. */
function Sight({ r }: { r: RescueState }) {
  const { ax, ay } = aim(r);
  const toPx = (a: number) => Math.max(-52, Math.min(52, (a / (Math.PI / 2)) * 52));
  const x = 60 + toPx(ax);
  const y = 60 - toPx(ay);
  const lock = (RESCUE.lockDeg / 90) * 52;
  const rd = readout(r);
  return (
    <svg viewBox="0 0 120 120" className="rsc-sight" role="img" aria-label={`Orientación: el satélite está a ${fmtNum(rd.alignDeg, 0)}° del morro`}>
      <rect x={2} y={2} width={116} height={116} rx={10} className="rsc-radar__bg" />
      <line x1={60} y1={8} x2={60} y2={112} className="rsc-radar__ring" />
      <line x1={8} y1={60} x2={112} y2={60} className="rsc-radar__ring" />
      <circle cx={60} cy={60} r={lock} className={rd.alignDeg <= RESCUE.lockDeg ? 'rsc-sight__lock rsc-sight__lock--on' : 'rsc-sight__lock'} />
      <circle cx={x} cy={y} r={5} className="rsc-radar__sat" />
    </svg>
  );
}

function Pad({ ctl, label, held, set, title }: { ctl: Ctl; label: string; held: Record<string, boolean>; set: (c: Ctl, v: boolean) => void; title: string }) {
  const on = (e: RPointerEvent<HTMLButtonElement>) => {
    e.currentTarget.setPointerCapture(e.pointerId);
    set(ctl, true);
  };
  const off = () => set(ctl, false);
  return (
    <button className={`rsc-pad ${held[ctl] ? 'rsc-pad--on' : ''}`} onPointerDown={on} onPointerUp={off} onPointerCancel={off} onLostPointerCapture={off} title={title} aria-label={title} aria-pressed={!!held[ctl]}>
      {label}
    </button>
  );
}

export function RescuePanel() {
  const r = useFlightSim((s) => s.rescue);
  const settled = useFlightSim((s) => s.rescueSettled);
  const craft = useFlightSim((s) => s.rescueCraft);
  const accept = useFlightSim((s) => s.rescueAccept);
  const decline = useFlightSim((s) => s.rescueDecline);
  const lock = useFlightSim((s) => s.rescueLock);
  const analyze = useFlightSim((s) => s.rescueAnalyze);
  const plan = useFlightSim((s) => s.rescuePlan);
  const assist = useFlightSim((s) => s.rescueAssist);
  const retry = useFlightSim((s) => s.rescueRetry);
  const finish = useFlightSim((s) => s.rescueFinish);
  const abort = useFlightSim((s) => s.rescueAbort);
  const camMode = useFlightView((s) => s.mode);
  const setMode = useFlightView((s) => s.setMode);
  const front = usePanelLayout((s) => s.front);
  const setMin = usePanelLayout((s) => s.setMin);
  const [scale, setScale] = useState(10);
  const [held, setHeld] = useState<Record<string, boolean>>({});
  const live = useMemo(() => ({ current: {} as Record<string, boolean> }), []);
  const setCtl = (c: Ctl, v: boolean) => {
    live.current = { ...live.current, [c]: v };
    setHeld(live.current);
  };

  const open = !!r && !settled && r.step !== 'declined';
  const step = r?.step;
  // Tutorial «¿Cómo se juega?»: se abre solo la primera vez; mientras está abierto, todo se detiene.
  const [tut, setTut] = useState<number | null>(null);
  useEffect(() => {
    if (step === 'locate' && !tutorialSeen()) setTut(0);
  }, [step]);
  const closeTut = () => {
    markTutorialSeen();
    setTut(null);
  };
  const running = open && !!step && ACTIVE.includes(step) && tut === null;

  useEffect(() => {
    if (open) {
      front('rescue');
      setMin('rescue', false);
    }
  }, [open, front, setMin]);

  // Teclado (solo mientras se pilota).
  useEffect(() => {
    if (!running) return;
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
      const c = KEYS[e.code];
      if (!c) return;
      e.preventDefault();
      const down = e.type === 'keydown';
      if (!!live.current[c] !== down) {
        live.current = { ...live.current, [c]: down };
        setHeld(live.current);
      }
    };
    window.addEventListener('keydown', onKey);
    window.addEventListener('keyup', onKey);
    return () => {
      window.removeEventListener('keydown', onKey);
      window.removeEventListener('keyup', onKey);
      live.current = {};
      setHeld({});
    };
  }, [running, live]);

  // Bucle de la simulación: 20 pasos por segundo real, a la velocidad de tiempo elegida.
  useEffect(() => {
    if (!running) return;
    const id = window.setInterval(() => {
      const h = live.current;
      const input: RescueInput = {
        main: !!h.main,
        fwd: (h['fwd+'] ? 1 : 0) - (h['fwd-'] ? 1 : 0),
        right: (h['right+'] ? 1 : 0) - (h['right-'] ? 1 : 0),
        up: (h['up+'] ? 1 : 0) - (h['up-'] ? 1 : 0),
        yaw: (h['yaw+'] ? 1 : 0) - (h['yaw-'] ? 1 : 0),
        pitch: (h['pitch+'] ? 1 : 0) - (h['pitch-'] ? 1 : 0),
      };
      // Girar la nave se hace a ritmo real (más fácil de controlar).
      const rs = useFlightSim.getState().rescue;
      const k = rs?.step === 'locate' || input.yaw || input.pitch ? 1 : scale;
      useFlightSim.getState().rescueStep(input, 0.05 * k);
    }, 50);
    return () => window.clearInterval(id);
  }, [running, scale, live]);

  if (!open || !r || !craft) return null;
  const rd = readout(r);
  const stepIdx = STEPS.findIndex((s) => s.id.includes(r.step));
  const limit = speedLimit(r.plan ?? 'safe', rd.distanceM);
  const speedState = rd.closingMS <= limit ? 'ok' : rd.closingMS <= limit * 1.5 ? 'warn' : 'bad';
  const { right, up } = bodyAxes(r.yaw, r.pitch);
  const vr = r.relVel[0] * right[0] + r.relVel[1] * right[1] + r.relVel[2] * right[2];
  const vu = r.relVel[0] * up[0] + r.relVel[1] * up[1] + r.relVel[2] * up[2];
  const fuelFrac = craft.budgetKg > 0 ? r.fuelKg / craft.budgetKg : 1;
  const assistOk = canAssist(r);
  const watching = camMode === 'target';

  // Consejos del copiloto (según los mismos indicadores).
  const tips: string[] = [];
  if (r.step === 'locate' || r.step === 'approach' || r.step === 'assist') {
    const thr = r.step === 'locate' ? RESCUE.lockDeg * 0.8 : RESCUE.assistAlignDeg * 0.8;
    if (rd.alignDeg > thr) {
      const { ax, ay } = aim(r);
      const h = Math.abs(ax) * 57.3 > thr * 0.4 ? (ax > 0 ? 'a la derecha (→)' : 'a la izquierda (←)') : '';
      const v = Math.abs(ay) * 57.3 > thr * 0.4 ? (ay > 0 ? 'hacia arriba (↑)' : 'hacia abajo (↓)') : '';
      tips.push(`Gira la nave ${[h, v].filter(Boolean).join(' y ')} hasta centrar el satélite en la mira.`);
    }
  }
  if (r.step === 'approach' || r.step === 'assist') {
    if (Math.abs(vr) > 0.05) tips.push(`El satélite se desliza hacia la ${vr > 0 ? 'derecha: pulsa D' : 'izquierda: pulsa A'} para seguirlo.`);
    if (Math.abs(vu) > 0.05) tips.push(`El satélite se mueve hacia ${vu > 0 ? 'arriba: pulsa R' : 'abajo: pulsa F'} para seguirlo.`);
    if (speedState !== 'ok') tips.push('¡Demasiado rápido para esta distancia! Frena con S.');
    else if (rd.distanceM > RESCUE.assistDistM && rd.closingMS < limit * 0.5) tips.push('Acércate: pulsa W (o la barra espaciadora para el motor principal).');
    else if (rd.distanceM <= RESCUE.assistDistM && rd.relSpeedMS > RESCUE.assistSpeedMS) tips.push('Ya estás cerca: frena con S hasta casi pararte.');
  }

  const controls = (
    <div className="rsc-ctl">
      <div className="rsc-ctl__group" role="group" aria-label="Girar la nave">
        <span className="small muted">Girar</span>
        <div className="rsc-ctl__grid">
          <span />
          <Pad ctl="pitch+" label="↑" held={held} set={setCtl} title="Morro arriba (flecha ↑)" />
          <span />
          <Pad ctl="yaw-" label="←" held={held} set={setCtl} title="Girar a la izquierda (flecha ←)" />
          <span className="rsc-ctl__mid" aria-hidden="true">
            ⟲
          </span>
          <Pad ctl="yaw+" label="→" held={held} set={setCtl} title="Girar a la derecha (flecha →)" />
          <span />
          <Pad ctl="pitch-" label="↓" held={held} set={setCtl} title="Morro abajo (flecha ↓)" />
          <span />
        </div>
      </div>
      {r.step !== 'locate' && (
        <div className="rsc-ctl__group" role="group" aria-label="Propulsores">
          <span className="small muted">Propulsores</span>
          <div className="rsc-ctl__grid">
            <Pad ctl="up+" label="R ⇡" held={held} set={setCtl} title="Subir (R)" />
            <Pad ctl="fwd+" label="W ▲" held={held} set={setCtl} title="Avanzar (W)" />
            <Pad ctl="up-" label="F ⇣" held={held} set={setCtl} title="Bajar (F)" />
            <Pad ctl="right-" label="A ◀" held={held} set={setCtl} title="Desplazarse a la izquierda (A)" />
            <Pad ctl="fwd-" label="S ▼" held={held} set={setCtl} title="Frenar / retroceder (S)" />
            <Pad ctl="right+" label="D ▶" held={held} set={setCtl} title="Desplazarse a la derecha (D)" />
          </div>
          <Pad ctl="main" label="Motor principal (espacio)" held={held} set={setCtl} title="Motor principal: empuja 4 veces más (barra espaciadora)" />
        </div>
      )}
    </div>
  );

  return (
    <FloatPanel id="rescue" reserveBottom={58} className="fev fev--rescue rsc" eyebrow={<span className="fev__badge">MISIÓN DE RESCATE</span>} title="Satélite en apuros">
      <div className="rsc-top">
        <ol className="rsc-steps" aria-label="Pasos del rescate">
          {STEPS.map((s, i) => (
            <li key={s.label} className={i < stepIdx || r.step === 'done' ? 'done' : i === stepIdx ? 'cur' : ''}>
              {s.label}
            </li>
          ))}
        </ol>
        {stepIdx >= 0 && r.step !== 'done' && <p className="rsc-steplabel small">{`Paso ${stepIdx + 1} de 7 · ${STEPS[stepIdx].label}`}</p>}
      </div>

      {tut !== null && <RescueTutorial page={tut} setPage={setTut} onClose={closeTut} />}

      {tut === null && r.step === 'offer' && (
        <>
          <div className="fev__msg">
            <NpcAvatar mood="worried" />
            <p className="fev__bubble">
              <strong>Centro de control:</strong> Un pequeño satélite de una universidad (un CubeSat) ha perdido el control y gira sin parar. Está cerca de nuestra ruta. ¿Puedes ayudarlo?
            </p>
          </div>
          <details className="fev__why" open>
            <summary>¿Qué hay que hacer?</summary>
            <p className="small">
              Al girar, sus paneles no miran al Sol y se queda sin batería. Si nos acercamos a menos de 120 m y nos quedamos casi quietos a su lado, nuestra antena de corto alcance puede enviarle la orden de reinicio. Hay que
              acercarse despacio: un choque lo dañaría.
            </p>
          </details>
          <ul className="small rsc-cost">
            <li>{`Combustible máximo para el rescate: ${fmtNum(craft.budgetKg, 1)} kg (de la reserva para imprevistos), más lo necesario para volver al rumbo.`}</li>
            <li>Premio: hasta 450 puntos y datos científicos extra.</li>
            <li>Es opcional: si lo rechazas, el viaje sigue igual.</li>
          </ul>
          <p className="small muted">Misión simulada: el satélite es ficticio; los movimientos siguen la física real.</p>
          <div className="rsc-actions">
            <button className="btn btn--primary" onClick={accept}>
              Aceptar el rescate
            </button>
            <button className="btn" onClick={decline}>
              Rechazar y seguir el viaje
            </button>
          </div>
          <button className="chip chip--neutral rsc-howto" onClick={() => setTut(0)}>
            ❓ ¿Cómo se juega?
          </button>
        </>
      )}

      {tut === null && r.step !== 'offer' && r.step !== 'done' && r.step !== 'failed' && (
        <>
          <div className="rsc-inst small" role="status">
            {r.step === 'locate' && 'Gira la nave con las flechas (o los botones) hasta que el satélite (punto rojo) quede dentro del círculo de la mira.'}
            {r.step === 'observe' && 'La cámara sigue al satélite. Espera unos segundos para medir hacia dónde se mueve.'}
            {r.step === 'plan' && 'Elige cómo acercarte. Cuanto más cerca, más despacio hay que ir.'}
            {r.step === 'approach' && 'Acércate hasta menos de 120 m, frena casi del todo y mantén el morro apuntando al satélite.'}
            {r.step === 'assist' && 'Enviando la orden de reinicio. ¡Quédate cerca y quieto hasta que termine!'}
          </div>

          <div className="rsc-instruments">
            <Radar r={r} />
            <div className="rsc-side">
              <Sight r={r} />
              <p className="small mono rsc-align">{`${fmtNum(rd.alignDeg, 0)}° del morro`}</p>
            </div>
          </div>

          <div className="stats-grid tm-grid rsc-read">
            <div className="stat">
              <span className="stat__label">Distancia</span>
              <span className="stat__value" data-testid="rescue-distance">
                {dist(rd.distanceM)}
              </span>
            </div>
            <div className={`stat rsc-speed rsc-speed--${r.plan ? speedState : 'ok'}`}>
              <span className="stat__label">Velocidad de acercamiento</span>
              <span className="stat__value">{speed(rd.closingMS)}</span>
              {r.plan && <span className="stat__sub">{`máx. ${speed(limit)}`}</span>}
            </div>
            <div className="stat">
              <span className="stat__label">Velocidad relativa</span>
              <span className="stat__value">{speed(rd.relSpeedMS)}</span>
              <span className="stat__sub">{`lateral ${speed(rd.lateralMS)}`}</span>
            </div>
            <div className="stat">
              <span className="stat__label">Si no hacemos nada</span>
              <span className="stat__value">{dist(rd.cpaM)}</span>
              <span className="stat__sub">{rd.cpaS > 0 ? `paso más cercano en ${fmtNum(rd.cpaS / 60, 1)} min` : 'se está alejando'}</span>
            </div>
          </div>
          <div className="tm-row">
            <span>Combustible del rescate</span>
            <span className={`tm-bar ${fuelFrac > 0.8 ? 'tm-bar--warn' : ''}`} role="img" aria-label={`Combustible usado: ${Math.round(fuelFrac * 100)} %`}>
              <span style={{ width: `${Math.min(100, fuelFrac * 100)}%` }} />
            </span>
            <span className="mono">{`${fmtNum(r.fuelKg, 2)} / ${fmtNum(craft.budgetKg, 1)} kg`}</span>
          </div>

          {r.step === 'observe' && (
            <>
              <div className="tm-row">
                <span>Midiendo el movimiento</span>
                <span className="tm-bar" role="img" aria-label="Progreso de la medición">
                  <span style={{ width: `${Math.min(100, (r.observeT / RESCUE.observeS) * 100)}%` }} />
                </span>
                <span className="mono">{`${Math.min(100, Math.round((r.observeT / RESCUE.observeS) * 100))} %`}</span>
              </div>
              <button className="btn btn--primary" disabled={r.observeT < RESCUE.observeS} onClick={analyze}>
                Analizar el movimiento
              </button>
            </>
          )}

          {r.step === 'plan' && (
            <>
              <p className="small">
                {`El satélite está a ${dist(rd.distanceM)} y se mueve a ${speed(rd.relSpeedMS)} respecto de nosotros. ${rd.cpaS > 0 ? `Si no hacemos nada, pasará a ${dist(rd.cpaM)} de nosotros.` : 'Se está alejando: hay que ir a por él.'}`}
              </p>
              <ul className="fev__opts">
                {PLANS.map((p) => (
                  <li key={p.id}>
                    <button className="fev__opt" onClick={() => plan(p.id)}>
                      <strong>{p.title}</strong>
                      <span className="small muted">{p.text}</span>
                    </button>
                  </li>
                ))}
              </ul>
            </>
          )}

          {(r.step === 'locate' || r.step === 'approach' || r.step === 'assist') && controls}

          {tips.length > 0 && (
            <ul className="rsc-tips small">
              {tips.map((t) => (
                <li key={t}>{t}</li>
              ))}
            </ul>
          )}

          {r.step === 'locate' && (
            <button className="btn btn--primary" disabled={rd.alignDeg > RESCUE.lockDeg} onClick={lock}>
              {rd.alignDeg > RESCUE.lockDeg ? `Fijar objetivo (centra la mira: ${fmtNum(rd.alignDeg, 0)}°)` : 'Fijar objetivo'}
            </button>
          )}

          {r.step === 'approach' && (
            <>
              <ul className="rsc-req small" aria-label="Condiciones para la asistencia">
                <li className={rd.distanceM <= RESCUE.assistDistM ? 'ok' : ''}>{`Distancia ≤ ${RESCUE.assistDistM} m`}</li>
                <li className={rd.relSpeedMS <= RESCUE.assistSpeedMS ? 'ok' : ''}>{`Velocidad relativa ≤ ${fmtNum(RESCUE.assistSpeedMS, 1)} m/s`}</li>
                <li className={rd.alignDeg <= RESCUE.assistAlignDeg ? 'ok' : ''}>{`Morro hacia el satélite (≤ ${RESCUE.assistAlignDeg}°)`}</li>
              </ul>
              <button className="btn btn--primary" disabled={!assistOk} onClick={assist}>
                Ejecutar asistencia
              </button>
            </>
          )}

          {r.step === 'assist' && (
            <div className="tm-row">
              <span>Reinicio del satélite</span>
              <span className="tm-bar" role="img" aria-label="Progreso del reinicio">
                <span style={{ width: `${Math.min(100, (r.holdT / RESCUE.assistHoldS) * 100)}%` }} />
              </span>
              <span className="mono">{`${Math.min(100, Math.round((r.holdT / RESCUE.assistHoldS) * 100))} %`}</span>
            </div>
          )}

          {(r.step === 'approach' || r.step === 'assist' || r.step === 'observe') && (
            <div className="rsc-foot">
              <span className="segmented rsc-speedsel" role="group" aria-label="Velocidad del tiempo del rescate">
                {[1, 5, 10, 20].map((k) => (
                  <button key={k} aria-pressed={scale === k} onClick={() => setScale(k)}>
                    {`×${k}`}
                  </button>
                ))}
              </span>
              <button className="chip chip--neutral" aria-pressed={watching} onClick={() => setMode(watching ? 'external' : 'target')}>
                {watching ? 'Vista exterior' : '📷 Cámara al satélite'}
              </button>
            </div>
          )}
          <div className="rsc-foot">
            <button className="chip chip--neutral rsc-howto" onClick={() => setTut(0)}>
              ❓ ¿Cómo se juega?
            </button>
            <button className="chip chip--neutral rsc-abort" onClick={abort}>
              Abandonar el rescate
            </button>
          </div>
        </>
      )}

      {r.step === 'done' && (
        <div className="fev__result" role="status">
          <p>
            <strong>¡Rescate completado!</strong> El satélite recibió la orden, dejó de girar y sus paneles vuelven a mirar al Sol.
          </p>
          <ul className="fev__changes">
            <li className="small mono">{`+${rescuePoints(r)} puntos de descubrimiento`}</li>
            <li className="small mono">{`Maniobra: ${fmtNum(r.dvUsed, 1)} m/s · combustible ${fmtNum(r.fuelKg, 2)} kg`}</li>
            <li className="small mono">{`Volver al rumbo costará ${fmtNum(returnDv(r), 1)} m/s más`}</li>
            {r.overLimitS > 1 && <li className="small mono">{`Tiempo por encima de la velocidad segura: ${fmtNum(r.overLimitS, 0)} s (resta puntos)`}</li>}
          </ul>
          <button className="btn btn--primary" onClick={finish}>
            Volver al rumbo de la Luna
          </button>
        </div>
      )}

      {r.step === 'failed' && (
        <div className="fev__result" role="status">
          <p>
            <strong>Rescate no completado.</strong>{' '}
            {r.outcome === 'collision'
              ? 'Chocamos con el satélite a más de 0,5 m/s: se alejó dando vueltas. Nuestra nave está bien.'
              : r.outcome === 'lost'
                ? 'El satélite se alejó a más de 40 km y lo perdimos de vista.'
                : r.outcome === 'abandoned'
                  ? 'Decidiste abandonar el rescate. Otro equipo lo intentará más tarde.'
                : 'Se acabó el combustible reservado para el rescate.'}
          </p>
          <p className="small muted">Tu misión a la Luna sigue adelante. En el espacio real, cada maniobra cerca de otro satélite se ensaya muchas veces.</p>
          <div className="rsc-actions">
            {r.outcome === 'collision' && r.retries < 1 && (
              <button className="btn btn--primary" onClick={retry}>
                Intentarlo otra vez
              </button>
            )}
            <button className="btn" onClick={finish}>
              Volver al rumbo de la Luna
            </button>
          </div>
        </div>
      )}
    </FloatPanel>
  );
}
