/**
 * Ajustes de las decisiones contrarreloj (Fase 8.6): activadas o no y segundos (15–25).
 * Se guardan en el navegador para el próximo vuelo.
 */
import { create } from 'zustand';
import { clampSeconds, COUNTDOWN } from '../../sim/Countdown';

const KEY = 'nexus-countdown';

function load(): { enabled: boolean; seconds: number } {
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) ?? 'null') as { enabled?: unknown; seconds?: unknown } | null;
    return {
      enabled: typeof raw?.enabled === 'boolean' ? raw.enabled : true,
      seconds: typeof raw?.seconds === 'number' ? clampSeconds(raw.seconds) : COUNTDOWN.defaultS,
    };
  } catch {
    return { enabled: true, seconds: COUNTDOWN.defaultS };
  }
}

interface CountdownSettings {
  enabled: boolean;
  seconds: number;
  setEnabled: (v: boolean) => void;
  setSeconds: (s: number) => void;
}

export const useCountdownSettings = create<CountdownSettings>()((set, get) => {
  const save = () => {
    try {
      localStorage.setItem(KEY, JSON.stringify({ enabled: get().enabled, seconds: get().seconds }));
    } catch {
      /* sin almacenamiento: solo dura esta sesión */
    }
  };
  return {
    ...load(),
    setEnabled: (enabled) => {
      set({ enabled });
      save();
    },
    setSeconds: (s) => {
      set({ seconds: clampSeconds(s) });
      save();
    },
  };
});
