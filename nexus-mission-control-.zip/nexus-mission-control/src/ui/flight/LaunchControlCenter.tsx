/**
 * Centro de control del vuelo Tierra → Luna (Fases 8.1–8.5).
 *  - Telemetría completa de la trayectoria física (sim/FlightDynamics) y de los sistemas de la nave
 *    (sim/FlightEvents): altitud, velocidad, aceleración, combustible, energía, temperatura,
 *    motores, comunicaciones, radiación, distancia al destino, posición y tiempo de misión.
 *  - Controles: iniciar, pausar/reanudar, reiniciar, más rápido/más lento, siguiente evento,
 *    cámaras, trayectoria 3D, mapa y orden de paneles.
 *  - Ventanas flotantes (FloatPanel): se mueven, se minimizan y se reordenan; el centro de la
 *    escena 3D queda libre.
 *  - Eventos inesperados con alerta, mensaje del centro de control, explicación y decisiones.
 *  - Descubrimientos (8.4): aviso, cámara de observación, ficha, diario y mapa.
 *  - Rescate espacial opcional (8.5): pilotaje con indicadores de distancia, velocidad y orientación.
 */
import { useEffect, useMemo, useRef, useState } from 'react';
import { getComponent } from '../../data/components/catalog';
import { getLauncher, LUNAR_LAUNCHERS } from '../../data/launchers/launchers';
import { templateForMission } from '../../data/missions/missions';
import type { Mission } from '../../data/schemas';
import { difficultyDef } from '../../data/difficulty';
import { designComponents, designTotals } from '../../sim/DesignSystem';
import { EARTH_MOON_KM, FLIGHT_GAME, flightStateAt, inEarthShadow, type FlightProfile } from '../../sim/FlightDynamics';
import {
  applyEffects,
  commsStatus,
  NETWORK_LABEL,
  REPAIRS,
  temperatureC,
  type FlightCtx,
  type FlightEnv,
  type FlightWindows,
} from '../../sim/FlightEvents';
import { ascentState, currentEvent, formatMET, launchTimeline, type LaunchTimeline } from '../../sim/LaunchSystem';
import { propellantAfterBurn } from '../../sim/MissionSystem';
import { analyzePlan } from '../../sim/PlanningSystem';
import { fmtNum } from '../../sim/units';
import { useGameStore } from '../../state/useGameStore';
import { CAM_MODES, useFlightProfile, useFlightView } from '../../scene/flight/flightView';
import { PAD_LON_DEG, regionAt } from '../../scene/flight/geography';
import { NpcAvatar } from '../review/ReviewArt';
import { CRUISE_SPEEDS, LAUNCH_SPEEDS, useFlightSim } from './flightSim';
import { DiscoveryAlert, ExplorationJournal } from './DiscoveryPanels';
import { FloatPanel, usePanelLayout, usePanelPos, useStageSize } from './FloatPanel';
import { RescuePanel } from './RescuePanel';
import { useSurface } from '../surface/surfaceStore';
import { CountdownSettings, CountdownTimer } from './CountdownUI';
import { useCountdownSettings } from './countdownSettings';
import { anyEventById, isUrgent } from '../../sim/Countdown';
import { TrajectoryMap } from './TrajectoryMap';
import { CRUISE_HOURS, trajectoryAt } from './trajectory';

function GoItem({ go, label, detail }: { go: boolean; label: string; detail: string }) {
  return (
    <li className={`go-item ${go ? 'go-item--go' : 'go-item--nogo'}`}>
      <span className="go-item__state">{go ? 'GO' : 'NO-GO'}</span>
      <span>
        <strong>{label}</strong>
        <br />
        <span className="small muted">{detail}</span>
      </span>
    </li>
  );
}

function Bar({ value, warn, label, text }: { value: number; warn?: boolean; label: string; text?: string }) {
  const v = Math.max(0, Math.min(1, value));
  return (
    <span className={`tm-bar ${warn ? 'tm-bar--warn' : ''}`} role="img" aria-label={`${label}: ${text ?? `${Math.round(v * 100)} %`}`}>
      <span style={{ width: `${v * 100}%` }} />
    </span>
  );
}

/** Contexto de los sistemas y eventos a partir del diseño y del plan (los mismos números del Planner). */
function buildCtx(mission: Mission, report: NonNullable<ReturnType<typeof analyzePlan>>): FlightCtx {
  const e = report.engineering;
  const p = e.power;
  const dv = report.deltaV;
  const totals = designTotals(mission.design, getComponent);
  const loiDv = dv.loiMS + dv.tcmMS + (Number.isFinite(dv.windowPenaltyMS) ? dv.windowPenaltyMS : 0);
  const leftAfterLoi = propellantAfterBurn(dv.dryKg, totals.propellantKg, dv.ispS, loiDv);
  return {
    hasThermal: designComponents(mission.design, getComponent).some((c) => c.category === 'PROTECTION'),
    antennaMbps: e.comms?.downlinkMbps ?? 0,
    energyMargin: p && p.rechargeNeededWh > 0 ? p.orbitBalanceWh / p.rechargeNeededWh : 1,
    dvMargin: Number.isFinite(dv.marginFraction) ? dv.marginFraction : 0,
    batteryMaxWh: p?.batteryWh ?? 0,
    busLoadW: p?.busLoadW ?? 0,
    genW: p?.sunlitGenW ?? p?.nominalGenW ?? 0,
    propellantKg: totals.propellantKg,
    dryKg: dv.dryKg,
    ispS: dv.ispS,
    spendableKg: Math.max(0, leftAfterLoi * 0.9),
    problemsEnabled: difficultyDef(mission.difficulty).events,
  };
}

function flightWindows(tl: LaunchTimeline, p: FlightProfile): FlightWindows {
  const H = 3600;
  const soiH = (p.tSoi - tl.endS) / H;
  return {
    ascent: [tl.mecoS * 0.35, tl.mecoS * 0.9],
    orbit: [tl.secoS + 240, tl.tliStartS - 240],
    cruise: [tl.endS + 3 * H, tl.endS + Math.max(10, Math.min(70, soiH - 2)) * H],
    approach: [p.tSoi + H, p.tPeri - 3 * H],
  };
}

function EventAlert() {
  const active = useFlightSim((s) => s.active);
  const ctx = useFlightSim((s) => s.ctx);
  const vars = useFlightSim((s) => s.vars);
  const t = useFlightSim((s) => s.lastT);
  const tArr = useFlightSim((s) => s.tArr);
  const choose = useFlightSim((s) => s.choose);
  const close = useFlightSim((s) => s.closeEvent);
  const expire = useFlightSim((s) => s.expireEvent);
  const cdOn = useCountdownSettings((s) => s.enabled);
  const cdSecs = useCountdownSettings((s) => s.seconds);
  const front = usePanelLayout((s) => s.front);
  const setMin = usePanelLayout((s) => s.setMin);
  useEffect(() => {
    if (active) {
      front('event');
      setMin('event', false);
    }
  }, [active?.id, front, setMin]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!active || !ctx || !vars) return null;
  const def = anyEventById(active.id);
  if (!def) return null;
  const ec = { ctx, vars, t, tArr, window: active.window, mag: active.mag };
  const urgent = isUrgent(def);
  const timed = urgent && cdOn && !active.choice;
  const tone = urgent ? 'urgent' : def.kind === 'problem' ? 'alert' : def.kind === 'discovery' ? 'discovery' : 'good';
  const badge = urgent ? '¡CONTRARRELOJ!' : def.kind === 'problem' ? 'ALERTA' : def.kind === 'discovery' ? 'DESCUBRIMIENTO' : 'BUENAS NOTICIAS';
  return (
    <FloatPanel id="event" className={`fev fev--${tone}`} eyebrow={<span className="fev__badge">{badge}</span>} title={def.title}>
      {timed && <CountdownTimer key={`${active.id}-${cdSecs}`} seconds={cdSecs} onExpire={expire} />}
      {urgent && <p className="fev__quick">{def.quick}</p>}
      <div className="fev__msg">
        <NpcAvatar mood={def.kind === 'problem' ? 'worried' : 'happy'} />
        <p className="fev__bubble">
          <strong>Centro de control:</strong> {def.message(ec)}
        </p>
      </div>
      <details className="fev__why" open={!urgent}>
        <summary>¿Qué está pasando?</summary>
        <p className="small">{def.explain}</p>
      </details>
      {!active.choice ? (
        <>
          <p className="eyebrow" style={{ marginTop: 10 }}>
            ¿Qué hacemos?
          </p>
          <ul className="fev__opts">
            {def.options.map((o) => {
              // Vista previa de las consecuencias con los mismos cálculos que se aplicarán.
              const preview = applyEffects(vars, ctx, o.effect(ec), t, tArr).changes;
              return (
                <li key={o.id}>
                  <button className="fev__opt" onClick={() => choose(o.id)}>
                    <strong>{o.label}</strong>
                    <span className="small muted">{preview.length ? preview.join(' · ') : 'Sin coste'}</span>
                  </button>
                </li>
              );
            })}
          </ul>
          {urgent ? (
            <>
              <p className="small fev__ifnot">
                <strong>{timed ? 'Si se acaba el tiempo:' : 'Si no se hace nada:'}</strong> {applyEffects(vars, ctx, def.timeout.effect(ec), t, tArr).changes.join(' · ')}
              </p>
              {!timed && <p className="small muted">Temporizadores desactivados: esta situación espera a que decidas.</p>}
              <details className="fev__cdset">
                <summary>⏱ Ajustes del temporizador</summary>
                <CountdownSettings compact />
              </details>
            </>
          ) : (
            <p className="small muted">El tiempo está en pausa hasta que decidas.</p>
          )}
        </>
      ) : (
        <div className="fev__result" role="status">
          {active.timedOut && <p className="fev__timeout">⏱ ¡Se acabó el tiempo!</p>}
          <p className="small">{active.outcome}</p>
          {active.changes.length > 0 && (
            <ul className="fev__changes">
              {active.changes.map((c) => (
                <li key={c} className="small mono">
                  {c}
                </li>
              ))}
            </ul>
          )}
          <button className="btn btn--primary" onClick={close}>
            Continuar el vuelo
          </button>
        </div>
      )}
    </FloatPanel>
  );
}

export function LaunchControlCenter({ mission }: { mission: Mission }) {
  const launch = useGameStore((s) => s.launch);
  const start = useGameStore((s) => s.launchStartCountdown);
  const abort = useGameStore((s) => s.launchAbort);
  const advance = useGameStore((s) => s.launchAdvance);
  const setSpeed = useGameStore((s) => s.launchSetSpeed);
  const toggle = useGameStore((s) => s.launchTogglePause);
  const skip = useGameStore((s) => s.launchSkipToNext);
  const finish = useGameStore((s) => s.launchFinish);
  const landingGoal = useSurface((s) => !!s.goals[mission.id]);
  const setLandingGoal = useSurface((s) => s.setGoal);
  const startLanding = useSurface((s) => s.startLanding);
  const startCruise = useGameStore((s) => s.launchStartCruise);
  const camMode = useFlightView((s) => s.mode);
  const setCamMode = useFlightView((s) => s.setMode);
  const resetView = useFlightView((s) => s.reset);
  const showTraj = useFlightView((s) => s.showTrajectory);
  const toggleTraj = useFlightView((s) => s.toggleTrajectory);
  const sim = useFlightSim();
  const arrange = usePanelLayout((s) => s.arrange);
  const setMin = usePanelLayout((s) => s.setMin);
  const mapPos = usePanelPos('map');
  const journalPos = usePanelPos('journal');
  const hudRef = useRef<HTMLDivElement>(null);
  useStageSize(hudRef);
  const [confirmRestart, setConfirmRestart] = useState(false);

  const template = templateForMission(mission)!;
  const launcher = (mission.plan && getLauncher(mission.plan.launcherId)) || LUNAR_LAUNCHERS[0];
  const tl = useMemo(() => launchTimeline(launcher), [launcher]);
  const profile = useFlightProfile(launcher, mission.plan?.altitudeKm);
  const report = useMemo(
    () => (mission.plan ? analyzePlan({ design: mission.design, lookup: getComponent, template, objectiveId: mission.objectiveId, plan: mission.plan, difficulty: mission.difficulty }) : null),
    [mission, template],
  );

  // Sistemas y eventos de esta misión.
  useEffect(() => {
    if (!profile || !report) return;
    if (useFlightSim.getState().missionId !== mission.id) useFlightSim.getState().init(mission.id, buildCtx(mission, report), flightWindows(tl, profile), profile.tPeri, 0, profile);
  }, [profile, report, mission, tl]);

  // Al despegar, la verificación se minimiza sola.
  const preLaunch = launch.phase === 'ready' || launch.phase === 'countdown';
  useEffect(() => {
    setMin('check', !preLaunch);
  }, [preLaunch, setMin]);

  // Reloj: 10 ticks por segundo de tiempo real (en el crucero, a la velocidad elegida).
  // (En el crucero el store deja `running` activo: la pausa del crucero la lleva flightSim.)
  const cruiseRun = launch.phase === 'cruise' && !sim.cruisePaused;
  const launchRun = (launch.phase === 'countdown' || launch.phase === 'flight') && launch.running;
  useEffect(() => {
    if (!launchRun && !cruiseRun) return;
    const k = launch.phase === 'cruise' ? sim.cruiseSpeed / 16 : 1;
    const id = window.setInterval(() => advance(0.1 * k), 100);
    return () => window.clearInterval(id);
  }, [launchRun, launch.phase, cruiseRun, sim.cruiseSpeed, advance]);

  const cruising = launch.phase === 'cruise' || launch.phase === 'lunar-arrival';
  const metT = cruising ? tl.endS + launch.cruiseH * 3600 : launch.t;
  const st = profile ? flightStateAt(profile, metT) : null;
  const ev = (id: string) => tl.events.find((e) => e.id === id)?.tS ?? Infinity;
  const scSepS = ev('sc-sep');

  // Los sistemas avanzan con el tiempo de misión.
  useEffect(() => {
    if (!profile || !st) return;
    const env: FlightEnv = {
      separated: metT >= scSepS,
      deployed: metT >= ev('deploy'),
      inFairing: metT < ev('fairing'),
      sunlit: !inEarthShadow(profile, st.x, st.y),
      nearEarth: st.altitudeKm < 2000,
    };
    useFlightSim.getState().tick(metT, env);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [metT, profile]);

  if (!report) return null;
  const engCritical = report.engineering.issues.filter((i) => i.severity === 'critical').length;
  const polls = [
    { label: 'Vehículo', go: report.massFits && report.fairingFits, detail: `${launcher.name}: masa ${fmtNum(report.massWithMarginKg)} / ${launcher.payloadToTLIKg} kg, cabe en la cofia` },
    { label: 'Trayectoria', go: report.deltaV.ok && report.window.status !== 'closed', detail: `Δv ${fmtNum(report.deltaV.availableMS, 0)} / ${fmtNum(report.deltaV.requiredMS, 0)} m/s · ventana ${report.window.status === 'optimal' ? 'óptima' : report.window.status}` },
    { label: 'Nave', go: engCritical === 0, detail: engCritical === 0 ? 'Energía, datos y subsistemas sin problemas críticos' : `${engCritical} problemas críticos` },
    { label: 'Presupuesto', go: !!report.engineering.budget && !report.engineering.budget.overBudget, detail: `${fmtNum(report.engineering.budget?.committedMUSD ?? 0)} / ${template.budgetCapMUSD} MUSD` },
    { label: 'Meteorología', go: true, detail: 'Condiciones favorables (simulada: siempre GO en esta versión)' },
  ];
  const allGo = polls.every((p) => p.go) && report.ready;
  const traj = cruising ? trajectoryAt({ kind: 'cruise', hours: launch.cruiseH }) : trajectoryAt({ kind: 'launch', t: launch.t, tl });
  const cur = currentEvent(launch.t, tl);
  const ascent = ascentState(launch.t, tl);
  const eventActive = !!sim.active;
  const v = sim.vars;
  const ctx = sim.ctx;

  // ── Telemetría ──
  const thrusting = st ? st.thrustG > 0.01 : ascent.thrusting !== 0;
  const stageName = !st
    ? 'Sin propulsión'
    : st.phase === 'approach'
      ? 'Aproximación a la Luna'
      : st.phase === 'stage1'
        ? launcher.stages[0].name
        : st.phase === 'stage2' || st.phase === 'tli'
          ? launcher.stages[1].name
          : st.phase === 'parking'
            ? 'Órbita de aparcamiento'
            : st.phase === 'cruise'
              ? cruising
                ? 'Crucero'
                : 'Rumbo a la Luna'
              : 'Sin propulsión';
  const ascending = !st || st.phase === 'pad' || st.phase === 'stage1' || st.phase === 'coast';
  const nearMoon = !!st && (st.phase === 'approach' || st.moonDistanceKm < 66100);
  const summary: Array<{ label: string; value: string }> = st
    ? nearMoon
      ? [
          { label: 'Altura sobre la Luna', value: `${fmtNum(st.moonAltitudeKm)} km` },
          { label: 'Velocidad respecto de la Luna', value: `${fmtNum(st.moonSpeedKmS, 2)} km/s` },
        ]
      : st.phase === 'cruise'
        ? [
            { label: 'Distancia a la Tierra', value: `${fmtNum(st.altitudeKm)} km` },
            { label: 'Velocidad', value: `${fmtNum(st.speedKmS, 2)} km/s` },
          ]
        : [
            { label: 'Altitud', value: `${fmtNum(st.altitudeKm)} km` },
            { label: ascending ? 'Velocidad' : 'Velocidad orbital', value: `${fmtNum(ascending ? st.groundSpeedKmS : st.speedKmS, 2)} km/s` },
          ]
    : [
        { label: 'Altitud', value: `${fmtNum(ascent.altitudeKm)} km` },
        { label: 'Velocidad', value: `${fmtNum(ascent.velocityKmS, 2)} km/s` },
      ];

  // Combustible de las etapas del cohete (según el tiempo de encendido de cada etapa).
  const b1 = launcher.stages[0].burnTimeS;
  const b2 = launcher.stages[1].burnTimeS;
  const sesS = ev('ses');
  const used2 = Math.max(0, Math.min(metT, tl.secoS) - sesS) + Math.max(0, Math.min(metT, tl.tliEndS) - tl.tliStartS);
  const fuel1 = metT <= 0 ? 1 : Math.max(0, 1 - metT / b1);
  const fuel2 = Math.max(0, 1 - used2 / b2);
  const stage1Sep = metT >= ev('stage-sep');
  const engine1 = metT > -3 && metT <= 0 && launch.phase !== 'ready' ? 'Encendido (sujeto)' : metT > 0 && metT <= tl.mecoS ? 'Encendido' : stage1Sep ? 'Separada' : metT > tl.mecoS ? 'Apagado' : 'Apagado';
  const engine2 =
    metT >= scSepS
      ? 'Separada de la nave'
      : (metT > sesS && metT <= tl.secoS) || (metT > tl.tliStartS && metT <= tl.tliEndS)
        ? 'Encendido'
        : metT > tl.tliEndS
          ? 'Apagado (combustible agotado)'
          : metT > tl.secoS
            ? 'Apagado · espera la inyección translunar'
            : 'En espera';

  // Posición.
  let position = '—';
  if (st) {
    if (nearMoon) position = `A ${fmtNum(st.moonAltitudeKm)} km de la superficie lunar`;
    else if (st.altitudeKm < 3000) {
      const lon = ((Math.atan2(st.y, st.x) - FLIGHT_GAME.padAngle0 - st.earthAngle) * 180) / Math.PI + PAD_LON_DEG;
      const lonN = ((((lon + 180) % 360) + 360) % 360) - 180;
      position = `Sobre ${regionAt(lonN, 0)} · ${fmtNum(Math.abs(lonN), 1)}° ${lonN < 0 ? 'O' : 'E'}, ecuador`;
    } else position = `A ${fmtNum(st.altitudeKm)} km de la Tierra (${Math.round((Math.hypot(st.x, st.y) / EARTH_MOON_KM) * 100)} % del camino a la Luna)`;
  }
  const sunlit = profile && st ? !inEarthShadow(profile, st.x, st.y) : true;
  const commsPhase = metT < tl.secoS ? 'ascent' : metT < tl.tliEndS ? 'orbit' : 'deep';
  const comms = v && ctx && st ? commsStatus(v, ctx, metT, Math.hypot(st.x, st.y), commsPhase) : null;
  const temp = v ? temperatureC(v) : 21;
  const sensorFault = !!v && metT < v.sensorFaultUntil;
  const battFrac = v && ctx && ctx.batteryMaxWh > 0 ? v.batteryWh / ctx.batteryMaxWh : 1;
  const separated = metT >= scSepS;
  const deployed = metT >= ev('deploy');
  const genW = ctx && v && deployed && sunlit ? ctx.genW * v.powerFactor : 0;
  const loadW = ctx && v ? (separated ? ctx.busLoadW : ctx.busLoadW * 0.6) * (v.safeMode ? 0.6 : 1) + v.extraLoadW : 0;
  const degraded: Array<{ kind: keyof typeof REPAIRS; text: string }> = [];
  if (v) {
    if (comms?.down || v.commsFactor < 1) degraded.push({ kind: 'comms', text: comms?.down ? 'Sin comunicación con la Tierra' : `Señal reducida al ${Math.round(v.commsFactor * 100)} %` });
    if (sensorFault) degraded.push({ kind: 'sensor', text: 'Sensor de estrellas fuera de servicio' });
    if (v.powerFactor < 1) degraded.push({ kind: 'power', text: `Paneles al ${Math.round(v.powerFactor * 100)} %` });
    if (v.heatFault || temp > 40) degraded.push({ kind: 'heat', text: `Temperatura alta (${fmtNum(temp, 0)} °C)` });
  }

  // ── Controles ──
  const paused = launch.phase === 'flight' ? !launch.running : launch.phase === 'cruise' ? sim.cruisePaused : false;
  const canPause = launch.phase === 'flight' || launch.phase === 'cruise';
  const togglePause = () => (launch.phase === 'flight' ? toggle() : sim.setCruisePaused(!sim.cruisePaused));
  const speeds = launch.phase === 'cruise' ? CRUISE_SPEEDS : LAUNCH_SPEEDS;
  const curSpeed = launch.phase === 'cruise' ? sim.cruiseSpeed : launch.speed;
  const idx = Math.max(0, speeds.indexOf(curSpeed));
  const setSp = (i: number) => {
    const sp = speeds[Math.max(0, Math.min(speeds.length - 1, i))];
    if (launch.phase === 'cruise') sim.setCruiseSpeed(sp);
    else setSpeed(sp);
  };
  // «Siguiente evento» también se detiene en los descubrimientos que hay por el camino.
  const skipNext = () => {
    const nextT = tl.events.find((e) => e.tS > launch.t + 1e-6)?.tS ?? Infinity;
    const fs = useFlightSim.getState();
    const sg = fs.sightings.find((x) => !fs.detected.includes(x.id) && x.t > launch.t && x.t < nextT);
    if (sg && launch.phase === 'flight') useGameStore.setState({ launch: { ...launch, t: sg.t } });
    else skip();
  };
  const speedLabel = launch.phase === 'cruise' ? `${curSpeed} h/s` : `×${curSpeed}`;
  const rescueOpen = !!sim.rescue && !sim.rescueSettled && sim.rescue.step !== 'declined';
  const timeLocked = eventActive || !!sim.discovery || rescueOpen;

  return (
    <div className="flight-hud" ref={hudRef}>
      {/* Reloj compacto arriba */}
      <div className="fh-top">
        <div className="panel met met--compact">
          <span className="met__label">{launch.phase === 'countdown' ? 'Cuenta regresiva' : launch.phase === 'ready' ? 'En la plataforma' : 'Tiempo de misión'}</span>
          <span className="met__value" data-testid="met">
            {formatMET(metT)}
          </span>
          <span className="met__event">
            {cruising ? stageName : cur ? cur.title : launch.phase === 'ready' ? `${launcher.name} listo · ${mission.plan?.altitudeKm} km · ${mission.plan?.inclinationDeg}°` : 'Secuencia automática en curso'}
          </span>
          <span className="met__telem" aria-label="Telemetría resumida">
            {summary.map((x) => (
              <span key={x.label}>
                <span className="met__k">{x.label}</span> <strong className="mono">{x.value}</strong>
              </span>
            ))}
            {paused && canPause && <span className="badge badge--soft">En pausa</span>}
          </span>
        </div>
      </div>

      {/* Verificación GO/NO-GO */}
      <FloatPanel id="check" className="flight-left" reserveBottom={110} eyebrow={`Launch Control · ${mission.name}`} title="Verificación previa">
        <ul className="go-list">
          {polls.map((p) => (
            <GoItem key={p.label} {...p} />
          ))}
        </ul>
        <p className="small muted">Cada responsable da su «GO». Si alguno dice «NO-GO», no se lanza: así funcionan los centros de control reales.</p>
        {launch.phase === 'ready' && (
          <button className="btn btn--primary" style={{ width: '100%' }} disabled={!allGo} onClick={start}>
            {allGo ? 'Iniciar cuenta regresiva' : 'NO-GO: revisa el plan'}
          </button>
        )}
        {launch.phase === 'countdown' && (
          <button className="btn btn--danger" style={{ width: '100%' }} onClick={abort}>
            Abortar lanzamiento
          </button>
        )}
        <details className="flight-settings">
          <summary>⚙ Ajustes del vuelo: objetivo y contrarreloj</summary>
        <div className="cds" role="group" aria-label="Objetivo del vuelo">
          <h3 className="section-title">Objetivo del vuelo</h3>
          <label className="cds__row">
            <input type="checkbox" checked={landingGoal} onChange={(e) => setLandingGoal(mission.id, e.target.checked)} />
            <span>Aterrizar en la Luna con un módulo de descenso</span>
          </label>
          <p className="small muted">Si lo activas, al llegar a la Luna podrás pilotar el descenso y después explorar con un rover.</p>
        </div>
        <CountdownSettings />
        </details>
      </FloatPanel>

      {/* Telemetría */}
      <FloatPanel id="telemetry" className="flight-right" eyebrow="Telemetría" title={stageName}>
        <div className="stats-grid tm-grid">
          <div className="stat">
            <span className="stat__label">Tiempo de misión</span>
            <span className="stat__value">{formatMET(metT)}</span>
          </div>
          {summary.map((x) => (
            <div className="stat" key={x.label}>
              <span className="stat__label">{x.label}</span>
              <span className="stat__value">{x.value}</span>
            </div>
          ))}
          <div className="stat">
            <span className="stat__label">Aceleración</span>
            <span className="stat__value">{thrusting && st ? `${fmtNum(st.thrustG, 1)} g` : '0 g · ingravidez'}</span>
          </div>
          <div className="stat">
            <span className="stat__label">Distancia al destino</span>
            <span className="stat__value">{st ? `${fmtNum(st.moonAltitudeKm)} km` : '—'}</span>
          </div>
        </div>
        <p className="tm-pos small">
          <span className="muted">Posición:</span> {position}
        </p>

        <h3 className="section-title">Combustible</h3>
        <div className="tm-row">
          <span>
            {launcher.stages[0].name} {stage1Sep && <span className="muted">· separada</span>}
          </span>
          <Bar value={stage1Sep ? 0 : fuel1} label={launcher.stages[0].name} />
          <span className="mono">{stage1Sep ? '—' : `${Math.round(fuel1 * 100)} %`}</span>
        </div>
        <div className="tm-row">
          <span>{launcher.stages[1].name}</span>
          <Bar value={separated ? 0 : fuel2} label={launcher.stages[1].name} />
          <span className="mono">{separated ? '—' : `${Math.round(fuel2 * 100)} %`}</span>
        </div>
        {v && ctx && (
          <div className="tm-row">
            <span>Nave (propulsores)</span>
            <Bar value={ctx.propellantKg > 0 ? v.propellantKg / ctx.propellantKg : 0} warn={v.spentKg > ctx.spendableKg * 0.8} label="Combustible de la nave" />
            <span className="mono">{fmtNum(v.propellantKg, 1)} kg</span>
          </div>
        )}
        <p className="small muted tm-note">Etapas: según el tiempo de encendido. Nave: el combustible que se gaste en imprevistos se descuenta al llegar a la Luna.</p>

        <h3 className="section-title">Energía</h3>
        {v && ctx && (
          <>
            <div className="tm-row">
              <span>Batería {v.safeMode && <span className="badge badge--hard">Modo seguro</span>}</span>
              <Bar value={battFrac} warn={battFrac < 0.3} label="Batería" />
              <span className="mono">{Math.round(battFrac * 100)} %</span>
            </div>
            <p className="small tm-note">
              {deployed ? (sunlit ? '☀ Paneles al Sol' : '● En la sombra de la Tierra') : 'Paneles plegados: la nave usa su batería'}
              {` · genera ${fmtNum(genW, 0)} W · consume ${fmtNum(loadW, 0)} W`}
            </p>
          </>
        )}

        <h3 className="section-title">Temperatura y radiación</h3>
        {v && (
          <>
            <div className="tm-row">
              <span>Interior de la nave</span>
              <Bar value={(temp + 20) / 80} warn={temp > 40 || temp < 0} label="Temperatura" text={`${fmtNum(temp, 0)} °C`} />
              <span className={`mono ${temp > 40 || temp < 0 ? 'bad' : ''}`}>{fmtNum(temp, 0)} °C</span>
            </div>
            <p className="small tm-note">
              Dosis de radiación: <strong className="mono">{fmtNum(v.doseMSv, 2)} mSv</strong> · valores estimados (modelo simplificado).
            </p>
          </>
        )}

        <h3 className="section-title">Motores</h3>
        <ul className="tm-engines">
          <li className={engine1 === 'Encendido' || engine1 === 'Encendido (sujeto)' ? 'on' : ''}>
            <span>{launcher.stages[0].name}</span>
            <span>{engine1}</span>
          </li>
          <li className={engine2 === 'Encendido' ? 'on' : ''}>
            <span>{launcher.stages[1].name}</span>
            <span>{engine2}</span>
          </li>
          <li>
            <span>Propulsores de la nave</span>
            <span>{separated ? 'Listos' : 'Integrados en el cohete'}</span>
          </li>
        </ul>

        <h3 className="section-title">Comunicaciones</h3>
        {comms && (
          <>
            <div className="tm-row">
              <span>{NETWORK_LABEL[comms.network]}</span>
              <Bar value={comms.quality} warn={comms.quality < 0.5} label="Calidad de la señal" />
              <span className="mono">{comms.down ? 'Sin señal' : `${Math.round(comms.quality * 100)} %`}</span>
            </div>
            <p className="small tm-note">
              Retardo de la señal: <strong className="mono">{fmtNum(comms.delayS, 2)} s</strong> (distancia ÷ velocidad de la luz)
              {separated && ` · datos: ${fmtNum(comms.rateMbps, 1)} Mbps`}
            </p>
          </>
        )}
        <p className="small tm-note">Orientación: sensor de estrellas {sensorFault ? <strong className="bad">fuera de servicio</strong> : 'correcto'}</p>

        <h3 className="section-title">Estado de los sistemas</h3>
        {degraded.length === 0 && (!v || v.trajErrorKm <= 0) ? (
          <p className="small ok">Todos los sistemas funcionan con normalidad.</p>
        ) : (
          <ul className="tm-systems">
            {degraded.map((d) => (
              <li key={d.kind}>
                <span className="small bad">{d.text}</span>
                <button className="chip chip--neutral" disabled={timeLocked} onClick={() => sim.repair(d.kind)}>
                  Recuperar: {REPAIRS[d.kind].label}
                </button>
              </li>
            ))}
            {v && v.trajErrorKm > 0 && (
              <li>
                <span className="small bad">Desviación de trayectoria: {fmtNum(v.trajErrorKm, 0)} km</span>
                <button className="chip chip--neutral" disabled={timeLocked || !separated} onClick={sim.correctTrajectory}>
                  Corregir ahora
                </button>
              </li>
            )}
          </ul>
        )}
        <p className="small muted tm-note">
          {profile
            ? 'Trayectoria calculada con física: gravedad de la Tierra y de la Luna, giro terrestre y aire. El empuje lo fija un guiado simplificado (no son datos del motor).'
            : 'Calculando la trayectoria física…'}
        </p>
      </FloatPanel>

      {/* Cronología y bitácora */}
      <FloatPanel id="timeline" eyebrow="Cronología" title="Eventos y bitácora" reserveBottom={6}>
        <ol className="timeline">
          {tl.events.map((e) => {
            const stt = launch.t >= e.tS && launch.phase !== 'ready' && launch.phase !== 'countdown' ? (cur?.id === e.id ? 'current' : 'done') : 'next';
            return (
              <li key={e.id} className={`tl-item tl-item--${stt}`}>
                <span className="tl-item__t mono">{formatMET(e.tS)}</span>
                <span>
                  <strong>{e.title}</strong>
                  {stt === 'current' && <span className="small muted"> — {e.detail}</span>}
                </span>
              </li>
            );
          })}
        </ol>
        <h3 className="section-title">Bitácora del vuelo</h3>
        {sim.log.length === 0 ? (
          <p className="small muted">Sin incidencias por ahora.</p>
        ) : (
          <ol className="flight-log">
            {[...sim.log].reverse().map((l, k) => (
              <li key={k} className={`log log--${l.level === 'warn' ? 'warn' : 'info'}`}>
                <span className="mono">{formatMET(l.t)}</span> <span>{l.text}</span>
                {l.detail?.map((d) => (
                  <span key={d} className="log__detail small muted">
                    {d}
                  </span>
                ))}
              </li>
            ))}
          </ol>
        )}
      </FloatPanel>

      {/* Mapa esquemático */}
      <FloatPanel id="map" eyebrow="Mapa" title="Trayectoria esquemática" reserveBottom={6}>
        <TrajectoryMap point={traj} />
      </FloatPanel>

      <EventAlert />
      <DiscoveryAlert />
      <RescuePanel />
      <ExplorationJournal />

      {/* Controles */}
      <FloatPanel id="controls" className="fh-bar" title="Controles del vuelo" reserveBottom={6}>
        <div className="fc-row" role="toolbar" aria-label="Control del tiempo">
          {launch.phase === 'ready' && (
            <button className="btn btn--primary fc-main" disabled={!allGo} onClick={start}>
              ▶ Iniciar
            </button>
          )}
          {launch.phase === 'countdown' && (
            <button className="btn btn--danger fc-main" onClick={abort}>
              Abortar
            </button>
          )}
          {canPause && (
            <button className="btn fc-main" disabled={timeLocked} onClick={togglePause}>
              {paused ? '▶ Reanudar' : '⏸ Pausar'}
            </button>
          )}
          <span className="fh-time" role="group" aria-label="Velocidad del tiempo">
            <button className="chip chip--neutral" disabled={timeLocked || idx === 0} onClick={() => setSp(idx - 1)} aria-label="Más lento">
              − Más lento
            </button>
            <span className="fc-speed mono" data-testid="time-speed">
              {speedLabel}
            </span>
            <button className="chip chip--neutral" disabled={timeLocked || idx === speeds.length - 1} onClick={() => setSp(idx + 1)} aria-label="Más rápido">
              Más rápido +
            </button>
          </span>
          {launch.phase === 'flight' && (
            <button className="chip chip--neutral" disabled={timeLocked} onClick={skipNext}>
              Siguiente evento ⏭
            </button>
          )}
          {launch.phase !== 'ready' &&
            (confirmRestart ? (
              <span className="fc-confirm">
                <span className="small">¿Volver a la plataforma?</span>
                <button
                  className="chip chip--neutral"
                  onClick={() => {
                    setConfirmRestart(false);
                    sim.restart();
                  }}
                >
                  Sí, reiniciar
                </button>
                <button className="chip chip--neutral" onClick={() => setConfirmRestart(false)}>
                  No
                </button>
              </span>
            ) : (
              <button className="chip chip--neutral" onClick={() => setConfirmRestart(true)}>
                ↺ Reiniciar
              </button>
            ))}
        </div>
        <div className="fc-row">
          <div className="segmented fh-cams" role="group" aria-label="Cámara">
            {CAM_MODES.map((c) => (
              <button key={c.id} aria-pressed={camMode === c.id} title={c.hint} onClick={() => setCamMode(c.id)}>
                {c.label}
              </button>
            ))}
          </div>
          <button className="chip chip--neutral" onClick={resetView} title="Vuelve al encuadre inicial de la cámara">
            Restablecer vista
          </button>
          <button className="chip chip--neutral" aria-pressed={showTraj} onClick={toggleTraj}>
            Trayectoria 3D
          </button>
          <button className="chip chip--neutral" aria-pressed={!mapPos.min} onClick={() => setMin('map', !mapPos.min)}>
            Mapa
          </button>
          <button className="chip chip--neutral" aria-pressed={!journalPos.min} onClick={() => setMin('journal', !journalPos.min)}>
            {`Diario (${sim.points} pts)`}
          </button>
          <button className="chip chip--neutral" onClick={arrange} title="Devuelve los paneles a su sitio inicial">
            Ordenar paneles
          </button>
        </div>
        <p className="fh-hint small">
          {camMode === 'onboard' ? 'Arrastra para mirar alrededor · rueda para el zoom' : camMode === 'free' ? 'Arrastra para girar · rueda para acercar o alejar · botón derecho (o Mayús) para desplazar' : 'Arrastra para girar · rueda para acercar o alejar'}
          {' · '}Mueve los paneles por su cabecera
        </p>
      </FloatPanel>

      {/* Avisos del vuelo (abajo, sobre los controles) */}
      <div className="fh-bottom">
        {launch.phase === 'arrived' && (
          <div className="panel arrival">
            <p className="eyebrow">Nave separada y activa</p>
            <p className="small" style={{ margin: '6px 0 10px' }}>
              Tu nave ya vuela sola hacia la Luna. El crucero dura unos 4 días.
            </p>
            <button className="btn btn--primary" onClick={startCruise}>
              Iniciar crucero hacia la Luna
            </button>
          </div>
        )}
        {launch.phase === 'cruise' && (
          <div className="panel arrival">
            <p className="small" style={{ margin: 0 }} data-testid="cruise">
              Día {fmtNum(launch.cruiseH / 24, 1)} de {CRUISE_HOURS / 24} · la gravedad terrestre frena la nave hasta que la Luna la atrae.
            </p>
          </div>
        )}
        {launch.phase === 'lunar-arrival' && !eventActive && (
          <div className="panel arrival">
            <p className="eyebrow">Llegada a la Luna</p>
            <p className="small" style={{ margin: '6px 0 10px' }}>
              La nave llega a {fmtNum(0.8, 1)} km/s sobre la velocidad de escape lunar: si no frena, pasará de largo. El encendido de inserción cuesta{' '}
              {fmtNum(report.deltaV.loiMS, 0)} m/s de Δv (más {fmtNum(report.deltaV.tcmMS + (Number.isFinite(report.deltaV.windowPenaltyMS) ? report.deltaV.windowPenaltyMS : 0), 0)} m/s de
              correcciones del viaje).
            </p>
            {landingGoal ? (
              <>
                <p className="small arrival__goal">🌕 Objetivo del vuelo: aterrizar en la Luna. Tras la inserción, el módulo de descenso se separa y bajas pilotándolo.</p>
                <div className="arrival__actions">
                  <button className="btn btn--primary" onClick={() => startLanding(mission.id)}>
                    Inserción en órbita y descenso a la Luna
                  </button>
                  <button className="btn" onClick={finish}>
                    Solo inserción en órbita (sin aterrizar)
                  </button>
                </div>
              </>
            ) : (
              <button className="btn btn--primary" onClick={finish}>
                Encender motor: inserción en órbita lunar
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
