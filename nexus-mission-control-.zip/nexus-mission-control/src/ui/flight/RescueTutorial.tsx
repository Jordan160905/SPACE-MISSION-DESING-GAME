/**
 * Tutorial del rescate espacial: cómo se juega, en 5 tarjetas con dibujos.
 * Se abre solo la primera vez que se acepta un rescate y se puede volver a abrir con «¿Cómo se juega?».
 * Mientras está abierto, la simulación del rescate está detenida.
 */
import type { ReactNode } from 'react';
import { RESCUE } from '../../sim/Rescue';
import { fmtNum } from '../../sim/units';

export const RESCUE_TUTORIAL_KEY = 'nexus-rescue-tutorial-seen';

export function tutorialSeen() {
  try {
    return localStorage.getItem(RESCUE_TUTORIAL_KEY) === '1';
  } catch {
    return false;
  }
}
export function markTutorialSeen() {
  try {
    localStorage.setItem(RESCUE_TUTORIAL_KEY, '1');
  } catch {
    /* almacenamiento no disponible: se volverá a mostrar */
  }
}

function Key({ k, wide }: { k: string; wide?: boolean }) {
  return <kbd className={`rtut-key ${wide ? 'rtut-key--wide' : ''}`}>{k}</kbd>;
}

/** Dibujo 1: la nave, el satélite y la zona de 120 m. */
function ArtGoal() {
  return (
    <svg viewBox="0 0 300 130" className="rtut-art" aria-hidden="true">
      <circle cx={225} cy={65} r={52} className="rtut-zone" />
      <text x={225} y={128} className="rtut-label" textAnchor="middle">
        zona de 120 m
      </text>
      <g transform="translate(225 65) rotate(25)">
        <rect x={-7} y={-10} width={14} height={20} className="rtut-sat" />
        <rect x={-22} y={-8} width={13} height={16} className="rtut-panel" />
        <rect x={9} y={-8} width={13} height={16} className="rtut-panel" />
      </g>
      <path d="M200 30 a30 30 0 0 1 40 -6" className="rtut-spin" markerEnd="url(#rtut-a)" />
      <g transform="translate(60 65) rotate(90)">
        <path d="M0 -20 L12 14 L0 8 L-12 14 Z" className="rtut-craft" />
      </g>
      <line x1={86} y1={65} x2={165} y2={65} className="rtut-path" markerEnd="url(#rtut-a)" />
      <text x={125} y={56} className="rtut-label" textAnchor="middle">
        despacio
      </text>
      <defs>
        <marker id="rtut-a" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
          <path d="M0 0 L10 5 L0 10 z" className="rtut-arrowhead" />
        </marker>
      </defs>
    </svg>
  );
}

/** Dibujo 2: la mira con el punto del satélite entrando al círculo. */
function ArtSight() {
  return (
    <svg viewBox="0 0 300 130" className="rtut-art" aria-hidden="true">
      <rect x={95} y={8} width={114} height={114} rx={10} className="rtut-box" />
      <line x1={152} y1={14} x2={152} y2={116} className="rtut-grid" />
      <line x1={101} y1={65} x2={203} y2={65} className="rtut-grid" />
      <circle cx={152} cy={65} r={12} className="rtut-lock" />
      <circle cx={192} cy={38} r={5} className="rtut-dot rtut-dot--ghost" />
      <path d="M187 42 Q172 56 160 61" className="rtut-path" markerEnd="url(#rtut-b)" />
      <circle cx={152} cy={65} r={5} className="rtut-dot" />
      <text x={230} y={42} className="rtut-label">
        satélite
      </text>
      <text x={20} y={70} className="rtut-label">
        mira
      </text>
      <defs>
        <marker id="rtut-b" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
          <path d="M0 0 L10 5 L0 10 z" className="rtut-arrowhead" />
        </marker>
      </defs>
    </svg>
  );
}

/** Dibujo 3: la nave con las flechas de los propulsores. */
function ArtThrust() {
  const arrow = (x1: number, y1: number, x2: number, y2: number, label: string, lx: number, ly: number) => (
    <g>
      <line x1={x1} y1={y1} x2={x2} y2={y2} className="rtut-path" markerEnd="url(#rtut-c)" />
      <text x={lx} y={ly} className="rtut-keylabel" textAnchor="middle">
        {label}
      </text>
    </g>
  );
  return (
    <svg viewBox="0 0 300 130" className="rtut-art" aria-hidden="true">
      <path d="M150 38 L166 86 L150 78 L134 86 Z" className="rtut-craft" />
      {arrow(150, 34, 150, 8, 'W', 166, 20)}
      {arrow(150, 92, 150, 122, 'S', 166, 112)}
      {arrow(128, 64, 92, 64, 'A', 110, 56)}
      {arrow(172, 64, 208, 64, 'D', 190, 56)}
      <text x={238} y={40} className="rtut-label">
        R: subir
      </text>
      <text x={238} y={58} className="rtut-label">
        F: bajar
      </text>
      <text x={18} y={110} className="rtut-label">
        frente: hacia donde apunta el morro
      </text>
      <defs>
        <marker id="rtut-c" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
          <path d="M0 0 L10 5 L0 10 z" className="rtut-arrowhead" />
        </marker>
      </defs>
    </svg>
  );
}

/** Dibujo 4: el radar explicado. */
function ArtRadar() {
  return (
    <svg viewBox="0 0 300 130" className="rtut-art" aria-hidden="true">
      <circle cx={80} cy={65} r={58} className="rtut-box" />
      <circle cx={80} cy={65} r={20} className="rtut-zone" />
      <circle cx={80} cy={65} r={40} className="rtut-grid" fill="none" />
      <path d="M80 57 L86 73 L80 69 L74 73 Z" className="rtut-craft" />
      <circle cx={105} cy={25} r={5} className="rtut-dot" />
      <line x1={105} y1={25} x2={122} y2={33} className="rtut-vel" markerEnd="url(#rtut-d)" />
      <text x={150} y={22} className="rtut-label">
        ● satélite
      </text>
      <text x={150} y={42} className="rtut-label rtut-label--warn">
        → hacia dónde se mueve
      </text>
      <text x={150} y={62} className="rtut-label rtut-label--ok">
        ◯ zona de 120 m
      </text>
      <text x={150} y={82} className="rtut-label">
        ▲ tu nave (morro hacia arriba)
      </text>
      <text x={150} y={102} className="rtut-label">
        más lejos = más fuera
      </text>
      <defs>
        <marker id="rtut-d" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
          <path d="M0 0 L10 5 L0 10 z" className="rtut-arrowhead--warn" />
        </marker>
      </defs>
    </svg>
  );
}

/** Dibujo 5: velocidad que baja al acercarse. */
function ArtTips() {
  return (
    <svg viewBox="0 0 300 130" className="rtut-art" aria-hidden="true">
      <line x1={30} y1={105} x2={280} y2={105} className="rtut-grid" />
      <line x1={30} y1={105} x2={30} y2={15} className="rtut-grid" />
      <path d="M30 100 L110 30 L280 98" className="rtut-curve" />
      <text x={34} y={122} className="rtut-label">
        lejos
      </text>
      <text x={250} y={122} className="rtut-label">
        cerca
      </text>
      <text x={60} y={22} className="rtut-label">
        acelera
      </text>
      <text x={170} y={44} className="rtut-label">
        frena con tiempo
      </text>
      <text x={36} y={64} className="rtut-label" transform="rotate(-90 36 64)">
        velocidad
      </text>
    </svg>
  );
}

type Page = { title: string; art: ReactNode; body: ReactNode };

function pages(): Page[] {
  return [
    {
      title: 'Tu misión',
      art: <ArtGoal />,
      body: (
        <ul className="rtut-list">
          <li>{`Acércate al satélite hasta menos de ${RESCUE.assistDistM} m.`}</li>
          <li>{`Frena casi del todo: menos de ${fmtNum(RESCUE.assistSpeedMS, 1)} m/s respecto de él.`}</li>
          <li>{`Apunta el morro hacia él (menos de ${RESCUE.assistAlignDeg}°).`}</li>
          <li>{`Pulsa «Ejecutar asistencia» y quédate quieto ${RESCUE.assistHoldS} s mientras le enviamos la orden de reinicio.`}</li>
        </ul>
      ),
    },
    {
      title: 'Girar la nave',
      art: <ArtSight />,
      body: (
        <>
          <p className="rtut-keys">
            <Key k="←" />
            <Key k="→" /> girar a los lados · <Key k="↑" />
            <Key k="↓" /> morro arriba o abajo
          </p>
          <p>El punto rojo de la mira es el satélite. Gira hasta meterlo en el círculo: entonces el morro lo apunta. Girar no te mueve: solo cambia hacia dónde miras.</p>
        </>
      ),
    },
    {
      title: 'Moverse con los propulsores',
      art: <ArtThrust />,
      body: (
        <>
          <p className="rtut-keys">
            <Key k="W" /> avanzar · <Key k="S" /> frenar o retroceder · <Key k="A" />
            <Key k="D" /> izquierda o derecha · <Key k="R" />
            <Key k="F" /> subir o bajar · <Key k="Espacio" wide /> motor principal (4 veces más fuerte)
          </p>
          <p>En el espacio no hay rozamiento: si empujas, sigues moviéndote aunque sueltes la tecla. Para parar hay que empujar al revés. Todo esto también se puede hacer manteniendo pulsados los botones del panel.</p>
        </>
      ),
    },
    {
      title: 'Leer los instrumentos',
      art: <ArtRadar />,
      body: (
        <ul className="rtut-list">
          <li>Radar: tu nave está en el centro, mirando hacia arriba. La flecha naranja dice hacia dónde se escapa el satélite.</li>
          <li>Velocidad de acercamiento: verde = bien, ámbar = un poco rápido, rojo = ¡frena!</li>
          <li>«Si no hacemos nada»: a qué distancia pasaría el satélite si no tocas nada.</li>
          <li>Combustible del rescate: no lo gastes todo.</li>
        </ul>
      ),
    },
    {
      title: 'Consejos de piloto',
      art: <ArtTips />,
      body: (
        <ul className="rtut-list">
          <li>Primero gira hacia el satélite, después avanza con W.</li>
          <li>Si la flecha naranja va hacia un lado, empuja hacia ese lado (A o D) para seguirlo.</li>
          <li>Cuanto más cerca, más despacio: frena con S antes de llegar.</li>
          <li>Lejos usa el tiempo ×20; cerca, ×1 o ×5 para tener más control.</li>
          <li>El copiloto te dice en naranja qué tecla pulsar.</li>
          <li>Si chocas a más de 0,5 m/s el satélite se daña; tienes un reintento.</li>
        </ul>
      ),
    },
  ];
}

export const TUTORIAL_PAGES = 5;

export function RescueTutorial({ page, setPage, onClose }: { page: number; setPage: (n: number) => void; onClose: () => void }) {
  const all = pages();
  const p = all[Math.max(0, Math.min(all.length - 1, page))];
  const last = page >= all.length - 1;
  return (
    <section className="rtut" aria-label="Tutorial: cómo se juega el rescate">
      <p className="rtut-eyebrow">{`Cómo se juega · ${page + 1} de ${all.length}`}</p>
      <h3 className="rtut-title">{p.title}</h3>
      {p.art}
      <div className="rtut-body small">{p.body}</div>
      <div className="rtut-dots" aria-hidden="true">
        {all.map((_, i) => (
          <span key={i} className={i === page ? 'on' : ''} />
        ))}
      </div>
      <div className="rtut-nav">
        <button className="btn" disabled={page === 0} onClick={() => setPage(page - 1)}>
          ← Anterior
        </button>
        {last ? (
          <button className="btn btn--primary" onClick={onClose}>
            ¡A jugar!
          </button>
        ) : (
          <button className="btn btn--primary" onClick={() => setPage(page + 1)}>
            Siguiente →
          </button>
        )}
      </div>
      {!last && (
        <button className="rtut-skip" onClick={onClose}>
          Saltar el tutorial
        </button>
      )}
    </section>
  );
}
