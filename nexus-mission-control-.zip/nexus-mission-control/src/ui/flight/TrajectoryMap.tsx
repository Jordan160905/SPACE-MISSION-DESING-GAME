/**
 * Mini pantalla de trayectoria Tierra–Luna (esquemática, no a escala).
 * La posición sale de trajectoryAt(), alimentada con el mismo tiempo que el resto del vuelo.
 */
import { fmtNum } from '../../sim/units';
import { MAP, transferPath, type TrajectoryPoint } from './trajectory';

const LEG_LABEL: Record<TrajectoryPoint['leg'], string> = {
  pad: 'En la plataforma',
  ascent: 'Ascenso',
  parking: 'Órbita de aparcamiento',
  tli: 'Inyección translunar',
  cruise: 'Crucero hacia la Luna',
  'lunar-orbit': 'Órbita lunar',
};

export function TrajectoryMap({ point, contact }: { point: TrajectoryPoint; contact?: boolean }) {
  const { earth, parkingR, moon, lunarOrbitR } = MAP;
  return (
    <div className="panel traj" aria-label="Trayectoria de la nave">
      <div className="traj__head">
        <span className="eyebrow">Trayectoria</span>
        <span className="small mono">{LEG_LABEL[point.leg]}</span>
      </div>
      <svg viewBox="0 0 300 130" className="traj__svg" role="img" aria-label={`${LEG_LABEL[point.leg]}, a ${fmtNum(point.distanceFromEarthKm, 0)} km de la Tierra`}>
        <defs>
          <radialGradient id="traj-earth" cx="0.35" cy="0.35" r="0.75">
            <stop offset="0" stopColor="#7fc4ff" />
            <stop offset="1" stopColor="#1b4d8f" />
          </radialGradient>
          <radialGradient id="traj-moon" cx="0.35" cy="0.35" r="0.75">
            <stop offset="0" stopColor="#e6e3dc" />
            <stop offset="1" stopColor="#8c8a85" />
          </radialGradient>
        </defs>
        {/* trayecto completo (punteado) y recorrido (sólido) */}
        <path d={transferPath()} className="traj__path" />
        <path d={transferPath()} className="traj__done" pathLength={1} strokeDasharray={`${point.progress} 1`} />
        <circle cx={earth.x} cy={earth.y} r={parkingR} className="traj__orbit" />
        <circle cx={moon.x} cy={moon.y} r={lunarOrbitR} className="traj__orbit traj__orbit--moon" />
        <circle cx={earth.x} cy={earth.y} r={earth.r} fill="url(#traj-earth)" />
        <circle cx={moon.x} cy={moon.y} r={moon.r} fill="url(#traj-moon)" />
        <text x={earth.x} y={earth.y + earth.r + 12} className="traj__label">Tierra</text>
        <text x={moon.x} y={moon.y + lunarOrbitR + 11} className="traj__label">Luna</text>
        {contact && <line x1={point.x} y1={point.y} x2={earth.x} y2={earth.y} className="traj__link" />}
        <circle cx={point.x} cy={point.y} r={6} className="traj__halo" />
        <circle cx={point.x} cy={point.y} r={2.6} className="traj__craft" data-testid="traj-craft" />
      </svg>
      <div className="traj__foot small">
        <span>
          Distancia a la Tierra: <strong className="mono">{fmtNum(point.distanceFromEarthKm, 0)} km</strong>
        </span>
        <span className="muted">Esquema, no a escala</span>
      </div>
    </div>
  );
}
