/**
 * Estado del vuelo en curso (Fases 8.2 y 8.3): sistemas de la nave, eventos inesperados,
 * velocidad del crucero y pausa. La lógica es pura (sim/FlightEvents); aquí solo se guarda el
 * estado y se conecta con el reloj de lanzamiento del juego (useGameStore.launch).
 *
 * Al llegar a la órbita lunar (etapa Operaciones), el combustible gastado en imprevistos y los datos
 * de los descubrimientos se pasan a la misión, así las decisiones del vuelo tienen consecuencias reales.
 */
import { create } from 'zustand';
import {
  applyEffects,
  initialVars,
  REPAIRS,
  scheduleFlightEvents,
  seedFrom,
  stepVars,
  type FlightCtx,
  type FlightEnv,
  type FlightVars,
  type FlightWindow,
  type FlightWindows,
  type ScheduledFlightEvent,
} from '../../sim/FlightEvents';
import { CRUISE_HOURS } from '../../sim/LaunchSystem';
import { anyEventById, isUrgent, scheduleUrgent } from '../../sim/Countdown';
import type { FlightProfile } from '../../sim/FlightDynamics';
import { discoveryById, discoveryPoints, distanceTo, isVisible, objectPosition, scheduleDiscoveries, type Sighting } from '../../sim/Discoveries';
import {
  canAssist,
  newRescue,
  readout,
  RESCUE,
  rescuePoints,
  retryRescue,
  returnDv,
  stepRescue,
  type RescueCraft,
  type RescueInput,
  type RescuePlan,
  type RescueState,
} from '../../sim/Rescue';
import { propellantForDv } from '../../sim/FlightEvents';
import { useFlightView } from '../../scene/flight/flightView';
import { upsertMission } from '../../state/missionLogic';
import { fmtNum } from '../../sim/units';
import { useGameStore } from '../../state/useGameStore';

export interface ActiveFlightEvent extends ScheduledFlightEvent {
  /** Reanudar el tiempo al cerrar. */
  resume: boolean;
  choice: string | null;
  changes: string[];
  outcome: string | null;
  /** Contrarreloj: se acabó el tiempo sin decidir. */
  timedOut?: boolean;
}

export interface FlightLogItem {
  t: number;
  level: 'info' | 'warn' | 'good';
  text: string;
  /** Consecuencias aplicadas (se muestran aparte para que se traduzcan por separado). */
  detail?: string[];
}

export interface DiaryEntry {
  id: string;
  t: number;
  name: string;
  typeLabel: string;
  distanceKm: number | null;
  observed: boolean;
  points: number;
  /** Posición (marco físico) para el mapa; null para objetos del cielo. */
  pos: [number, number, number] | null;
  rescue?: boolean;
}

export interface ActiveDiscovery {
  sighting: Sighting;
  resume: boolean;
  identified: boolean;
  observed: boolean;
  registered: boolean;
}

/** Velocidades del crucero (horas de misión por segundo real). La del juego es 16 h/s. */
export const CRUISE_SPEEDS = [1, 4, 16, 48];
/** Velocidades del lanzamiento (× tiempo real). */
export const LAUNCH_SPEEDS = [1, 2, 5, 10, 30, 60, 120];

interface FlightSimState {
  missionId: string | null;
  attempt: number;
  ctx: FlightCtx | null;
  windows: FlightWindows | null;
  tArr: number;
  vars: FlightVars | null;
  schedule: ScheduledFlightEvent[];
  fired: string[];
  lastT: number;
  active: ActiveFlightEvent | null;
  log: FlightLogItem[];
  autoCorrected: boolean;
  handedOff: boolean;
  cruiseSpeed: number;
  cruisePaused: boolean;
  // ── Descubrimientos (8.4) ──
  profile: FlightProfile | null;
  sightings: Sighting[];
  detected: string[];
  discovery: ActiveDiscovery | null;
  diary: DiaryEntry[];
  points: number;
  // ── Rescate (8.5) ──
  rescueAt: number | null;
  rescue: RescueState | null;
  rescueResume: boolean;
  rescueCraft: RescueCraft | null;
  rescueSettled: boolean;
  /** Resumen de la actividad en la superficie (8.8–8.9), para el registro de operaciones. */
  surfaceSummary: string | null;
  init: (missionId: string, ctx: FlightCtx, windows: FlightWindows, tArr: number, attempt?: number, profile?: FlightProfile | null) => void;
  observeDiscovery: () => void;
  identifyDiscovery: () => void;
  registerDiscovery: () => void;
  closeDiscovery: () => void;
  rescueAccept: () => void;
  rescueDecline: () => void;
  rescueLock: () => void;
  rescueAnalyze: () => void;
  rescuePlan: (plan: RescuePlan) => void;
  rescueStep: (input: RescueInput, dt: number) => void;
  rescueAssist: () => void;
  rescueRetry: () => void;
  rescueAbort: () => void;
  rescueFinish: () => void;
  tick: (t: number, env: FlightEnv) => void;
  choose: (optionId: string) => void;
  closeEvent: () => void;
  /** Contrarreloj (8.6): se acabó el tiempo sin decidir. */
  expireEvent: () => void;
  repair: (kind: keyof typeof REPAIRS) => void;
  /** Corrige ya la desviación de trayectoria pendiente. */
  correctTrajectory: () => void;
  restart: () => void;
  setCruiseSpeed: (h: number) => void;
  setCruisePaused: (p: boolean) => void;
}

function sightingPos(p: FlightProfile, sg: Sighting, t: number): [number, number, number] | null {
  return objectPosition(p, sg, t);
}

function pauseTime(): boolean {
  const g = useGameStore.getState();
  if (g.launch.phase === 'flight' && g.launch.running) {
    g.launchTogglePause();
    return true;
  }
  const sim = useFlightSim.getState();
  if (g.launch.phase === 'cruise' && !sim.cruisePaused) {
    useFlightSim.setState({ cruisePaused: true });
    return true;
  }
  return false;
}

function resumeTime() {
  const g = useGameStore.getState();
  if (g.launch.phase === 'flight' && !g.launch.running) g.launchTogglePause();
  if (g.launch.phase === 'cruise') useFlightSim.setState({ cruisePaused: false });
}

/**
 * Vuelve el reloj al instante `to` (≤ `now`) si el salto es pequeño: en el crucero siempre (cada tick
 * avanza como mucho unas horas) y en el lanzamiento hasta 150 s (no deshace «Siguiente evento»).
 */
function rewindTo(to: number, now: number, p: FlightProfile): boolean {
  if (now - to <= 0) return true;
  const g = useGameStore.getState();
  if (g.launch.phase === 'cruise' && to >= p.tl.endS) {
    useGameStore.setState({ launch: { ...g.launch, cruiseH: (to - p.tl.endS) / 3600 } });
    return true;
  }
  if (g.launch.phase === 'flight' && now - to <= 150 && Math.abs(g.launch.t - now) < 1e-6) {
    useGameStore.setState({ launch: { ...g.launch, t: to } });
    return true;
  }
  return false;
}

/** Sin volver atrás (tras un salto grande), solo se anuncia si el objeto sigue cerca de verdad. */
function nearEnough(p: FlightProfile, sg: Sighting, t: number) {
  const def = discoveryById(sg.id);
  if (!def || def.zone === 'sky' || def.zone === 'approach') return true;
  return distanceTo(p, sg, t) < (def.zone === 'cruise' ? 80000 : 1500);
}

/** Tiempo que pasa por una decisión: solo se puede adelantar el reloj durante el crucero. */
function advanceCruise(seconds: number) {
  const g = useGameStore.getState();
  if (g.launch.phase !== 'cruise' || seconds <= 0) return;
  const cruiseH = Math.min(CRUISE_HOURS, g.launch.cruiseH + seconds / 3600);
  useGameStore.setState({ launch: { ...g.launch, cruiseH, phase: cruiseH >= CRUISE_HOURS ? 'lunar-arrival' : 'cruise' } });
}

export const useFlightSim = create<FlightSimState>()((set, get) => ({
  missionId: null,
  attempt: 0,
  ctx: null,
  windows: null,
  tArr: 0,
  vars: null,
  schedule: [],
  fired: [],
  lastT: -10,
  active: null,
  log: [],
  autoCorrected: false,
  handedOff: false,
  cruiseSpeed: 16,
  cruisePaused: false,
  profile: null,
  sightings: [],
  detected: [],
  discovery: null,
  diary: [],
  points: 0,
  rescueAt: null,
  rescue: null,
  rescueResume: false,
  rescueCraft: null,
  rescueSettled: false,
  surfaceSummary: null,

  init: (missionId, ctx, windows, tArr, attempt = 0, profile = null) => {
    const base = scheduleFlightEvents(ctx, windows, seedFrom(missionId, attempt));
    // Contrarreloj (8.6): a lo sumo una situación urgente por vuelo, y no en todos.
    const urgent = scheduleUrgent(ctx, windows, seedFrom(missionId, attempt + 303), base);
    const schedule = urgent ? [...base, urgent].sort((a, b) => a.t - b.t) : base;
    const seed = seedFrom(missionId, attempt + 101);
    const sightings = profile ? scheduleDiscoveries(profile, seed, schedule.map((e) => e.t)) : [];
    // Rescate: una vez, en el crucero, solo si la nave tiene propulsores y combustible de sobra.
    let rescueAt: number | null = null;
    if (profile && ctx.ispS > 0 && ctx.spendableKg >= 1.5) {
      const busy = [...schedule.map((e) => e.t), ...sightings.map((x) => x.t)];
      const H = 3600;
      for (let k = 0; k < 40 && rescueAt === null; k++) {
        const t = profile.tl.endS + (18 + ((seed >>> (k % 24)) % 1000) / 1000 * 36) * H + k * 0.5 * H;
        if (t < profile.tSoi - 4 * H && busy.every((b) => Math.abs(b - t) > 3 * H)) rescueAt = t;
      }
    }
    const craft: RescueCraft | null = profile ? { massKg: ctx.dryKg + ctx.propellantKg, ispS: ctx.ispS, budgetKg: Math.min(4, ctx.spendableKg * 0.6) } : null;
    set({
      missionId,
      attempt,
      ctx,
      windows,
      tArr,
      vars: initialVars(ctx),
      schedule,
      fired: [],
      lastT: -10,
      active: null,
      log: [],
      autoCorrected: false,
      handedOff: false,
      cruisePaused: false,
      profile,
      sightings,
      detected: [],
      discovery: null,
      diary: [],
      points: 0,
      rescueAt,
      rescue: null,
      rescueResume: false,
      rescueCraft: craft,
      rescueSettled: false,
      surfaceSummary: null,
    });
  },

  tick: (t, env) => {
    const s = get();
    if (!s.ctx || !s.vars || !s.windows) return;
    if (t <= s.lastT) {
      if (t < s.lastT) set({ lastT: t });
      return;
    }
    let vars = stepVars(s.vars, s.ctx, Math.max(0, s.lastT), Math.max(0, t), env);
    const log = [...s.log];
    let autoCorrected = s.autoCorrected;
    // Corrección automática pendiente al acercarse a la Luna (más cara cuanto más tarde).
    if (!autoCorrected && vars.trajErrorKm > 0 && t >= s.windows.approach[0]) {
      const before = vars.trajErrorKm;
      const r = applyEffects(vars, s.ctx, { correctTrajectory: true }, t, s.tArr);
      vars = r.vars;
      autoCorrected = true;
      log.push({ t, level: 'warn', text: `Corrección de trayectoria al llegar: ${Math.round(before)} km`, detail: r.changes });
    }
    let active = s.active;
    let fired = s.fired;
    if (!active) {
      const next = s.schedule.find((e) => !fired.includes(e.id) && e.t <= t);
      const def = next && anyEventById(next.id);
      if (next && def) {
        fired = [...fired, next.id];
        const ec = { ctx: s.ctx, vars, t, tArr: s.tArr, window: next.window as FlightWindow, mag: next.mag };
        if (def.onTrigger) vars = applyEffects(vars, s.ctx, def.onTrigger(ec), t, s.tArr).vars;
        log.push({ t, level: def.kind === 'problem' ? 'warn' : 'good', text: def.title });
        set({ vars, log, fired, autoCorrected, lastT: t });
        const resume = pauseTime();
        set({ active: { ...next, resume, choice: null, changes: [], outcome: null } });
        return;
      }
    }
    set({ vars, log, fired, autoCorrected, lastT: t, active });
    const busy = active || s.discovery || (s.rescue && !['done', 'failed', 'declined'].includes(s.rescue.step));
    if (busy) return;
    // Descubrimientos: el objeto aparece donde le corresponde y el tiempo se detiene para observarlo.
    const p = s.profile;
    const sg = p ? s.sightings.find((x) => !s.detected.includes(x.id) && x.t <= t) : undefined;
    if (p && sg) {
      const detected = [...s.detected, sg.id];
      // El reloj avanza a saltos (hasta horas por tick en el crucero): se vuelve al instante del
      // paso para que el objeto esté a la distancia prevista.
      const at = rewindTo(sg.t, t, p) ? sg.t : t;
      if (!isVisible(p, sg, at) || (at !== sg.t && !nearEnough(p, sg, at))) return set({ detected });
      const resume = pauseTime();
      set({ detected, lastT: at, discovery: { sighting: sg, resume, identified: false, observed: false, registered: false } });
      return;
    }
    // Rescate opcional.
    if (s.rescueAt !== null && !s.rescue && t >= s.rescueAt) {
      const resume = pauseTime();
      set({ rescue: newRescue(s.attempt + (s.missionId?.length ?? 0) + 7), rescueResume: resume, log: [...get().log, { t, level: 'warn', text: 'Solicitud de rescate: un satélite tiene problemas' }] });
    }
  },

  choose: (optionId) => {
    const s = get();
    const a = s.active;
    if (!a || a.choice || !s.ctx || !s.vars) return;
    const def = anyEventById(a.id);
    const opt = def?.options.find((o) => o.id === optionId);
    if (!def || !opt) return;
    const spec = opt.effect({ ctx: s.ctx, vars: s.vars, t: s.lastT, tArr: s.tArr, window: a.window, mag: a.mag });
    const r = applyEffects(s.vars, s.ctx, spec, s.lastT, s.tArr);
    set({
      vars: r.vars,
      active: { ...a, choice: optionId, changes: r.changes, outcome: opt.outcome },
      log: [...s.log, { t: s.lastT, level: def.kind === 'problem' ? 'info' : 'good', text: opt.label, detail: r.changes }],
    });
    if (spec.advanceS) advanceCruise(spec.advanceS);
  },

  expireEvent: () => {
    const s = get();
    const a = s.active;
    if (!a || a.choice || !s.ctx || !s.vars) return;
    const def = anyEventById(a.id);
    if (!isUrgent(def)) return;
    const spec = def.timeout.effect({ ctx: s.ctx, vars: s.vars, t: s.lastT, tArr: s.tArr, window: a.window, mag: a.mag });
    const r = applyEffects(s.vars, s.ctx, spec, s.lastT, s.tArr);
    set({
      vars: r.vars,
      active: { ...a, choice: 'timeout', timedOut: true, changes: r.changes, outcome: def.timeout.outcome },
      log: [...s.log, { t: s.lastT, level: 'warn', text: 'Se acabó el tiempo sin decidir', detail: r.changes }],
    });
  },

  closeEvent: () => {
    const a = get().active;
    if (!a) return;
    set({ active: null });
    if (a.resume) resumeTime();
  },

  repair: (kind) => {
    const s = get();
    if (!s.ctx || !s.vars) return;
    const rep = REPAIRS[kind];
    const r = applyEffects(s.vars, s.ctx, rep.effect, s.lastT, s.tArr);
    set({ vars: r.vars, log: [...s.log, { t: s.lastT, level: 'info', text: rep.text, detail: r.changes }] });
  },

  correctTrajectory: () => {
    const s = get();
    if (!s.ctx || !s.vars || s.vars.trajErrorKm <= 0) return;
    const r = applyEffects(s.vars, s.ctx, { correctTrajectory: true }, s.lastT, s.tArr);
    set({ vars: r.vars, log: [...s.log, { t: s.lastT, level: 'info', text: 'Corrección de trayectoria', detail: r.changes }] });
  },

  /** Reinicia el vuelo desde la plataforma (nuevo intento, nuevos eventos). */
  restart: () => {
    const s = get();
    const g = useGameStore.getState();
    useGameStore.setState({ launch: { ...g.launch, phase: 'ready', t: -10, running: false, cruiseH: 0 } });
    if (s.missionId && s.ctx && s.windows) get().init(s.missionId, s.ctx, s.windows, s.tArr, s.attempt + 1, s.profile);
  },

  // ── Descubrimientos ──
  observeDiscovery: () => {
    const d = get().discovery;
    if (!d) return;
    set({ discovery: { ...d, observed: true } });
    useFlightView.getState().setMode('target');
  },
  identifyDiscovery: () => {
    const d = get().discovery;
    if (d) set({ discovery: { ...d, identified: true } });
  },
  registerDiscovery: () => {
    const s = get();
    const d = s.discovery;
    const def = d && discoveryById(d.sighting.id);
    if (!d || !def || d.registered || !d.identified) return;
    const pts = discoveryPoints(def, d.observed);
    const dist = s.profile && def.zone !== 'sky' ? distanceTo(s.profile, d.sighting, s.lastT) : null;
    const entry: DiaryEntry = {
      id: def.id,
      t: s.lastT,
      name: def.name,
      typeLabel: def.typeLabel,
      distanceKm: dist,
      observed: d.observed,
      points: pts,
      pos: s.profile && def.zone !== 'sky' ? sightingPos(s.profile, d.sighting, s.lastT) : null,
    };
    set({
      discovery: { ...d, registered: true },
      diary: [...s.diary, entry],
      points: s.points + pts,
      log: [...s.log, { t: s.lastT, level: 'good', text: `Diario: ${def.name}`, detail: [`+${pts} puntos de descubrimiento`] }],
    });
  },
  closeDiscovery: () => {
    const d = get().discovery;
    if (!d) return;
    set({ discovery: null });
    if (useFlightView.getState().mode === 'target') useFlightView.getState().setMode('external');
    if (d.resume) resumeTime();
  },

  // ── Rescate ──
  rescueAccept: () => {
    const r = get().rescue;
    if (r?.step === 'offer') set({ rescue: { ...r, step: 'locate' } });
  },
  rescueDecline: () => {
    const s = get();
    if (s.rescue?.step !== 'offer') return;
    set({ rescue: { ...s.rescue, step: 'declined' }, rescueSettled: true, log: [...s.log, { t: s.lastT, level: 'info', text: 'Rescate rechazado: seguimos rumbo a la Luna' }] });
    if (s.rescueResume) resumeTime();
  },
  rescueLock: () => {
    const r = get().rescue;
    if (r?.step === 'locate' && readout(r).alignDeg <= RESCUE.lockDeg) {
      set({ rescue: { ...r, step: 'observe', observeT: 0 } });
      useFlightView.getState().setMode('target');
    }
  },
  rescueAnalyze: () => {
    const r = get().rescue;
    if (r?.step === 'observe' && r.observeT >= RESCUE.observeS) set({ rescue: { ...r, step: 'plan' } });
  },
  rescuePlan: (plan) => {
    const r = get().rescue;
    if (r?.step === 'plan') set({ rescue: { ...r, plan, step: 'approach' } });
  },
  rescueStep: (input, dt) => {
    const s = get();
    if (!s.rescue || !s.rescueCraft) return;
    // Pasos cortos (≤ 0,1 s) para que la física no dependa de la velocidad del tiempo elegida.
    let r = s.rescue;
    let left = dt;
    while (left > 1e-9 && r.step !== 'done' && r.step !== 'failed') {
      const h = Math.min(0.1, left);
      r = stepRescue(r, input, h, s.rescueCraft);
      left -= h;
    }
    set({ rescue: r });
  },
  rescueAssist: () => {
    const r = get().rescue;
    if (r?.step === 'approach' && canAssist(r)) set({ rescue: { ...r, step: 'assist', holdT: 0 } });
  },
  rescueRetry: () => {
    const r = get().rescue;
    if (r?.step === 'failed' && r.outcome === 'collision' && r.retries < 1) set({ rescue: retryRescue(r) });
  },
  /** Abandonar el rescate en cualquier momento del pilotaje (es opcional). */
  rescueAbort: () => {
    const r = get().rescue;
    if (r && ['locate', 'observe', 'plan', 'approach', 'assist'].includes(r.step)) set({ rescue: { ...r, step: 'failed', outcome: 'abandoned' } });
  },
  /** Cierra el rescate: combustible gastado + volver al rumbo, premio y tiempo transcurrido. */
  rescueFinish: () => {
    const s = get();
    const r = s.rescue;
    if (!r || !s.ctx || !s.vars || s.rescueSettled || (r.step !== 'done' && r.step !== 'failed')) return;
    const back = returnDv(r);
    const backKg = propellantForDv(back, s.ctx, s.vars.propellantKg);
    const ok = r.step === 'done';
    const pts = rescuePoints(r);
    const applied = applyEffects(s.vars, s.ctx, { propellantKg: -(r.fuelKg + backKg), scienceGbit: ok ? 1.5 : 0 }, s.lastT, s.tArr);
    const entry: DiaryEntry | null = ok
      ? { id: 'rescue', t: s.lastT, name: 'Rescate de un pequeño satélite', typeLabel: 'Misión de rescate', distanceKm: readout(r).distanceM / 1000, observed: true, points: pts, pos: null, rescue: true }
      : null;
    set({
      vars: applied.vars,
      rescueSettled: true,
      points: s.points + pts,
      diary: entry ? [...s.diary, entry] : s.diary,
      log: [
        ...s.log,
        {
          t: s.lastT,
          level: ok ? 'good' : 'warn',
          text: ok ? `Rescate completado: +${pts} puntos` : 'Rescate no completado',
          detail: [`Maniobra: ${r.dvUsed.toFixed(1).replace('.', ',')} m/s · volver al rumbo: ${back.toFixed(1).replace('.', ',')} m/s`, ...applied.changes],
        },
      ],
    });
    if (useFlightView.getState().mode === 'target') useFlightView.getState().setMode('external');
    advanceCruise(r.t);
    if (s.rescueResume) resumeTime();
  },

  setCruiseSpeed: (h) => set({ cruiseSpeed: h }),
  setCruisePaused: (p) => set({ cruisePaused: p }),
}));

// Al llegar a Operaciones, las consecuencias del vuelo pasan a la misión.
useGameStore.subscribe((g, prev) => {
  const sim = useFlightSim.getState();
  if (!sim.missionId || !sim.vars || sim.handedOff) return;
  const m = g.missions.find((x) => x.id === sim.missionId);
  const pm = prev.missions.find((x) => x.id === sim.missionId);
  if (!m || !pm || pm.stage !== 'LAUNCH' || m.stage !== 'OPERATIONS' || !m.flight) return;
  useFlightSim.setState({ handedOff: true });
  const v = sim.vars;
  const decisions = sim.log.filter((l) => l.level !== 'warn').length;
  const parts = [`${sim.fired.length} imprevisto(s)`, `${decisions} decisión(es)`];
  if (v.spentKg >= 0) parts.push(`${fmtNum(v.spentKg, 2)} kg de combustible extra gastado`);
  else parts.push(`${fmtNum(-v.spentKg, 2)} kg de combustible ahorrado`);
  if (v.scienceGbit > 0) parts.push(`${fmtNum(v.scienceGbit, 1)} Gbit de descubrimientos`);
  const lines = [{ tH: 0, level: 'info' as const, text: `Viaje a la Luna: ${parts.join(', ')}.` }];
  if (sim.diary.length) lines.push({ tH: 0, level: 'info' as const, text: `Diario de exploración: ${sim.diary.length} registro(s), ${sim.points} puntos de descubrimiento.` });
  if (sim.surfaceSummary) lines.push({ tH: 0, level: 'info' as const, text: sim.surfaceSummary });
  const flight = {
    ...m.flight,
    propellantKg: Math.max(0, m.flight.propellantKg - v.spentKg),
    deliveredGbit: m.flight.deliveredGbit + v.scienceGbit,
    log: [...m.flight.log, ...lines],
  };
  useGameStore.setState({ missions: upsertMission(g.missions, { ...m, flight }) });
});
