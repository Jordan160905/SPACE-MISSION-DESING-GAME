/**
 * Ventanas flotantes del centro de control (Fase 8.2): se arrastran por la cabecera, se minimizan,
 * pasan al frente al tocarlas y se pueden reordenar. Las posiciones se guardan en el navegador.
 */
import { useEffect, useMemo, type PointerEvent as RPointerEvent, type ReactNode } from 'react';
import { create } from 'zustand';

export type PanelId = 'controls' | 'check' | 'telemetry' | 'timeline' | 'map' | 'event' | 'discovery' | 'journal' | 'rescue';

interface PanelPos {
  x: number;
  y: number;
  min: boolean;
}

const KEY = 'nexus-flight-panels';
const WIDTHS: Record<PanelId, number> = { controls: 620, check: 320, telemetry: 330, timeline: 330, map: 380, event: 380, discovery: 380, journal: 360, rescue: 360 };
/** Alto aproximado al abrir un panel minimizado (si no cabe, sube). */
const OPEN_H: Record<PanelId, number> = { controls: 186, check: 560, telemetry: 600, timeline: 440, map: 260, event: 520, discovery: 560, journal: 520, rescue: 640 };

/** Distribución inicial: los bordes de la pantalla, dejando libre el centro de la escena. */
export function defaultLayout(w: number, h: number): Record<PanelId, PanelPos> {
  const right = Math.max(10, w - WIDTHS.telemetry - 10);
  return {
    check: { x: 10, y: 10, min: false },
    telemetry: { x: right, y: 64, min: false },
    timeline: { x: right, y: Math.max(120, h - 50), min: true },
    map: { x: 10, y: Math.max(120, h - 50), min: true },
    controls: { x: Math.max(10, (w - WIDTHS.controls) / 2), y: Math.max(80, h - 192), min: false },
    event: { x: Math.max(10, Math.min(w - WIDTHS.event - 10, w - WIDTHS.telemetry - WIDTHS.event - 30)), y: 64, min: false },
    // A la izquierda: el objeto se observa en el centro de la escena.
    discovery: { x: 10, y: 64, min: false },
    journal: { x: 10, y: Math.max(120, h - 100), min: true },
    rescue: { x: 10, y: 64, min: false },
  };
}

function load(): Partial<Record<PanelId, PanelPos>> {
  try {
    return JSON.parse(window.localStorage.getItem(KEY) ?? '{}');
  } catch {
    return {};
  }
}

interface LayoutState {
  pos: Partial<Record<PanelId, PanelPos>>;
  order: PanelId[];
  stage: { w: number; h: number };
  setStage: (w: number, h: number) => void;
  move: (id: PanelId, x: number, y: number) => void;
  setMin: (id: PanelId, min: boolean) => void;
  front: (id: PanelId) => void;
  arrange: () => void;
}

const save = (pos: Partial<Record<PanelId, PanelPos>>) => {
  try {
    window.localStorage.setItem(KEY, JSON.stringify(pos));
  } catch {
    /* sin almacenamiento: las posiciones duran la sesión */
  }
};

export const usePanelLayout = create<LayoutState>()((set, get) => ({
  pos: typeof window === 'undefined' ? {} : load(),
  order: ['controls', 'check', 'telemetry', 'timeline', 'map', 'journal', 'event', 'discovery', 'rescue'],
  stage: { w: 1200, h: 800 },
  setStage: (w, h) => set({ stage: { w, h } }),
  move: (id, x, y) => {
    const cur = get().pos[id] ?? defaultLayout(get().stage.w, get().stage.h)[id];
    const pos = { ...get().pos, [id]: { ...cur, x, y } };
    save(pos);
    set({ pos });
  },
  setMin: (id, min) => {
    const { w, h } = get().stage;
    const cur = get().pos[id] ?? defaultLayout(w, h)[id];
    // Al abrirlo, sube lo necesario para que se vea entero.
    const y = min ? cur.y : Math.max(0, Math.min(cur.y, h - OPEN_H[id] - 10));
    if (min === cur.min && y === cur.y) return;
    const pos = { ...get().pos, [id]: { ...cur, min, y } };
    save(pos);
    set({ pos });
  },
  front: (id) => set({ order: [...get().order.filter((x) => x !== id), id] }),
  /** «Ordenar paneles»: vuelve a la distribución inicial (abiertos y minimizados por defecto). */
  arrange: () => {
    save({});
    set({ pos: {} });
  },
}));

/** Posición efectiva de un panel (la guardada o la inicial), siempre dentro de la pantalla. */
export function usePanelPos(id: PanelId): PanelPos {
  const saved = usePanelLayout((s) => s.pos[id]);
  const stage = usePanelLayout((s) => s.stage);
  const d = defaultLayout(stage.w, stage.h)[id];
  const p = saved ?? d;
  return { min: p.min, x: Math.max(0, Math.min(p.x, stage.w - 120)), y: Math.max(0, Math.min(p.y, stage.h - 40)) };
}

/** Mide el área del HUD de vuelo para colocar y limitar los paneles. */
export function useStageSize(ref: { current: HTMLElement | null }) {
  const setStage = usePanelLayout((s) => s.setStage);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const upd = () => setStage(el.clientWidth, el.clientHeight);
    upd();
    const ro = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(upd) : null;
    ro?.observe(el);
    window.addEventListener('resize', upd);
    return () => {
      ro?.disconnect();
      window.removeEventListener('resize', upd);
    };
  }, [ref, setStage]);
}

interface Props {
  id: PanelId;
  title: ReactNode;
  eyebrow?: ReactNode;
  className?: string;
  /** Botones extra en la cabecera. */
  actions?: ReactNode;
  /** Ancho en px (por defecto el del panel). */
  width?: number;
  minimizable?: boolean;
  /** Espacio que se deja libre abajo (para los paneles minimizados). */
  reserveBottom?: number;
  children: ReactNode;
}

export function FloatPanel({ id, title, eyebrow, className = '', actions, width, minimizable = true, reserveBottom = 58, children }: Props) {
  const p = usePanelPos(id);
  const move = usePanelLayout((s) => s.move);
  const setMin = usePanelLayout((s) => s.setMin);
  const front = usePanelLayout((s) => s.front);
  const z = usePanelLayout((s) => s.order.indexOf(id));
  const stage = usePanelLayout((s) => s.stage);
  // Minimizado ocupa poco: solo la cabecera, más estrecha.
  const w = Math.min(p.min ? Math.min(250, width ?? WIDTHS[id]) : (width ?? WIDTHS[id]), stage.w - 20);
  const label = useMemo(() => (typeof title === 'string' ? title : id), [title, id]);

  const startDrag = (e: RPointerEvent<HTMLElement>) => {
    if ((e.target as HTMLElement).closest('button')) return;
    front(id);
    const el = e.currentTarget.parentElement as HTMLElement;
    const sx = e.clientX - p.x;
    const sy = e.clientY - p.y;
    const h = el.offsetHeight;
    const target = e.currentTarget;
    target.setPointerCapture(e.pointerId);
    const onMove = (ev: PointerEvent) => {
      const nx = Math.max(0, Math.min(ev.clientX - sx, stage.w - w));
      const ny = Math.max(0, Math.min(ev.clientY - sy, stage.h - Math.min(h, 48)));
      el.style.left = `${nx}px`;
      el.style.top = `${ny}px`;
    };
    const onUp = (ev: PointerEvent) => {
      target.removeEventListener('pointermove', onMove);
      target.removeEventListener('pointerup', onUp);
      target.removeEventListener('pointercancel', onUp);
      const nx = Math.max(0, Math.min(ev.clientX - sx, stage.w - w));
      const ny = Math.max(0, Math.min(ev.clientY - sy, stage.h - Math.min(h, 48)));
      move(id, nx, ny);
    };
    target.addEventListener('pointermove', onMove);
    target.addEventListener('pointerup', onUp);
    target.addEventListener('pointercancel', onUp);
  };

  return (
    <section
      className={`panel fpanel ${p.min ? 'fpanel--min' : ''} ${className}`}
      style={{ left: p.x, top: p.y, width: w, zIndex: 10 + z, maxHeight: Math.max(120, stage.h - p.y - reserveBottom) }}
      data-panel={id}
      aria-label={label}
      onPointerDown={() => front(id)}
    >
      <header className="fpanel__head" onPointerDown={startDrag} title="Arrastra para mover">
        <span className="fpanel__grip" aria-hidden="true">
          ⋮⋮
        </span>
        <div className="fpanel__titles">
          {eyebrow && <p className="eyebrow">{eyebrow}</p>}
          <h2 className="fpanel__title">{title}</h2>
        </div>
        {actions}
        {minimizable && (
          <button className="btn btn--ghost fpanel__btn" onClick={() => setMin(id, !p.min)} aria-label={p.min ? `Mostrar ${label}` : `Minimizar ${label}`} aria-expanded={!p.min}>
            {p.min ? '▢' : '—'}
          </button>
        )}
      </header>
      {!p.min && <div className="fpanel__body">{children}</div>}
    </section>
  );
}
