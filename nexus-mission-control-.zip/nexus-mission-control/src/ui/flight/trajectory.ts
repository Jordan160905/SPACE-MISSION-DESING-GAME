/**
 * Posición de la nave en el mini mapa Tierra–Luna (pura y probada). Esquemático, NO a escala:
 * la Luna está a 384 400 km, ~30 veces el diámetro terrestre.
 *   ascenso → órbita de aparcamiento → inyección translunar → crucero (4 días) → órbita lunar.
 */
import { CRUISE_HOURS, type LaunchTimeline } from '../../sim/LaunchSystem';

export { CRUISE_HOURS };

export const MAP = {
  earth: { x: 46, y: 92, r: 16 },
  parkingR: 25,
  moon: { x: 262, y: 52, r: 7 },
  lunarOrbitR: 13,
  /** Ángulo (rad) donde sale la inyección translunar de la órbita de aparcamiento. */
  departAngle: -0.55,
  /** Control de la curva de transferencia (Bézier cuadrática). */
  control: { x: 150, y: -18 },
};
export const EARTH_MOON_KM = 384_400;

export type TrajectoryInput =
  | { kind: 'launch'; t: number; tl: LaunchTimeline }
  | { kind: 'cruise'; hours: number }
  | { kind: 'orbit'; orbitPhase: number };

export interface TrajectoryPoint {
  x: number;
  y: number;
  /** Fracción del trayecto Tierra→Luna recorrida (0–1), para la barra de progreso. */
  progress: number;
  distanceFromEarthKm: number;
  leg: 'pad' | 'ascent' | 'parking' | 'tli' | 'cruise' | 'lunar-orbit';
}

const clamp = (v: number) => Math.max(0, Math.min(1, v));

export function transferStart() {
  const { earth, parkingR, departAngle } = MAP;
  return { x: earth.x + parkingR * Math.cos(departAngle), y: earth.y + parkingR * Math.sin(departAngle) };
}

export function transferEnd() {
  const { moon, lunarOrbitR } = MAP;
  return { x: moon.x - lunarOrbitR, y: moon.y };
}

/** Punto de la curva de transferencia para s ∈ [0,1]. */
export function transferPoint(s: number) {
  const a = transferStart();
  const b = transferEnd();
  const c = MAP.control;
  const u = 1 - s;
  return { x: u * u * a.x + 2 * u * s * c.x + s * s * b.x, y: u * u * a.y + 2 * u * s * c.y + s * s * b.y };
}

/** Trazado SVG de la transferencia. */
export function transferPath(): string {
  const a = transferStart();
  const b = transferEnd();
  return `M${a.x.toFixed(1)},${a.y.toFixed(1)} Q${MAP.control.x},${MAP.control.y} ${b.x.toFixed(1)},${b.y.toFixed(1)}`;
}

export function trajectoryAt(input: TrajectoryInput): TrajectoryPoint {
  const { earth, parkingR, departAngle, moon, lunarOrbitR } = MAP;
  if (input.kind === 'orbit') {
    const a = 2 * Math.PI * input.orbitPhase;
    return { x: moon.x + lunarOrbitR * Math.cos(a), y: moon.y + lunarOrbitR * Math.sin(a), progress: 1, distanceFromEarthKm: EARTH_MOON_KM, leg: 'lunar-orbit' };
  }
  if (input.kind === 'cruise') {
    const f = clamp(input.hours / CRUISE_HOURS);
    const s = 0.04 + 0.96 * f;
    const p = transferPoint(s);
    return { ...p, progress: s, distanceFromEarthKm: EARTH_MOON_KM * s, leg: 'cruise' };
  }
  const { t, tl } = input;
  const start = -Math.PI / 2;
  if (t <= 0) return { x: earth.x, y: earth.y - earth.r, progress: 0, distanceFromEarthKm: 0, leg: 'pad' };
  if (t <= tl.secoS) {
    const f = t / tl.secoS;
    const r = earth.r + (parkingR - earth.r) * f;
    const a = start + 0.5 * f;
    return { x: earth.x + r * Math.cos(a), y: earth.y + r * Math.sin(a), progress: 0, distanceFromEarthKm: 200 * f, leg: 'ascent' };
  }
  if (t <= tl.tliStartS) {
    // Casi una vuelta completa a la órbita de aparcamiento hasta el punto de salida.
    const f = (t - tl.secoS) / (tl.tliStartS - tl.secoS);
    const a0 = start + 0.5;
    const a1 = departAngle + 2 * Math.PI;
    const a = a0 + (a1 - a0) * f;
    return { x: earth.x + parkingR * Math.cos(a), y: earth.y + parkingR * Math.sin(a), progress: 0, distanceFromEarthKm: 200, leg: 'parking' };
  }
  const f = clamp((t - tl.tliStartS) / (tl.endS - tl.tliStartS));
  const s = 0.04 * f;
  return { ...transferPoint(s), progress: s, distanceFromEarthKm: 200 + (EARTH_MOON_KM * 0.04 - 200) * f, leg: 'tli' };
}
