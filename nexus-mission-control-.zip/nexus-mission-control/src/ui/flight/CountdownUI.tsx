/**
 * Piezas de interfaz de las decisiones contrarreloj (Fase 8.6): temporizador y ajustes.
 */
import { useEffect, useMemo, useRef, useState } from 'react';
import { COUNTDOWN } from '../../sim/Countdown';
import { useCountdownSettings } from './countdownSettings';

/** Temporizador visual (anillo + barra). Llama a onExpire una sola vez al llegar a 0. */
export function CountdownTimer({ seconds, onExpire }: { seconds: number; onExpire: () => void }) {
  const start = useMemo(() => performance.now(), []);
  const [left, setLeft] = useState(seconds);
  const fired = useRef(false);
  const cb = useRef(onExpire);
  cb.current = onExpire;
  useEffect(() => {
    const id = window.setInterval(() => {
      const l = Math.max(0, seconds - (performance.now() - start) / 1000);
      setLeft(l);
      if (l <= 0 && !fired.current) {
        fired.current = true;
        window.clearInterval(id);
        cb.current?.();
      }
    }, 100);
    return () => window.clearInterval(id);
  }, [seconds, start]);
  const frac = left / seconds;
  const R = 26;
  const C = 2 * Math.PI * R;
  const level = frac > 0.5 ? 'ok' : frac > 0.25 ? 'warn' : 'bad';
  const whole = Math.ceil(left);
  return (
    <div className={`cdt cdt--${level}`} role="timer" aria-live="off" aria-label={`Quedan ${whole} segundos para decidir`}>
      <svg viewBox="0 0 64 64" className="cdt__ring" aria-hidden="true">
        <circle cx={32} cy={32} r={R} className="cdt__track" />
        <circle cx={32} cy={32} r={R} className="cdt__arc" strokeDasharray={`${C * frac} ${C}`} transform="rotate(-90 32 32)" />
        <text x={32} y={38} textAnchor="middle" className="cdt__num">
          {whole}
        </text>
      </svg>
      <div className="cdt__side">
        <strong>¡Decide rápido!</strong>
        <span className="small">{`Quedan ${whole} s`}</span>
        <span className="cdt__bar" aria-hidden="true">
          <span style={{ width: `${frac * 100}%` }} />
        </span>
      </div>
    </div>
  );
}

/** Ajustes: activar o desactivar los temporizadores y elegir los segundos. */
export function CountdownSettings({ compact }: { compact?: boolean }) {
  const enabled = useCountdownSettings((s) => s.enabled);
  const seconds = useCountdownSettings((s) => s.seconds);
  const setEnabled = useCountdownSettings((s) => s.setEnabled);
  const setSeconds = useCountdownSettings((s) => s.setSeconds);
  return (
    <div className={`cds ${compact ? 'cds--compact' : ''}`} role="group" aria-label="Ajustes de las decisiones contrarreloj">
      {!compact && <h3 className="section-title">Decisiones contrarreloj</h3>}
      <label className="cds__row">
        <input type="checkbox" checked={enabled} onChange={(e) => setEnabled(e.target.checked)} />
        <span>Temporizadores activados</span>
      </label>
      <label className="cds__row">
        <span>Tiempo para decidir</span>
        <input type="range" min={COUNTDOWN.minS} max={COUNTDOWN.maxS} step={1} value={seconds} disabled={!enabled} onChange={(e) => setSeconds(Number(e.target.value))} aria-label="Segundos para decidir" />
        <span className="mono">{`${seconds} s`}</span>
      </label>
      {!compact && <p className="small muted">A veces, durante el viaje, habrá que decidir antes de que se acabe el tiempo. Si los desactivas, esas situaciones esperan a que decidas.</p>}
    </div>
  );
}
