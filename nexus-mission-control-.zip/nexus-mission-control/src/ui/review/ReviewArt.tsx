/**
 * Ilustraciones originales de la Revisión (SVG en línea, sin imágenes externas):
 * la directora de vuelo, los iconos de cada «poder», insignias de nivel, meteoritos de peligro y
 * el cohete del despegue. Decorativas: el texto de al lado siempre dice lo mismo (aria-hidden).
 */
import type { Mood, PowerCard, PowerState } from './reviewGame';

const STATE_COLOR: Record<PowerState, string> = { ok: 'var(--ok)', warn: 'var(--signal)', fail: 'var(--critical)', pending: 'var(--text-lo)' };

export function NpcAvatar({ mood }: { mood: Mood }) {
  const visor = mood === 'happy' ? '#63e6f0' : mood === 'thinking' ? '#9fb3ff' : '#ffb547';
  return (
    <svg className={`npc-avatar npc-avatar--${mood}`} viewBox="0 0 120 120" aria-hidden="true">
      <defs>
        <radialGradient id="npc-bg" cx="50%" cy="40%" r="60%">
          <stop offset="0" stopColor="#123a52" />
          <stop offset="1" stopColor="#050c18" />
        </radialGradient>
        <linearGradient id="npc-suit" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#e9f2fb" />
          <stop offset="1" stopColor="#9fb1c6" />
        </linearGradient>
      </defs>
      <circle cx="60" cy="60" r="58" fill="url(#npc-bg)" stroke={visor} strokeOpacity="0.6" strokeWidth="2" />
      {/* estrellas */}
      <circle cx="22" cy="28" r="1.4" fill="#fff" opacity="0.8" />
      <circle cx="98" cy="22" r="1.1" fill="#fff" opacity="0.7" />
      <circle cx="104" cy="58" r="1.3" fill="#fff" opacity="0.6" />
      {/* traje */}
      <path d="M20 118c2-24 18-36 40-36s38 12 40 36z" fill="url(#npc-suit)" />
      <rect x="44" y="92" width="32" height="14" rx="3" fill="#24435c" />
      <circle cx="51" cy="99" r="2.4" fill="#7ef0a8" />
      <circle cx="60" cy="99" r="2.4" fill="#ffb547" />
      <circle cx="69" cy="99" r="2.4" fill="#ff5d73" />
      {/* parche de misión (original) */}
      <circle cx="88" cy="96" r="7" fill="#1b2d63" stroke="#fff" strokeWidth="1.2" />
      <path d="M88 91l1.5 3.3 3.5.4-2.6 2.4.7 3.5-3.1-1.8-3.1 1.8.7-3.5-2.6-2.4 3.5-.4z" fill="#ffd36b" />
      {/* casco */}
      <circle cx="60" cy="54" r="32" fill="#dfe9f4" />
      <circle cx="60" cy="56" r="25" fill="#0b1626" />
      {/* cara */}
      <ellipse cx="60" cy="58" rx="17" ry="19" fill="#f2c49b" />
      <path d="M43 52c0-14 8-20 17-20s18 6 18 20c-4-6-10-9-18-9s-13 3-17 9z" fill="#5a3825" />
      <ellipse cx="53" cy="57" rx="2.2" ry={mood === 'happy' ? 1.6 : 2.4} fill="#1d2433" />
      <ellipse cx="67" cy="57" rx="2.2" ry={mood === 'happy' ? 1.6 : 2.4} fill="#1d2433" />
      {mood === 'worried' ? (
        <>
          <path d="M49 52l7-2.5M71 52l-7-2.5" stroke="#5a3825" strokeWidth="1.6" strokeLinecap="round" />
          <path d="M54 69q6-4 12 0" stroke="#8a3b3b" strokeWidth="2" fill="none" strokeLinecap="round" />
        </>
      ) : mood === 'thinking' ? (
        <path d="M54 68h12" stroke="#8a3b3b" strokeWidth="2" strokeLinecap="round" />
      ) : (
        <path d="M53 66q7 7 14 0" stroke="#8a3b3b" strokeWidth="2" fill="#fff" strokeLinecap="round" />
      )}
      <circle cx="49" cy="63" r="2.6" fill="#ff8a8a" opacity="0.35" />
      <circle cx="71" cy="63" r="2.6" fill="#ff8a8a" opacity="0.35" />
      {/* micrófono */}
      <path d="M40 60q2 14 14 15" stroke="#24435c" strokeWidth="2.2" fill="none" strokeLinecap="round" />
      <circle cx="55" cy="75" r="2.4" fill="#24435c" />
      {/* reflejo del visor */}
      <path d="M38 40a25 25 0 0 1 22-11" stroke={visor} strokeWidth="3" fill="none" strokeLinecap="round" opacity="0.8" />
      <circle cx="60" cy="56" r="25" fill="none" stroke={visor} strokeWidth="2" opacity="0.7" />
      {/* antena del casco */}
      <path d="M86 32l8-10" stroke="#9fb1c6" strokeWidth="2" />
      <circle cx="95" cy="21" r="3" fill={visor} className="npc-antenna" />
    </svg>
  );
}

export function PowerIcon({ id, state }: { id: PowerCard['id']; state: PowerState }) {
  const c = STATE_COLOR[state];
  const common = { className: 'power-icon', viewBox: '0 0 48 48', 'aria-hidden': true } as const;
  switch (id) {
    case 'energy':
      return (
        <svg {...common}>
          <circle cx="14" cy="13" r="6" fill="#ffd36b" />
          {[0, 45, 90, 135, 180, 225, 270, 315].map((a) => (
            <path key={a} d="M14 3v3" stroke="#ffd36b" strokeWidth="2" strokeLinecap="round" transform={`rotate(${a} 14 13)`} />
          ))}
          <path d="M18 40l6-16h20l-6 16z" fill="#1e3a66" stroke={c} strokeWidth="1.6" />
          <path d="M23 32h18M21 36h18M30 24l-4 16M37 24l-4 16" stroke={c} strokeWidth="1" opacity="0.7" />
          <path d="M31 40v5M26 45h10" stroke="#9fb1c6" strokeWidth="2" />
        </svg>
      );
    case 'battery':
      return (
        <svg {...common}>
          <rect x="8" y="14" width="30" height="20" rx="4" fill="#0b1626" stroke={c} strokeWidth="2" />
          <rect x="38" y="20" width="4" height="8" rx="1.5" fill={c} />
          <rect x="11" y="17" width="7" height="14" rx="1.5" fill={c} />
          <rect x="20" y="17" width="7" height="14" rx="1.5" fill={c} opacity={state === 'fail' ? 0.15 : 1} />
          <rect x="29" y="17" width="6" height="14" rx="1.5" fill={c} opacity={state === 'ok' ? 1 : 0.15} />
          <path d="M24 8l-3 5h4l-3 5" stroke="#ffd36b" strokeWidth="1.8" fill="none" strokeLinecap="round" />
        </svg>
      );
    case 'data':
      return (
        <svg {...common}>
          <path d="M8 30a14 14 0 0 0 20-20z" fill="#1e3a66" stroke={c} strokeWidth="1.8" />
          <path d="M18 20l6-6" stroke={c} strokeWidth="2" strokeLinecap="round" />
          <circle cx="25" cy="13" r="2.4" fill={c} />
          <path d="M14 30l-4 12h16l-4-12" fill="#24435c" />
          <path d="M31 9a10 10 0 0 1 8 8M33 4a15 15 0 0 1 11 11" stroke="#63e6f0" strokeWidth="2" fill="none" strokeLinecap="round" className="power-icon__waves" />
        </svg>
      );
    case 'mass':
      return (
        <svg {...common}>
          <path d="M24 4c6 5 8 13 8 22H16c0-9 2-17 8-22z" fill="#dfe9f4" />
          <circle cx="24" cy="16" r="3" fill="#1e3a66" stroke={c} strokeWidth="1.4" />
          <path d="M16 26l-5 7h5M32 26l5 7h-5" fill="#9fb1c6" />
          <path d="M8 40h32" stroke={c} strokeWidth="2.5" strokeLinecap="round" />
          <path d="M14 40l-3 5M34 40l3 5" stroke="#9fb1c6" strokeWidth="2" />
          <text x="24" y="38" textAnchor="middle" fontSize="7" fontFamily="monospace" fill={c} fontWeight="700">
            kg
          </text>
        </svg>
      );
    case 'money':
      return (
        <svg {...common}>
          {[34, 28, 22].map((y, k) => (
            <g key={y}>
              <ellipse cx={20 + k * 2} cy={y + 4} rx="12" ry="4" fill="#b8860b" />
              <ellipse cx={20 + k * 2} cy={y} rx="12" ry="4" fill="#ffd36b" stroke="#b8860b" />
            </g>
          ))}
          <circle cx="34" cy="16" r="9" fill="#ffd36b" stroke={c} strokeWidth="2" />
          <text x="34" y="20" textAnchor="middle" fontSize="11" fontWeight="700" fill="#7a5a00">
            $
          </text>
        </svg>
      );
    case 'fuel':
      return (
        <svg {...common}>
          <rect x="12" y="6" width="18" height="26" rx="5" fill="#24435c" stroke={c} strokeWidth="1.8" />
          <rect x="15" y={state === 'ok' ? 12 : state === 'warn' ? 20 : 27} width="12" height={state === 'ok' ? 17 : state === 'warn' ? 9 : 2} rx="2" fill={c} />
          <path d="M16 32l-2 5h14l-2-5" fill="#9fb1c6" />
          <path d="M21 37c-3 4-2 8 0 9 2-1 3-5 0-9z" fill="#ffb547" className="power-icon__flame" />
          <path d="M33 14h6l3 4v14" stroke="#9fb1c6" strokeWidth="2" fill="none" />
        </svg>
      );
  }
}

export function LevelBadge({ level, done, current, locked }: { level: number; done: boolean; current: boolean; locked: boolean }) {
  const col = done ? 'var(--ok)' : current ? 'var(--signal)' : 'var(--text-lo)';
  return (
    <svg className="level-badge" viewBox="0 0 48 48" aria-hidden="true">
      <path d="M24 3l18 10v22L24 45 6 35V13z" fill="#0b1626" stroke={col} strokeWidth="2.2" />
      {locked ? (
        <g>
          <rect x="16" y="22" width="16" height="12" rx="2" fill={col} />
          <path d="M19 22v-4a5 5 0 0 1 10 0v4" stroke={col} strokeWidth="2.4" fill="none" />
        </g>
      ) : done ? (
        <path d="M15 24l6 6 12-13" stroke={col} strokeWidth="3.4" fill="none" strokeLinecap="round" strokeLinejoin="round" />
      ) : (
        <text x="24" y="30" textAnchor="middle" fontSize="16" fontWeight="700" fontFamily="monospace" fill={col}>
          {level}
        </text>
      )}
    </svg>
  );
}

export function Meteor({ level }: { level: 'low' | 'medium' | 'high' }) {
  const s = level === 'high' ? 1 : level === 'medium' ? 0.8 : 0.62;
  const col = level === 'high' ? '#ff5d73' : level === 'medium' ? '#ffb547' : '#7ef0a8';
  return (
    <svg className={`meteor meteor--${level}`} viewBox="0 0 56 48" aria-hidden="true">
      <path d={`M${50 - 30 * s} ${20 + 6 * s}L54 4`} stroke={col} strokeWidth={6 * s} strokeLinecap="round" opacity="0.35" />
      <path d={`M${50 - 30 * s} ${24 + 4 * s}L50 12`} stroke={col} strokeWidth={3 * s} strokeLinecap="round" opacity="0.5" />
      <g transform={`translate(22 28) scale(${s})`}>
        <path d="M-15 -4c2-9 13-13 20-9 9 1 12 10 9 17-2 9-12 12-20 9-7-2-11-10-9-17z" fill="#5d6b7d" stroke={col} strokeWidth="2" />
        <circle cx="-5" cy="-3" r="4" fill="#3f4a58" />
        <circle cx="6" cy="4" r="3" fill="#3f4a58" />
        <circle cx="-2" cy="8" r="2" fill="#3f4a58" />
      </g>
    </svg>
  );
}

export function RocketHero({ go }: { go: boolean }) {
  return (
    <svg className={`rocket-hero ${go ? 'rocket-hero--go' : ''}`} viewBox="0 0 120 160" aria-hidden="true">
      {[
        [14, 20],
        [100, 34],
        [24, 90],
        [96, 110],
        [60, 10],
      ].map(([x, y]) => (
        <path key={`${x}-${y}`} d={`M${x} ${y - 4}l1.2 2.8 2.8 1.2-2.8 1.2-1.2 2.8-1.2-2.8-2.8-1.2 2.8-1.2z`} fill="#ffd36b" className="rocket-hero__star" />
      ))}
      <g className="rocket-hero__body">
        <path d="M60 18c14 12 20 34 20 60v34H40V78c0-26 6-48 20-60z" fill="#e9f2fb" />
        <path d="M60 18c6 6 10 13 13 22H47c3-9 7-16 13-22z" fill="#ff5d73" />
        <circle cx="60" cy="64" r="9" fill="#0b1626" stroke="#63e6f0" strokeWidth="3" />
        <circle cx="57" cy="61" r="2.5" fill="#63e6f0" opacity="0.7" />
        <path d="M40 92l-14 22h14zM80 92l14 22H80z" fill="#ff5d73" />
        <rect x="54" y="96" width="12" height="18" rx="2" fill="#24435c" />
        {go && (
          <g className="rocket-hero__flame">
            <path d="M46 112c2 18 8 30 14 40 6-10 12-22 14-40z" fill="#ffb547" />
            <path d="M52 112c1 12 4 20 8 27 4-7 7-15 8-27z" fill="#ffd36b" />
          </g>
        )}
      </g>
    </svg>
  );
}
