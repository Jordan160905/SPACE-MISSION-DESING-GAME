/** Construye la entrada de la revisión de concepto para una misión: el mismo análisis que el resto de pantallas. */
import { getComponent } from '../../data/components/catalog';
import { getMissionTemplate, templateForMission } from '../../data/missions/missions';
import type { Mission } from '../../data/schemas';
import type { ReviewInput } from '../../sim/ConceptReview';
import { analysisInputForMission, analyzeEngineering } from '../../sim/EngineeringAnalysis';
import { analyzePlan } from '../../sim/PlanningSystem';

export function reviewInputFor(mission: Mission): ReviewInput | null {
  const template = templateForMission(mission);
  if (!template) return null;
  const plan = mission.plan ? analyzePlan({ design: mission.design, lookup: getComponent, template, objectiveId: mission.objectiveId, plan: mission.plan, difficulty: mission.difficulty }) : null;
  const engineering = plan?.engineering ?? analyzeEngineering(analysisInputForMission(mission.design, getComponent, mission, getMissionTemplate));
  return { mission, template: plan ? { ...template, durationDays: plan.plan.durationDays } : template, engineering, plan, lookup: getComponent };
}
