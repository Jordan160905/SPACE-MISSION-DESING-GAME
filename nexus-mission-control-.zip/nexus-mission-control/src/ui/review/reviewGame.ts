/**
 * Revisión gamificada: traduce el mismo análisis de la junta (sim/ConceptReview, EngineeringAnalysis,
 * PlanningSystem) a «poderes» de la nave, estrellas y mensajes de la directora de vuelo.
 * No calcula nada nuevo: los umbrales son los mismos de la lista CML 4 (márgenes ≥ 10 %, reserva
 * de presupuesto ≥ 5 %, descarga de batería ≤ 40 %).
 */
import type { CmlReport, ReviewInput, Risk } from '../../sim/ConceptReview';
import { MAX_DOD, RECOMMENDED_DOD } from '../../sim/PowerSystem';
import { fmtNum } from '../../sim/units';
import { STAGE_ORDER } from '../../state/missionLogic';
import { numLocale } from '../../i18n/lang';

export type PowerState = 'ok' | 'warn' | 'fail' | 'pending';

export interface PowerCard {
  id: 'energy' | 'battery' | 'data' | 'mass' | 'money' | 'fuel';
  /** Nombre sencillo y término técnico. */
  title: string;
  tech: string;
  state: PowerState;
  /** Lo que se mide, en palabras simples. */
  value: string;
  /** Barra: valor relativo al límite (1 = justo en el límite). null si no hay datos. */
  fill: number | null;
  /** true: más es mejor (energía, datos). false: menos es mejor (masa, dinero…). */
  higherIsBetter: boolean;
  /** Etiqueta del límite que marca la barra. */
  limit: string;
  why: string;
  tip: string;
}

const LAUNCH_IDX = STAGE_ORDER.indexOf('LAUNCH');

export function powerCards(i: ReviewInput): PowerCard[] {
  const e = i.engineering;
  const p = e.power;
  const cards: PowerCard[] = [];

  // Energía: lo que sobra al sol frente a lo que hay que recargar tras la sombra.
  const eMargin = p && p.rechargeNeededWh > 0 ? p.orbitBalanceWh / p.rechargeNeededWh : p && p.orbitBalanceWh >= 0 ? 1 : -1;
  cards.push({
    id: 'energy',
    title: 'Energía',
    tech: 'Balance de energía por órbita',
    state: !p ? 'pending' : !p.sustainable ? 'fail' : eMargin >= 0.1 ? 'ok' : 'warn',
    value: p ? `${p.orbitBalanceWh >= 0 ? '+' : ''}${fmtNum(p.orbitBalanceWh)} Wh por vuelta` : 'Sin nave',
    fill: p ? (p.rechargeNeededWh > 0 ? p.sunlitSurplusWh / p.rechargeNeededWh : 1) : null,
    higherIsBetter: true,
    limit: 'lo que gasta en la sombra',
    why: 'Los paneles solares cargan la batería al sol. Cuando la nave pasa por la sombra de la Luna, vive solo de la batería.',
    tip: 'Más paneles o instrumentos que gasten menos.',
  });

  // Batería: cuánto se vacía en cada sombra.
  cards.push({
    id: 'battery',
    title: 'Batería',
    tech: 'Profundidad de descarga',
    state: !p ? 'pending' : p.depthOfDischarge <= RECOMMENDED_DOD ? 'ok' : p.depthOfDischarge <= MAX_DOD ? 'warn' : 'fail',
    value: p ? `Se vacía un ${Math.round(p.depthOfDischarge * 100)} % en cada sombra` : 'Sin nave',
    fill: p ? p.depthOfDischarge / RECOMMENDED_DOD : null,
    higherIsBetter: false,
    limit: `${Math.round(RECOMMENDED_DOD * 100)} % recomendado`,
    why: 'Una batería que se vacía mucho en cada vuelta se cansa rápido, como la de un celular viejo.',
    tip: 'Una batería más grande se vacía menos.',
  });

  // Ciencia: datos que llegan a la Tierra frente a la meta del objetivo.
  const d = e.data;
  cards.push({
    id: 'data',
    title: 'Ciencia enviada',
    tech: 'Datos entregados frente al objetivo',
    state: !d ? 'pending' : d.targetGbit === 0 || d.missionDeliveredGbit >= d.targetGbit * 1.1 ? 'ok' : d.targetMet ? 'warn' : 'fail',
    value: d ? (d.targetGbit > 0 ? `${fmtNum(d.missionDeliveredGbit, 0)} de ${d.targetGbit.toLocaleString(numLocale())} Gbit` : `${fmtNum(d.missionDeliveredGbit, 0)} Gbit`) : 'Sin nave',
    fill: d ? (d.targetGbit > 0 ? d.missionDeliveredGbit / d.targetGbit : 1) : null,
    higherIsBetter: true,
    limit: 'meta científica',
    why: 'La misión existe para traer datos. La antena los envía a la Tierra cuando hay contacto.',
    tip: 'Antena más rápida, más memoria o una misión más larga.',
  });

  // Peso: masa con margen frente a lo que el cohete lleva a la Luna.
  const cap = i.plan?.launcher.payloadToTLIKg ?? 0;
  const massKg = i.plan?.massWithMarginKg ?? e.mass?.wetWithMarginKg ?? 0;
  const lm = cap > 0 ? (cap - massKg) / cap : -1;
  cards.push({
    id: 'mass',
    title: 'Peso',
    tech: 'Masa frente a la capacidad del lanzador',
    state: !i.plan ? (e.mass ? (e.mass.launchersThatFit.length > 0 ? 'warn' : 'fail') : 'pending') : lm >= 0.1 && i.plan.fairingFits ? 'ok' : lm >= 0 && i.plan.fairingFits ? 'warn' : 'fail',
    value: i.plan ? `${fmtNum(massKg)} kg de ${cap.toLocaleString(numLocale())} kg que lleva el ${i.plan.launcher.name}` : e.mass ? `${fmtNum(massKg)} kg (aún sin cohete elegido)` : 'Sin nave',
    fill: i.plan && cap > 0 ? massKg / cap : null,
    higherIsBetter: false,
    limit: 'capacidad del cohete',
    why: 'Cada cohete solo puede llevar cierto peso hasta la Luna. Conviene que sobre un poco por si la nave crece.',
    tip: 'Quita piezas que no uses o elige un cohete más grande.',
  });

  // Dinero: costo comprometido frente al tope.
  const b = e.budget;
  const reserve = b && b.capMUSD > 0 ? b.remainingMUSD / b.capMUSD : -1;
  cards.push({
    id: 'money',
    title: 'Dinero',
    tech: 'Costo frente al presupuesto',
    state: !b ? 'pending' : b.overBudget ? 'fail' : reserve >= 0.05 ? 'ok' : 'warn',
    value: b ? `${fmtNum(b.committedMUSD)} de ${b.capMUSD} millones de dólares` : 'Sin nave',
    fill: b ? b.usedFraction : null,
    higherIsBetter: false,
    limit: 'presupuesto',
    why: 'Las misiones reales tienen un tope de dinero. Si te pasas, la misión se cancela.',
    tip: 'Piezas más baratas o un cohete más económico.',
  });

  // Combustible: Δv disponible frente a lo necesario.
  const dv = i.plan?.deltaV;
  cards.push({
    id: 'fuel',
    title: 'Combustible',
    tech: 'Presupuesto de Δv',
    state: !dv ? 'pending' : !dv.ok ? 'fail' : dv.marginFraction >= 0.1 ? 'ok' : 'warn',
    value: dv ? `${fmtNum(dv.availableMS, 0)} m/s de ${Number.isFinite(dv.requiredMS) ? fmtNum(dv.requiredMS, 0) : '∞'} m/s que necesita` : 'Falta el plan de vuelo',
    fill: dv && Number.isFinite(dv.requiredMS) && dv.requiredMS > 0 ? dv.availableMS / dv.requiredMS : null,
    higherIsBetter: true,
    limit: 'lo que necesita para frenar y mantenerse',
    why: 'Al llegar, la nave enciende el motor para frenar y quedarse en órbita. Δv es cuánto puede cambiar su velocidad con el combustible que lleva.',
    tip: 'Otro tanque, una nave más ligera o una ventana de lanzamiento óptima.',
  });
  return cards;
}

/** Estrellas: una por cada poder en verde. */
export function stars(cards: PowerCard[]): { earned: number; total: number } {
  return { earned: cards.filter((c) => c.state === 'ok').length, total: cards.length };
}

/** Nombres sencillos de cada nivel CML (el nombre oficial se muestra debajo). */
export const CML_KID_NAME: Record<number, string> = {
  1: 'La idea',
  2: '¿Es posible?',
  3: 'Comparar opciones',
  4: 'Diseño elegido',
  5: 'Lista para la junta',
};

export type Mood = 'happy' | 'thinking' | 'worried';
export interface NpcLine {
  mood: Mood;
  text: string;
}

export type FlightGate = 'design' | 'plan' | 'ready' | 'flown';

/** ¿Puede la misión ir al vuelo? Requiere el plan confirmado (etapa Lanzamiento o posterior). */
export function flightGate(stage: ReviewInput['mission']['stage']): FlightGate {
  const idx = STAGE_ORDER.indexOf(stage);
  if (idx < STAGE_ORDER.indexOf('PLANNING')) return 'design';
  if (idx < LAUNCH_IDX) return 'plan';
  return idx === LAUNCH_IDX ? 'ready' : 'flown';
}

const STATE_RANK: Record<PowerState, number> = { fail: 0, warn: 1, pending: 2, ok: 3 };

export function npcLines(cml: CmlReport, cards: PowerCard[], risks: Risk[], gate: FlightGate): Record<'level' | 'powers' | 'risks' | 'launch', NpcLine> {
  const worst = [...cards].filter((c) => c.state !== 'ok').sort((a, b) => STATE_RANK[a.state] - STATE_RANK[b.state])[0];
  const high = risks.filter((r) => r.level === 'high');
  const next = cml.next;
  const missing = next ? [...next.keyMissing, ...cml.items.filter((x) => x.level === next.level && x.status !== 'G' && !x.key)][0] : undefined;
  const { earned, total } = stars(cards);
  return {
    level:
      cml.level >= 5
        ? { mood: 'happy', text: `¡Nivel ${cml.level} alcanzado! Tu misión está tan madura como para presentarla ante una junta de la NASA.` }
        : {
            mood: cml.level >= 3 ? 'thinking' : 'worried',
            text: `Tu misión está en el nivel ${cml.level}. ${missing ? `Para subir al nivel ${next!.level}, lo más importante es: «${missing.label}».` : 'Sigue avanzando para subir de nivel.'}`,
          },
    powers:
      !worst
        ? { mood: 'happy', text: `¡Todos los sistemas en verde! Ganaste ${earned} de ${total} estrellas.` }
        : worst.state === 'pending'
          ? { mood: 'thinking', text: `Llevas ${earned} de ${total} estrellas. Aún falta información de «${worst.title}»: ${worst.tip}` }
          : { mood: worst.state === 'fail' ? 'worried' : 'thinking', text: `Llevas ${earned} de ${total} estrellas. Revisa «${worst.title}»: ${worst.tip}` },
    risks:
      high.length === 0
        ? { mood: 'happy', text: risks.length ? 'Ningún peligro grande a la vista. Aun así, conoce tus escudos por si acaso.' : 'Todavía no hay datos para buscar peligros: diseña la nave primero.' }
        : { mood: 'worried', text: `¡Cuidado! Hay ${high.length} ${high.length === 1 ? 'peligro grande' : 'peligros grandes'}. El más serio: «${high[0].title}».` },
    launch:
      gate === 'ready'
        ? { mood: 'happy', text: '¡La junta aprueba! El cohete te espera en la plataforma. ¿Listo para la cuenta regresiva?' }
        : gate === 'flown'
          ? { mood: 'happy', text: 'Esta misión ya despegó. Puedes volver al vuelo para seguirla.' }
          : gate === 'plan'
            ? { mood: 'thinking', text: 'Casi: falta confirmar el plan de vuelo en el Planner antes de despegar.' }
            : { mood: 'worried', text: 'Primero hay que terminar y aprobar el diseño de la nave en el LAB.' },
  };
}

/** Datos curiosos verificables que amplían lo que se ve en cada paso. */
export const FUN_FACTS: Record<'level' | 'powers' | 'risks' | 'launch', string> = {
  level: 'La NASA mide qué tan madura está una idea de misión con 9 niveles (CML). En NEXUS puedes llegar hasta el 5: el nivel de una Revisión del Concepto de Misión.',
  powers: 'Un CubeSat 1U es un cubo de 10 cm por lado que pesa entre 1 y 1,33 kg. ¡Muchas misiones reales empezaron así de pequeñas!',
  risks: 'La Luna tiene «mascons»: zonas con más masa bajo la superficie que tiran de las naves en órbitas bajas y deforman su órbita.',
  launch: 'La Luna está, en promedio, a unos 384 400 km de la Tierra. En NEXUS tu nave tarda 4 días en llegar.',
};
