/**
 * MassSystem — masa seca, propelente y masa con margen de diseño.
 * Margen de 10 % sobre la masa seca: práctica habitual porque los diseños "engordan".
 * La comparación con la capacidad del lanzador se completa en la Fase 4.
 */
import type { Launcher, SpacecraftDesign } from '../data/schemas';
import type { ComponentLookup } from './BudgetSystem';
import { designTotals } from './DesignSystem';

export const DRY_MASS_MARGIN = 0.1;

export interface MassAnalysis {
  dryKg: number;
  propellantKg: number;
  wetKg: number;
  marginKg: number;
  /** Masa a considerar frente al lanzador: húmeda + margen. */
  wetWithMarginKg: number;
  /** Lanzadores que pueden llevarla (con margen), del más barato al más caro. */
  launchersThatFit: string[];
}

export function analyzeMass(design: SpacecraftDesign, lookup: ComponentLookup, launchers: Launcher[]): MassAnalysis {
  const t = designTotals(design, lookup);
  const marginKg = t.massDryKg * DRY_MASS_MARGIN;
  const wetWithMarginKg = t.massWetKg + marginKg;
  return {
    dryKg: t.massDryKg,
    propellantKg: t.propellantKg,
    wetKg: t.massWetKg,
    marginKg,
    wetWithMarginKg,
    launchersThatFit: [...launchers].sort((a, b) => (a.costMUSD ?? Infinity) - (b.costMUSD ?? Infinity)).filter((l) => l.payloadToTLIKg >= wetWithMarginKg).map((l) => l.id),
  };
}
