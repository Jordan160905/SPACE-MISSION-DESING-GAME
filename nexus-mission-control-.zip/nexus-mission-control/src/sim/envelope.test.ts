import { describe, expect, it } from 'vitest';
import { getComponent } from '../data/components/catalog';
import { EMPTY_DESIGN, placePart, setChassis } from './DesignSystem';
import { stowedEnvelope } from './EnvelopeSystem';

const L = getComponent;
function build(chassisId: string, parts: Array<[string, string]>) {
  let d = setChassis(EMPTY_DESIGN, chassisId, L).design;
  for (const [c, s] of parts) d = placePart(d, c, s, L).design;
  return d;
}

describe('EnvelopeSystem', () => {
  it('sin chasis no hay envolvente', () => {
    expect(stowedEnvelope(EMPTY_DESIGN, L)).toBe(null);
  });

  it('chasis mediano vacío: diagonal de la caja y anillo inferior', () => {
    const e = stowedEnvelope(build('chassis-m', []), L)!;
    expect(e.diameterM).toBeCloseTo(2 * Math.hypot(0.5, 0.5), 6);
    expect(e.heightM).toBeCloseTo(1.1 + 0.12, 6);
  });

  it('calcula a mano el diseño de referencia (cámara)', () => {
    const e = stowedEnvelope(
      build('chassis-m', [
        ['camera', 'bottom-0'],
        ['thruster', 'bottom-1'],
        ['antenna-hg', 'top-0'],
        ['attitude-sensor', 'side-pz-0'],
        ['solar-adv', 'side-px-0'],
      ]),
      L,
    )!;
    // Radio: sensor en +Z → hypot(0.5 + 0.22, 0 + 0.1) = 0.7269 > diagonal 0.7071
    expect(e.diameterM).toBeCloseTo(2 * Math.hypot(0.72, 0.1), 6);
    // Altura: 1.1 (caja) + 0.47 (antena) + 0.57 (cámara)
    expect(e.heightM).toBeCloseTo(1.1 + 0.47 + 0.57, 6);
  });

  it('el radar inferior ensancha mucho la envolvente', () => {
    const e = stowedEnvelope(build('chassis-m', [['radar', 'bottom-0']]), L)!;
    expect(e.diameterM).toBeCloseTo(2 * (0.3 + 0.625), 6);
  });
});
