/**
 * MissionSystem — simulación de la nave en órbita lunar, paso a paso (Fase 5).
 *
 * Usa EXACTAMENTE los mismos supuestos que el análisis medio de la Fase 3 (OrbitSystem,
 * PowerSystem, DataSystem), pero integrados en el tiempo con pasos de 2 minutos:
 *  - Fase orbital φ = (t / T) mod 1. Iluminada si φ < 1 − f_eclipse; el resto es eclipse.
 *  - La Tierra queda oculta en el mismo arco (peor caso: Sol y Tierra del mismo lado).
 *  - Estación terrestre: las primeras 8 h de cada día de misión. Contacto = estación ∧ Tierra visible.
 *  - Instrumentos pasivos: solo trabajan (y consumen) con luz. Activos: siempre. Apagados: nada.
 *  - Batería: carga con eficiencia 0,9; si llega a 0 → MODO SEGURO (instrumentos apagados).
 *    Sale del modo seguro al recuperar el 60 %. Si ni los sistemas básicos tienen energía → apagón.
 *  - Datos: lo que no cabe en memoria se pierde; en contacto se transmite a la tasa de la mejor antena.
 *  - Propelente: el mantenimiento orbital se paga continuamente (Tsiolkovsky con la masa actual).
 * La duración se mide desde la llegada a la órbita (tras la inserción lunar).
 */
import type { ComponentDef, FlightEventType, FlightLogEntry, FlightState, MissionPlan, SpacecraftDesign } from '../data/schemas';
import type { ComponentLookup } from './BudgetSystem';
import { designComponents, designTotals } from './DesignSystem';
import { analyzeOrbit, GROUND_STATION_HOURS_PER_DAY, type OrbitAnalysis } from './OrbitSystem';
import { BATTERY_CHARGE_EFFICIENCY, PANEL_EFFECTIVE_FACTOR } from './PowerSystem';
import { G0, loiDeltaV, stationKeepingDeltaV, TCM_MARGIN_MS, windowInfo } from './TrajectorySystem';
import { mbpsToGbitPerHour } from './units';

export const FLIGHT_STEP_H = 1 / 30; // 2 minutos
export const SAFE_MODE_EXIT_FRACTION = 0.6;
const MAX_LOG = 200;

export interface FlightInstrument {
  instanceId: string;
  componentId: string;
  name: string;
  drawW: number;
  dataGbitPerH: number;
  requiresSunlight: boolean;
}

/** Datos fijos de un vuelo (dependen del diseño y del plan, no del tiempo). */
export interface FlightModel {
  orbit: OrbitAnalysis;
  periodH: number;
  sunlitFraction: number;
  durationH: number;
  sunlitGenW: number;
  busLoadW: number;
  instruments: FlightInstrument[];
  antennaDrawW: number;
  downlinkGbitPerH: number;
  batteryCapacityWh: number;
  storageCapacityGbit: number;
  ispS: number;
  dryKg: number;
  /** Δv de mantenimiento por hora (m/s/h). */
  skMsPerHour: number;
  targetGbit: number;
}

export function buildFlightModel(
  design: SpacecraftDesign,
  lookup: ComponentLookup,
  plan: Pick<MissionPlan, 'altitudeKm' | 'inclinationDeg' | 'durationDays'>,
  targetGbit: number,
): FlightModel {
  const comps = designComponents(design, lookup);
  const orbit = analyzeOrbit({ altitudeKm: plan.altitudeKm, inclinationDeg: plan.inclinationDeg });
  const antenna = comps.filter((c) => c.category === 'COMMS').sort((a, b) => b.downlinkMbps - a.downlinkMbps)[0];
  const busLoadW = comps
    .filter((c) => c.category !== 'COMMS' && c.category !== 'PROPULSION' && c.category !== 'INSTRUMENT')
    .reduce((s, c) => s + c.powerDrawW, 0);
  const instruments: FlightInstrument[] = design.parts
    .map((p) => ({ p, c: lookup(p.componentId) as ComponentDef | undefined }))
    .filter((x): x is { p: (typeof design.parts)[number]; c: ComponentDef } => !!x.c && x.c.category === 'INSTRUMENT')
    .map(({ p, c }) => ({
      instanceId: p.instanceId,
      componentId: c.id,
      name: c.name,
      drawW: c.powerDrawW,
      dataGbitPerH: c.dataGenGbitPerH,
      requiresSunlight: c.requiresSunlight,
    }));
  const engines = comps.filter((c) => c.ispS > 0);
  const t = designTotals(design, lookup);
  return {
    orbit,
    periodH: orbit.periodS / 3600,
    sunlitFraction: 1 - orbit.eclipseFraction,
    durationH: plan.durationDays * 24,
    sunlitGenW: t.powerGenW * PANEL_EFFECTIVE_FACTOR,
    busLoadW,
    instruments,
    antennaDrawW: antenna?.powerDrawW ?? 0,
    downlinkGbitPerH: mbpsToGbitPerHour(antenna?.downlinkMbps ?? 0),
    batteryCapacityWh: t.energyStorageWh,
    storageCapacityGbit: t.dataStorageGbit,
    ispS: engines.length ? Math.max(...engines.map((c) => c.ispS)) : 0,
    dryKg: t.massDryKg,
    skMsPerHour: stationKeepingDeltaV(plan.altitudeKm, 1) / 24,
    targetGbit,
  };
}

/** Propelente que queda tras quemar `dvMS` partiendo de `propKg` (Tsiolkovsky). */
export function propellantAfterBurn(dryKg: number, propKg: number, ispS: number, dvMS: number): number {
  if (ispS <= 0 || dvMS <= 0) return propKg;
  const m0 = dryKg + propKg;
  const m1 = m0 * Math.exp(-dvMS / (ispS * G0));
  return Math.max(0, m1 - dryKg);
}

export function log(state: FlightState, level: FlightLogEntry['level'], text: string): FlightState {
  const entries = [...state.log, { tH: state.elapsedH, level, text }];
  return { ...state, log: entries.length > MAX_LOG ? entries.slice(entries.length - MAX_LOG) : entries };
}

/**
 * Estado al llegar a la órbita: batería llena, memoria vacía y el propelente que queda tras las
 * correcciones de trayectoria, la penalización de ventana y la inserción lunar.
 */
export function initFlight(
  model: FlightModel,
  plan: MissionPlan,
  propellantKg: number,
  scheduledEvents: Array<{ id: string; type: FlightEventType; atH: number }> = [],
): FlightState {
  const dv = TCM_MARGIN_MS + windowInfo(plan.launchDay).penaltyMS + loiDeltaV(plan.altitudeKm);
  const left = Number.isFinite(dv) ? propellantAfterBurn(model.dryKg, propellantKg, model.ispS, dv) : 0;
  let s: FlightState = {
    elapsedH: 0,
    batteryWh: model.batteryCapacityWh,
    storageGbit: 0,
    generatedGbit: 0,
    deliveredGbit: 0,
    lostGbit: 0,
    propellantKg: left,
    instrumentsOff: [],
    safeMode: false,
    blackoutH: 0,
    minBatteryFraction: 1,
    propellantDepleted: left <= 0,
    complete: false,
    log: [],
    scheduledEvents,
    pendingEventId: null,
    eventHistory: [],
    effects: [],
    extraCostMUSD: 0,
    safeModeEntries: 0,
  };
  s = log(s, 'info', `Inserción en órbita lunar completada: ${Math.round(dv)} m/s, quedan ${left.toFixed(1)} kg de propelente.`);
  s = log(s, 'info', `Órbita de ${plan.altitudeKm} km · ${plan.inclinationDeg}°. Comienza la campaña de ${plan.durationDays} días.`);
  return s;
}

export interface FlightSnapshot {
  orbitPhase: number;
  sunlit: boolean;
  earthVisible: boolean;
  stationAvailable: boolean;
  contact: boolean;
  genW: number;
  loadW: number;
  /** Instrumentos produciendo ahora mismo. */
  activeInstrumentIds: string[];
  dataRateGbitPerH: number;
  batteryFraction: number;
  storageFraction: number;
  deltaVLeftMS: number;
  /** Horas hasta la próxima ventana de estación (0 si está abierta). */
  nextStationH: number;
  /** Factor de generación por acontecimientos (1 = normal). */
  genFactor: number;
  stationOutage: boolean;
  offlineInstrumentIds: string[];
}

/** Efectos vigentes en el instante actual. */
export function activeEffects(s: FlightState) {
  return s.effects.filter((e) => e.kind === 'instrument-rate' || e.untilH > s.elapsedH + 1e-9);
}

export function snapshot(model: FlightModel, s: FlightState): FlightSnapshot {
  const orbitPhase = (s.elapsedH / model.periodH) % 1;
  const sunlit = orbitPhase < model.sunlitFraction;
  const earthVisible = sunlit; // mismo arco de ocultación que de eclipse (peor caso)
  const hourOfDay = s.elapsedH % 24;
  const fx = activeEffects(s);
  const outage = fx.some((e) => e.kind === 'station-outage');
  const stationAvailable = hourOfDay < GROUND_STATION_HOURS_PER_DAY && !outage;
  const contact = stationAvailable && earthVisible && model.downlinkGbitPerH > 0;
  const offline = new Set(fx.flatMap((e) => (e.kind === 'instrument-offline' ? [e.instanceId] : [])));
  const working = s.safeMode
    ? []
    : model.instruments.filter((i) => !s.instrumentsOff.includes(i.instanceId) && !offline.has(i.instanceId) && (!i.requiresSunlight || sunlit));
  const genFactor = fx.reduce((f, e) => (e.kind === 'gen-factor' ? f * e.factor : f), 1);
  const rateOf = (id: string) => fx.reduce((f, e) => (e.kind === 'instrument-rate' && e.instanceId === id ? f * e.factor : f), 1);
  const genW = sunlit ? model.sunlitGenW * genFactor : 0;
  const loadW = model.busLoadW + working.reduce((a, i) => a + i.drawW, 0) + (contact ? model.antennaDrawW : 0);
  const deltaVLeftMS = model.ispS > 0 ? model.ispS * G0 * Math.log((model.dryKg + s.propellantKg) / model.dryKg) : 0;
  return {
    orbitPhase,
    sunlit,
    earthVisible,
    stationAvailable,
    contact,
    genW,
    loadW,
    activeInstrumentIds: working.map((i) => i.instanceId),
    dataRateGbitPerH: working.reduce((a, i) => a + i.dataGbitPerH * rateOf(i.instanceId), 0),
    genFactor,
    stationOutage: outage,
    offlineInstrumentIds: [...offline],
    batteryFraction: model.batteryCapacityWh > 0 ? s.batteryWh / model.batteryCapacityWh : 0,
    storageFraction: model.storageCapacityGbit > 0 ? s.storageGbit / model.storageCapacityGbit : 1,
    deltaVLeftMS,
    nextStationH: stationAvailable ? 0 : 24 - hourOfDay,
  };
}

/** Un paso elemental de integración (dt en horas). */
function microStep(model: FlightModel, s0: FlightState, dt: number): FlightState {
  let s = s0;
  const snap = snapshot(model, s);

  // Energía
  const net = snap.genW - snap.loadW;
  let battery = s.batteryWh;
  let blackout = s.blackoutH;
  if (net >= 0) {
    battery = Math.min(model.batteryCapacityWh, battery + net * dt * BATTERY_CHARGE_EFFICIENCY);
  } else {
    battery -= -net * dt;
    if (battery < 0) {
      battery = 0;
      if (s.safeMode) blackout += dt; // ni siquiera los sistemas básicos
    }
  }
  s = { ...s, batteryWh: battery, blackoutH: blackout };
  const frac = model.batteryCapacityWh > 0 ? battery / model.batteryCapacityWh : 0;
  s = { ...s, minBatteryFraction: Math.min(s.minBatteryFraction, frac) };
  if (!s.safeMode && battery <= 0) {
    s = log({ ...s, safeMode: true, safeModeEntries: s.safeModeEntries + 1 }, 'critical', 'Batería agotada: MODO SEGURO. Instrumentos apagados para proteger la nave.');
  } else if (s.safeMode && frac >= SAFE_MODE_EXIT_FRACTION) {
    s = log({ ...s, safeMode: false }, 'info', `Batería al ${Math.round(frac * 100)} %: se restablecen los instrumentos.`);
  }

  // Datos (con el estado de instrumentos al inicio del paso)
  const produced = snap.dataRateGbitPerH * dt;
  let storage = s.storageGbit + produced;
  let lost = s.lostGbit;
  if (storage > model.storageCapacityGbit) {
    lost += storage - model.storageCapacityGbit;
    storage = model.storageCapacityGbit;
  }
  let delivered = s.deliveredGbit;
  if (snap.contact) {
    const sent = Math.min(storage, model.downlinkGbitPerH * dt);
    storage -= sent;
    delivered += sent;
  }
  s = { ...s, storageGbit: storage, lostGbit: lost, deliveredGbit: delivered, generatedGbit: s.generatedGbit + produced };

  // Propelente de mantenimiento
  if (!s.propellantDepleted && model.ispS > 0) {
    const left = propellantAfterBurn(model.dryKg, s.propellantKg, model.ispS, model.skMsPerHour * dt);
    s = { ...s, propellantKg: left };
    if (left <= 0) s = log({ ...s, propellantDepleted: true }, 'critical', 'Propelente agotado: ya no se puede mantener la órbita; los mascons la irán deformando.');
  }

  return { ...s, elapsedH: s.elapsedH + dt };
}

/** Siguiente acontecimiento programado que aún no ha ocurrido. */
export function nextScheduledEvent(state: FlightState) {
  const done = new Set(state.eventHistory.map((e) => e.id));
  return state.scheduledEvents.filter((e) => !done.has(e.id) && e.id !== state.pendingEventId).sort((a, b) => a.atH - b.atH)[0];
}

/** Retira los efectos caducados y lo anota en el registro. */
function expireEffects(s: FlightState): FlightState {
  const keep = s.effects.filter((e) => e.kind === 'instrument-rate' || e.untilH > s.elapsedH + 1e-9);
  if (keep.length === s.effects.length) return s;
  let out: FlightState = { ...s, effects: keep };
  for (const e of s.effects) {
    if (keep.includes(e)) continue;
    const text =
      e.kind === 'gen-factor'
        ? 'Generación eléctrica restablecida.'
        : e.kind === 'station-outage'
          ? 'Estación terrestre operativa de nuevo.'
          : e.kind === 'instrument-offline'
            ? 'Instrumento de nuevo en servicio.'
            : '';
    if (text) out = log(out, 'info', text);
  }
  return out;
}

export interface StepOptions {
  /** Para previsiones: no detenerse en acontecimientos futuros. */
  ignoreEvents?: boolean;
}

/**
 * Avanza la simulación `hours` horas (o hasta el final de la campaña). Si llega la hora de un
 * acontecimiento, se detiene en ese instante y lo deja PENDIENTE: no avanza hasta que se resuelva.
 */
export function stepFlight(model: FlightModel, state: FlightState, hours: number, opts: StepOptions = {}): FlightState {
  if (state.complete || (state.pendingEventId && !opts.ignoreEvents)) return state;
  let s = state;
  let end = Math.min(state.elapsedH + hours, model.durationH);
  const next = opts.ignoreEvents ? undefined : nextScheduledEvent(s);
  const eventDue = next !== undefined && next.atH <= end + 1e-9;
  if (eventDue) end = Math.max(s.elapsedH, next.atH);
  const targetBefore = s.deliveredGbit >= model.targetGbit;
  while (s.elapsedH < end - 1e-9) {
    const dt = Math.min(FLIGHT_STEP_H, end - s.elapsedH);
    s = expireEffects(microStep(model, s, dt));
  }
  if (!targetBefore && model.targetGbit > 0 && s.deliveredGbit >= model.targetGbit) {
    s = log(s, 'info', `Objetivo científico alcanzado: ${Math.round(s.deliveredGbit)} Gbit en Tierra.`);
  }
  if (eventDue && next) {
    return log({ ...s, pendingEventId: next.id }, 'warn', 'ACONTECIMIENTO: se requiere una decisión del control de misión.');
  }
  if (s.elapsedH >= model.durationH - 1e-9) {
    s = log({ ...s, complete: true }, 'info', 'Fin de la campaña de observación.');
  }
  return s;
}

export function setInstrument(state: FlightState, instrument: Pick<FlightInstrument, 'instanceId' | 'name'>, on: boolean): FlightState {
  const off = new Set(state.instrumentsOff);
  if (on === !off.has(instrument.instanceId)) return state;
  if (on) off.delete(instrument.instanceId);
  else off.add(instrument.instanceId);
  return log({ ...state, instrumentsOff: [...off] }, 'info', `Orden de tierra: ${instrument.name} ${on ? 'encendido' : 'apagado'}.`);
}
