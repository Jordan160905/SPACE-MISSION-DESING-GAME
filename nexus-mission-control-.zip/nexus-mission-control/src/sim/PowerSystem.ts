/**
 * PowerSystem — balance energético por órbita. Distingue potencia (W) de energía (Wh).
 *
 * Supuestos:
 *  - Generación efectiva iluminada = Σ paneles × 0,9 (pérdidas por orientación y temperatura).
 *  - Instrumentos pasivos (requiresSunlight) solo funcionan en la parte iluminada.
 *  - La antena solo consume durante el contacto con Tierra (se usa la mejor antena).
 *  - El propulsor solo consume durante maniobras: no entra en el balance de crucero.
 *  - La energía del eclipse sale de la batería y hay que reponerla con eficiencia de carga 0,9.
 *  - Profundidad de descarga (DoD): > 70 % crítico (degrada la batería en pocos ciclos); > 40 % a optimizar.
 */
import type { ComponentDef, SpacecraftDesign } from '../data/schemas';
import type { ComponentLookup } from './BudgetSystem';
import { designComponents } from './DesignSystem';
import type { OrbitAnalysis } from './OrbitSystem';

export const PANEL_EFFECTIVE_FACTOR = 0.9;
export const BATTERY_CHARGE_EFFICIENCY = 0.9;
export const MAX_DOD = 0.7;
export const RECOMMENDED_DOD = 0.4;

export interface PowerAnalysis {
  /** Generación nominal (suma de paneles) y efectiva iluminada. */
  nominalGenW: number;
  sunlitGenW: number;
  /** Cargas continuas (computadora, sensores, ruedas, térmico). */
  busLoadW: number;
  /** Consumo medio durante la parte iluminada y durante el eclipse. */
  sunlitLoadW: number;
  eclipseLoadW: number;
  sunlitH: number;
  eclipseH: number;
  /** Energía que la batería entrega en cada eclipse. */
  eclipseEnergyWh: number;
  /** Energía necesaria para recargarla (con pérdidas). */
  rechargeNeededWh: number;
  /** Excedente disponible para cargar durante la parte iluminada. */
  sunlitSurplusWh: number;
  /** Excedente − recarga necesaria (≥ 0 = sostenible). */
  orbitBalanceWh: number;
  batteryWh: number;
  depthOfDischarge: number;
  /** Autonomía sin Sol con la carga de eclipse, usando hasta MAX_DOD. */
  autonomyH: number;
  sustainable: boolean;
}

function bestAntenna(comps: ComponentDef[]): ComponentDef | undefined {
  return comps.filter((c) => c.category === 'COMMS').sort((a, b) => b.downlinkMbps - a.downlinkMbps)[0];
}

export function analyzePower(design: SpacecraftDesign, lookup: ComponentLookup, orbit: OrbitAnalysis): PowerAnalysis {
  const comps = designComponents(design, lookup);
  const nominalGenW = comps.reduce((s, c) => s + c.powerGenW, 0);
  const sunlitGenW = nominalGenW * PANEL_EFFECTIVE_FACTOR;

  let busLoadW = 0;
  let passiveInstrW = 0;
  let activeInstrW = 0;
  for (const c of comps) {
    if (c.category === 'COMMS' || c.category === 'PROPULSION') continue;
    if (c.category === 'INSTRUMENT') {
      if (c.requiresSunlight) passiveInstrW += c.powerDrawW;
      else activeInstrW += c.powerDrawW;
    } else {
      busLoadW += c.powerDrawW;
    }
  }
  const antennaAvgW = (bestAntenna(comps)?.powerDrawW ?? 0) * orbit.contactFraction;

  const sunlitLoadW = busLoadW + passiveInstrW + activeInstrW + antennaAvgW;
  const eclipseLoadW = busLoadW + activeInstrW + antennaAvgW;
  const sunlitH = orbit.sunlitMin / 60;
  const eclipseH = orbit.eclipseMin / 60;

  const eclipseEnergyWh = eclipseLoadW * eclipseH;
  const rechargeNeededWh = eclipseEnergyWh / BATTERY_CHARGE_EFFICIENCY;
  const sunlitSurplusWh = (sunlitGenW - sunlitLoadW) * sunlitH;
  const orbitBalanceWh = sunlitSurplusWh - rechargeNeededWh;
  const batteryWh = comps.reduce((s, c) => s + c.energyStorageWh, 0);
  const depthOfDischarge = batteryWh > 0 ? eclipseEnergyWh / batteryWh : Number.POSITIVE_INFINITY;
  const autonomyH = eclipseLoadW > 0 ? (batteryWh * MAX_DOD) / eclipseLoadW : Number.POSITIVE_INFINITY;

  return {
    nominalGenW,
    sunlitGenW,
    busLoadW,
    sunlitLoadW,
    eclipseLoadW,
    sunlitH,
    eclipseH,
    eclipseEnergyWh,
    rechargeNeededWh,
    sunlitSurplusWh,
    orbitBalanceWh,
    batteryWh,
    depthOfDischarge,
    autonomyH,
    sustainable: orbitBalanceWh >= 0 && depthOfDischarge <= MAX_DOD,
  };
}
