/**
 * ScheduleSystem — el recurso TIEMPO: desarrollo de la nave antes del lanzamiento y vida útil
 * en órbita.
 *
 * Desarrollo (modelo didáctico de «camino crítico»):
 *   - Cada pieza necesita un plazo según su herencia de vuelo: con herencia 6 meses, modificada 12,
 *     nueva 20 (hay que diseñarla, fabricarla y calificarla).
 *   - Las piezas se desarrollan en paralelo: manda la más lenta.
 *   - Después, integración y pruebas del conjunto: 6 meses + 0,25 meses por pieza (más piezas, más
 *     interfaces que probar). «CubeSat 101» da 2–12 meses para fabricación y pruebas.
 * Vida útil: días que el Δv sobrante permitiría seguir manteniendo la órbita tras la campaña.
 */
import type { ComponentDef, SpacecraftDesign } from '../data/schemas';
import type { ComponentLookup } from './BudgetSystem';
import { designComponents } from './DesignSystem';
import type { DeltaVBudget } from './TrajectorySystem';
import { stationKeepingDeltaV } from './TrajectorySystem';

export const DEV_MONTHS: Record<ComponentDef['heritage'], number> = { 'flight-proven': 6, modified: 12, new: 20 };
export const INTEGRATION_BASE_MONTHS = 6;
export const INTEGRATION_PER_PART_MONTHS = 0.25;
/** Reserva de calendario recomendada (meses). */
export const SCHEDULE_RESERVE_MONTHS = 3;

export interface ScheduleAnalysis {
  /** Pieza que marca el camino crítico (la más lenta). */
  driver: { id: string; name: string; months: number } | null;
  developmentMonths: number;
  integrationMonths: number;
  totalMonths: number;
  availableMonths: number;
  reserveMonths: number;
  ok: boolean;
}

export function analyzeSchedule(design: SpacecraftDesign, lookup: ComponentLookup, availableMonths: number): ScheduleAnalysis {
  const comps = designComponents(design, lookup);
  let driver: ScheduleAnalysis['driver'] = null;
  for (const c of comps) {
    const m = DEV_MONTHS[c.heritage];
    if (!driver || m > driver.months) driver = { id: c.id, name: c.name, months: m };
  }
  const developmentMonths = driver?.months ?? 0;
  const integrationMonths = comps.length ? INTEGRATION_BASE_MONTHS + INTEGRATION_PER_PART_MONTHS * comps.length : 0;
  const totalMonths = developmentMonths + integrationMonths;
  return {
    driver,
    developmentMonths,
    integrationMonths,
    totalMonths,
    availableMonths,
    reserveMonths: availableMonths - totalMonths,
    ok: totalMonths <= availableMonths,
  };
}

/**
 * Vida útil operativa estimada (días): la campaña planificada más los días extra de mantenimiento
 * orbital que pagaría el Δv sobrante. Sin motor, la órbita no se mantiene: la vida es la campaña.
 */
export function operationalLifetimeDays(dv: DeltaVBudget, altitudeKm: number, plannedDays: number): number {
  if (!(dv.ispS > 0) || !Number.isFinite(dv.marginMS) || dv.marginMS <= 0) return plannedDays;
  const perDay = stationKeepingDeltaV(altitudeKm, 1);
  return plannedDays + (perDay > 0 ? dv.marginMS / perDay : 0);
}
