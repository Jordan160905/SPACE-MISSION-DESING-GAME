/**
 * Misión secundaria de rescate (Fase 8.5). Funciones puras.
 *
 * Un pequeño satélite de otra misión (SIMULADO) viaja hacia la Luna por una trayectoria parecida
 * a la nuestra y perdió el control de su orientación: su antena no apunta a la Tierra. Nuestra nave
 * puede acercarse y enviarle un comando de reinicio por radio de corto alcance.
 *
 * Física: movimiento relativo en un marco local inercial (metros). Lejos de la Tierra y durante
 * minutos, la diferencia de gravedad entre las dos naves es despreciable (≈ 10⁻⁹ km/s²), así que el
 * satélite se mueve en línea recta respecto de nosotros y solo nuestros propulsores cambian eso.
 * El combustible sale de la ecuación del cohete (Isp de la nave).
 * Valores de juego: aceleración del motor principal (0,06 m/s²) y de los propulsores de
 * orientación (0,015 m/s²), giro de 15 °/s, distancia (2,5–4 km) y velocidad iniciales (1–2 m/s).
 */

export type Vec3 = [number, number, number];

export type RescueStep = 'offer' | 'locate' | 'observe' | 'plan' | 'approach' | 'assist' | 'done' | 'failed' | 'declined';
export type RescuePlan = 'fast' | 'safe' | 'slow';

export const RESCUE = {
  mainAccel: 0.06,
  rcsAccel: 0.015,
  turnRate: (15 * Math.PI) / 180,
  lockDeg: 10,
  assistDistM: 120,
  assistSpeedMS: 0.3,
  assistAlignDeg: 15,
  /** Tiempo que hay que mantenerse cerca mientras el satélite se reinicia (s). */
  assistHoldS: 12,
  collisionM: 20,
  collisionSpeedMS: 0.5,
  lostM: 40000,
  observeS: 5,
};

export interface RescueState {
  step: RescueStep;
  /** Posición y velocidad del satélite respecto de nuestra nave (m, m/s). */
  rel: Vec3;
  relVel: Vec3;
  /** Orientación de nuestra nave: guiñada y cabeceo (rad). */
  yaw: number;
  pitch: number;
  plan: RescuePlan | null;
  /** Δv gastado (m/s) y cambio neto de nuestra velocidad (para volver al rumbo). */
  dvUsed: number;
  netDv: Vec3;
  fuelKg: number;
  t: number;
  observeT: number;
  holdT: number;
  overLimitS: number;
  /** Giro del satélite averiado (rad/s), solo visual. */
  tumble: number;
  outcome: string | null;
  retries: number;
}

export interface RescueInput {
  main: boolean;
  /** Traslación con propulsores: adelante/atrás, derecha/izquierda, arriba/abajo (−1, 0 o 1). */
  fwd: number;
  right: number;
  up: number;
  yaw: number;
  pitch: number;
}

export const NO_INPUT: RescueInput = { main: false, fwd: 0, right: 0, up: 0, yaw: 0, pitch: 0 };

export function newRescue(seed = 1): RescueState {
  const r = (k: number) => {
    const x = Math.sin(seed * 12.9898 + k * 78.233) * 43758.5453;
    return x - Math.floor(x);
  };
  // Aparece a 2,5–4 km, cruzándose con nosotros a 1–2 m/s.
  const d = 2500 + r(1) * 1500;
  const a = (r(2) - 0.5) * 1.2;
  const rel: Vec3 = [d * Math.cos(a), (r(3) - 0.5) * 400, d * Math.sin(a)];
  const relVel: Vec3 = [-0.4 - r(4) * 0.6, (r(5) - 0.5) * 0.3, 0.8 + r(6) * 0.9];
  return {
    step: 'offer',
    rel,
    relVel,
    yaw: Math.PI * (0.5 + r(7)),
    pitch: 0,
    plan: null,
    dvUsed: 0,
    netDv: [0, 0, 0],
    fuelKg: 0,
    t: 0,
    observeT: 0,
    holdT: 0,
    overLimitS: 0,
    tumble: 0.35 + r(8) * 0.4,
    outcome: null,
    retries: 0,
  };
}

const len = (v: Vec3) => Math.hypot(v[0], v[1], v[2]);
const dot = (a: Vec3, b: Vec3) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross = (a: Vec3, b: Vec3): Vec3 => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const norm = (v: Vec3): Vec3 => {
  const l = len(v) || 1;
  return [v[0] / l, v[1] / l, v[2] / l];
};

/** Ejes de la nave: morro, derecha y arriba. */
export function bodyAxes(yaw: number, pitch: number) {
  const nose: Vec3 = [Math.cos(pitch) * Math.cos(yaw), Math.sin(pitch), Math.cos(pitch) * Math.sin(yaw)];
  let right = cross(nose, [0, 1, 0]);
  if (len(right) < 1e-6) right = [0, 0, 1];
  right = norm(right);
  const up = cross(right, nose);
  return { nose, right, up };
}

export interface RescueReadout {
  distanceM: number;
  /** Velocidad de acercamiento (positiva si nos acercamos). */
  closingMS: number;
  relSpeedMS: number;
  lateralMS: number;
  /** Ángulo entre el morro y el satélite (°) y hacia dónde girar. */
  alignDeg: number;
  turnYaw: number;
  turnPitch: number;
  /** Máximo acercamiento si nadie hace nada: distancia (m) y tiempo (s). */
  cpaM: number;
  cpaS: number;
  /** Velocidad máxima recomendada según el plan para la distancia actual. */
  limitMS: number;
}

/**
 * Velocidad de acercamiento recomendada (m/s): proporcional a la distancia (regla real de los
 * acoplamientos: cuanto más cerca, más despacio) y con un tope.
 */
export function speedLimit(plan: RescuePlan | null, d: number) {
  if (plan === 'fast') return Math.min(8, Math.max(0.3, d / 40));
  if (plan === 'slow') return Math.min(1.5, Math.max(0.1, d / 200));
  return Math.min(3, Math.max(0.2, d / 100));
}

export function readout(s: RescueState): RescueReadout {
  const d = len(s.rel);
  const u = norm(s.rel);
  const closing = -dot(s.relVel, u);
  const rs = len(s.relVel);
  const lateral = Math.sqrt(Math.max(0, rs * rs - closing * closing));
  const { nose, right, up } = bodyAxes(s.yaw, s.pitch);
  const align = (Math.acos(Math.max(-1, Math.min(1, dot(nose, u)))) * 180) / Math.PI;
  const v2 = dot(s.relVel, s.relVel);
  const tc = v2 > 1e-9 ? Math.max(0, -dot(s.rel, s.relVel) / v2) : 0;
  const cpa: Vec3 = [s.rel[0] + s.relVel[0] * tc, s.rel[1] + s.relVel[1] * tc, s.rel[2] + s.relVel[2] * tc];
  return {
    distanceM: d,
    closingMS: closing,
    relSpeedMS: rs,
    lateralMS: lateral,
    alignDeg: align,
    turnYaw: Math.sign(dot(u, right)),
    turnPitch: Math.sign(dot(u, up)),
    cpaM: len(cpa),
    cpaS: tc,
    limitMS: speedLimit(s.plan ?? 'safe', d),
  };
}

export interface RescueCraft {
  /** Masa de la nave (kg) e Isp (s) para el combustible; presupuesto máximo (kg). */
  massKg: number;
  ispS: number;
  budgetKg: number;
}

/** Avanza la simulación dt segundos con los mandos pulsados. */
export function stepRescue(s: RescueState, input: RescueInput, dt: number, craft: RescueCraft): RescueState {
  if (s.step === 'offer' || s.step === 'done' || s.step === 'failed' || s.step === 'declined') return s;
  const n: RescueState = { ...s, rel: [...s.rel] as Vec3, relVel: [...s.relVel] as Vec3, netDv: [...s.netDv] as Vec3 };
  n.t += dt;
  n.yaw += input.yaw * RESCUE.turnRate * dt;
  n.pitch = Math.max(-1.4, Math.min(1.4, n.pitch + input.pitch * RESCUE.turnRate * dt));
  const outOfFuel = n.fuelKg >= craft.budgetKg;
  const { nose, right, up } = bodyAxes(n.yaw, n.pitch);
  const acc: Vec3 = [0, 0, 0];
  if (!outOfFuel) {
    const add = (v: Vec3, k: number) => {
      acc[0] += v[0] * k;
      acc[1] += v[1] * k;
      acc[2] += v[2] * k;
    };
    if (input.main) add(nose, RESCUE.mainAccel);
    if (input.fwd) add(nose, input.fwd * RESCUE.rcsAccel);
    if (input.right) add(right, input.right * RESCUE.rcsAccel);
    if (input.up) add(up, input.up * RESCUE.rcsAccel);
  }
  const a = len(acc);
  // Nuestra aceleración cambia la velocidad relativa en sentido contrario.
  for (let i = 0; i < 3; i++) {
    n.relVel[i] -= acc[i] * dt;
    n.netDv[i] += acc[i] * dt;
    n.rel[i] += n.relVel[i] * dt;
  }
  if (a > 0) {
    const dv = a * dt;
    n.dvUsed += dv;
    n.fuelKg += craft.massKg * (1 - Math.exp(-dv / (Math.max(1, craft.ispS) * 9.80665)));
  }
  const r = readout(n);
  if (n.step === 'observe') n.observeT += dt;
  if (n.step === 'approach' || n.step === 'assist') {
    if (r.closingMS > r.limitMS) n.overLimitS += dt;
    if (r.distanceM < RESCUE.collisionM && r.relSpeedMS > RESCUE.collisionSpeedMS) {
      n.step = 'failed';
      n.outcome = 'collision';
    }
  }
  if (n.step === 'assist') {
    const okHold = r.distanceM <= RESCUE.assistDistM * 1.25 && r.relSpeedMS <= RESCUE.assistSpeedMS * 2 && r.alignDeg <= RESCUE.assistAlignDeg * 1.5;
    n.holdT = okHold ? n.holdT + dt : Math.max(0, n.holdT - dt * 2);
    if (n.holdT >= RESCUE.assistHoldS) {
      n.step = 'done';
      n.outcome = 'success';
    }
  }
  if (r.distanceM > RESCUE.lostM && n.step !== 'done' && n.step !== 'failed') {
    n.step = 'failed';
    n.outcome = 'lost';
  }
  if (n.fuelKg >= craft.budgetKg && (n.step === 'approach' || n.step === 'assist') && r.relSpeedMS > RESCUE.assistSpeedMS && r.distanceM > RESCUE.assistDistM) {
    n.step = 'failed';
    n.outcome = 'fuel';
  }
  return n;
}

/** ¿Se puede ejecutar la asistencia ya? */
export function canAssist(s: RescueState) {
  const r = readout(s);
  return r.distanceM <= RESCUE.assistDistM && r.relSpeedMS <= RESCUE.assistSpeedMS && r.alignDeg <= RESCUE.assistAlignDeg;
}

/** Δv (m/s) para volver a nuestro rumbo después del rescate: anular el cambio neto de velocidad. */
export function returnDv(s: RescueState) {
  return len(s.netDv);
}

/** Puntos del rescate: base + eficiencia de combustible − tiempo pasado de velocidad. */
export function rescuePoints(s: RescueState) {
  if (s.outcome !== 'success') return 0;
  const eff = Math.max(0, 1 - s.dvUsed / 40);
  const penalty = Math.min(100, Math.round(s.overLimitS * 2));
  return 300 + Math.round(eff * 150) - penalty;
}

/** Reintento tras un choque leve: el satélite se aleja a 500 m, sin velocidad relativa. */
export function retryRescue(s: RescueState): RescueState {
  const u = norm(s.rel);
  return { ...s, step: 'approach', rel: [u[0] * 500, u[1] * 500, u[2] * 500], relVel: [0, 0, 0], outcome: null, holdT: 0, retries: s.retries + 1 };
}
