/**
 * LaunchSystem — cronología del lanzamiento y perfil de ascenso SIMPLIFICADO (Fase 5).
 *
 * Los tiempos de apagado salen de los datos del lanzador (burnTimeS). El perfil de altitud y
 * velocidad es una curva suave de juego que reproduce órdenes de magnitud reales (≈ 70 km y
 * 2,2 km/s al apagar la primera etapa; órbita de aparcamiento de ≈ 200 km a 7,8 km/s; tras la
 * inyección translunar, ≈ 10,9 km/s). No es una integración de la trayectoria.
 */
import type { Launcher } from '../data/schemas';

export type LaunchEventId =
  | 'liftoff'
  | 'tower'
  | 'maxq'
  | 'booster-sep'
  | 'meco'
  | 'stage-sep'
  | 'ses'
  | 'fairing'
  | 'seco'
  | 'tli'
  | 'tli-end'
  | 'sc-sep'
  | 'deploy'
  | 'activation';

export interface LaunchEvent {
  id: LaunchEventId;
  tS: number;
  title: string;
  detail: string;
}

export interface LaunchTimeline {
  events: LaunchEvent[];
  mecoS: number;
  secoS: number;
  tliStartS: number;
  tliEndS: number;
  endS: number;
  boosterSepS: number | null;
}

export const PARKING_COAST_S = 2400;
/** Duración del crucero Tierra→Luna (transferencia directa). */
export const CRUISE_HOURS = 96;

export function launchTimeline(l: Launcher): LaunchTimeline {
  const [s1, s2] = l.stages;
  const meco = s1.burnTimeS;
  const ses = meco + 10;
  const seco = ses + s2.burnTimeS * 0.55;
  const tliStart = seco + PARKING_COAST_S;
  const tliEnd = tliStart + s2.burnTimeS * 0.45;
  const scSep = tliEnd + 120;
  const deploy = scSep + 300;
  const activation = deploy + 300;
  const booster = l.boosters && l.boosters.count > 0 ? Math.round(meco * 0.6) : null;
  const ev: LaunchEvent[] = [
    { id: 'liftoff', tS: 0, title: 'Despegue', detail: `Encendido de ${s1.engines} motores ${s1.engineName}. El empuje supera el peso del cohete.` },
    { id: 'tower', tS: 8, title: 'Torre superada', detail: 'El control pasa del centro de lanzamiento al control de misión.' },
    { id: 'maxq', tS: Math.round(meco * 0.42), title: 'Max-Q', detail: 'Máxima presión aerodinámica: el momento de mayor esfuerzo estructural.' },
    ...(booster !== null
      ? [{ id: 'booster-sep' as const, tS: booster, title: 'Separación de propulsores laterales', detail: 'Sin combustible, se desprenden para no cargar peso muerto.' }]
      : []),
    { id: 'meco', tS: meco, title: 'Apagado de la primera etapa (MECO)', detail: `Tras ${meco} s de combustión.` },
    { id: 'stage-sep', tS: meco + 3, title: 'Separación de etapas', detail: 'La primera etapa cae; la interetapa deja libre el motor de vacío.' },
    { id: 'ses', tS: ses, title: 'Encendido de la segunda etapa', detail: `${s2.engineName}: tobera grande, optimizada para el vacío.` },
    { id: 'fairing', tS: ses + 35, title: 'Separación de la cofia', detail: 'Ya casi no hay atmósfera: la cofia es peso inútil y se descarta.' },
    { id: 'seco', tS: Math.round(seco), title: 'Órbita de aparcamiento (SECO)', detail: 'Órbita terrestre de ≈ 200 km a 7,8 km/s. Espera hasta el punto de salida hacia la Luna.' },
    { id: 'tli', tS: Math.round(tliStart), title: 'Inyección translunar (TLI)', detail: 'La segunda etapa se reenciende para salir de la órbita terrestre rumbo a la Luna.' },
    { id: 'tli-end', tS: Math.round(tliEnd), title: 'Fin de la inyección translunar', detail: '≈ 10,9 km/s: la nave ya va camino de la Luna (≈ 4 días).' },
    { id: 'sc-sep', tS: Math.round(scSep), title: 'Separación de la nave', detail: 'El adaptador libera tu nave: desde ahora vuela sola.' },
    { id: 'deploy', tS: Math.round(deploy), title: 'Despliegue de paneles solares', detail: 'Los paneles plegados se abren y empiezan a generar energía.' },
    { id: 'activation', tS: Math.round(activation), title: 'Activación de sistemas', detail: 'Computadora, orientación y comunicaciones en línea. Crucero hacia la Luna.' },
  ];
  return { events: ev.sort((a, b) => a.tS - b.tS), mecoS: meco, secoS: seco, tliStartS: tliStart, tliEndS: tliEnd, endS: activation, boosterSepS: booster };
}

export interface AscentState {
  altitudeKm: number;
  velocityKmS: number;
  /** Qué etapa empuja: 1, 2 o ninguna. */
  thrusting: 0 | 1 | 2;
}

const smooth = (x: number) => Math.max(0, Math.min(1, x));

export function ascentState(tS: number, tl: LaunchTimeline): AscentState {
  if (tS <= 0) return { altitudeKm: 0, velocityKmS: 0, thrusting: 0 };
  const ses = tl.mecoS + 10;
  if (tS <= tl.mecoS) {
    const x = tS / tl.mecoS;
    return { altitudeKm: 70 * Math.pow(x, 1.8), velocityKmS: 2.2 * Math.pow(x, 1.6), thrusting: 1 };
  }
  if (tS <= tl.secoS) {
    const x = smooth((tS - ses) / (tl.secoS - ses));
    return { altitudeKm: 70 + 130 * Math.sin((x * Math.PI) / 2), velocityKmS: 2.2 + 5.6 * Math.pow(x, 1.2), thrusting: tS >= ses ? 2 : 0 };
  }
  if (tS <= tl.tliStartS) return { altitudeKm: 200, velocityKmS: 7.8, thrusting: 0 };
  if (tS <= tl.tliEndS) {
    const x = (tS - tl.tliStartS) / (tl.tliEndS - tl.tliStartS);
    return { altitudeKm: 200 + 300 * x * x, velocityKmS: 7.8 + 3.1 * x, thrusting: 2 };
  }
  // Tras la TLI: se aleja de la Tierra (≈ 10 km/s al principio, frenando por la gravedad)
  const dt = tS - tl.tliEndS;
  return { altitudeKm: 500 + dt * 8.5, velocityKmS: Math.max(9.2, 10.9 - dt * 0.0012), thrusting: 0 };
}

/** Evento en curso (el último cuyo tiempo ya pasó). */
export function currentEvent(tS: number, tl: LaunchTimeline): LaunchEvent | null {
  let cur: LaunchEvent | null = null;
  for (const e of tl.events) if (e.tS <= tS) cur = e;
  return cur;
}

export function nextEvent(tS: number, tl: LaunchTimeline): LaunchEvent | null {
  return tl.events.find((e) => e.tS > tS) ?? null;
}

export function formatMET(tS: number): string {
  const sign = tS < 0 ? 'T−' : 'T+';
  const a = Math.abs(Math.round(tS));
  const h = Math.floor(a / 3600);
  const m = Math.floor((a % 3600) / 60);
  const s = a % 60;
  const p = (n: number) => String(n).padStart(2, '0');
  return `${sign}${p(h)}:${p(m)}:${p(s)}`;
}
