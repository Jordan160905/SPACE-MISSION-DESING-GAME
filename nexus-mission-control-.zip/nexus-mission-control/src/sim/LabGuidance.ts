/**
 * LabGuidance — convierte el análisis de ingeniería en ayuda accionable para construir.
 *
 *  - `labParameters`: los seis parámetros críticos (masa, presupuesto, energía, comunicaciones,
 *    propulsión, instrumento) con tres estados:
 *      · 'ok'      → correcto: cumple con los datos actuales.
 *      · 'missing' → falta: aún no está la pieza que lo resuelve (todavía no se puede evaluar).
 *      · 'fail'    → incumple: las piezas están, pero los números violan una restricción.
 *  - `fixFor`: para cada problema, qué categoría del catálogo abrir, qué piezas sirven y qué hacer.
 *  - `constraintChecks`: las restricciones de la misión (obligatorias y recomendadas) con su estado.
 *
 * No calcula física nueva ni repite validaciones: interpreta `EngineeringReport` (issues y números),
 * que sigue siendo la única fuente de verdad. Sin incidencias críticas ⇒ el diseño es viable.
 */
import { difficultyDef, isComponentAllowed, type Difficulty } from '../data/difficulty';
import { getLauncher } from '../data/launchers/launchers';
import type { ComponentCategory, ComponentDef, MissionTemplate, SpacecraftDesign } from '../data/schemas';
import type { ComponentLookup } from './BudgetSystem';
import { designComponents, type DesignIssue } from './DesignSystem';
import type { EngineeringReport } from './EngineeringAnalysis';
import { fmtNum } from './units';
import { numLocale } from '../i18n/lang';

export interface FixTarget {
  category: ComponentCategory;
  /** Piezas del catálogo que pueden resolverlo (ya filtradas por la dificultad). */
  componentIds: string[];
  /** Qué hacer, en una frase. */
  action: string;
}

export type ParamState = 'ok' | 'missing' | 'fail';
export const PARAM_STATE_LABEL: Record<ParamState, string> = { ok: 'Correcto', missing: 'Falta', fail: 'Incumple' };

export interface LabParameter {
  id: 'mass' | 'budget' | 'energy' | 'comms' | 'propulsion' | 'instrument';
  label: string;
  value: string;
  state: ParamState;
  /** Por qué está así, con los números del análisis. */
  why: string;
  /** Dónde y cómo corregirlo (también sirve para optimizar cuando ya es correcto). */
  fix: FixTarget;
}

export interface GuidanceContext {
  design: SpacecraftDesign;
  lookup: ComponentLookup;
  catalog: ComponentDef[];
  objectiveInstrumentId?: string;
  difficulty?: Difficulty;
}

const family = (id: string) => id.split('-')[0];

function allowed(ids: string[], lookup: ComponentLookup, difficulty?: Difficulty): string[] {
  return ids.filter((id) => {
    const c = lookup(id);
    return !!c && isComponentAllowed(c, difficulty);
  });
}

function byCategory(catalog: ComponentDef[], cat: ComponentCategory, pred: (c: ComponentDef) => boolean = () => true): string[] {
  return catalog.filter((c) => c.category === cat && pred(c)).map((c) => c.id);
}

/** Qué categoría abrir y qué piezas destacar para resolver un problema del análisis. */
export function fixFor(issue: Pick<DesignIssue, 'id'>, ctx: GuidanceContext & { schedule?: EngineeringReport['schedule'] }): FixTarget | null {
  const { lookup, catalog, difficulty } = ctx;
  const ok = (ids: string[]) => allowed(ids, lookup, difficulty);
  const installed = designComponents(ctx.design, lookup).filter((c) => c.category !== 'STRUCTURE');
  const id = issue.id;

  if (id === 'no-chassis') return { category: 'STRUCTURE', componentIds: ok(byCategory(catalog, 'STRUCTURE')), action: 'Elige un chasis: es la base donde se anclan todas las piezas.' };
  if (id === 'objective-instrument' && ctx.objectiveInstrumentId)
    return { category: 'INSTRUMENT', componentIds: ok([ctx.objectiveInstrumentId]), action: 'Instala el instrumento de tu objetivo científico.' };
  if (['no-power', 'power-deficit', 'energy-balance', 'energy-margin', 'power-margin'].includes(id))
    return { category: 'POWER', componentIds: ok(byCategory(catalog, 'POWER', (c) => c.powerGenW > 0)), action: 'Añade paneles solares o cambia a unos más potentes.' };
  if (['no-battery', 'battery-empty', 'battery-dod', 'battery-dod-high'].includes(id))
    return { category: 'POWER', componentIds: ok(byCategory(catalog, 'POWER', (c) => c.energyStorageWh > 0)), action: 'Añade una batería o cambia a una de mayor capacidad.' };
  if (['no-comms', 'data-target', 'downlink-bottleneck', 'data-backlog'].includes(id))
    return { category: 'COMMS', componentIds: ok(byCategory(catalog, 'COMMS', (c) => c.downlinkMbps > 0)), action: 'Instala una antena; la de alta ganancia envía más datos por contacto.' };
  if (id === 'data-buffer') {
    const mem = catalog.filter((c) => c.dataStorageGbit > 0);
    return { category: mem[0]?.category ?? 'CONTROL', componentIds: ok(mem.map((c) => c.id)), action: 'Añade memoria para guardar los datos entre contactos con la Tierra.' };
  }
  if (id === 'no-obc') return { category: 'CONTROL', componentIds: ok(byCategory(catalog, 'CONTROL', (c) => c.id === 'obc')), action: 'Instala la computadora de a bordo.' };
  if (id === 'no-propulsion') return { category: 'PROPULSION', componentIds: ok(byCategory(catalog, 'PROPULSION')), action: 'Añade un motor y un tanque de propelente.' };
  if (id === 'no-thermal') return { category: 'PROTECTION', componentIds: ok(byCategory(catalog, 'PROTECTION')), action: 'Añade control térmico.' };
  if (id.startsWith('requires:')) {
    const req = id.split('->')[1];
    const c = req ? lookup(req) : undefined;
    return c ? { category: c.category, componentIds: ok([c.id]), action: `Instala ${c.name}: otra pieza de la nave lo necesita para funcionar.` } : null;
  }
  if (id.startsWith('incompatible:')) {
    const [a] = id.slice('incompatible:'.length).split('|');
    const c = lookup(a);
    return c
      ? { category: c.category, componentIds: ok(byCategory(catalog, c.category, (x) => family(x.id) === family(c.id) && x.id !== c.id)), action: 'Retira una de las dos piezas o cámbiala por una alternativa compatible.' }
      : null;
  }
  if (id === 'tier-locked') {
    const lockedPart = installed.find((c) => !isComponentAllowed(c, difficulty));
    if (!lockedPart) return null;
    return {
      category: lockedPart.category,
      componentIds: ok(byCategory(catalog, lockedPart.category, (x) => family(x.id) === family(lockedPart.id))),
      action: `En el nivel ${difficultyDef(difficulty).label} usa la versión simple de ${lockedPart.name}.`,
    };
  }
  if (id === 'budget-over' || id === 'budget-no-launcher') {
    // La pieza más cara (o la más pesada) y sus alternativas más baratas (o ligeras) de la misma familia.
    const key = id === 'budget-over' ? 'costMUSD' : 'massKg';
    const top = [...installed].sort((x, y) => y[key] - x[key])[0];
    if (!top) return { category: 'STRUCTURE', componentIds: ok(byCategory(catalog, 'STRUCTURE')), action: 'Prueba un chasis más pequeño.' };
    const alts = byCategory(catalog, top.category, (x) => family(x.id) === family(top.id) && x[key] < top[key]);
    return {
      category: top.category,
      componentIds: ok(alts),
      action:
        id === 'budget-over'
          ? `La pieza más cara es ${top.name} (${fmtNum(top.costMUSD, 1)} MUSD): cámbiala por una más barata o quítala.`
          : `La pieza más pesada es ${top.name} (${fmtNum(top.massKg)} kg): aligera la nave para usar un lanzador más barato.`,
    };
  }
  if ((id === 'schedule-late' || id === 'schedule-reserve') && ctx.schedule?.driver) {
    const d = lookup(ctx.schedule.driver.id);
    if (!d) return null;
    return {
      category: d.category,
      componentIds: ok(byCategory(catalog, d.category, (x) => family(x.id) === family(d.id) && x.heritage === 'flight-proven')),
      action: `${d.name} es lo que más tarda en desarrollarse: usa una versión con herencia de vuelo si existe.`,
    };
  }
  return null;
}

const critical = (issues: DesignIssue[]) => issues.filter((i) => i.severity === 'critical');
const hasCrit = (issues: DesignIssue[], ...ids: string[]) => critical(issues).some((i) => ids.some((id) => i.id === id || i.id.startsWith(id)));
const has = (issues: DesignIssue[], ...ids: string[]) => issues.some((i) => ids.includes(i.id));

/** Los seis parámetros críticos del diseño, con su estado y a dónde ir para corregirlos. */
export function labParameters(report: EngineeringReport, ctx: GuidanceContext): LabParameter[] {
  const issues = report.issues;
  const fx = (id: string, fallback: FixTarget): FixTarget => fixFor({ id }, { ...ctx, schedule: report.schedule }) ?? fallback;
  const noChassis = !ctx.design.chassisId;
  const out: LabParameter[] = [];

  // ── Masa: húmeda + margen frente a la capacidad a la Luna de los lanzadores.
  const m = report.mass;
  const fitNames = m ? m.launchersThatFit.map((id) => getLauncher(id)?.name ?? id) : [];
  out.push({
    id: 'mass',
    label: 'Masa',
    value: m ? `${fmtNum(m.wetWithMarginKg)} kg` : '—',
    state: !m ? 'missing' : fitNames.length > 0 ? 'ok' : 'fail',
    why: !m
      ? 'Instala un chasis para empezar a sumar masa.'
      : fitNames.length > 0
        ? `Con propelente y margen pesa ${fmtNum(m.wetWithMarginKg)} kg. Cabe en: ${fitNames.join(', ')}.`
        : `Con propelente y margen pesa ${fmtNum(m.wetWithMarginKg)} kg: ningún lanzador disponible la lleva a la Luna.`,
    fix: fx('budget-no-launcher', { category: 'STRUCTURE', componentIds: [], action: 'Aligera la nave.' }),
  });

  // ── Presupuesto: nave + operación (+ lanzador más barato que puede llevarla).
  const b = report.budget;
  out.push({
    id: 'budget',
    label: 'Presupuesto',
    value: b ? `${fmtNum(b.remainingMUSD, 1)} MUSD` : noChassis ? '—' : 'sin tope',
    state: noChassis ? 'missing' : hasCrit(issues, 'budget-over', 'budget-no-launcher') ? 'fail' : 'ok',
    why: noChassis
      ? 'Se calcula al instalar el chasis.'
      : !b
        ? 'Modo libre: sin presupuesto.'
        : hasCrit(issues, 'budget-no-launcher')
          ? (critical(issues).find((i) => i.id === 'budget-no-launcher')?.explanation ?? '')
          : `Quedan ${fmtNum(b.remainingMUSD, 1)} MUSD libres: comprometido ${fmtNum(b.committedMUSD, 1)} de ${b.capMUSD} MUSD (nave y operación). Debe quedar dinero para el lanzador.`,
    fix: fx('budget-over', { category: 'STRUCTURE', componentIds: [], action: 'Usa piezas más baratas.' }),
  });

  // ── Energía: balance por órbita y descarga de batería en el eclipse.
  const p = report.power;
  const energyMissing = noChassis || hasCrit(issues, 'no-power', 'no-battery');
  const energyFail = !energyMissing && (hasCrit(issues, 'energy-balance', 'battery-empty', 'battery-dod', 'power-deficit') || (p ? !p.sustainable : false));
  const needBattery = hasCrit(issues, 'no-battery', 'battery-empty', 'battery-dod') && !hasCrit(issues, 'no-power');
  out.push({
    id: 'energy',
    label: 'Energía',
    value: p && !energyMissing ? `${p.orbitBalanceWh >= 0 ? '+' : ''}${fmtNum(p.orbitBalanceWh)} Wh` : '—',
    state: energyMissing ? 'missing' : energyFail ? 'fail' : 'ok',
    why: energyMissing
      ? hasCrit(issues, 'no-power')
        ? 'Faltan paneles solares: sin ellos la nave no genera energía.'
        : noChassis
          ? 'Instala un chasis primero.'
          : 'Falta una batería: la nave pasa parte de cada órbita en la sombra.'
      : p
        ? `Balance por órbita ${p.orbitBalanceWh >= 0 ? '+' : ''}${fmtNum(p.orbitBalanceWh)} Wh. Genera ${fmtNum(p.nominalGenW, 0)} W al sol y consume ${fmtNum(p.sunlitLoadW, 0)} W; la batería se descarga un ${Math.round(p.depthOfDischarge * 100)} % en cada eclipse.`
        : '',
    fix: needBattery ? fx('no-battery', { category: 'POWER', componentIds: [], action: '' }) : fx('no-power', { category: 'POWER', componentIds: [], action: '' }),
  });

  // ── Comunicaciones: datos que llegan a la Tierra frente a los exigidos.
  const d = report.data;
  const commsMissing = noChassis || hasCrit(issues, 'no-comms');
  const commsFail = !commsMissing && hasCrit(issues, 'data-target');
  out.push({
    id: 'comms',
    label: 'Comunicaciones',
    value: report.comms && !commsMissing ? `${fmtNum(report.comms.downlinkGbitPerDay, 0)} Gbit/día` : '—',
    state: commsMissing ? 'missing' : commsFail ? 'fail' : 'ok',
    why: commsMissing
      ? 'Falta una antena: la nave no puede enviar sus datos a la Tierra.'
      : d && d.targetGbit > 0
        ? `Llegarán ${fmtNum(d.missionDeliveredGbit, 0)} de ${d.targetGbit.toLocaleString(numLocale())} Gbit exigidos por tu objetivo.`
        : `Enlace de ${fmtNum(report.comms?.downlinkMbps ?? 0)} Mbps durante los contactos con la estación.`,
    fix: has(issues, 'data-buffer') && !commsFail && !commsMissing ? fx('data-buffer', { category: 'COMMS', componentIds: [], action: '' }) : fx('no-comms', { category: 'COMMS', componentIds: [], action: '' }),
  });

  // ── Propulsión: motor + tanque para frenar al llegar y mantener la órbita.
  const propMissing = noChassis || hasCrit(issues, 'no-propulsion', 'requires:thruster', 'requires:prop-tank');
  out.push({
    id: 'propulsion',
    label: 'Propulsión',
    value: report.mass && !propMissing ? `${fmtNum(report.mass.propellantKg)} kg` : '—',
    state: propMissing ? 'missing' : 'ok',
    why: propMissing
      ? 'Falta motor o tanque: sin ellos la nave no puede frenar al llegar a la Luna.'
      : `Motor y ${fmtNum(report.mass?.propellantKg ?? 0)} kg de propelente para frenar al llegar a la Luna y mantener la órbita.`,
    fix: fx('no-propulsion', { category: 'PROPULSION', componentIds: [], action: '' }),
  });

  // ── Instrumento del objetivo y lo que necesita para funcionar.
  const inst = ctx.objectiveInstrumentId;
  const instName = inst ? ctx.lookup(inst)?.name : undefined;
  const instMissing = noChassis || hasCrit(issues, 'objective-instrument') || (inst ? critical(issues).some((i) => i.id.startsWith(`requires:${inst}->`)) : false);
  const instFail = !instMissing && (inst ? critical(issues).some((i) => i.id.startsWith('incompatible:') && i.id.includes(inst)) : false);
  const instReq = inst ? critical(issues).find((i) => i.id.startsWith(`requires:${inst}->`)) : undefined;
  out.push({
    id: 'instrument',
    label: 'Instrumento',
    value: instName ?? '—',
    state: instMissing ? 'missing' : instFail ? 'fail' : 'ok',
    why: instReq
      ? `${instReq.title}.`
      : instMissing
        ? `Tu objetivo necesita: ${instName?.toLowerCase() ?? 'su instrumento'}.`
        : instFail
          ? `${instName} es incompatible con otra pieza instalada.`
          : `${instName ?? 'Instrumento'} instalado con todo lo que necesita.`,
    fix: instReq ? fx(instReq.id, { category: 'INSTRUMENT', componentIds: [], action: '' }) : fx('objective-instrument', { category: 'INSTRUMENT', componentIds: [], action: '' }),
  });
  return out;
}

export interface ConstraintCheck {
  id: string;
  label: string;
  /** 'hard' = obligatoria (impide avanzar), 'soft' = recomendada (da puntos y seguridad). */
  severity: 'hard' | 'soft';
  state: ParamState;
  detail: string;
}

/** Estado de cada restricción de la misión, a partir de los mismos parámetros e incidencias. */
export function constraintChecks(template: MissionTemplate, report: EngineeringReport, params: LabParameter[]): ConstraintCheck[] {
  const param = (id: LabParameter['id']) => params.find((p) => p.id === id)!;
  const issues = report.issues;
  return template.constraints.map((c) => {
    const base = { id: c.id, label: c.label, severity: c.severity };
    switch (c.id) {
      case 'c-budget':
        return { ...base, state: param('budget').state, detail: param('budget').why };
      case 'c-launcher':
        return { ...base, state: param('mass').state, detail: param('mass').why };
      case 'c-power':
        return { ...base, state: param('energy').state, detail: param('energy').why };
      case 'c-instrument':
        return { ...base, state: param('instrument').state, detail: param('instrument').why };
      case 'c-downlink': {
        const comms = param('comms');
        if (comms.state !== 'ok') return { ...base, state: comms.state, detail: comms.why };
        const slow = issues.find((i) => ['downlink-bottleneck', 'data-backlog', 'data-buffer'].includes(i.id));
        return { ...base, state: slow ? 'fail' : 'ok', detail: slow ? slow.title : comms.why };
      }
      case 'c-margin': {
        const m = report.mass;
        const p = report.power;
        if (!m || !p || param('energy').state === 'missing') return { ...base, state: 'missing', detail: 'Se evalúa cuando la nave tiene chasis, paneles y batería.' };
        const capacities = m.launchersThatFit.map((id) => getLauncher(id)?.payloadToTLIKg ?? 0);
        const massMargin = capacities.length ? Math.max(...capacities) / m.wetWithMarginKg - 1 : -1;
        const energyMargin = p.rechargeNeededWh > 0 ? p.orbitBalanceWh / p.rechargeNeededWh : 0;
        const okMass = massMargin >= 0.1;
        const okEnergy = !has(issues, 'energy-margin', 'power-margin') && energyMargin >= 0.1;
        return {
          ...base,
          state: okMass && okEnergy ? 'ok' : 'fail',
          detail: `Masa: ${massMargin >= 0 ? `${Math.round(massMargin * 100)} %` : 'sin lanzador'} de margen · energía: ${Math.round(energyMargin * 100)} % de margen.`,
        };
      }
      default:
        return { ...base, state: report.viable ? 'ok' : 'missing', detail: c.description };
    }
  });
}
