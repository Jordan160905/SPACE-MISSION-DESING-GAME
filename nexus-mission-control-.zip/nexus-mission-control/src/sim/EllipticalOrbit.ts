/**
 * EllipticalOrbit — órbitas keplerianas elípticas alrededor de la Luna (problema de dos cuerpos).
 *
 * Inspirado en el «Elliptical Orbit Simulator» de NASA Mission Viz y en la forma en que GMAT
 * describe una órbita con elementos keplerianos. Es una herramienta EDUCATIVA del Planner: la
 * simulación de la misión sigue usando la órbita circular de OrbitSystem (ver ASSUMPTIONS.md).
 *
 * Fórmulas:
 *   a = (r_p + r_a) / 2,  e = (r_a − r_p) / (r_a + r_p),  T = 2π √(a³/μ)
 *   vis-viva: v = √(μ (2/r − 1/a))
 *   Kepler: M = E − e·sin E (se resuelve con Newton-Raphson; arranque de Murison para e alto)
 *   anomalía verdadera: tan(ν/2) = √((1+e)/(1−e)) · tan(E/2);  r = a (1 − e·cos E)
 */
import { MOON_MU_KM3_S2, MOON_RADIUS_KM } from './OrbitSystem';

export interface EllipseInput {
  periapsisAltKm: number;
  apoapsisAltKm: number;
}

export interface Ellipse {
  periapsisAltKm: number;
  apoapsisAltKm: number;
  rpKm: number;
  raKm: number;
  aKm: number;
  e: number;
  periodS: number;
  vPeriKmS: number;
  vApoKmS: number;
}

export interface OrbitState {
  /** Tiempo desde el paso por el periapsis (s), reducido a [0, T). */
  tS: number;
  meanAnomaly: number;
  eccentricAnomaly: number;
  trueAnomaly: number;
  rKm: number;
  altitudeKm: number;
  speedKmS: number;
  /** Posición en el plano orbital (periapsis sobre +x), km. */
  xKm: number;
  yKm: number;
}

export const MIN_PERIAPSIS_ALT_KM = 10;
/** Límite práctico: más lejos, la gravedad terrestre domina y el modelo de dos cuerpos deja de valer. */
export const MAX_APOAPSIS_ALT_KM = 20000;

export function makeEllipse(input: EllipseInput): Ellipse {
  const hp = Math.min(input.periapsisAltKm, input.apoapsisAltKm);
  const ha = Math.max(input.periapsisAltKm, input.apoapsisAltKm);
  if (!(hp >= MIN_PERIAPSIS_ALT_KM)) throw new Error(`El periapsis debe estar al menos a ${MIN_PERIAPSIS_ALT_KM} km`);
  if (!(ha <= MAX_APOAPSIS_ALT_KM)) throw new Error(`El apoapsis no puede superar ${MAX_APOAPSIS_ALT_KM} km`);
  const rp = MOON_RADIUS_KM + hp;
  const ra = MOON_RADIUS_KM + ha;
  const a = (rp + ra) / 2;
  const e = (ra - rp) / (ra + rp);
  return {
    periapsisAltKm: hp,
    apoapsisAltKm: ha,
    rpKm: rp,
    raKm: ra,
    aKm: a,
    e,
    periodS: 2 * Math.PI * Math.sqrt((a * a * a) / MOON_MU_KM3_S2),
    vPeriKmS: visViva(rp, a),
    vApoKmS: visViva(ra, a),
  };
}

export function visViva(rKm: number, aKm: number): number {
  return Math.sqrt(MOON_MU_KM3_S2 * (2 / rKm - 1 / aKm));
}

/** Resuelve la ecuación de Kepler M = E − e sin E (0 ≤ e < 1). Devuelve E en [0, 2π). */
export function solveKepler(meanAnomaly: number, e: number, tol = 1e-12): number {
  if (!(e >= 0 && e < 1)) throw new Error('Solo órbitas elípticas (0 ≤ e < 1)');
  const M = ((meanAnomaly % (2 * Math.PI)) + 2 * Math.PI) % (2 * Math.PI);
  // Arranque de tercer orden (Murison): converge en pocas iteraciones incluso con e alto.
  const s = Math.sin(M);
  const c = Math.cos(M);
  let E = M + e * s + e * e * s * c + 0.5 * e * e * e * s * (3 * c * c - 1);
  for (let k = 0; k < 50; k++) {
    const f = E - e * Math.sin(E) - M;
    const step = f / (1 - e * Math.cos(E));
    E -= step;
    if (Math.abs(step) < tol) break;
  }
  return ((E % (2 * Math.PI)) + 2 * Math.PI) % (2 * Math.PI);
}

export function stateAt(el: Ellipse, timeS: number): OrbitState {
  const t = ((timeS % el.periodS) + el.periodS) % el.periodS;
  const M = (2 * Math.PI * t) / el.periodS;
  const E = solveKepler(M, el.e);
  const nu = 2 * Math.atan2(Math.sqrt(1 + el.e) * Math.sin(E / 2), Math.sqrt(1 - el.e) * Math.cos(E / 2));
  const r = el.aKm * (1 - el.e * Math.cos(E));
  return {
    tS: t,
    meanAnomaly: M,
    eccentricAnomaly: E,
    trueAnomaly: (nu + 2 * Math.PI) % (2 * Math.PI),
    rKm: r,
    altitudeKm: r - MOON_RADIUS_KM,
    speedKmS: visViva(r, el.aKm),
    xKm: r * Math.cos(nu),
    yKm: r * Math.sin(nu),
  };
}

/**
 * Fracción del periodo que la nave pasa por debajo de una altitud (p. ej. la máxima útil para un
 * instrumento). Se calcula de forma exacta con la ecuación de Kepler: el tiempo entre −E* y +E*.
 */
export function fractionBelowAltitude(el: Ellipse, altitudeKm: number): number {
  const r = MOON_RADIUS_KM + altitudeKm;
  if (r <= el.rpKm) return 0;
  if (r >= el.raKm) return 1;
  if (el.e === 0) return 1;
  const cosE = (1 - r / el.aKm) / el.e;
  const E = Math.acos(Math.max(-1, Math.min(1, cosE)));
  const M = E - el.e * Math.sin(E);
  return M / Math.PI;
}

/**
 * Δv para terminar la misión con un impacto controlado desde una órbita circular de altitud h:
 * un frenado que baja el periapsis hasta la superficie (Hohmann parcial). Así se evita dejar
 * basura en órbita lunar, como hicieron Lunar Prospector y LADEE.
 */
export function disposalDeltaVMS(altitudeKm: number): number {
  const r = MOON_RADIUS_KM + altitudeKm;
  const a = (r + MOON_RADIUS_KM) / 2;
  const vCirc = Math.sqrt(MOON_MU_KM3_S2 / r);
  return (vCirc - visViva(r, a)) * 1000;
}

/** Puntos de la elipse para dibujarla (plano orbital, km). */
export function ellipsePath(el: Ellipse, samples = 180): Array<[number, number]> {
  const pts: Array<[number, number]> = [];
  for (let k = 0; k <= samples; k++) {
    const nu = (2 * Math.PI * k) / samples;
    const r = (el.aKm * (1 - el.e * el.e)) / (1 + el.e * Math.cos(nu));
    pts.push([r * Math.cos(nu), r * Math.sin(nu)]);
  }
  return pts;
}
