/**
 * Fase 8.6: decisiones contrarreloj (ocasionales, con consecuencias en la simulación).
 */
import { describe, expect, it } from 'vitest';
import { anyEventById, clampSeconds, COUNTDOWN, isUrgent, scheduleUrgent, URGENT_EVENTS } from './Countdown';
import { applyEffects, initialVars, scheduleFlightEvents, type FlightCtx, type FlightWindows } from './FlightEvents';

const CTX: FlightCtx = { hasThermal: true, antennaMbps: 40, energyMargin: 0.4, dvMargin: 0.3, batteryMaxWh: 900, busLoadW: 60, genW: 300, propellantKg: 40, dryKg: 240, ispS: 220, spendableKg: 5, problemsEnabled: true };
const W: FlightWindows = { ascent: [60, 150], orbit: [700, 2700], cruise: [14000, 260000], approach: [280000, 335000] };

describe('Decisiones contrarreloj', () => {
  it('cubre las cuatro situaciones pedidas, cada una con 2–3 opciones y lo que pasa si no se decide', () => {
    expect(new Set(URGENT_EVENTS.map((e) => e.category))).toEqual(new Set(['trajectory', 'comms', 'heat', 'power']));
    for (const e of URGENT_EVENTS) {
      expect(e.options.length).toBeGreaterThanOrEqual(2);
      expect(e.options.length).toBeLessThanOrEqual(3);
      expect(e.quick.length).toBeGreaterThan(20);
      expect(isUrgent(anyEventById(e.id))).toBe(true);
    }
  });

  it('aparece solo a veces (no en todos los vuelos), como mucho una vez y lejos de otros eventos', () => {
    let n = 0;
    for (let seed = 1; seed <= 200; seed++) {
      const base = scheduleFlightEvents(CTX, W, seed);
      const u = scheduleUrgent(CTX, W, seed, base);
      if (!u) continue;
      n++;
      expect(u.t).toBeGreaterThan(W.cruise[0]);
      expect(u.t).toBeLessThan(W.cruise[1]);
      for (const o of base) expect(Math.abs(o.t - u.t)).toBeGreaterThan(3 * 3600);
    }
    expect(n).toBeGreaterThan(100);
    expect(n).toBeLessThan(200);
    expect(scheduleUrgent({ ...CTX, problemsEnabled: false }, W, 3, [])).toBe(null);
  });

  it('las consecuencias cambian variables reales y no decidir sale peor', () => {
    for (const e of URGENT_EVENTS) {
      const ec = { ctx: CTX, vars: initialVars(CTX), t: 50000, tArr: 300000, window: 'cruise' as const, mag: 0.5 };
      const v0 = applyEffects(ec.vars, CTX, e.onTrigger!(ec), 50000, 300000).vars;
      const ec2 = { ...ec, vars: v0 };
      const late = applyEffects(v0, CTX, e.timeout.effect(ec2), 50000, 300000);
      expect(late.changes.length).toBeGreaterThan(0);
      const cost = (v: typeof v0) => v.spentKg * 40 + (900 - v.batteryWh) * 0.2 + v.trajErrorKm * 0.05 + Math.max(0, v.commsDownUntil - 50000) / 3600 + Math.max(0, v.sensorFaultUntil - 50000) / 3600;
      const best = Math.min(...e.options.map((o) => cost(applyEffects(v0, CTX, o.effect(ec2), 50000, 300000).vars)));
      expect(cost(late.vars)).toBeGreaterThan(best);
    }
  });

  it('el tiempo se puede configurar entre 15 y 25 s', () => {
    expect(clampSeconds(5)).toBe(COUNTDOWN.minS);
    expect(clampSeconds(40)).toBe(COUNTDOWN.maxS);
    expect(clampSeconds(18.4)).toBe(18);
    expect(COUNTDOWN.defaultS).toBeGreaterThanOrEqual(15);
  });
});
