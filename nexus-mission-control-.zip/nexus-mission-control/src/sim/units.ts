import { numLocale } from '../i18n/lang';
/**
 * Conversiones de unidades del motor de simulación.
 * Todas las funciones son puras y están cubiertas por pruebas (units.test.ts).
 */

/** Mbps → Gbit/h.  1 Mbps × 3600 s/h ÷ 1000 Mbit/Gbit = 3,6 Gbit/h */
export function mbpsToGbitPerHour(mbps: number): number {
  return (mbps * 3600) / 1000;
}

/** Energía (Wh) = potencia (W) × tiempo (h). */
export function energyWh(powerW: number, hours: number): number {
  return powerW * hours;
}

/** Autonomía (h) de una batería ante un consumo constante. Infinito si no hay consumo. */
export function autonomyHours(storageWh: number, drawW: number): number {
  if (drawW <= 0) return Number.POSITIVE_INFINITY;
  return storageWh / drawW;
}

/** Redondeo para mostrar en UI sin falsear precisión. */
export function round(value: number, decimals = 1): number {
  const f = 10 ** decimals;
  return Math.round(value * f) / f;
}

/** Número con formato español (coma decimal), sin inventar precisión. */
export function fmtNum(value: number, decimals = 1): string {
  return round(value, decimals).toLocaleString(numLocale(), { maximumFractionDigits: decimals });
}

export function formatMUSD(value: number): string {
  return `${round(value, 1).toLocaleString(numLocale(), { minimumFractionDigits: 1, maximumFractionDigits: 1 })} MUSD`;
}
