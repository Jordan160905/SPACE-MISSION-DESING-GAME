/**
 * Fase 7 (Revisión gamificada): los «poderes», las estrellas, la puerta al vuelo y los mensajes de la
 * directora salen del mismo análisis de la junta, con piezas reales del catálogo.
 */
import { describe, expect, it } from 'vitest';
import { getComponent } from '../data/components/catalog';
import { LUNA_01 } from '../data/missions/missions';
import type { Mission, MissionPlan, SpacecraftDesign } from '../data/schemas';
import { MissionSchema } from '../data/schemas';
import { flightGate, npcLines, powerCards, stars } from '../ui/review/reviewGame';
import { conceptMaturity, riskRegister, type ReviewInput } from './ConceptReview';
import { EMPTY_DESIGN, placePart, setChassis } from './DesignSystem';
import { analyzeEngineering } from './EngineeringAnalysis';
import { analyzePlan } from './PlanningSystem';

const L = getComponent;
function build(chassisId: string, parts: Array<[string, string]>): SpacecraftDesign {
  let d = setChassis(EMPTY_DESIGN, chassisId, L).design;
  for (const [c, s] of parts) d = placePart(d, c, s, L).design;
  return d;
}
const REF = build('chassis-m', [
  ['camera', 'bottom-0'],
  ['thruster', 'bottom-1'],
  ['antenna-hg', 'top-0'],
  ['attitude-sensor', 'side-pz-0'],
  ['solar-adv', 'side-px-0'],
  ['solar-adv', 'side-nx-0'],
  ['battery-adv', 'bay-0'],
  ['obc', 'bay-1'],
  ['prop-tank', 'bay-2'],
  ['thermal', 'bay-3'],
]);
const PLAN: MissionPlan = { launcherId: 'minotaur-iv', altitudeKm: 75, inclinationDeg: 90, durationDays: 60, launchDay: 7 };

function mission(design: SpacecraftDesign, plan: MissionPlan | null, stage: Mission['stage']): Mission {
  return MissionSchema.parse({
    id: 'm1',
    templateId: 'luna-01',
    objectiveId: 'obj-mapping',
    name: 'LUNA-01 · Intento 1',
    stage,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
    design,
    plan,
  });
}
function input(m: Mission): ReviewInput {
  const plan = m.plan ? analyzePlan({ design: m.design, lookup: L, template: LUNA_01, objectiveId: m.objectiveId, plan: m.plan }) : null;
  return { mission: m, template: LUNA_01, engineering: plan?.engineering ?? analyzeEngineering({ design: m.design, lookup: L, template: LUNA_01, objectiveId: m.objectiveId }), plan, lookup: L };
}

describe('Revisión gamificada', () => {
  it('nave vacía: ningún poder se marca como listo y no hay estrellas', () => {
    const cards = powerCards(input(mission(EMPTY_DESIGN, null, 'DESIGN')));
    expect(cards.map((c) => c.id)).toEqual(['energy', 'battery', 'data', 'mass', 'money', 'fuel']);
    expect(cards.every((c) => c.state === 'pending')).toBe(true);
    expect(stars(cards)).toEqual({ earned: 0, total: 6 });
  });

  it('diseño de referencia con plan: los poderes usan los números del análisis', () => {
    const i = input(mission(REF, PLAN, 'LAUNCH'));
    const cards = powerCards(i);
    const by = Object.fromEntries(cards.map((c) => [c.id, c]));
    const p = i.engineering.power!;
    expect(by.energy.state).toBe(p.sustainable ? (p.orbitBalanceWh / p.rechargeNeededWh >= 0.1 ? 'ok' : 'warn') : 'fail');
    expect(by.money.fill).toBeCloseTo(i.engineering.budget!.usedFraction, 9);
    expect(by.mass.fill).toBeCloseTo(i.plan!.massWithMarginKg / i.plan!.launcher.payloadToTLIKg, 9);
    expect(by.fuel.fill).toBeCloseTo(i.plan!.deltaV.availableMS / i.plan!.deltaV.requiredMS, 9);
    // el plan de referencia es viable: nada en rojo
    expect(cards.some((c) => c.state === 'fail' || c.state === 'pending')).toBe(false);
    expect(stars(cards).earned).toBe(cards.filter((c) => c.state === 'ok').length);
  });

  it('sin plan de vuelo: el combustible queda pendiente', () => {
    const cards = powerCards(input(mission(REF, null, 'DESIGN')));
    expect(cards.find((c) => c.id === 'fuel')!.state).toBe('pending');
  });

  it('puerta al vuelo: solo con el plan confirmado', () => {
    expect(flightGate('DESIGN')).toBe('design');
    expect(flightGate('PLANNING')).toBe('plan');
    expect(flightGate('LAUNCH')).toBe('ready');
    expect(flightGate('OPERATIONS')).toBe('flown');
  });

  it('la directora celebra si está lista y advierte si falta el plan', () => {
    const i = input(mission(REF, PLAN, 'LAUNCH'));
    const risks = riskRegister(i);
    const cml = conceptMaturity(i);
    const cards = powerCards(i);
    expect(npcLines(cml, cards, risks, 'ready').launch.mood).toBe('happy');
    expect(npcLines(cml, cards, risks, 'plan').launch.text).toMatch(/Planner/);
    const high = risks.filter((r) => r.level === 'high');
    expect(npcLines(cml, cards, risks, 'ready').risks.mood).toBe(high.length ? 'worried' : 'happy');
  });
});
