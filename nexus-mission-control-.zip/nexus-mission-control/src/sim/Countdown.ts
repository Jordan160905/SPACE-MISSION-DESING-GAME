/**
 * Decisiones contrarreloj (Fase 8.6).
 * Situaciones urgentes y poco frecuentes: desviación de trayectoria, pérdida de comunicación,
 * anomalía de temperatura y problema de energía. Cada una tiene una descripción sencilla,
 * 2–3 opciones y lo que pasa si se acaba el tiempo sin decidir. Todas las consecuencias son
 * efectos del simulador del vuelo (combustible, batería, temperatura, señal, trayectoria…).
 */
import { eventById, type EffectCtx, type EffectSpec, type FlightCtx, type FlightEventDef, type FlightWindows, type ScheduledFlightEvent } from './FlightEvents';

export interface UrgentEventDef extends FlightEventDef {
  urgent: true;
  /** Lo que hay que saber en una frase (se lee rápido). */
  quick: string;
  /** Si nadie decide a tiempo. */
  timeout: { effect: (c: EffectCtx) => EffectSpec; outcome: string };
}

export const COUNTDOWN = {
  minS: 15,
  maxS: 25,
  defaultS: 20,
  /** Probabilidad de que un vuelo tenga una situación contrarreloj (con problemas activados). */
  chance: 0.8,
};

const H = 3600;
const devKm = (c: EffectCtx) => Math.round(500 + c.mag * 900);

export const URGENT_EVENTS: UrgentEventDef[] = [
  {
    id: 'urgent-trajectory',
    urgent: true,
    kind: 'problem',
    category: 'trajectory',
    title: '¡Desviación repentina!',
    windows: ['cruise'],
    weight: () => 1.2,
    quick: 'Un propulsor se quedó encendido y la nave se sale de su camino.',
    message: (c) => `Un propulsor pequeño se encendió solo y nos empuja fuera de la ruta: ya vamos ${devKm(c)} km desviados y el error crece.`,
    explain: 'Cuanto antes se corrige un desvío, menos combustible cuesta: el cambio de velocidad es la distancia que hay que corregir dividida entre el tiempo que queda.',
    onTrigger: (c) => ({ trajErrorKm: devKm(c) }),
    options: [
      {
        id: 'fire',
        label: 'Cortar el propulsor y corregir ya',
        effect: () => ({ correctTrajectory: true }),
        outcome: 'Propulsor apagado y corrección inmediata: volvemos al camino gastando lo mínimo.',
      },
      {
        id: 'cut',
        label: 'Solo cortar el propulsor y corregir al llegar',
        effect: () => ({}),
        outcome: 'El desvío deja de crecer, pero corregirlo cerca de la Luna costará más combustible.',
      },
    ],
    timeout: {
      effect: (c) => ({ trajErrorKm: Math.round(devKm(c) * 0.8), propellantKg: -0.2 }),
      outcome: 'Se acabó el tiempo: el propulsor siguió encendido. Perdimos combustible y el desvío casi se duplicó.',
    },
  },
  {
    id: 'urgent-comms',
    urgent: true,
    kind: 'problem',
    category: 'comms',
    title: '¡Silencio de radio!',
    windows: ['cruise'],
    weight: (c) => (c.antennaMbps < 10 ? 1.4 : 1),
    quick: 'La antena dejó de apuntar a la Tierra: no recibimos nada de la nave.',
    message: () => 'La señal se ha cortado de golpe. La antena perdió la Tierra y la nave no puede enviar datos.',
    explain: 'La antena principal envía un haz muy estrecho, como una linterna. La de respaldo no necesita apuntar, pero es mucho más lenta.',
    onTrigger: () => ({ commsDownS: 1e9 }),
    options: [
      {
        id: 'backup',
        label: 'Pasar a la antena de respaldo',
        effect: () => ({ clearComms: true, commsFactor: 0.25, commsFactorS: 6 * H, batteryWh: -10 }),
        outcome: 'Hay señal de nuevo, aunque lenta durante unas horas.',
      },
      {
        id: 'thrusters',
        label: 'Reorientar la nave con los propulsores',
        effect: () => ({ clearComms: true, propellantKg: -0.25 }),
        outcome: 'Un pequeño encendido apunta la antena a la Tierra: señal completa al instante.',
      },
      {
        id: 'reboot',
        label: 'Reiniciar el ordenador de orientación',
        effect: () => ({ clearComms: true, commsDownS: 1 * H, batteryWh: -6 }),
        outcome: 'Tras reiniciarse, el ordenador vuelve a apuntar la antena. Una hora sin señal.',
      },
    ],
    timeout: {
      effect: () => ({ clearComms: true, commsDownS: 8 * H, batteryWh: -12 }),
      outcome: 'Se acabó el tiempo: la nave entró sola en modo de espera y estuvo 8 horas sin comunicar.',
    },
  },
  {
    id: 'urgent-heat',
    urgent: true,
    kind: 'problem',
    category: 'heat',
    title: '¡Temperatura disparada!',
    windows: ['cruise'],
    weight: (c) => (c.hasThermal ? 0.8 : 1.6),
    quick: 'Un lado de la nave se está recalentando al Sol muy deprisa.',
    message: () => 'La nave quedó parada con un lado al Sol y los equipos se están calentando muy rápido.',
    explain: 'En el espacio no hay aire que enfríe: el calor solo se va por radiación. La electrónica funciona bien entre unos 0 y 40 °C.',
    onTrigger: () => ({ tempOffsetC: 22, heatFault: true }),
    options: [
      {
        id: 'roll',
        label: 'Girar la nave para darle sombra',
        effect: () => ({ heatFault: false, tempOffsetC: -16, propellantKg: -0.15 }),
        outcome: 'Al girar, el lado caliente queda a la sombra y la temperatura baja enseguida.',
      },
      {
        id: 'radiators',
        label: 'Encender los radiadores al máximo',
        effect: () => ({ heatFault: false, tempOffsetC: -12, extraLoadW: 30, extraLoadS: 3 * H }),
        outcome: 'Los radiadores expulsan el calor, pero gastan batería durante unas horas.',
      },
    ],
    timeout: {
      effect: () => ({ heatFault: false, tempOffsetC: -6, sensorFaultS: 6 * H, batteryWh: -20 }),
      outcome: 'Se acabó el tiempo: el control automático reaccionó tarde. Un sensor se dañó por el calor y la batería sufrió.',
    },
  },
  {
    id: 'urgent-power',
    urgent: true,
    kind: 'problem',
    category: 'power',
    title: '¡Caída de energía!',
    windows: ['cruise'],
    weight: (c) => (c.energyMargin < 0.15 ? 1.8 : 1),
    quick: 'Un fallo en el regulador hace que los paneles den muy poca electricidad.',
    message: () => 'El regulador de los paneles solares falló: la nave recibe solo un tercio de la electricidad y la batería empieza a bajar.',
    explain: 'Los paneles cargan la batería a través de un regulador. Si falla, la nave vive de la batería hasta que se arregle.',
    onTrigger: () => ({ powerFactor: 0.35 }),
    options: [
      {
        id: 'restart',
        label: 'Reiniciar el regulador',
        effect: () => ({ powerFactor: 1, batteryWh: -25 }),
        outcome: 'El reinicio consume algo de batería, pero los paneles vuelven a dar toda su energía.',
      },
      {
        id: 'save',
        label: 'Apagar todo lo que no sea esencial',
        effect: () => ({ powerFactor: 0.35, powerFactorS: 10 * H, extraLoadW: -15, extraLoadS: 10 * H }),
        outcome: 'Gastando menos, la batería aguanta hasta que el regulador se recupera solo.',
      },
    ],
    timeout: {
      effect: () => ({ powerFactor: 0.35, powerFactorS: 16 * H, batteryWh: -60 }),
      outcome: 'Se acabó el tiempo: la batería se descargó mucho antes de que el sistema reaccionara.',
    },
  },
];

export function urgentById(id: string): UrgentEventDef | undefined {
  return URGENT_EVENTS.find((e) => e.id === id);
}

/** Busca un evento normal o contrarreloj. */
export function anyEventById(id: string): FlightEventDef | UrgentEventDef | undefined {
  return eventById(id) ?? urgentById(id);
}

export function isUrgent(def: FlightEventDef | undefined): def is UrgentEventDef {
  return !!def && (def as UrgentEventDef).urgent === true;
}

function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/**
 * A lo sumo UNA situación contrarreloj por vuelo (no siempre): en el crucero, lejos de los demás
 * eventos (≥ 3 h) y de otro problema del mismo tipo. Devuelve null si este vuelo no tiene.
 */
export function scheduleUrgent(ctx: FlightCtx, w: FlightWindows, seed: number, others: ScheduledFlightEvent[]): ScheduledFlightEvent | null {
  if (!ctx.problemsEnabled) return null;
  const r = rng(seed ^ 0x5bd1e995);
  if (r() > COUNTDOWN.chance) return null;
  const usedCats = new Set(others.map((o) => eventById(o.id)?.category).filter(Boolean));
  const pool = URGENT_EVENTS.filter((e) => !usedCats.has(e.category));
  const list = pool.length ? pool : URGENT_EVENTS;
  const weights = list.map((e) => e.weight(ctx));
  let x = r() * weights.reduce((a, b) => a + b, 0);
  let def = list[list.length - 1];
  for (let i = 0; i < list.length; i++) {
    x -= weights[i];
    if (x <= 0) {
      def = list[i];
      break;
    }
  }
  const [a, b] = w.cruise;
  for (let k = 0; k < 30; k++) {
    const t = a + (b - a) * (0.15 + r() * 0.7);
    if (others.every((o) => Math.abs(o.t - t) > 3 * H)) return { id: def.id, t, window: 'cruise', mag: r() };
  }
  return null;
}

export function clampSeconds(s: number) {
  return Math.max(COUNTDOWN.minS, Math.min(COUNTDOWN.maxS, Math.round(s)));
}
