import { describe, expect, it } from 'vitest';
import { getComponent } from '../data/components/catalog';
import { LUNA_01 } from '../data/missions/missions';
import type { FlightState, MissionPlan } from '../data/schemas';
import { budgetSummary } from './BudgetSystem';
import { designTotals, EMPTY_DESIGN, placePart, setChassis } from './DesignSystem';
import { buildFlightModel, initFlight, stepFlight } from './MissionSystem';
import { debriefInsights, scoreMission } from './ScoringSystem';

const L = getComponent;
let d = setChassis(EMPTY_DESIGN, 'chassis-m', L).design;
for (const [c, s] of [
  ['camera', 'bottom-0'], ['thruster', 'bottom-1'], ['antenna-hg', 'top-0'], ['attitude-sensor', 'side-pz-0'], ['solar-adv', 'side-px-0'],
  ['solar-adv', 'side-nx-0'], ['battery-adv', 'bay-0'], ['obc', 'bay-1'], ['prop-tank', 'bay-2'], ['thermal', 'bay-3'],
] as Array<[string, string]>) d = placePart(d, c, s, L).design;
const PLAN: MissionPlan = { launcherId: 'minotaur-iv', altitudeKm: 75, inclinationDeg: 90, durationDays: 60, launchDay: 7 };
const OBJ = LUNA_01.objectives[0];
const model = buildFlightModel(d, L, PLAN, OBJ.dataTargetGbit);
const budget = budgetSummary(LUNA_01, d, L, 50, 15); // 40,6 + 50 (Minotaur IV) + 15 = 105,6
const done = stepFlight(model, initFlight(model, PLAN, designTotals(d, L).propellantKg), 24 * 60);
const input = (flight: FlightState) => ({ template: LUNA_01, objective: OBJ, plan: PLAN, model, flight, budget, designOptimizations: [] });

describe('ScoringSystem', () => {
  it('campaña limpia: éxito, puntos por criterio y total coherente', () => {
    const s = scoreMission(input(done));
    expect(s.success).toBe(true);
    const by = Object.fromEntries(s.criteria.map((c) => [c.id, c.points]));
    expect(by.science).toBe(40);
    expect(by.energy).toBe(15);
    expect(by.data).toBe(10);
    expect(by.decisions).toBe(20); // sin acontecimientos
    // presupuesto: sobran 34,4 de 140 → 8 + 7 × mín(1, 34,4 / (0,25 × 140)) = 14,88 → 14,9
    expect(by.budget).toBe(14.9);
    expect(s.total).toBe(100); // el total se redondea a entero
    expect(s.grade).toBe('S');
    expect(s.xp).toBe(500 + 300);
  });

  it('sin alcanzar el objetivo: no hay éxito y la XP es parcial, aunque la puntuación sea alta en otros criterios', () => {
    const short: FlightState = { ...done, deliveredGbit: 1000 };
    const s = scoreMission(input(short));
    expect(s.success).toBe(false);
    expect(s.criteria.find((c) => c.id === 'science')!.points).toBe(20);
    expect(s.xp).toBe(Math.round(s.total * 1.5));
    expect(s.xp).toBeLessThan(LUNA_01.rewards.xp);
  });

  it('modo seguro, apagón, pérdidas y decisiones subóptimas restan puntos', () => {
    const rough: FlightState = {
      ...done,
      safeModeEntries: 2,
      blackoutH: 1.5,
      lostGbit: done.generatedGbit * 0.2,
      eventHistory: [
        { id: 'a', type: 'comms-outage', atH: 10, choiceId: 'wait', choiceLabel: 'Esperar', rank: 3, optionCount: 3, summary: '' },
        { id: 'b', type: 'power-degradation', atH: 20, choiceId: 'keep', choiceLabel: 'Mantener', rank: 1, optionCount: 3, summary: '' },
      ],
    };
    const by = Object.fromEntries(scoreMission(input(rough)).criteria.map((c) => [c.id, c.points]));
    expect(by.energy).toBe(15 - 8 - 3);
    expect(by.data).toBe(8);
    expect(by.decisions).toBe(13); // (0,3 + 1) / 2 × 20
  });

  it('presupuesto excedido por costos extra → 0 puntos de presupuesto', () => {
    const s = scoreMission(input({ ...done, extraCostMUSD: 40 }));
    expect(s.criteria.find((c) => c.id === 'budget')!.points).toBe(0);
    expect(s.spentMUSD).toBeCloseTo(145.6, 9); // 105,6 + 40 > 140
  });

  it('el informe explica aciertos, errores y recomendaciones con su porqué', () => {
    const good = debriefInsights(input(done), scoreMission(input(done)));
    expect(good.good.some((g) => g.text.startsWith('Objetivo científico cumplido'))).toBe(true);
    expect(good.errors).toHaveLength(0);
    expect(good.coverage).toBeCloseTo(1, 9);
    const bad: FlightState = { ...done, deliveredGbit: 500, lostGbit: 300, safeModeEntries: 1 };
    const ins = debriefInsights(input(bad), scoreMission(input(bad)));
    expect(ins.errors.map((e) => e.text).join(' ')).toContain('No se alcanzó el objetivo');
    expect(ins.recommendations.some((r) => r.text.includes('segunda computadora'))).toBe(true);
    for (const x of [...ins.good, ...ins.errors, ...ins.recommendations]) expect(x.why.length).toBeGreaterThan(10);
  });
});
