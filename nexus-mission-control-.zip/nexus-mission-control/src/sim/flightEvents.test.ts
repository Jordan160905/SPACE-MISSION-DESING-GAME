/**
 * Fases 8.2 y 8.3: sistemas de la nave durante el vuelo y eventos inesperados.
 */
import { describe, expect, it } from 'vitest';
import {
  applyEffects,
  commsStatus,
  correctionDv,
  DOSE_MSV_PER_DAY,
  FLIGHT_EVENTS,
  initialVars,
  LIGHT_KMS,
  propellantForDv,
  scheduleFlightEvents,
  seedFrom,
  stepVars,
  temperatureC,
  type FlightCtx,
  type FlightWindows,
} from './FlightEvents';

const CTX: FlightCtx = {
  hasThermal: true,
  antennaMbps: 40,
  energyMargin: 0.4,
  dvMargin: 0.3,
  batteryMaxWh: 900,
  busLoadW: 60,
  genW: 300,
  propellantKg: 40,
  dryKg: 240,
  ispS: 220,
  spendableKg: 5,
  problemsEnabled: true,
};
const W: FlightWindows = { ascent: [60, 150], orbit: [700, 2700], cruise: [14000, 260000], approach: [280000, 335000] };
const ENV = { separated: true, deployed: true, inFairing: false, sunlit: true, nearEarth: false };

describe('Sistemas de la nave en vuelo', () => {
  it('la batería se carga al sol con los paneles abiertos y se descarga en la sombra', () => {
    const v0 = { ...initialVars(CTX), batteryWh: 400 };
    const sun = stepVars(v0, CTX, 0, 3600, ENV);
    expect(sun.batteryWh).toBeCloseTo(400 + (300 - 60), 6);
    const shade = stepVars(v0, CTX, 0, 3600, { ...ENV, sunlit: false });
    expect(shade.batteryWh).toBeCloseTo(400 - 60, 6);
  });

  it('con la batería muy baja entra en modo seguro y sale al recuperarse', () => {
    const low = stepVars({ ...initialVars(CTX), batteryWh: 100 }, CTX, 0, 60, { ...ENV, sunlit: false });
    expect(low.safeMode).toBe(true);
    const back = stepVars({ ...low, batteryWh: 500 }, CTX, 60, 120, ENV);
    expect(back.safeMode).toBe(false);
  });

  it('la temperatura tiende al equilibrio: sin control térmico se calienta mucho más al sol', () => {
    const hot = stepVars(initialVars({ ...CTX, hasThermal: false }), { ...CTX, hasThermal: false }, 0, 10 * 3600, ENV);
    const ok = stepVars(initialVars(CTX), CTX, 0, 10 * 3600, ENV);
    expect(temperatureC(hot)).toBeGreaterThan(40);
    expect(temperatureC(ok)).toBeLessThan(30);
  });

  it('la dosis de radiación usa las tasas de referencia (órbita baja y espacio profundo)', () => {
    const deep = stepVars(initialVars(CTX), CTX, 0, 86400, ENV);
    expect(deep.doseMSv).toBeCloseTo(DOSE_MSV_PER_DAY.deep, 6);
    const leo = stepVars(initialVars(CTX), CTX, 0, 86400, { ...ENV, nearEarth: true });
    expect(leo.doseMSv).toBeCloseTo(DOSE_MSV_PER_DAY.leo, 6);
  });

  it('el retardo de la señal es la distancia entre la velocidad de la luz (≈ 1,3 s hasta la Luna)', () => {
    const c = commsStatus(initialVars(CTX), CTX, 0, 384400, 'deep');
    expect(c.delayS).toBeCloseTo(384400 / LIGHT_KMS, 9);
    expect(c.delayS).toBeGreaterThan(1.27);
    expect(c.network).toBe('dsn');
  });
});

describe('Consecuencias de las decisiones', () => {
  it('corregir una desviación pronto cuesta menos combustible que hacerlo tarde', () => {
    const v = { ...initialVars(CTX), trajErrorKm: 1000 };
    const early = applyEffects(v, CTX, { correctTrajectory: true }, 20000, 345600);
    const late = applyEffects(v, CTX, { correctTrajectory: true }, 330000, 345600);
    expect(early.vars.trajErrorKm).toBe(0);
    expect(CTX.propellantKg - early.vars.propellantKg).toBeLessThan(CTX.propellantKg - late.vars.propellantKg);
    expect(correctionDv(1000, 20 * 3600)).toBeCloseTo(13.89, 1);
    // Ecuación del cohete.
    expect(propellantForDv(10, CTX, 40)).toBeCloseTo(280 * (1 - Math.exp(-10 / (220 * 9.80665))), 9);
  });

  it('el combustible para frenar en la Luna está protegido: una mala decisión no termina la misión', () => {
    const v = initialVars(CTX);
    const r = applyEffects(v, CTX, { propellantKg: -50 }, 1000, 345600);
    expect(r.reserveProtected).toBe(true);
    expect(r.vars.spentKg).toBeCloseTo(CTX.spendableKg, 9);
    expect(r.vars.propellantKg).toBeCloseTo(CTX.propellantKg - CTX.spendableKg, 9);
  });

  it('los efectos temporales caducan y el sistema se recupera solo', () => {
    const r = applyEffects(initialVars(CTX), CTX, { commsFactor: 0.3, commsFactorS: 3600, powerFactor: 0.5, powerFactorS: 1800 }, 0, 1e6);
    expect(r.vars.commsFactor).toBe(0.3);
    const later = stepVars(r.vars, CTX, 0, 4000, ENV);
    expect(later.commsFactor).toBe(1);
    expect(later.powerFactor).toBe(1);
  });
});

describe('Eventos inesperados', () => {
  it('cada evento explica el problema y ofrece dos o tres decisiones (los positivos, al menos una)', () => {
    for (const e of FLIGHT_EVENTS) {
      expect(e.explain.length).toBeGreaterThan(40);
      if (e.kind === 'problem') {
        expect(e.options.length).toBeGreaterThanOrEqual(2);
        expect(e.options.length).toBeLessThanOrEqual(3);
      } else expect(e.options.length).toBeGreaterThanOrEqual(1);
    }
    const kinds = new Set(FLIGHT_EVENTS.map((e) => e.category));
    for (const c of ['comms', 'heat', 'trajectory', 'sensor', 'fuel', 'power', 'radiation', 'good']) expect(kinds.has(c as never)).toBe(true);
  });

  it('la programación es reproducible, no repite eventos ni categorías seguidas y respeta las ventanas', () => {
    const a = scheduleFlightEvents(CTX, W, seedFrom('m1', 0));
    const b = scheduleFlightEvents(CTX, W, seedFrom('m1', 0));
    expect(a).toEqual(b);
    for (let s = 0; s < 60; s++) {
      const sch = scheduleFlightEvents(CTX, W, seedFrom(`m${s}`, s));
      expect(sch.length).toBeGreaterThanOrEqual(3);
      expect(new Set(sch.map((e) => e.id)).size).toBe(sch.length);
      for (const e of sch) {
        const [t0, t1] = W[e.window];
        expect(e.t).toBeGreaterThanOrEqual(t0);
        expect(e.t).toBeLessThanOrEqual(t1);
        expect(FLIGHT_EVENTS.find((d) => d.id === e.id)!.windows).toContain(e.window);
      }
      for (let i = 1; i < sch.length; i++) {
        const c0 = FLIGHT_EVENTS.find((d) => d.id === sch[i - 1].id)!.category;
        const c1 = FLIGHT_EVENTS.find((d) => d.id === sch[i].id)!.category;
        if (c0 !== 'good' || c1 !== 'good') expect(c0 === c1 && c0 !== 'good').toBe(false);
      }
      // Siempre hay al menos un evento positivo o descubrimiento en el crucero.
      expect(sch.some((e) => e.window === 'cruise' && FLIGHT_EVENTS.find((d) => d.id === e.id)!.kind !== 'problem')).toBe(true);
    }
  });

  it('los eventos son coherentes con el diseño: sin control térmico, el calor aparece mucho más', () => {
    let hotNo = 0;
    let hotYes = 0;
    for (let s = 0; s < 200; s++) {
      if (scheduleFlightEvents({ ...CTX, hasThermal: false }, W, seedFrom('x', s)).some((e) => e.id === 'overheat')) hotNo++;
      if (scheduleFlightEvents(CTX, W, seedFrom('x', s)).some((e) => e.id === 'overheat')) hotYes++;
    }
    expect(hotNo).toBeGreaterThan(hotYes * 1.5);
  });

  it('en el modo sandbox solo hay eventos positivos', () => {
    for (let s = 0; s < 30; s++) {
      const sch = scheduleFlightEvents({ ...CTX, problemsEnabled: false }, W, seedFrom('sb', s));
      expect(sch.every((e) => FLIGHT_EVENTS.find((d) => d.id === e.id)!.kind !== 'problem')).toBe(true);
    }
  });
});
