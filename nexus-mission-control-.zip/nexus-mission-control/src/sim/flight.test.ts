/**
 * Pruebas del motor de vuelo (Fase 5): conservación, coherencia con el análisis medio de la
 * Fase 3, modo seguro, propelente y cronología de lanzamiento.
 */
import { describe, expect, it } from 'vitest';
import { getComponent } from '../data/components/catalog';
import { LAUNCHERS } from '../data/launchers/launchers';
import { LUNA_01 } from '../data/missions/missions';
import type { MissionPlan, SpacecraftDesign } from '../data/schemas';
import { EMPTY_DESIGN, placePart, setChassis, designTotals } from './DesignSystem';
import { analyzeEngineering } from './EngineeringAnalysis';
import { ascentState, currentEvent, formatMET, launchTimeline, nextEvent } from './LaunchSystem';
import { buildFlightModel, initFlight, propellantAfterBurn, setInstrument, snapshot, stepFlight } from './MissionSystem';
import { G0, loiDeltaV } from './TrajectorySystem';

const L = getComponent;
function build(chassisId: string, parts: Array<[string, string]>): SpacecraftDesign {
  let d = setChassis(EMPTY_DESIGN, chassisId, L).design;
  for (const [c, s] of parts) d = placePart(d, c, s, L).design;
  return d;
}
const CAMERA_REF = build('chassis-m', [
  ['camera', 'bottom-0'],
  ['thruster', 'bottom-1'],
  ['antenna-hg', 'top-0'],
  ['attitude-sensor', 'side-pz-0'],
  ['solar-adv', 'side-px-0'],
  ['solar-adv', 'side-nx-0'],
  ['battery-adv', 'bay-0'],
  ['obc', 'bay-1'],
  ['prop-tank', 'bay-2'],
  ['thermal', 'bay-3'],
]);
const PLAN: MissionPlan = { launcherId: 'minotaur-iv', altitudeKm: 75, inclinationDeg: 90, durationDays: 60, launchDay: 7 };

function start(design = CAMERA_REF, plan = PLAN) {
  const model = buildFlightModel(design, L, plan, 2000);
  const state = initFlight(model, plan, designTotals(design, L).propellantKg);
  return { model, state };
}

describe('MissionSystem: arranque', () => {
  it('batería llena, memoria vacía y propelente tras la inserción (Tsiolkovsky)', () => {
    const { model, state } = start();
    expect(state.batteryWh).toBe(900);
    expect(state.storageGbit).toBe(0);
    const dv = 30 + 0 + loiDeltaV(75); // día 7 = ventana óptima, sin penalización
    const m0 = model.dryKg + 80;
    expect(state.propellantKg).toBeCloseTo(m0 * Math.exp(-dv / (315 * G0)) - model.dryKg, 6);
    expect(state.log[0].text).toContain('Inserción en órbita lunar');
  });

  it('propellantAfterBurn: sin motor o sin Δv no gasta', () => {
    expect(propellantAfterBurn(100, 50, 0, 500)).toBe(50);
    expect(propellantAfterBurn(100, 50, 300, 0)).toBe(50);
    expect(propellantAfterBurn(100, 10, 300, 99999)).toBe(0);
  });
});

describe('MissionSystem: conservación', () => {
  it('datos: generados = entregados + en memoria + perdidos', () => {
    let { model, state } = start();
    state = stepFlight(model, state, 24 * 5);
    expect(state.generatedGbit).toBeCloseTo(state.deliveredGbit + state.storageGbit + state.lostGbit, 6);
  });

  it('la batería nunca supera su capacidad ni baja de 0', () => {
    let { model, state } = start();
    for (let i = 0; i < 48; i++) {
      state = stepFlight(model, state, 0.5);
      expect(state.batteryWh).toBeLessThanOrEqual(model.batteryCapacityWh + 1e-9);
      expect(state.batteryWh).toBeGreaterThan(-1e-9);
    }
  });

  it('avanzar 1 día de una vez o en 24 pasos de 1 h da el mismo resultado', () => {
    const a = start();
    const b = start();
    const one = stepFlight(a.model, a.state, 24);
    let many = b.state;
    for (let i = 0; i < 24; i++) many = stepFlight(b.model, many, 1);
    expect(many.deliveredGbit).toBeCloseTo(one.deliveredGbit, 6);
    expect(many.batteryWh).toBeCloseTo(one.batteryWh, 6);
  });
});

describe('MissionSystem: coherencia con el análisis medio de la Fase 3', () => {
  it('datos producidos para Tierra en 10 días ≈ análisis (±3 %)', () => {
    const report = analyzeEngineering({
      design: CAMERA_REF,
      lookup: L,
      template: LUNA_01,
      objectiveId: 'obj-mapping',
      orbit: { altitudeKm: 75, inclinationDeg: 90 },
    });
    let { model, state } = start();
    state = stepFlight(model, state, 24 * 10);
    const expected = report.data!.deliveredGbitPerDay * 10;
    // Al cortar a mitad de día, hasta 16 h de datos esperan en memoria la siguiente estación:
    // se comparan entregados + pendientes (sin pérdidas en este diseño).
    expect(state.lostGbit).toBe(0);
    expect(Math.abs(state.deliveredGbit + state.storageGbit - expected) / expected).toBeLessThan(0.03);
  });

  it('descarga máxima de batería ≈ descarga por órbita del análisis', () => {
    const report = analyzeEngineering({ design: CAMERA_REF, lookup: L, template: LUNA_01, objectiveId: 'obj-mapping', orbit: { altitudeKm: 75, inclinationDeg: 90 } });
    let { model, state } = start();
    state = stepFlight(model, state, 24);
    // El peor eclipse coincide con contacto (antena encendida); el análisis promedia la antena.
    expect(1 - state.minBatteryFraction).toBeGreaterThan(report.power!.depthOfDischarge * 0.8);
    expect(1 - state.minBatteryFraction).toBeLessThan(report.power!.depthOfDischarge * 1.6);
  });
});

describe('MissionSystem: decisiones del jugador', () => {
  it('apagar el instrumento detiene los datos y reduce el consumo', () => {
    let { model, state } = start();
    const cam = model.instruments[0];
    state = setInstrument(state, cam, false);
    const s = snapshot(model, state);
    expect(s.activeInstrumentIds).toEqual([]);
    const after = stepFlight(model, state, 12);
    expect(after.generatedGbit).toBe(0);
    expect(after.log.at(-1)?.text ?? '').not.toContain('MODO SEGURO');
    expect(setInstrument(after, cam, false)).toBe(after); // sin cambios si ya estaba apagado
  });

  it('una nave con poca energía entra en MODO SEGURO y se recupera', () => {
    // Radar con un solo panel avanzado: balance negativo por órbita.
    const weak = build('chassis-m', [
      ['radar', 'bottom-0'],
      ['thruster', 'bottom-1'],
      ['antenna-hg', 'top-0'],
      ['attitude-sensor', 'side-pz-0'],
      ['thermal', 'side-nz-0'],
      ['solar-adv', 'side-px-0'],
      ['battery-adv', 'bay-0'],
      ['obc', 'bay-1'],
      ['prop-tank', 'bay-2'],
      ['reaction-wheels', 'bay-3'],
    ]);
    const plan = { ...PLAN, launcherId: 'falcon-9', altitudeKm: 55 };
    let { model, state } = start(weak, plan);
    state = stepFlight(model, state, 24 * 2);
    expect(state.log.some((e) => e.text.includes('MODO SEGURO'))).toBe(true);
    expect(state.log.some((e) => e.text.includes('se restablecen'))).toBe(true);
    expect(state.minBatteryFraction).toBe(0);
  });

  it('el mantenimiento orbital consume propelente con el tiempo', () => {
    let { model, state } = start();
    const p0 = state.propellantKg;
    state = stepFlight(model, state, 24 * 30);
    expect(state.propellantKg).toBeLessThan(p0);
    expect(state.propellantDepleted).toBe(false);
  });

  it('la campaña termina exactamente en la duración planificada', () => {
    let { model, state } = start(CAMERA_REF, { ...PLAN, durationDays: 30 });
    state = stepFlight(model, state, 24 * 100);
    expect(state.complete).toBe(true);
    expect(state.elapsedH).toBeCloseTo(30 * 24, 6);
    expect(state.deliveredGbit).toBeGreaterThan(2000);
    expect(state.log.some((e) => e.text.includes('Objetivo científico alcanzado'))).toBe(true);
    expect(stepFlight(model, state, 10)).toBe(state);
  });
});

describe('LaunchSystem', () => {
  for (const l of LAUNCHERS) {
    it(`${l.name}: eventos en orden y coherentes con los datos`, () => {
      const tl = launchTimeline(l);
      for (let i = 1; i < tl.events.length; i++) expect(tl.events[i].tS).toBeGreaterThan(tl.events[i - 1].tS - 1e-9);
      expect(tl.mecoS).toBe(l.stages[0].burnTimeS);
      expect(tl.events.some((e) => e.id === 'booster-sep')).toBe(!!l.boosters);
      expect(tl.events.at(-1)!.id).toBe('activation');
    });
  }

  it('perfil de ascenso: órdenes de magnitud reales', () => {
    const tl = launchTimeline(LAUNCHERS[1]);
    expect(ascentState(-5, tl).altitudeKm).toBe(0);
    expect(ascentState(tl.mecoS, tl).velocityKmS).toBeCloseTo(2.2, 6);
    expect(ascentState(tl.secoS, tl).velocityKmS).toBeCloseTo(7.8, 6);
    expect(ascentState(tl.secoS + 10, tl).altitudeKm).toBe(200);
    expect(ascentState(tl.tliEndS, tl).velocityKmS).toBeCloseTo(10.9, 6);
    expect(ascentState(tl.mecoS + 5, tl).thrusting).toBe(0); // entre MECO y encendido de la 2.ª
  });

  it('evento actual/siguiente y formato T±', () => {
    const tl = launchTimeline(LAUNCHERS[0]);
    expect(currentEvent(-1, tl)).toBe(null);
    expect(currentEvent(1, tl)!.id).toBe('liftoff');
    expect(nextEvent(1, tl)!.id).toBe('tower');
    expect(formatMET(-10)).toBe('T−00:00:10');
    expect(formatMET(3725)).toBe('T+01:02:05');
  });
});
