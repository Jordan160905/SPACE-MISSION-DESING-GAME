import { describe, expect, it } from 'vitest';
import { getComponent } from '../data/components/catalog';
import type { FlightState, MissionPlan, SpacecraftDesign } from '../data/schemas';
import { designTotals, EMPTY_DESIGN, placePart, setChassis } from './DesignSystem';
import { eventContext, eventDefinition, previewOptions, resolveEvent, scheduleEvents } from './EventSystem';
import { buildFlightModel, initFlight, snapshot, stepFlight } from './MissionSystem';

const L = getComponent;
function build(chassisId: string, parts: Array<[string, string]>): SpacecraftDesign {
  let d = setChassis(EMPTY_DESIGN, chassisId, L).design;
  for (const [c, s] of parts) d = placePart(d, c, s, L).design;
  return d;
}
const BASE: Array<[string, string]> = [
  ['camera', 'bottom-0'],
  ['thruster', 'bottom-1'],
  ['antenna-hg', 'top-0'],
  ['attitude-sensor', 'side-pz-0'],
  ['solar-adv', 'side-px-0'],
  ['solar-adv', 'side-nx-0'],
  ['battery-adv', 'bay-0'],
  ['obc', 'bay-1'],
  ['prop-tank', 'bay-2'],
  ['thermal', 'bay-3'],
];
const CAMERA = build('chassis-m', BASE);
const PLAN: MissionPlan = { launcherId: 'minotaur-iv', altitudeKm: 75, inclinationDeg: 90, durationDays: 60, launchDay: 7 };

function flightWith(events: ReturnType<typeof scheduleEvents>, design = CAMERA) {
  const model = buildFlightModel(design, L, PLAN, 2000);
  const state = initFlight(model, PLAN, designTotals(design, L).propellantKg, events);
  return { model, state, ctx: eventContext(design, L, model, 30) };
}

describe('calendario de acontecimientos', () => {
  it('determinista por misión, uno de cada tipo, dentro de la campaña', () => {
    const a = scheduleEvents('mision-123', 1440, true);
    const b = scheduleEvents('mision-123', 1440, true);
    expect(a).toEqual(b);
    expect(new Set(a.map((e) => e.type)).size).toBe(3);
    for (const e of a) {
      expect(e.atH).toBeGreaterThan(23);
      expect(e.atH).toBeLessThan(1440 - 71);
    }
    for (let i = 1; i < a.length; i++) expect(a[i].atH).toBeGreaterThan(a[i - 1].atH);
  });

  it('otra misión, otro orden o momento; sin instrumentos no hay anomalía de instrumento', () => {
    const seeds = ['a', 'b', 'c', 'd', 'e'].map((s) => scheduleEvents(s, 1440, true).map((e) => e.type).join());
    expect(new Set(seeds).size).toBeGreaterThan(1);
    expect(scheduleEvents('x', 1440, false).map((e) => e.type)).not.toContain('instrument-anomaly');
  });
});

describe('pausa por acontecimiento', () => {
  it('la simulación se detiene en el acontecimiento y no avanza hasta decidir', () => {
    let { model, state } = flightWith([{ id: 'ev-1', type: 'comms-outage', atH: 30 }]);
    state = stepFlight(model, state, 100);
    expect(state.elapsedH).toBeCloseTo(30, 9);
    expect(state.pendingEventId).toBe('ev-1');
    expect(stepFlight(model, state, 50)).toBe(state);
  });
});

describe('opciones que dependen del diseño', () => {
  it('reorientar: sin ruedas gasta propelente; con ruedas, no', () => {
    const noWheels = flightWith([]);
    const def1 = eventDefinition('power-degradation', noWheels.ctx, noWheels.state);
    const re1 = def1.options.find((o) => o.id === 'reorient')!;
    expect(re1.label).toContain('propulsores');
    expect(re1.apply(noWheels.state).propellantKg).toBeLessThan(noWheels.state.propellantKg);

    const withWheels = build('chassis-l', [...BASE.filter(([, s]) => s !== 'bay-3'), ['thermal', 'bay-3'], ['reaction-wheels', 'bay-4']]);
    const w = flightWith([], withWheels);
    const re2 = eventDefinition('power-degradation', w.ctx, w.state).options.find((o) => o.id === 'reorient')!;
    expect(re2.label).toContain('ruedas');
    expect(re2.apply(w.state).propellantKg).toBe(w.state.propellantKg);
  });

  it('antena de respaldo: solo si queda presupuesto', () => {
    const f = flightWith([]);
    const rich = eventDefinition('comms-outage', f.ctx, f.state).options.find((o) => o.id === 'backup')!;
    expect(rich.available).toBe(true);
    const poor = eventDefinition('comms-outage', { ...f.ctx, remainingBudgetMUSD: 1 }, f.state).options.find((o) => o.id === 'backup')!;
    expect(poor.available).toBe(false);
    expect(poor.unavailableReason).toContain('1.0');
  });

  it('recalibrar: exige al menos 50 % de batería y la consume', () => {
    const f = flightWith([]);
    const ok = eventDefinition('instrument-anomaly', f.ctx, f.state).options.find((o) => o.id === 'recalibrate')!;
    expect(ok.available).toBe(true);
    expect(ok.apply(f.state).batteryWh).toBeCloseTo(f.state.batteryWh - 900 * 0.35, 9);
    const low: FlightState = { ...f.state, batteryWh: 300 };
    expect(eventDefinition('instrument-anomaly', f.ctx, low).options.find((o) => o.id === 'recalibrate')!.available).toBe(false);
  });
});

describe('efectos reales en la simulación', () => {
  it('caída de generación: el snapshot genera menos mientras dura y luego se restablece', () => {
    let { model, state, ctx } = flightWith([{ id: 'ev-1', type: 'power-degradation', atH: 10 }]);
    state = stepFlight(model, state, 10);
    state = resolveEvent(ctx, state, 'keep');
    expect(snapshot(model, state).genFactor).toBeCloseTo(0.6, 9);
    state = stepFlight(model, state, 49);
    expect(snapshot(model, state).genFactor).toBe(1);
    expect(state.log.some((e) => e.text === 'Generación eléctrica restablecida.')).toBe(true);
  });

  it('avería de estación: «esperar» pierde datos por memoria llena; la antena de respaldo, casi nada', () => {
    let { model, state, ctx } = flightWith([{ id: 'ev-1', type: 'comms-outage', atH: 26 }]);
    state = stepFlight(model, state, 26);
    const def = eventDefinition('comms-outage', ctx, state);
    const pv = Object.fromEntries(previewOptions(ctx, state, def).map((p) => [p.optionId, p]));
    expect(pv.wait.lostGbit).toBeGreaterThan(150);
    expect(pv.backup.lostGbit).toBeLessThan(pv.wait.lostGbit);
    expect(pv['instruments-off'].lostGbit).toBe(0);
    expect(pv.backup.costMUSD).toBe(1.5);
    const after = resolveEvent(ctx, state, 'backup');
    expect(after.extraCostMUSD).toBe(1.5);
    expect(after.eventHistory[0].rank).toBe(1); // la mejor opción según la previsión
    expect(after.pendingEventId).toBe(null);
  });

  it('modo degradado: el instrumento produce la mitad el resto de la misión', () => {
    let { model, state, ctx } = flightWith([{ id: 'ev-1', type: 'instrument-anomaly', atH: 12 }]);
    state = stepFlight(model, state, 12);
    const rateBefore = 18;
    state = resolveEvent(ctx, state, 'degraded');
    // avanzar hasta que esté iluminada
    for (let k = 0; k < 40 && !snapshot(model, state).sunlit; k++) state = stepFlight(model, state, 0.1);
    expect(snapshot(model, state).dataRateGbitPerH).toBeCloseTo(rateBefore * 0.5, 9);
  });

  it('opción no disponible o inexistente: no cambia nada', () => {
    let { model, state, ctx } = flightWith([{ id: 'ev-1', type: 'comms-outage', atH: 5 }]);
    state = stepFlight(model, state, 5);
    expect(resolveEvent({ ...ctx, remainingBudgetMUSD: 0 }, state, 'backup')).toBe(state);
    expect(resolveEvent(ctx, state, 'nope')).toBe(state);
  });

  it('una campaña con 3 acontecimientos resueltos termina con su historial completo', () => {
    const events = scheduleEvents('campaña', 60 * 24, true);
    let { model, state, ctx } = flightWith(events);
    let guard = 0;
    while (!state.complete && guard++ < 20) {
      state = stepFlight(model, state, 24 * 60);
      if (state.pendingEventId) state = resolveEvent(ctx, state, eventDefinition(state.scheduledEvents.find((e) => e.id === state.pendingEventId)!.type, ctx, state).options[0].id);
    }
    expect(state.complete).toBe(true);
    expect(state.eventHistory.map((e) => e.type).sort()).toEqual(['comms-outage', 'instrument-anomaly', 'power-degradation']);
  });
});
