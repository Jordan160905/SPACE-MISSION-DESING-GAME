/**
 * Minijuego del rover lunar (Fase 8.9): conducción sobre el terreno y misiones de exploración.
 * El rover es de juego, con valores parecidos a los rovers lunares reales (velocidad de unos pocos
 * metros por segundo, paneles solares, subida limitada por la pendiente).
 */
import { heightAt, slopeAt, TERRAIN, type Terrain } from './LunarTerrain';

export const ROVER = {
  maxSpeed: 4,
  accel: 0.9,
  brake: 2,
  turnDegS: 40,
  /** Pendiente máxima que puede subir (°). */
  maxClimbDeg: 22,
  radiusM: 1.6,
  /** Consumo de energía (% por segundo) parado, a toda velocidad y extra por subir. */
  idlePct: 0.01,
  drivePct: 0.09,
  /** Carga de los paneles solares parado (% por segundo). */
  solarPct: 0.06,
  /** Celda del mapa de exploración (m). */
  cell: 20,
};

export type RoverMissionId = 'rock' | 'crater' | 'sample' | 'hill' | 'investigate' | 'send';

export interface RoverMission {
  id: RoverMissionId;
  title: string;
  goal: string;
  /** Mantener «Acción» (E) este tiempo, parado en el sitio. 0 = basta con llegar. */
  holdS: number;
  points: number;
  gbit: number;
  done: string;
}

export const ROVER_MISSIONS: RoverMission[] = [
  {
    id: 'rock',
    title: 'Localizar una roca',
    goal: 'Busca la roca grande marcada en el mapa y acércate a menos de 10 m.',
    holdS: 0,
    points: 120,
    gbit: 0.2,
    done: 'Roca localizada. Es un trozo de roca expulsado por el impacto que formó un cráter cercano.',
  },
  {
    id: 'crater',
    title: 'Explorar un cráter',
    goal: 'Entra en el cráter marcado y llega hasta su fondo. Baja despacio: las paredes son empinadas.',
    holdS: 0,
    points: 150,
    gbit: 0.3,
    done: 'Estás dentro del cráter. Las paredes muestran capas de material de distintas épocas.',
  },
  {
    id: 'sample',
    title: 'Recoger una muestra virtual',
    goal: 'En el fondo del cráter, para el rover en el punto marcado y mantén pulsado «Recoger» (E).',
    holdS: 4,
    points: 150,
    gbit: 0.4,
    done: 'Muestra guardada: regolito fino y trozos de roca del fondo del cráter.',
  },
  {
    id: 'hill',
    title: 'Encontrar una ubicación',
    goal: 'Encuentra la cima de la colina (marcada en el mapa): desde allí se ve toda la zona.',
    holdS: 0,
    points: 120,
    gbit: 0.2,
    done: 'Has llegado al punto de observación en lo alto de la colina.',
  },
  {
    id: 'investigate',
    title: 'Completar una investigación',
    goal: 'En la cima, para el rover y mantén pulsado «Medir» (E) para analizar la muestra con los instrumentos.',
    holdS: 6,
    points: 200,
    gbit: 0.6,
    done: 'Medición terminada. Responde la pregunta de la investigación.',
  },
  {
    id: 'send',
    title: 'Enviar los resultados',
    goal: 'Vuelve junto al módulo de descenso (su antena es más potente) y mantén pulsado «Enviar» (E).',
    holdS: 5,
    points: 200,
    gbit: 0.5,
    done: 'Resultados recibidos en el centro de control. ¡Misión de exploración completada!',
  },
];

/** Pregunta de la investigación (misión 5). */
export const INVESTIGATION = {
  question: 'Los instrumentos dicen que la muestra es polvo muy fino y con bordes afilados. ¿Por qué el polvo lunar es así?',
  options: [
    'Porque en la Luna no hay viento ni agua que redondeen los granos.',
    'Porque la Luna está hecha de arena de playa.',
    'Porque los astronautas lo trituraron con las botas.',
  ],
  correct: 0,
  explain: 'En la Tierra el viento y el agua desgastan los granos y los redondean. En la Luna los micrometeoritos rompen las rocas y nada los pule: por eso el regolito es fino, afilado y se pega a todo.',
  bonus: 100,
};

export interface RoverState {
  x: number;
  z: number;
  heading: number;
  speed: number;
  energy: number;
  t: number;
  distanceM: number;
  mission: number;
  holdT: number;
  /** Misión 5: la medición terminó y falta responder. */
  quizPending: boolean;
  quizAnswer: number | null;
  points: number;
  gbit: number;
  explored: string[];
  bumps: number;
  /** Aviso del momento (pendiente, roca, batería…). */
  warn: 'steep' | 'rock' | 'energy' | 'edge' | null;
  lastDone: RoverMissionId | null;
  finished: boolean;
}

export interface RoverInput {
  drive: number;
  turn: number;
  action: boolean;
}
export const NO_ROVER_INPUT: RoverInput = { drive: 0, turn: 0, action: false };

const cellKey = (x: number, z: number) => `${Math.floor(x / ROVER.cell)},${Math.floor(z / ROVER.cell)}`;

export function newRover(x: number, z: number): RoverState {
  // Sale junto al módulo, mirando hacia la primera misión.
  return {
    x: x + 6,
    z: z + 4,
    heading: 0.9,
    speed: 0,
    energy: 100,
    t: 0,
    distanceM: 0,
    mission: 0,
    holdT: 0,
    quizPending: false,
    quizAnswer: null,
    points: 0,
    gbit: 0,
    explored: [cellKey(x, z)],
    bumps: 0,
    warn: null,
    lastDone: null,
    finished: false,
  };
}

/** Pendiente del terreno en la dirección del movimiento (°; positiva = cuesta arriba). */
export function gradeAhead(t: Terrain, x: number, z: number, heading: number, dir: number) {
  const e = 2;
  const hx = Math.cos(heading) * dir;
  const hz = Math.sin(heading) * dir;
  const h0 = heightAt(t, x, z);
  const h1 = heightAt(t, x + hx * e, z + hz * e);
  return (Math.atan2(h1 - h0, e) * 180) / Math.PI;
}

/** Dónde está el objetivo de una misión. */
export function missionTarget(t: Terrain, id: RoverMissionId, lander: { x: number; z: number }) {
  const s = t.sites;
  switch (id) {
    case 'rock':
      return { x: s.rock.x, z: s.rock.z, r: 10 };
    case 'crater':
      return { x: s.crater.x, z: s.crater.z, r: s.crater.r * 0.55 };
    case 'sample':
      return { x: s.sample.x, z: s.sample.z, r: 6 };
    case 'hill':
      return { x: s.hill.x, z: s.hill.z, r: 15 };
    case 'investigate':
      return { x: s.hill.x, z: s.hill.z, r: 25 };
    case 'send':
      return { x: lander.x, z: lander.z, r: 15 };
  }
}

const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));

export function stepRover(t: Terrain, s: RoverState, input: RoverInput, dt: number, lander: { x: number; z: number }): RoverState {
  if (s.finished) return s;
  let { x, z, heading, speed, energy } = s;
  let warn: RoverState['warn'] = null;
  const canDrive = energy > 0;
  const drive = canDrive ? clamp(input.drive, -1, 1) : 0;
  if (!canDrive && input.drive) warn = 'energy';
  // Giro (sobre sí mismo, como los rovers con dirección en las seis ruedas).
  if (canDrive) heading += ((clamp(input.turn, -1, 1) * ROVER.turnDegS * Math.PI) / 180) * dt;
  // Velocidad máxima según la pendiente.
  const dir = drive !== 0 ? Math.sign(drive) : Math.sign(speed) || 1;
  const grade = gradeAhead(t, x, z, heading, dir);
  let vmax = ROVER.maxSpeed * clamp(1 - Math.max(0, grade) / ROVER.maxClimbDeg, 0, 1.25);
  if (grade < 0) vmax = ROVER.maxSpeed * Math.min(1.2, 1 - grade / 60);
  if (drive !== 0 && grade > ROVER.maxClimbDeg) {
    vmax = 0;
    warn = 'steep';
  }
  const target = drive * vmax * (drive < 0 ? 0.6 : 1);
  const rate = Math.abs(target) > Math.abs(speed) && Math.sign(target) === Math.sign(speed || target) ? ROVER.accel : ROVER.brake;
  speed += clamp(target - speed, -rate * dt, rate * dt);
  // Gravedad en la pendiente: cuesta abajo se acelera un poco si no se frena.
  let nx = x + Math.cos(heading) * speed * dt;
  let nz = z + Math.sin(heading) * speed * dt;
  // Obstáculos: rocas de más de 0,6 m.
  let bumps = s.bumps;
  for (const k of t.rocks) {
    if (k.r < 0.6) continue;
    const d = Math.hypot(nx - k.x, nz - k.z);
    const min = k.r + ROVER.radiusM;
    if (d < min) {
      // Choque suave: se detiene y queda pegado al borde de la roca.
      const ux = (nx - k.x) / (d || 1);
      const uz = (nz - k.z) / (d || 1);
      nx = k.x + ux * min;
      nz = k.z + uz * min;
      if (Math.abs(speed) > 0.3) bumps++;
      speed = 0;
      warn = 'rock';
      break;
    }
  }
  const half = TERRAIN.size / 2 - 30;
  if (Math.abs(nx) > half || Math.abs(nz) > half) {
    nx = clamp(nx, -half, half);
    nz = clamp(nz, -half, half);
    speed = 0;
    warn = 'edge';
  }
  const moved = Math.hypot(nx - x, nz - z);
  x = nx;
  z = nz;
  // Energía: conducir y subir gasta; parado, los paneles cargan.
  const up = Math.max(0, grade) * (Math.abs(speed) > 0.05 ? 1 : 0);
  const use = ROVER.idlePct + ROVER.drivePct * (Math.abs(speed) / ROVER.maxSpeed) * (1 + up / 10);
  const charge = Math.abs(speed) < 0.05 ? ROVER.solarPct : 0;
  energy = clamp(energy + (charge - use) * dt, 0, 100);
  if (energy < 10 && !warn) warn = 'energy';
  // Mapa de exploración.
  const key = cellKey(x, z);
  const explored = s.explored.includes(key) ? s.explored : [...s.explored, key];
  let next: RoverState = { ...s, x, z, heading, speed, energy, t: s.t + dt, distanceM: s.distanceM + moved, explored, bumps, warn };
  next = checkMission(t, next, input.action, dt, lander);
  return next;
}

/** Avance de la misión actual. */
function checkMission(t: Terrain, s: RoverState, action: boolean, dt: number, lander: { x: number; z: number }): RoverState {
  const m = ROVER_MISSIONS[s.mission];
  if (!m || s.quizPending) return s;
  const tg = missionTarget(t, m.id, lander);
  const inside = Math.hypot(s.x - tg.x, s.z - tg.z) <= tg.r;
  if (!inside) return s.holdT ? { ...s, holdT: 0 } : s;
  if (m.holdS === 0) return complete(s, m);
  const still = Math.abs(s.speed) < 0.1;
  if (!(action && still)) return s.holdT ? { ...s, holdT: 0 } : s;
  const holdT = s.holdT + dt;
  if (holdT < m.holdS) return { ...s, holdT };
  if (m.id === 'investigate') return { ...s, holdT: 0, quizPending: true };
  return complete({ ...s, energy: m.id === 'send' ? Math.max(0, s.energy - 5) : s.energy }, m);
}

function complete(s: RoverState, m: RoverMission): RoverState {
  const mission = s.mission + 1;
  return { ...s, mission, holdT: 0, points: s.points + m.points, gbit: s.gbit + m.gbit, lastDone: m.id, finished: mission >= ROVER_MISSIONS.length };
}

/** Respuesta a la pregunta de la investigación. */
export function answerInvestigation(s: RoverState, option: number): RoverState {
  if (!s.quizPending) return s;
  const m = ROVER_MISSIONS[s.mission];
  const ok = option === INVESTIGATION.correct;
  const done = complete({ ...s, quizPending: false, quizAnswer: option }, m);
  return ok ? { ...done, points: done.points + INVESTIGATION.bonus } : done;
}

/** Porcentaje del terreno cercano (600 × 600 m alrededor del módulo) ya explorado. */
export function exploredPct(s: RoverState, lander: { x: number; z: number }) {
  const half = 300;
  let n = 0;
  let total = 0;
  for (let gx = Math.floor((lander.x - half) / ROVER.cell); gx < Math.ceil((lander.x + half) / ROVER.cell); gx++)
    for (let gz = Math.floor((lander.z - half) / ROVER.cell); gz < Math.ceil((lander.z + half) / ROVER.cell); gz++) {
      total++;
      if (s.explored.includes(`${gx},${gz}`)) n++;
    }
  return total ? (n / total) * 100 : 0;
}

export function roverReadout(t: Terrain, s: RoverState, lander: { x: number; z: number }) {
  const m = ROVER_MISSIONS[s.mission];
  const tg = m ? missionTarget(t, m.id, lander) : null;
  const dist = tg ? Math.hypot(tg.x - s.x, tg.z - s.z) : 0;
  // Ángulo del objetivo respecto del frente del rover (+ = a la derecha).
  let rel = tg ? Math.atan2(tg.z - s.z, tg.x - s.x) - s.heading : 0;
  rel = Math.atan2(Math.sin(rel), Math.cos(rel));
  return {
    mission: m ?? null,
    target: tg,
    distanceM: dist,
    bearingDeg: (rel * 180) / Math.PI,
    slopeDeg: slopeAt(t, s.x, s.z).deg,
    grade: gradeAhead(t, s.x, s.z, s.heading, 1),
    inTarget: tg ? dist <= tg.r : false,
  };
}
