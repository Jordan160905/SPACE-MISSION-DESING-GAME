/**
 * BudgetSystem — contabilidad de la misión.
 *
 * Contabiliza componentes, operación (días × costo diario) y lanzamiento. Lo que aún no se ha
 * decidido (el lanzador, hasta la Fase 4) aparece como PENDIENTE, nunca como cifra inventada.
 */
import type { ComponentDef, MissionTemplate, SpacecraftDesign } from '../data/schemas';

export type ComponentLookup = (id: string) => ComponentDef | undefined;

export interface BudgetLine {
  id: 'components' | 'launch' | 'operations';
  label: string;
  /** null = todavía no determinado en esta etapa del juego. */
  amountMUSD: number | null;
  note: string;
}

export interface BudgetSummary {
  capMUSD: number;
  lines: BudgetLine[];
  committedMUSD: number;
  remainingMUSD: number;
  overBudget: boolean;
  /** Fracción comprometida (0–1+) para barras de progreso. */
  usedFraction: number;
}

/** Suma el costo del chasis y de todas las piezas montadas. Lanza si una pieza no existe. */
export function designCostMUSD(design: SpacecraftDesign, lookup: ComponentLookup): number {
  const ids = [...(design.chassisId ? [design.chassisId] : []), ...design.parts.map((p) => p.componentId)];
  return ids.reduce((sum, id) => {
    const c = lookup(id);
    if (!c) throw new Error(`Componente desconocido en el diseño: ${id}`);
    return sum + c.costMUSD;
  }, 0);
}

export function budgetSummary(
  template: MissionTemplate,
  design: SpacecraftDesign,
  lookup: ComponentLookup,
  launchCostMUSD: number | null = null,
  operationsCostMUSD: number | null = null,
): BudgetSummary {
  const components = designCostMUSD(design, lookup);
  const lines: BudgetLine[] = [
    {
      id: 'components',
      label: 'Componentes de la nave',
      amountMUSD: components,
      note: design.chassisId ? `${design.parts.length + 1} piezas` : 'Sin diseño todavía',
    },
    {
      id: 'launch',
      label: 'Lanzamiento',
      amountMUSD: launchCostMUSD,
      note: launchCostMUSD === null ? 'Se define al elegir lanzador' : 'Lanzador seleccionado',
    },
    {
      id: 'operations',
      label: 'Operación',
      amountMUSD: operationsCostMUSD,
      note: operationsCostMUSD === null ? 'Depende de la duración y el plan' : 'Duración × costo diario',
    },
  ];
  const committed = lines.reduce((s, l) => s + (l.amountMUSD ?? 0), 0);
  return {
    capMUSD: template.budgetCapMUSD,
    lines,
    committedMUSD: committed,
    remainingMUSD: template.budgetCapMUSD - committed,
    overBudget: committed > template.budgetCapMUSD,
    usedFraction: committed / template.budgetCapMUSD,
  };
}
