/**
 * Fase 1 de la mejora de experiencia: asistente de nueva misión.
 * Glosario emergente y niveles de dificultad que cambian parámetros reales.
 */
import { describe, expect, it } from 'vitest';
import { applyDifficulty, difficultyDef } from '../data/difficulty';
import { LUNA_01 } from '../data/missions/missions';
import { glossSegments, TOOLTIPS, tooltipById } from '../data/tooltips';
import { GRADE_THRESHOLDS, XP_PER_POINT_FAIL, XP_PER_POINT_SUCCESS } from './ScoringSystem';

describe('glosario emergente', () => {
  it('reconoce términos sin distinguir mayúsculas y conserva el texto original', () => {
    const segs = glossSegments('La Órbita polar y el presupuesto en MUSD.');
    expect(segs.map((s) => s.text).join('')).toBe('La Órbita polar y el presupuesto en MUSD.');
    const tips = segs.filter((s) => s.tip).map((s) => s.tip!.id);
    expect(tips).toEqual(['polar', 'presupuesto', 'musd']);
  });
  it('prefiere la coincidencia más larga («órbita polar» antes que «órbita»)', () => {
    const tip = glossSegments('una órbita polar').find((s) => s.tip)!;
    expect(tip.text).toBe('órbita polar');
    expect(tip.tip!.id).toBe('polar');
  });
  it('no marca palabras dentro de otras', () => {
    expect(glossSegments('orbitales').some((s) => s.tip)).toBe(false);
  });
  it('cada definición es única y localizable', () => {
    const ids = TOOLTIPS.map((t) => t.id);
    expect(new Set(ids).size).toBe(ids.length);
    for (const id of ids) expect(tooltipById(id)?.simple.length).toBeGreaterThan(10);
  });
});

describe('dificultad del asistente', () => {
  it('se llama Fácil / Intermedio / Difícil y conserva el rol de cada nivel', () => {
    expect(['explorer', 'engineer', 'expert'].map((d) => difficultyDef(d as never).label)).toEqual(['Fácil', 'Intermedio', 'Difícil']);
    expect(difficultyDef('explorer').persona).toBe('Explorador');
  });
  it('cambia parámetros reales de la misión', () => {
    const easy = applyDifficulty(LUNA_01, 'explorer');
    const mid = applyDifficulty(LUNA_01, 'engineer');
    const hard = applyDifficulty(LUNA_01, 'expert');
    expect(mid).toBe(LUNA_01);
    expect(easy.budgetCapMUSD).toBeGreaterThan(mid.budgetCapMUSD);
    expect(hard.budgetCapMUSD).toBeLessThan(mid.budgetCapMUSD);
    expect(easy.developmentMonths).toBeGreaterThan(hard.developmentMonths);
  });
});

describe('recompensas mostradas en el asistente', () => {
  it('salen de la misma tabla que usa la puntuación', () => {
    expect(GRADE_THRESHOLDS.map(([g]) => g)).toEqual(['S', 'A', 'B', 'C', 'D']);
    expect(XP_PER_POINT_SUCCESS).toBe(3);
    expect(XP_PER_POINT_FAIL).toBe(1.5);
  });
});
