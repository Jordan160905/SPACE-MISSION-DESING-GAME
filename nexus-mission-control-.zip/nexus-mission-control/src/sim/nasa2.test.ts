/**
 * Requisitos del reto NASA: dificultad y sandbox, recurso tiempo, panel de recursos con recursos
 * críticos, modo equipo (votos y coordinación), códigos para compartir.
 */
import { describe, expect, it } from 'vitest';
import { getComponent } from '../data/components/catalog';
import { applyDifficulty, DIFFICULTIES, isComponentAllowed } from '../data/difficulty';
import { LUNA_01, templateForMission } from '../data/missions/missions';
import { MissionSchema, type MissionPlan, type SpacecraftDesign } from '../data/schemas';
import { createMission, withDesign, withPlan, withTeamDecision } from '../state/missionLogic';
import { decodeShare, encodeShare, ShareCodeError } from '../state/shareCode';
import { catalogAdvice } from './CatalogAdvisor';
import { EMPTY_DESIGN, placePart, setChassis } from './DesignSystem';
import { analysisInputForMission, analyzeEngineering } from './EngineeringAnalysis';
import { analyzePlan } from './PlanningSystem';
import { missionResources } from './ResourceSystem';
import { analyzeSchedule, operationalLifetimeDays } from './ScheduleSystem';
import { coordination, roleGoals, tallyVotes } from './TeamSystem';

const L = getComponent;
function build(chassisId: string, parts: Array<[string, string]>): SpacecraftDesign {
  let d = setChassis(EMPTY_DESIGN, chassisId, L).design;
  for (const [c, s] of parts) d = placePart(d, c, s, L).design;
  return d;
}
const CAMERA_REF = build('chassis-m', [
  ['camera', 'bottom-0'],
  ['thruster', 'bottom-1'],
  ['antenna-hg', 'top-0'],
  ['attitude-sensor', 'side-pz-0'],
  ['solar-adv', 'side-px-0'],
  ['solar-adv', 'side-nx-0'],
  ['battery-adv', 'bay-0'],
  ['obc', 'bay-1'],
  ['prop-tank', 'bay-2'],
  ['thermal', 'bay-3'],
]);
const PLAN: MissionPlan = { launcherId: 'minotaur-iv', altitudeKm: 75, inclinationDeg: 90, durationDays: 60, launchDay: 7 };

describe('Dificultad y sandbox', () => {
  it('ajusta presupuesto, calendario, objetivo de datos y XP; Ingeniero es la plantilla base', () => {
    expect(applyDifficulty(LUNA_01, 'engineer')).toBe(LUNA_01);
    const ex = applyDifficulty(LUNA_01, 'explorer');
    expect(ex.budgetCapMUSD).toBe(175);
    expect(ex.developmentMonths).toBe(45);
    expect(ex.objectives[0].dataTargetGbit).toBe(1600);
    const xp = applyDifficulty(LUNA_01, 'expert');
    expect(xp.budgetCapMUSD).toBe(119);
    expect(xp.objectives[0].dataTargetGbit).toBe(2400);
    expect(xp.rewards.xp).toBe(750);
    const sb = applyDifficulty(LUNA_01, 'sandbox');
    expect(sb.rewards.xp).toBe(0);
    expect(sb.rewards.unlocks).toEqual([]);
    expect(applyDifficulty(LUNA_01, 'expert')).toBe(xp); // memorizada: selectores estables
    expect(DIFFICULTIES.find((d) => d.id === 'sandbox')!.events).toBe(false);
  });

  it('Explorador solo admite componentes simples (el análisis y el catálogo lo explican)', () => {
    expect(isComponentAllowed(L('solar-adv')!, 'explorer')).toBe(false);
    expect(isComponentAllowed(L('solar-basic')!, 'explorer')).toBe(true);
    expect(isComponentAllowed(L('solar-adv')!, 'engineer')).toBe(true);
    const r = analyzeEngineering({ design: CAMERA_REF, lookup: L, template: applyDifficulty(LUNA_01, 'explorer'), objectiveId: 'obj-mapping', difficulty: 'explorer' });
    expect(r.issues.find((i) => i.id === 'tier-locked')?.severity).toBe('critical');
    expect(catalogAdvice(L('battery-adv')!, CAMERA_REF, L, 'explorer').label).toBe('Gama avanzada');
  });

  it('cada objetivo se puede cumplir en Explorador solo con componentes simples', () => {
    const t = applyDifficulty(LUNA_01, 'explorer');
    const designs: Record<string, SpacecraftDesign> = {
      'obj-mapping': build('chassis-m', [
        ['camera', 'bottom-0'],
        ['thruster', 'bottom-1'],
        ['antenna-hg', 'top-0'],
        ['attitude-sensor', 'side-pz-0'],
        ['solar-basic', 'side-px-0'],
        ['solar-basic', 'side-nx-0'],
        ['battery-basic', 'bay-0'],
        ['obc', 'bay-1'],
        ['prop-tank', 'bay-2'],
        ['thermal', 'bay-3'],
      ]),
      'obj-mineral': build('chassis-m', [
        ['spectrometer', 'bottom-0'],
        ['thruster', 'bottom-1'],
        ['antenna-hg', 'top-0'],
        ['attitude-sensor', 'side-pz-0'],
        ['solar-basic', 'side-px-0'],
        ['solar-basic', 'side-nx-0'],
        ['battery-basic', 'bay-0'],
        ['obc', 'bay-1'],
        ['prop-tank', 'bay-2'],
        ['thermal', 'bay-3'],
      ]),
      'obj-polar-ice': build('chassis-l', [
        ['radar', 'bottom-0'],
        ['thruster', 'bottom-1'],
        ['antenna-hg', 'top-0'],
        ['attitude-sensor', 'side-pz-0'],
        ['solar-basic', 'side-px-0'],
        ['solar-basic', 'side-nx-0'],
        ['solar-basic', 'side-px-1'],
        ['solar-basic', 'side-nx-1'],
        ['battery-basic', 'bay-0'],
        ['battery-basic', 'bay-1'],
        ['obc', 'bay-2'],
        ['prop-tank', 'bay-3'],
        ['reaction-wheels', 'bay-4'],
        ['prop-tank', 'bay-5'],
        ['thermal', 'side-nz-0'],
      ]),
    };
    for (const o of t.objectives) {
      const rec = o.recommendedOrbit;
      const plan: MissionPlan = { ...PLAN, launcherId: 'falcon-9', altitudeKm: Math.round((rec.altitudeKm[0] + rec.altitudeKm[1]) / 2), inclinationDeg: 90 };
      const r = analyzePlan({ design: designs[o.id], lookup: L, template: t, objectiveId: o.id, plan, difficulty: 'explorer' });
      expect(r.issues.filter((i) => i.severity === 'critical').map((i) => i.id), o.id).toEqual([]);
    }
  });

  it('las misiones guardan su dificultad; los guardados antiguos son «Ingeniero»', () => {
    const m = createMission({ template: LUNA_01, objectiveId: 'obj-mapping', id: 'x', now: new Date(), difficulty: 'expert' });
    expect(m.difficulty).toBe('expert');
    expect(templateForMission(m)!.budgetCapMUSD).toBe(119);
    const { difficulty: _d, ...old } = m;
    expect(MissionSchema.parse(old).difficulty).toBe('engineer');
    // El análisis de la misión usa la plantilla ajustada (presupuesto de Experto)
    const r = analyzeEngineering(analysisInputForMission(CAMERA_REF, L, m, () => LUNA_01));
    expect(r.budget!.capMUSD).toBe(119);
  });
});

describe('Recurso tiempo', () => {
  it('camino crítico: la pieza más lenta + integración y pruebas', () => {
    const s = analyzeSchedule(CAMERA_REF, L, 36);
    // modificadas (12 meses) + 6 + 0,25 × 11 piezas
    expect(s.developmentMonths).toBe(12);
    expect(s.integrationMonths).toBeCloseTo(8.75, 9);
    expect(s.totalMonths).toBeCloseTo(20.75, 9);
    expect(s.ok).toBe(true);
    const radar = build('chassis-m', [['radar', 'bottom-0']]);
    expect(analyzeSchedule(radar, L, 36).driver!.id).toBe('radar');
    expect(analyzeSchedule(radar, L, 20).ok).toBe(false);
  });

  it('el análisis marca un calendario imposible como crítico', () => {
    const t = { ...LUNA_01, developmentMonths: 15 };
    const r = analyzeEngineering({ design: CAMERA_REF, lookup: L, template: t, objectiveId: 'obj-mapping' });
    expect(r.issues.find((i) => i.id === 'schedule-late')?.severity).toBe('critical');
  });

  it('vida útil: la campaña más los días que paga el Δv sobrante', () => {
    const r = analyzePlan({ design: CAMERA_REF, lookup: L, template: LUNA_01, objectiveId: 'obj-mapping', plan: PLAN });
    const life = operationalLifetimeDays(r.deltaV, PLAN.altitudeKm, PLAN.durationDays);
    expect(life).toBeGreaterThan(PLAN.durationDays);
    // sin motor la vida es solo la campaña
    expect(operationalLifetimeDays({ ...r.deltaV, ispS: 0 }, 75, 60)).toBe(60);
  });
});

describe('Panel de recursos', () => {
  it('seis recursos con margen y los dos más críticos son los de menos margen', () => {
    const r = analyzePlan({ design: CAMERA_REF, lookup: L, template: LUNA_01, objectiveId: 'obj-mapping', plan: PLAN });
    const rep = missionResources(r.engineering, r);
    expect(rep.resources.map((x) => x.id)).toEqual(['mass', 'energy', 'budget', 'data', 'comms', 'time']);
    expect(rep.critical).toHaveLength(2);
    const sorted = [...rep.resources].sort((a, b) => a.margin - b.margin).map((x) => x.id);
    expect(rep.critical).toEqual(sorted.slice(0, 2));
    for (const x of rep.resources) expect(x.plain.length).toBeGreaterThan(20);
  });

  it('un recurso excedido aparece como «over» y entre los críticos', () => {
    const r = analyzePlan({ design: CAMERA_REF, lookup: L, template: { ...LUNA_01, budgetCapMUSD: 60 }, objectiveId: 'obj-mapping', plan: PLAN });
    const rep = missionResources(r.engineering, r);
    expect(rep.resources.find((x) => x.id === 'budget')!.state).toBe('over');
    expect(rep.critical).toContain('budget');
  });
});

describe('Modo equipo', () => {
  it('mayoría simple; en empate decide la dirección', () => {
    expect(tallyVotes([{ role: 'scientist', choice: 'a' }, { role: 'engineer', choice: 'a' }, { role: 'director', choice: 'b' }]).outcome).toBe('a');
    const tie = tallyVotes([{ role: 'scientist', choice: 'a' }, { role: 'director', choice: 'b' }]);
    expect(tie.outcome).toBe('b');
    expect(tie.tieBrokenByDirector).toBe(true);
    expect(tallyVotes([{ role: 'scientist', choice: 'a' }, { role: 'operations', choice: 'a' }]).unanimous).toBe(true);
    expect(() => tallyVotes([])).toThrow();
  });

  it('las metas de los roles chocan: el cohete barato no satisface a Operaciones', () => {
    const r = analyzePlan({ design: CAMERA_REF, lookup: L, template: LUNA_01, objectiveId: 'obj-mapping', plan: PLAN });
    const g = roleGoals(r.engineering, r);
    expect(g.map((x) => x.role)).toEqual(['director', 'scientist', 'engineer', 'operations']);
    expect(g.find((x) => x.role === 'operations')!.met).toBe(false); // Minotaur IV: 8 de 8 → Laplace 90 %
    const m = analyzePlan({ design: CAMERA_REF, lookup: L, template: LUNA_01, objectiveId: 'obj-mapping', plan: { ...PLAN, launcherId: 'falcon-9' } });
    expect(roleGoals(m.engineering, m).find((x) => x.role === 'operations')!.met).toBe(true);
  });

  it('el equipo se valida y las decisiones quedan registradas con su índice de coordinación', () => {
    expect(() => MissionSchema.shape.team.parse({ name: 'A', members: [{ name: 'x', role: 'director' }, { name: 'y', role: 'director' }] })).toThrow();
    let m = createMission({
      template: LUNA_01,
      objectiveId: 'obj-mapping',
      id: 't',
      now: new Date(),
      team: { name: 'Artemisa', members: [{ name: 'Ana', role: 'director' }, { name: 'Luis', role: 'scientist' }] },
    });
    m = withTeamDecision(m, { kind: 'design', atISO: 'x', label: 'Aprobar', votes: [{ role: 'director', choice: 'approve' }, { role: 'scientist', choice: 'approve' }], outcome: 'approve', unanimous: true }, new Date());
    m = withTeamDecision(m, { kind: 'event', atISO: 'x', label: 'Evento', votes: [{ role: 'director', choice: 'a' }, { role: 'scientist', choice: 'b' }], outcome: 'a', unanimous: false, bestShare: 0.5 }, new Date());
    const c = coordination(m.teamLog);
    expect(c.decisions).toBe(2);
    expect(c.unanimousShare).toBe(0.5);
    expect(c.bestOptionShare).toBe(0.5);
    expect(c.index).toBe(50);
    expect(coordination([]).index).toBe(0);
  });
});

describe('Compartir diseños', () => {
  it('el código recupera exactamente misión, dificultad, nave y plan', () => {
    let m = createMission({ template: LUNA_01, objectiveId: 'obj-mineral', id: 's', now: new Date(), difficulty: 'expert' });
    m = withPlan(withDesign(m, CAMERA_REF, new Date()), PLAN, new Date());
    const code = encodeShare({ ...m, name: 'Órbita ñandú' });
    expect(code.startsWith('NEXUS1.')).toBe(true);
    const back = decodeShare(code);
    expect(back.design).toEqual(CAMERA_REF);
    expect(back.plan).toEqual(PLAN);
    expect(back.difficulty).toBe('expert');
    expect(back.name).toBe('Órbita ñandú');
  });

  it('rechaza códigos dañados o ajenos con un mensaje claro', () => {
    expect(() => decodeShare('hola')).toThrow(ShareCodeError);
    expect(() => decodeShare('NEXUS1.@@@')).toThrow(ShareCodeError);
    expect(() => decodeShare('NEXUS1.' + btoa('{"a":1}'))).toThrow(ShareCodeError);
  });
});

describe('Compatibilidad del vehículo de lanzamiento', () => {
  it('explica por qué un vehículo no sirve: retirado, masa, cofia o presupuesto', async () => {
    const { getLauncher } = await import('../data/launchers/launchers');
    const { launcherCompatibility } = await import('./LauncherCompatibility');
    const ctx = { massWithMarginKg: 280, envelope: { diameterM: 1.6, heightM: 2, belowM: 0.3, half: [0.8, 1, 0.8] as [number, number, number] }, budgetForLauncherMUSD: 84 };
    const delta = launcherCompatibility(getLauncher('delta-ii')!, ctx as never);
    expect(delta.compatible).toBe(false);
    expect(delta.reason).toMatch(/Retirado/);
    const minI = launcherCompatibility(getLauncher('minotaur-i')!, ctx as never);
    expect(minI.compatible).toBe(false);
    expect(minI.checks.find((c) => c.id === 'orbit')!.ok).toBe(false); // solo órbita baja: no llega a la Luna
    const heavyShip = launcherCompatibility(getLauncher('minotaur-iv')!, { ...ctx, massWithMarginKg: 420 } as never);
    expect(heavyShip.reason).toMatch(/pesa demasiado/);
    expect(launcherCompatibility(getLauncher('minotaur-iv')!, ctx as never).compatible).toBe(true);
    expect(launcherCompatibility(getLauncher('falcon-9')!, ctx as never).compatible).toBe(true);
    const pricey = launcherCompatibility(getLauncher('falcon-9')!, { ...ctx, budgetForLauncherMUSD: 55 } as never);
    expect(pricey.compatible).toBe(false);
    expect(pricey.reason).toMatch(/presupuesto/);
    // Cada ficha compara lo que necesita la misión con lo que ofrece el vehículo en los 5 requisitos.
    expect(launcherCompatibility(getLauncher('atlas-v')!, ctx as never).checks.map((c) => c.id)).toEqual(['availability', 'orbit', 'mass', 'fairing', 'budget']);
    const big = launcherCompatibility(getLauncher('minotaur-iv')!, { ...ctx, envelope: { ...ctx.envelope, diameterM: 2.5 } } as never);
    expect(big.reason).toMatch(/cofia/);
  });
});
