/**
 * Fases 8.8 y 8.9: aterrizaje lunar jugable y rover de exploración.
 * Los «pilotos» de estas pruebas usan exactamente los mismos mandos que el jugador.
 */
import { describe, expect, it } from 'vitest';
import { altitude, evaluate, landerReadout, LANDER, landingAdvice, landingPoints, LIMITS, newLander, NO_LANDER_INPUT, stepLander, type LanderInput, type LanderState } from './Lander';
import { heightAt, inSafeZone, makeTerrain, rockNear, slopeAt, TERRAIN } from './LunarTerrain';
import { answerInvestigation, exploredPct, INVESTIGATION, newRover, NO_ROVER_INPUT, ROVER, ROVER_MISSIONS, roverReadout, stepRover, type RoverInput, type RoverState } from './Rover';

const T = makeTerrain(7);

/** Piloto con los mismos mandos que el jugador (subir/bajar empuje, inclinar, nivelar). */
function landerPilot(s: LanderState): LanderInput {
  const r = landerReadout(T, s);
  const alt = r.altitudeM;
  const d = Math.max(1e-6, r.safeDistM);
  const vMax = Math.min(14, 0.05 * d);
  const vxd = (r.safeDx / d) * vMax;
  const vzd = (r.safeDz / d) * vMax;
  const vyd = -Math.max(0.7, Math.min(22, 0.09 * alt));
  let ax = Math.max(-2.2, Math.min(2.2, (vxd - s.v[0]) * 0.6));
  let az = Math.max(-2.2, Math.min(2.2, (vzd - s.v[2]) * 0.6));
  if (alt < 6) {
    ax = Math.max(-0.4, Math.min(0.4, -s.v[0] * 0.8));
    az = Math.max(-0.4, Math.min(0.4, -s.v[2] * 0.8));
  }
  const ay = (vyd - s.v[1]) * 0.9 + 1.62;
  const a = Math.hypot(ax, ay, az);
  const p = (Math.atan2(ax, Math.max(0.1, ay)) * 180) / Math.PI;
  const rl = (Math.asin(Math.max(-1, Math.min(1, az / a))) * 180) / Math.PI;
  const thr = (a * (LANDER.dryKg + s.fuelKg)) / LANDER.thrustN;
  const step = (want: number, have: number, tol: number) => (Math.abs(want - have) < tol ? 0 : Math.sign(want - have));
  return { throttle: step(thr, s.throttle, 0.01), pitch: step(p, s.pitch, 0.5), roll: step(rl, s.roll, 0.5), level: false };
}

function fly(s0: LanderState, pilot: (s: LanderState) => LanderInput, maxS = 600) {
  let s = s0;
  for (let i = 0; i < maxS / 0.05 && !s.done; i++) s = stepLander(T, s, pilot(s), 0.05);
  return s;
}

describe('Terreno lunar', () => {
  it('tiene cráteres, rocas y relieve, y una zona segura llana y sin rocas', () => {
    expect(T.craters.length).toBeGreaterThan(20);
    expect(T.rocks.length).toBeGreaterThan(150);
    expect(slopeAt(T, TERRAIN.safe.x, TERRAIN.safe.z).deg).toBeLessThan(2);
    for (let a = 0; a < 6.28; a += 0.5) {
      const x = TERRAIN.safe.x + Math.cos(a) * 30;
      const z = TERRAIN.safe.z + Math.sin(a) * 30;
      expect(slopeAt(T, x, z).deg).toBeLessThan(TERRAIN.maxSlopeDeg);
      expect(rockNear(T, x, z, 2.2, 0.5)).toBe(null);
    }
    // Los cráteres son cuencos: el centro está más bajo que el borde.
    const c = T.craters[0];
    expect(heightAt(T, c.x, c.z)).toBeLessThan(heightAt(T, c.x + c.r, c.z) - 4);
  });
});

describe('Aterrizaje lunar', () => {
  it('la física sigue la gravedad lunar y la ecuación del cohete', () => {
    const s0 = { ...newLander(T), throttle: 0 };
    const s1 = stepLander(T, s0, { ...NO_LANDER_INPUT, setThrottle: 0 }, 1);
    expect(s1.v[1] - s0.v[1]).toBeCloseTo(-1.62, 2);
    const s2 = stepLander(T, s0, { ...NO_LANDER_INPUT, setThrottle: 1 }, 1);
    expect(s0.fuelKg - s2.fuelKg).toBeCloseTo(LANDER.thrustN / (LANDER.ispS * 9.80665), 2);
  });

  it('es jugable: con los mandos del jugador se aterriza suave en la zona segura', () => {
    for (const attempt of [0, 1, 2, 3]) {
      const s = fly(newLander(T, attempt), landerPilot);
      expect(s.done).toBe(true);
      expect(s.touchdown!.success).toBe(true);
      expect(s.touchdown!.verticalMS).toBeLessThan(LIMITS.verticalMS);
      expect(inSafeZone(s.p[0], s.p[2])).toBe(true);
      expect(landingPoints(s.touchdown!)).toBeGreaterThan(700);
    }
  });

  it('sin frenar se estrella y el juego explica qué mejorar', () => {
    const s = fly(newLander(T), () => ({ ...NO_LANDER_INPUT, setThrottle: 0 }));
    expect(s.touchdown!.success).toBe(false);
    expect(s.touchdown!.outcome === 'crash' || s.touchdown!.outcome === 'away').toBe(true);
    const adv = landingAdvice(s.touchdown!);
    expect(adv.length).toBeGreaterThan(0);
    expect(landingPoints(s.touchdown!)).toBe(0);
  });

  it('demasiada inclinación al tocar el suelo hace volcar', () => {
    const base = newLander(T);
    const s: LanderState = { ...base, p: [0, heightAt(T, 0, 0), 0], v: [0, -0.8, 0], pitch: 20, roll: 0 };
    const td = evaluate(T, s);
    expect(td.success).toBe(false);
    expect(td.outcome).toBe('tipped');
    expect(landingAdvice(td).join(' ')).toContain('Nivelar');
  });

  it('la altitud es sobre el suelo (radar), no sobre un nivel fijo', () => {
    const s = newLander(T);
    expect(altitude(T, s)).toBeCloseTo(1200, 0);
  });
});

/** Conductor con los mismos mandos del jugador (adelante/atrás, girar, acción). */
function roverDriver() {
  let backT = 0;
  let turnDir = 1;
  return (s: RoverState, lander: { x: number; z: number }): RoverInput => {
    const r = roverReadout(T, s, lander);
    if (s.quizPending) return NO_ROVER_INPUT;
    if (r.inTarget && r.mission && r.mission.holdS > 0) return { drive: 0, turn: 0, action: true };
    if (backT > 0) {
      backT -= 0.1;
      return { drive: backT > 1.2 ? -1 : 1, turn: backT > 1.2 ? 0 : turnDir, action: false };
    }
    if (s.warn === 'rock' || s.warn === 'steep') {
      backT = 2.5;
      turnDir = -turnDir;
      return { drive: -1, turn: 0, action: false };
    }
    const b = r.bearingDeg;
    const turn = Math.abs(b) > 4 ? Math.sign(b) : 0;
    const drive = Math.abs(b) > 50 ? 0 : 1;
    return { drive, turn, action: false };
  };
}

describe('Rover lunar', () => {
  const lander = { x: 0, z: 0 };
  it('avanza, gira, gasta energía al moverse y la recupera parado al sol', () => {
    let s = newRover(0, 0);
    const e0 = s.energy;
    for (let i = 0; i < 100; i++) s = stepRover(T, s, { drive: 1, turn: 0, action: false }, 0.1, lander);
    expect(s.distanceM).toBeGreaterThan(15);
    expect(s.energy).toBeLessThan(e0);
    const h0 = s.heading;
    for (let i = 0; i < 10; i++) s = stepRover(T, s, { drive: 0, turn: 1, action: false }, 0.1, lander);
    expect(s.heading - h0).toBeCloseTo((ROVER.turnDegS * Math.PI) / 180, 1);
    for (let i = 0; i < 20; i++) s = stepRover(T, s, NO_ROVER_INPUT, 0.1, lander);
    const e1 = s.energy;
    for (let i = 0; i < 100; i++) s = stepRover(T, s, NO_ROVER_INPUT, 0.1, lander);
    expect(s.energy).toBeGreaterThan(e1);
  });

  it('las rocas grandes son obstáculos', () => {
    const k = T.sites.rock;
    let s: RoverState = { ...newRover(0, 0), x: k.x - 12, z: k.z, heading: 0 };
    for (let i = 0; i < 200; i++) s = stepRover(T, s, { drive: 1, turn: 0, action: false }, 0.1, lander);
    expect(Math.hypot(s.x - k.x, s.z - k.z)).toBeGreaterThanOrEqual(k.r + ROVER.radiusM - 0.01);
    expect(s.warn === 'rock' || s.bumps > 0).toBe(true);
  });

  it('las 6 misiones se completan conduciendo con los mandos del jugador', () => {
    let s = newRover(0, 0);
    const drive = roverDriver();
    for (let i = 0; i < 20000 && !s.finished; i++) {
      if (s.quizPending) s = answerInvestigation(s, INVESTIGATION.correct);
      s = stepRover(T, s, drive(s, lander), 0.1, lander);
    }
    expect(s.finished).toBe(true);
    expect(s.mission).toBe(ROVER_MISSIONS.length);
    expect(s.points).toBe(ROVER_MISSIONS.reduce((a, m) => a + m.points, 0) + INVESTIGATION.bonus);
    expect(exploredPct(s, lander)).toBeGreaterThan(3);
  });
});
