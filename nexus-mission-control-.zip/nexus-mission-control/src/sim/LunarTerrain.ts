/**
 * Terreno lunar del minijuego de aterrizaje (8.8) y del rover (8.9).
 * Procedural y reproducible (misma semilla → mismo terreno). Metros; x = este, z = sur, y = arriba
 * (los mismos ejes que la escena 3D).
 *  - Relieve suave de colinas (ruido de valores en varias escalas).
 *  - Cráteres con cuenco y borde levantado (perfil típico de los cráteres simples).
 *  - Rocas sueltas (más alrededor de los cráteres, como los materiales expulsados por el impacto).
 *  - Una zona segura llana y sin rocas, señalada para aterrizar.
 */

export const TERRAIN = {
  /** Lado del terreno (m). */
  size: 2400,
  /** Zona segura: centro y radio (m). */
  safe: { x: 0, z: 0, r: 45 },
  /** Límite de pendiente para apoyarse con seguridad (°). */
  maxSlopeDeg: 8,
};

export interface Crater {
  x: number;
  z: number;
  r: number;
  depth: number;
}
export interface Rock {
  x: number;
  z: number;
  r: number;
}

function hash2(ix: number, iz: number, seed: number) {
  let h = (Math.imul(ix, 374761393) + Math.imul(iz, 668265263) + Math.imul(seed, 2147483647)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}

function noise(x: number, z: number, scale: number, seed: number) {
  const gx = x / scale;
  const gz = z / scale;
  const ix = Math.floor(gx);
  const iz = Math.floor(gz);
  const fx = gx - ix;
  const fz = gz - iz;
  const sx = fx * fx * (3 - 2 * fx);
  const sz = fz * fz * (3 - 2 * fz);
  const a = hash2(ix, iz, seed);
  const b = hash2(ix + 1, iz, seed);
  const c = hash2(ix, iz + 1, seed);
  const d = hash2(ix + 1, iz + 1, seed);
  return (a + (b - a) * sx + (c - a) * sz + (a - b - c + d) * sx * sz) * 2 - 1;
}

export function mulberry(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export interface RoverSites {
  /** Roca grande que hay que localizar (misión 1). */
  rock: Rock;
  /** Cráter que hay que explorar (misión 2). */
  crater: Crater;
  /** Punto del fondo del cráter donde se recoge la muestra (misión 3). */
  sample: { x: number; z: number };
  /** Cima de la colina: punto de observación (misiones 4 y 5). */
  hill: { x: number; z: number; r: number; h: number };
}

export interface Terrain {
  seed: number;
  craters: Crater[];
  rocks: Rock[];
  sites: RoverSites;
  /** Altura del centro de la zona segura. */
  safeH: number;
}

const SITES: RoverSites = {
  rock: { x: 95, z: 140, r: 2.6 },
  crater: { x: -190, z: 170, r: 70, depth: 7 },
  sample: { x: -195, z: 178 },
  hill: { x: 140, z: -160, r: 80, h: 15 },
};

function craterProfile(d: number, c: Crater) {
  const u = d / c.r;
  if (u > 2.2) return 0;
  // Cuenco parabólico dentro, borde levantado alrededor (≈ 4 % del diámetro de altura).
  const bowl = u < 1 ? -c.depth * (1 - u * u) : 0;
  const rim = c.depth * 0.42 * Math.exp(-(((u - 1) / 0.28) ** 2));
  return bowl + rim;
}

/** Terreno reproducible. */
export function makeTerrain(seed = 7): Terrain {
  const r = mulberry(seed);
  const craters: Crater[] = [SITES.crater];
  const half = TERRAIN.size / 2;
  const avoid = (x: number, z: number, rad: number) =>
    Math.hypot(x - TERRAIN.safe.x, z - TERRAIN.safe.z) < rad + TERRAIN.safe.r * 1.6 ||
    Math.hypot(x - SITES.hill.x, z - SITES.hill.z) < rad + SITES.hill.r ||
    Math.hypot(x - SITES.rock.x, z - SITES.rock.z) < rad + 20 ||
    craters.some((c) => Math.hypot(x - c.x, z - c.z) < (rad + c.r) * 1.05);
  // Pocos cráteres grandes y muchos pequeños (como en la Luna real).
  for (let k = 0; k < 400 && craters.length < 46; k++) {
    const big = craters.length < 8;
    const rad = big ? 50 + r() * 90 : 6 + r() ** 2 * 40;
    const x = (r() * 2 - 1) * (half - rad);
    const z = (r() * 2 - 1) * (half - rad);
    if (avoid(x, z, rad)) continue;
    craters.push({ x, z, r: rad, depth: rad * (0.16 + r() * 0.06) });
  }
  const rocks: Rock[] = [SITES.rock];
  const freeOfRocks = (x: number, z: number) =>
    Math.hypot(x - TERRAIN.safe.x, z - TERRAIN.safe.z) > TERRAIN.safe.r + 6 && Math.hypot(x - SITES.sample.x, z - SITES.sample.z) > 10 && Math.hypot(x - SITES.rock.x, z - SITES.rock.z) > 10;
  for (const c of craters) {
    const n = Math.round(c.r / 6);
    for (let i = 0; i < n; i++) {
      const a = r() * Math.PI * 2;
      const d = c.r * (0.9 + r() * 0.9);
      const x = c.x + Math.cos(a) * d;
      const z = c.z + Math.sin(a) * d;
      if (Math.abs(x) < half - 5 && Math.abs(z) < half - 5 && freeOfRocks(x, z)) rocks.push({ x, z, r: 0.3 + r() ** 2 * 1.6 });
    }
  }
  for (let i = 0; i < 260; i++) {
    const x = (r() * 2 - 1) * (half - 5);
    const z = (r() * 2 - 1) * (half - 5);
    if (freeOfRocks(x, z)) rocks.push({ x, z, r: 0.2 + r() ** 3 * 1.4 });
  }
  const t: Terrain = { seed, craters, rocks, sites: SITES, safeH: 0 };
  t.safeH = rawHeight(t, TERRAIN.safe.x, TERRAIN.safe.z);
  return t;
}

function rawHeight(t: Terrain, x: number, z: number) {
  let h = noise(x, z, 260, t.seed) * 7 + noise(x, z, 70, t.seed + 1) * 1.8 + noise(x, z, 18, t.seed + 2) * 0.35;
  const hl = t.sites.hill;
  h += hl.h * Math.exp(-((Math.hypot(x - hl.x, z - hl.z) / hl.r) ** 2) * 1.6);
  for (const c of t.craters) {
    const dx = x - c.x;
    const dz = z - c.z;
    if (Math.abs(dx) > c.r * 2.2 || Math.abs(dz) > c.r * 2.2) continue;
    h += craterProfile(Math.hypot(dx, dz), c);
  }
  return h;
}

/** Altura del suelo (m) en (x, z). La zona segura está allanada. */
export function heightAt(t: Terrain, x: number, z: number) {
  const h = rawHeight(t, x, z);
  const d = Math.hypot(x - TERRAIN.safe.x, z - TERRAIN.safe.z);
  const R = TERRAIN.safe.r;
  if (d >= R * 1.8) return h;
  const u = Math.max(0, Math.min(1, (R * 1.8 - d) / (R * 0.8)));
  const w = u * u * (3 - 2 * u);
  return h + (t.safeH - h) * w;
}

/** Pendiente del suelo (°) y dirección de bajada. */
export function slopeAt(t: Terrain, x: number, z: number) {
  const e = 1.5;
  const gx = (heightAt(t, x + e, z) - heightAt(t, x - e, z)) / (2 * e);
  const gz = (heightAt(t, x, z + e) - heightAt(t, x, z - e)) / (2 * e);
  return { deg: (Math.atan(Math.hypot(gx, gz)) * 180) / Math.PI, gx, gz };
}

/** Normal del suelo (unitaria). */
export function normalAt(t: Terrain, x: number, z: number): [number, number, number] {
  const { gx, gz } = slopeAt(t, x, z);
  const l = Math.hypot(gx, 1, gz);
  return [-gx / l, 1 / l, -gz / l];
}

/** Roca más cercana que toca un círculo de radio `rad` alrededor de (x, z), si la hay. */
export function rockNear(t: Terrain, x: number, z: number, rad: number, minR = 0): Rock | null {
  let best: Rock | null = null;
  let bd = Infinity;
  for (const k of t.rocks) {
    if (k.r < minR) continue;
    const d = Math.hypot(k.x - x, k.z - z) - k.r;
    if (d < rad && d < bd) {
      bd = d;
      best = k;
    }
  }
  return best;
}

export function inSafeZone(x: number, z: number) {
  return Math.hypot(x - TERRAIN.safe.x, z - TERRAIN.safe.z) <= TERRAIN.safe.r;
}

/** ¿Hay cráter en este punto? (para explicar por qué un sitio no es bueno). */
export function craterAt(t: Terrain, x: number, z: number): Crater | null {
  return t.craters.find((c) => Math.hypot(x - c.x, z - c.z) < c.r * 1.15) ?? null;
}

let cached: Terrain | null = null;
export function getTerrain(): Terrain {
  if (!cached) cached = makeTerrain(7);
  return cached;
}
