import { describe, expect, it } from 'vitest';
import { getComponent } from '../data/components/catalog';
import { LUNA_01 } from '../data/missions/missions';
import { budgetSummary, designCostMUSD } from './BudgetSystem';
import { autonomyHours, energyWh, mbpsToGbitPerHour, round } from './units';

describe('unidades', () => {
  it('1 Mbps equivale a 3,6 Gbit/h', () => {
    expect(mbpsToGbitPerHour(1)).toBeCloseTo(3.6, 10);
    expect(mbpsToGbitPerHour(40)).toBeCloseTo(144, 10);
  });

  it('energía = potencia × tiempo', () => {
    expect(energyWh(150, 2)).toBe(300);
  });

  it('autonomía = capacidad ÷ consumo', () => {
    expect(autonomyHours(400, 100)).toBe(4);
    expect(autonomyHours(400, 0)).toBe(Number.POSITIVE_INFINITY);
  });

  it('round no inventa decimales', () => {
    expect(round(1.26, 1)).toBe(1.3);
    expect(round(1.24, 1)).toBe(1.2);
  });
});

describe('BudgetSystem', () => {
  const empty = { chassisId: null, parts: [] };

  it('un diseño vacío cuesta 0', () => {
    expect(designCostMUSD(empty, getComponent)).toBe(0);
  });

  it('suma chasis y piezas', () => {
    const design = {
      chassisId: 'chassis-m',
      parts: [
        { instanceId: 'a', componentId: 'camera', socketId: 'bottom-0' },
        { instanceId: 'b', componentId: 'obc', socketId: 'bay-0' },
      ],
    };
    expect(designCostMUSD(design, getComponent)).toBeCloseTo(11 + 6 + 2.5, 10);
  });

  it('rechaza componentes desconocidos', () => {
    const bad = { chassisId: 'no-existe', parts: [] };
    expect(() => designCostMUSD(bad, getComponent)).toThrow();
  });

  it('lanzamiento y operación quedan pendientes (null) y no suman', () => {
    const s = budgetSummary(LUNA_01, empty, getComponent);
    expect(s.capMUSD).toBe(140);
    expect(s.committedMUSD).toBe(0);
    expect(s.remainingMUSD).toBe(140);
    expect(s.lines.find((l) => l.id === 'launch')!.amountMUSD).toBe(null);
    expect(s.overBudget).toBe(false);
  });

  it('detecta presupuesto excedido', () => {
    const s = budgetSummary(LUNA_01, { chassisId: 'chassis-l', parts: [] }, getComponent, 130);
    expect(s.committedMUSD).toBe(148);
    expect(s.overBudget).toBe(true);
    expect(s.remainingMUSD).toBe(-8);
  });
});
