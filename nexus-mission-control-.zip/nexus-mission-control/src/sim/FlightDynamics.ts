/**
 * FlightDynamics — trayectoria física del vuelo Tierra → Luna (Fase 8.1).
 *
 * A diferencia del perfil suavizado de LaunchSystem, aquí la trayectoria se INTEGRA numéricamente
 * (Runge-Kutta de 4.º orden) con las leyes de Newton y constantes reales:
 *  - gravedad terrestre (μ = 398 600,4 km³/s²) y lunar (μ = 4 902,8 km³/s²), radios medios reales;
 *  - rotación de la Tierra (día sideral), que regala ~0,46 km/s al lanzar hacia el este;
 *  - atmósfera exponencial (ρ₀ = 1,225 kg/m³, altura de escala 8,5 km) con arrastre;
 *  - Luna en órbita circular de 384 400 km y 27,32 días;
 *  - «cónicas enlazadas»: fuera de la esfera de influencia lunar (66 100 km) solo atrae la Tierra;
 *    dentro, solo la Luna (método estándar de diseño de misiones lunares).
 *
 * Simplificaciones (valores de JUEGO, no datos del vehículo):
 *  - Todo el vuelo ocurre en un plano: lanzamiento desde el ecuador y Luna en ese mismo plano.
 *  - El catálogo no tiene empuje ni masas de cada etapa, así que el empuje se obtiene por guiado:
 *    la primera etapa sigue un giro por gravedad con una relación de masas típica (3,4) y se ajusta
 *    para llegar a una velocidad y altitud de apagado razonables; la segunda etapa usa un guiado en
 *    lazo cerrado que llega a la órbita de aparcamiento de 200 km en el tiempo de la cronología.
 *  - La inyección translunar (TLI) es un encendido hacia delante cuya intensidad se calcula para que
 *    la nave pase por el periapsis lunar (a la altitud del plan) justo al terminar el crucero.
 * Los tiempos de los eventos son los de LaunchSystem (datos de cada lanzador).
 */
import type { Launcher } from '../data/schemas';
import { CRUISE_HOURS, launchTimeline, type LaunchTimeline } from './LaunchSystem';

// ───────────────────────── Constantes físicas reales ─────────────────────────
export const MU_EARTH = 398600.4418; // km³/s²
export const R_EARTH = 6371.0; // km (radio medio)
export const MU_MOON = 4902.8001; // km³/s²
export const R_MOON = 1737.4; // km
export const EARTH_MOON_KM = 384400; // distancia media
export const MOON_PERIOD_S = 27.321661 * 86400; // periodo sideral
export const EARTH_SIDEREAL_S = 86164.0905;
export const MOON_SOI_KM = 66100; // esfera de influencia (Laplace)
export const G0 = 9.80665e-3; // km/s²
export const OMEGA_EARTH = (2 * Math.PI) / EARTH_SIDEREAL_S;
export const N_MOON = (2 * Math.PI) / MOON_PERIOD_S;
const RHO0 = 1.225; // kg/m³
const H_SCALE = 8.5; // km

/** Parámetros de juego (no son datos de los vehículos). */
export const FLIGHT_GAME = {
  /** Coeficiente balístico m/(Cd·A) en kg/m² para el arrastre. */
  ballisticKgM2: 40000,
  stage1MassRatio: 3.4,
  parkingAltitudeKm: 200,
  /** Ascenso vertical hasta superar la torre; después empieza el programa de cabeceo. */
  pitchStartS: 10,
  /** Ángulo del lanzamiento: la plataforma empieza en +Y del plano. */
  padAngle0: Math.PI / 2,
};

export type FlightPhase = 'pad' | 'stage1' | 'coast' | 'stage2' | 'parking' | 'tli' | 'cruise' | 'approach';

export interface FlightSample {
  t: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  /** Dirección del eje del cohete (rad, en el plano). */
  att: number;
  /** Aceleración de empuje (km/s²). */
  thrust: number;
}

export interface FlightProfile {
  tl: LaunchTimeline;
  samples: FlightSample[];
  padRadiusKm: number;
  /** Ángulo de la Luna en t = 0 (lo elige el diseño de la trayectoria, como una ventana de lanzamiento). */
  moonPhase0: number;
  tSoi: number;
  tPeri: number;
  meco: { altitudeKm: number; groundSpeedKmS: number; liftoffTW: number; kickDeg: number };
  seco: { altitudeKm: number; speedKmS: number; eccentricity: number };
  tli: { deltaVKmS: number; endSpeedKmS: number; accelG: number };
  arrival: { vInfKmS: number; periapsisAltKm: number; periapsisSpeedKmS: number };
}

type State = [number, number, number, number];
type AccFn = (t: number, s: State) => [number, number];

function rk4(t: number, s: State, dt: number, acc: AccFn): State {
  const d = (tt: number, ss: State): State => {
    const [ax, ay] = acc(tt, ss);
    return [ss[2], ss[3], ax, ay];
  };
  const k1 = d(t, s);
  const s2: State = [s[0] + (k1[0] * dt) / 2, s[1] + (k1[1] * dt) / 2, s[2] + (k1[2] * dt) / 2, s[3] + (k1[3] * dt) / 2];
  const k2 = d(t + dt / 2, s2);
  const s3: State = [s[0] + (k2[0] * dt) / 2, s[1] + (k2[1] * dt) / 2, s[2] + (k2[2] * dt) / 2, s[3] + (k2[3] * dt) / 2];
  const k3 = d(t + dt / 2, s3);
  const s4: State = [s[0] + k3[0] * dt, s[1] + k3[1] * dt, s[2] + k3[2] * dt, s[3] + k3[3] * dt];
  const k4 = d(t + dt, s4);
  return [
    s[0] + ((k1[0] + 2 * k2[0] + 2 * k3[0] + k4[0]) * dt) / 6,
    s[1] + ((k1[1] + 2 * k2[1] + 2 * k3[1] + k4[1]) * dt) / 6,
    s[2] + ((k1[2] + 2 * k2[2] + 2 * k3[2] + k4[2]) * dt) / 6,
    s[3] + ((k1[3] + 2 * k2[3] + 2 * k3[3] + k4[3]) * dt) / 6,
  ];
}

const hyp = Math.hypot;

function earthGravity(x: number, y: number): [number, number] {
  const r = hyp(x, y);
  const k = -MU_EARTH / (r * r * r);
  return [k * x, k * y];
}

/** Velocidad respecto de la atmósfera (que gira con la Tierra). */
function airVelocity(s: State): [number, number] {
  return [s[2] + OMEGA_EARTH * s[1], s[3] - OMEGA_EARTH * s[0]];
}

function drag(s: State): [number, number] {
  const h = hyp(s[0], s[1]) - R_EARTH;
  if (h > 150) return [0, 0];
  const [ux, uy] = airVelocity(s);
  const u = hyp(ux, uy);
  if (u < 1e-9) return [0, 0];
  const rho = RHO0 * Math.exp(-Math.max(0, h) / H_SCALE);
  const a = (0.5 * rho * (u * 1000) ** 2) / FLIGHT_GAME.ballisticKgM2 / 1000; // km/s²
  return [(-a * ux) / u, (-a * uy) / u];
}

/** Bases locales: radial (arriba) y este (sentido de giro). */
function basis(x: number, y: number) {
  const r = hyp(x, y);
  const rx = x / r;
  const ry = y / r;
  return { r, rx, ry, ex: -ry, ey: rx };
}

export function moonPosition(phase0: number, t: number): [number, number] {
  const a = phase0 + N_MOON * t;
  return [EARTH_MOON_KM * Math.cos(a), EARTH_MOON_KM * Math.sin(a)];
}
export function moonVelocity(phase0: number, t: number): [number, number] {
  const a = phase0 + N_MOON * t;
  const v = EARTH_MOON_KM * N_MOON;
  return [-v * Math.sin(a), v * Math.cos(a)];
}

function padState(padRadiusKm: number, t: number): State {
  const a = FLIGHT_GAME.padAngle0 + OMEGA_EARTH * t;
  const x = padRadiusKm * Math.cos(a);
  const y = padRadiusKm * Math.sin(a);
  return [x, y, -OMEGA_EARTH * y, OMEGA_EARTH * x];
}

// ───────────────────────── Primera etapa: giro por gravedad ─────────────────────────

interface Stage1Result {
  state: State;
  samples: FlightSample[];
}

function stage1(A1: number, kick: number, tb: number, padR: number, record: boolean, dt = 0.5): Stage1Result {
  const tau = tb / (1 - 1 / FLIGHT_GAME.stage1MassRatio);
  const { pitchStartS } = FLIGHT_GAME;
  // Programa de cabeceo: vertical hasta superar la torre y luego inclinación progresiva hacia el este.
  const dirAt = (t: number, s: State): [number, number] => {
    const b = basis(s[0], s[1]);
    const x = t <= pitchStartS ? 0 : Math.min(1, (t - pitchStartS) / (tb - pitchStartS));
    const ang = kick * Math.pow(x, 0.7);
    return [Math.cos(ang) * b.rx + Math.sin(ang) * b.ex, Math.cos(ang) * b.ry + Math.sin(ang) * b.ey];
  };
  const thrustAt = (t: number) => A1 / (1 - t / tau);
  const acc: AccFn = (t, s) => {
    const [gx, gy] = earthGravity(s[0], s[1]);
    const [dx, dy] = drag(s);
    const [ux, uy] = dirAt(t, s);
    const a = thrustAt(t);
    return [gx + dx + a * ux, gy + dy + a * uy];
  };
  let s = padState(padR, 0);
  const samples: FlightSample[] = [];
  let t = 0;
  const push = () => {
    const [ux, uy] = dirAt(t, s);
    samples.push({ t, x: s[0], y: s[1], vx: s[2], vy: s[3], att: Math.atan2(uy, ux), thrust: thrustAt(t) });
  };
  if (record) push();
  while (t < tb - 1e-9) {
    const h = Math.min(dt, tb - t);
    s = rk4(t, s, h, acc);
    t += h;
    if (record) push();
  }
  return { state: s, samples };
}

function groundSpeed(s: State) {
  const [ux, uy] = airVelocity(s);
  return hyp(ux, uy);
}

function bisect(f: (x: number) => number, lo: number, hi: number, iters: number): number {
  let flo = f(lo);
  for (let i = 0; i < iters; i++) {
    const mid = (lo + hi) / 2;
    const fm = f(mid);
    if (Math.sign(fm) === Math.sign(flo)) {
      lo = mid;
      flo = fm;
    } else hi = mid;
  }
  return (lo + hi) / 2;
}

/** Objetivos de apagado de la primera etapa (juego): proporcionales al reparto del tiempo de empuje. */
export function stage1Targets(tl: LaunchTimeline, launcher: Launcher) {
  const burn2 = launcher.stages[1].burnTimeS * 0.55;
  const f = tl.mecoS / (tl.mecoS + burn2);
  const v = Math.max(1.8, Math.min(5, 7.8 * f * 0.75));
  const h = Math.max(60, Math.min(120, 25 * v + 15));
  return { groundSpeedKmS: v, altitudeKm: h };
}

// ───────────────────────── Segunda etapa: guiado en lazo cerrado ─────────────────────────

function stage2Guidance(t: number, s: State, tSeco: number): [number, number] {
  const b = basis(s[0], s[1]);
  const rT = R_EARTH + FLIGHT_GAME.parkingAltitudeKm;
  const vc = Math.sqrt(MU_EARTH / rT);
  const vr = s[2] * b.rx + s[3] * b.ry;
  const vt = s[2] * b.ex + s[3] * b.ey;
  const T = Math.max(tSeco - t, 1);
  const dh = rT - b.r;
  // Polinomio cúbico de altura que llega a (h objetivo, velocidad vertical 0) en el tiempo restante.
  const ar = (6 * dh - 4 * vr * T) / (T * T) + MU_EARTH / (b.r * b.r) - (vt * vt) / b.r;
  const at = (vc - vt) / T + (vr * vt) / b.r;
  return [ar * b.rx + at * b.ex, ar * b.ry + at * b.ey];
}

// ───────────────────────── Construcción del perfil ─────────────────────────

function coastAcc(): AccFn {
  return (_t, s) => earthGravity(s[0], s[1]);
}

function propagate(
  s0: State,
  t0: number,
  t1: number,
  dtMax: number,
  acc: AccFn,
  out: FlightSample[] | null,
  attFn: (t: number, s: State) => number,
  thrustFn: (t: number) => number,
): State {
  let s = s0;
  let t = t0;
  while (t < t1 - 1e-9) {
    const h = Math.min(dtMax, t1 - t);
    s = rk4(t, s, h, acc);
    t += h;
    if (out) out.push({ t, x: s[0], y: s[1], vx: s[2], vy: s[3], att: attFn(t, s), thrust: thrustFn(t) });
  }
  return s;
}

const prograde = (_t: number, s: State) => Math.atan2(s[3], s[2]);

/** Paso adaptativo: una fracción fija del tiempo orbital local. */
function adaptiveDt(r: number, mu: number, frac: number, min: number, max: number) {
  return Math.max(min, Math.min(max, frac * Math.sqrt((r * r * r) / mu)));
}

interface EarthLeg {
  samples: FlightSample[];
  /** Primera muestra cerca de la órbita lunar (caché). */
  farIndex?: number;
}

function earthLeg(s0: State, t0: number, tMax: number, stopAtKm = EARTH_MOON_KM * 1.35): EarthLeg {
  const samples: FlightSample[] = [{ t: t0, x: s0[0], y: s0[1], vx: s0[2], vy: s0[3], att: prograde(t0, s0), thrust: 0 }];
  let s = s0;
  let t = t0;
  const acc = coastAcc();
  while (t < tMax) {
    const r = hyp(s[0], s[1]);
    if (r > stopAtKm) break;
    const h = Math.min(adaptiveDt(r, MU_EARTH, 0.006, 1, 300), tMax - t);
    s = rk4(t, s, h, acc);
    t += h;
    samples.push({ t, x: s[0], y: s[1], vx: s[2], vy: s[3], att: prograde(t, s), thrust: 0 });
  }
  return { samples };
}

/** Interpolación de Hermite cúbica entre dos muestras (posición y velocidad). */
function hermite(a: FlightSample, b: FlightSample, t: number): State {
  const h = b.t - a.t;
  if (h <= 0) return [a.x, a.y, a.vx, a.vy];
  const u = (t - a.t) / h;
  const u2 = u * u;
  const u3 = u2 * u;
  const h00 = 2 * u3 - 3 * u2 + 1;
  const h10 = u3 - 2 * u2 + u;
  const h01 = -2 * u3 + 3 * u2;
  const h11 = u3 - u2;
  const d00 = 6 * u2 - 6 * u;
  const d10 = 3 * u2 - 4 * u + 1;
  const d01 = -6 * u2 + 6 * u;
  const d11 = 3 * u2 - 2 * u;
  return [
    h00 * a.x + h10 * h * a.vx + h01 * b.x + h11 * h * b.vx,
    h00 * a.y + h10 * h * a.vy + h01 * b.y + h11 * h * b.vy,
    (d00 * a.x + d10 * h * a.vx + d01 * b.x + d11 * h * b.vx) / h,
    (d00 * a.y + d10 * h * a.vy + d01 * b.y + d11 * h * b.vy) / h,
  ];
}

function firstSoiEntry(leg: EarthLeg, phase0: number): { t: number; s: State } | null {
  const S = leg.samples;
  let prev = Infinity;
  // La esfera de influencia empieza a 384 400 − 66 100 km: antes no hace falta mirar.
  let start = leg.farIndex ?? 0;
  if (leg.farIndex === undefined) {
    start = S.findIndex((p) => hyp(p.x, p.y) > EARTH_MOON_KM - MOON_SOI_KM - 5000);
    leg.farIndex = start < 0 ? S.length : start;
    start = leg.farIndex;
  }
  for (let i = Math.max(1, start); i < S.length; i++) {
    const [mx, my] = moonPosition(phase0, S[i].t);
    const d = hyp(S[i].x - mx, S[i].y - my);
    if (d < MOON_SOI_KM && prev >= MOON_SOI_KM && i > 0) {
      // Refinamiento por bisección del cruce de la esfera de influencia.
      let lo = S[i - 1].t;
      let hi = S[i].t;
      for (let k = 0; k < 40; k++) {
        const mid = (lo + hi) / 2;
        const st = hermite(S[i - 1], S[i], mid);
        const [qx, qy] = moonPosition(phase0, mid);
        if (hyp(st[0] - qx, st[1] - qy) < MOON_SOI_KM) hi = mid;
        else lo = mid;
      }
      return { t: hi, s: hermite(S[i - 1], S[i], hi) };
    }
    prev = d;
  }
  return null;
}

function relToMoon(phase0: number, t: number, s: State): State {
  const [mx, my] = moonPosition(phase0, t);
  const [mvx, mvy] = moonVelocity(phase0, t);
  return [s[0] - mx, s[1] - my, s[2] - mvx, s[3] - mvy];
}

/** Hipérbola lunar (dos cuerpos) desde un estado relativo: parámetro de impacto con signo y periapsis. */
function moonConic(rel: State) {
  const r = hyp(rel[0], rel[1]);
  const v2 = rel[2] ** 2 + rel[3] ** 2;
  const energy = v2 / 2 - MU_MOON / r;
  const h = rel[0] * rel[3] - rel[1] * rel[2];
  const vInf = energy > 0 ? Math.sqrt(2 * energy) : 0;
  const e = Math.sqrt(Math.max(0, 1 + (2 * energy * h * h) / (MU_MOON * MU_MOON)));
  const rp = (h * h) / (MU_MOON * (1 + e));
  return { vInf, h, rp, b: vInf > 0 ? h / vInf : NaN };
}

function impactTarget(rp: number, vInf: number) {
  return rp * Math.sqrt(1 + (2 * MU_MOON) / (rp * vInf * vInf));
}

/** Fase lunar que hace pasar la nave por el periapsis deseado (lado prógrado). */
function solveMoonPhase(leg: EarthLeg, rpTarget: number): number | null {
  const S = leg.samples;
  const iD = S.findIndex((p) => hyp(p.x, p.y) >= EARTH_MOON_KM);
  if (iD < 0) return null;
  const center = Math.atan2(S[iD].y, S[iD].x) - N_MOON * S[iD].t;
  const g = (ph: number) => {
    const e = firstSoiEntry(leg, ph);
    if (!e) return NaN;
    const c = moonConic(relToMoon(ph, e.t, e.s));
    return c.b - impactTarget(rpTarget, c.vInf);
  };
  // Barrido para encontrar el cambio de signo y bisección.
  const span = 0.35;
  const step = 0.01;
  let prevPh = NaN;
  let prevG = NaN;
  let best: number | null = null;
  for (let ph = center - span; ph <= center + span; ph += step) {
    const v = g(ph);
    if (Number.isFinite(v) && Number.isFinite(prevG) && Math.sign(v) !== Math.sign(prevG)) {
      const root = bisect(g, prevPh, ph, 40);
      if (best === null || Math.abs(root - center) < Math.abs(best - center)) best = root;
    }
    prevPh = ph;
    prevG = v;
  }
  return best;
}

function moonLeg(phase0: number, t0: number, s0Earth: State, out: FlightSample[] | null): { tPeri: number; rel: State; impact: boolean } {
  let rel = relToMoon(phase0, t0, s0Earth);
  let t = t0;
  const acc: AccFn = (_t, s) => {
    const r = hyp(s[0], s[1]);
    const k = -MU_MOON / (r * r * r);
    return [k * s[0], k * s[1]];
  };
  const toEarth = (tt: number, s: State): FlightSample => {
    const [mx, my] = moonPosition(phase0, tt);
    const [mvx, mvy] = moonVelocity(phase0, tt);
    const vx = s[2] + mvx;
    const vy = s[3] + mvy;
    return { t: tt, x: s[0] + mx, y: s[1] + my, vx, vy, att: Math.atan2(s[3], s[2]), thrust: 0 };
  };
  for (let guard = 0; guard < 200000; guard++) {
    const r = hyp(rel[0], rel[1]);
    if (r < R_MOON) return { tPeri: t, rel, impact: true };
    const rdot = rel[0] * rel[2] + rel[1] * rel[3];
    const h = adaptiveDt(r, MU_MOON, 0.004, 0.25, 120);
    const next = rk4(t, rel, h, acc);
    const rdotN = next[0] * next[2] + next[1] * next[3];
    if (rdot < 0 && rdotN >= 0) {
      // Periapsis dentro de este paso: se ubica por bisección.
      let lo = 0;
      let hi = h;
      for (let k = 0; k < 40; k++) {
        const m = (lo + hi) / 2;
        const sm = rk4(t, rel, m, acc);
        if (sm[0] * sm[2] + sm[1] * sm[3] < 0) lo = m;
        else hi = m;
      }
      const sp = rk4(t, rel, hi, acc);
      if (out) out.push(toEarth(t + hi, sp));
      return { tPeri: t + hi, rel: sp, impact: false };
    }
    rel = next;
    t += h;
    if (out) out.push(toEarth(t, rel));
  }
  return { tPeri: t, rel, impact: false };
}

/**
 * Construye la trayectoria completa del lanzador elegido hasta el periapsis lunar.
 * `lunarAltitudeKm`: altitud de la órbita lunar del plan (periapsis de llegada).
 */
export function buildFlightProfile(launcher: Launcher, lunarAltitudeKm: number, padHeightKm = 0.005): FlightProfile {
  const tl = launchTimeline(launcher);
  const padR = R_EARTH + padHeightKm;
  const tb1 = tl.mecoS;
  const target1 = stage1Targets(tl, launcher);

  // 1) Primera etapa: empuje inicial (rapidez) y ángulo de cabeceo (altitud) por bisección anidada.
  const solveA1 = (kick: number) =>
    bisect((A1) => groundSpeed(stage1(A1, kick, tb1, padR, false, 1).state) - target1.groundSpeedKmS, 1.15 * G0, 12 * G0, 22);
  // «kick» = inclinación desde la vertical al apagar la primera etapa.
  const kickRad = bisect(
    (kick) => {
      const st = stage1(solveA1(kick), kick, tb1, padR, false, 1).state;
      return hyp(st[0], st[1]) - R_EARTH - target1.altitudeKm;
    },
    (20 * Math.PI) / 180,
    (88 * Math.PI) / 180,
    20,
  );
  const A1 = solveA1(kickRad);
  const s1 = stage1(A1, kickRad, tb1, padR, true);
  const samples = s1.samples;
  let s = s1.state;
  const meco = { altitudeKm: hyp(s[0], s[1]) - R_EARTH, groundSpeedKmS: groundSpeed(s), liftoffTW: A1 / G0, kickDeg: (kickRad * 180) / Math.PI };

  // 2) Vuelo balístico entre etapas.
  const ses = tl.mecoS + 10;
  const ballistic: AccFn = (_t, st) => {
    const [gx, gy] = earthGravity(st[0], st[1]);
    const [dx, dy] = drag(st);
    return [gx + dx, gy + dy];
  };
  s = propagate(s, tl.mecoS, ses, 0.5, ballistic, samples, prograde, () => 0);

  // 3) Segunda etapa guiada hasta la órbita de aparcamiento.
  const stage2Acc: AccFn = (t, st) => {
    const [gx, gy] = earthGravity(st[0], st[1]);
    const [dx, dy] = drag(st);
    const [tx, ty] = stage2Guidance(t, st, tl.secoS);
    return [gx + dx + tx, gy + dy + ty];
  };
  s = propagate(
    s,
    ses,
    tl.secoS,
    0.5,
    stage2Acc,
    samples,
    (t, st) => {
      const [tx, ty] = stage2Guidance(t, st, tl.secoS);
      return Math.atan2(ty, tx);
    },
    () => 0,
  );
  // Magnitud del empuje de la 2.ª etapa (para la telemetría).
  for (const p of samples) if (p.t > ses && p.t <= tl.secoS) {
    const [tx, ty] = stage2Guidance(p.t, [p.x, p.y, p.vx, p.vy], tl.secoS);
    p.thrust = hyp(tx, ty);
  }
  const rS = hyp(s[0], s[1]);
  const vS = hyp(s[2], s[3]);
  const energyS = (vS * vS) / 2 - MU_EARTH / rS;
  const hS = s[0] * s[3] - s[1] * s[2];
  const seco = { altitudeKm: rS - R_EARTH, speedKmS: vS, eccentricity: Math.sqrt(Math.max(0, 1 + (2 * energyS * hS * hS) / (MU_EARTH * MU_EARTH))) };

  // 4) Órbita de aparcamiento hasta el encendido translunar.
  s = propagate(s, tl.secoS, tl.tliStartS, 2, coastAcc(), samples, prograde, () => 0);
  const sTli0 = s;

  // 5) Encendido translunar: se busca la aceleración que hace llegar a la Luna a tiempo.
  const tArr = tl.endS + CRUISE_HOURS * 3600;
  const tliBurn = (aT: number, out: FlightSample[] | null) => {
    const acc: AccFn = (_t, st) => {
      const [gx, gy] = earthGravity(st[0], st[1]);
      const v = hyp(st[2], st[3]);
      return [gx + (aT * st[2]) / v, gy + (aT * st[3]) / v];
    };
    return propagate(sTli0, tl.tliStartS, tl.tliEndS, 0.5, acc, out, prograde, () => aT);
  };
  const timeToMoonDistance = (a: number) => {
    const leg = earthLeg(tliBurn(a, null), tl.tliEndS, tl.tliEndS + 12 * 86400, EARTH_MOON_KM + 1);
    const n = leg.samples.length;
    const last = leg.samples[n - 1];
    if (hyp(last.x, last.y) < EARTH_MOON_KM) return Infinity;
    // Instante exacto del cruce (Hermite entre las dos últimas muestras).
    const prev = leg.samples[n - 2];
    let lo = prev.t;
    let hi = last.t;
    for (let k = 0; k < 30; k++) {
      const m = (lo + hi) / 2;
      const st = hermite(prev, last, m);
      if (hyp(st[0], st[1]) < EARTH_MOON_KM) lo = m;
      else hi = m;
    }
    return hi;
  };
  /** Aceleración del encendido que cruza la distancia lunar en el instante pedido (secante + respaldo). */
  const solveTli = (tDTarget: number, guess: number) => {
    const f = (a: number) => {
      const tD = timeToMoonDistance(a);
      return Number.isFinite(tD) ? tD - tDTarget : 1e9;
    };
    let a0 = guess;
    let a1 = guess * 1.02;
    let f0 = f(a0);
    let f1 = f(a1);
    for (let k = 0; k < 25 && Math.abs(f1) > 1; k++) {
      if (f1 === f0 || f0 >= 1e9 || f1 >= 1e9) break;
      const a2 = a1 - (f1 * (a1 - a0)) / (f1 - f0);
      a0 = a1;
      f0 = f1;
      a1 = Math.max(guess * 0.5, Math.min(guess * 2, a2));
      f1 = f(a1);
    }
    if (Math.abs(f1) <= 1) return a1;
    return bisect(f, guess * 0.6, guess * 1.6, 40);
  };
  const rpTarget = R_MOON + lunarAltitudeKm;
  const burnS = tl.tliEndS - tl.tliStartS;
  /** Cadena completa para una aceleración dada: tramo terrestre, fase lunar y periapsis. */
  const evalArrival = (a: number) => {
    const lg = earthLeg(tliBurn(a, null), tl.tliEndS, tl.tliEndS + 12 * 86400);
    const ph = solveMoonPhase(lg, rpTarget);
    if (ph === null) return null;
    const en = firstSoiEntry(lg, ph);
    if (!en) return null;
    const ml = moonLeg(ph, en.t, en.s, null);
    return { a, leg: lg, phase: ph, err: ml.tPeri - tArr };
  };
  // Primera estimación sin la Luna; luego secante sobre el instante real del periapsis.
  const aGuess = solveTli(tArr, 3.1 / burnS);
  let r0 = evalArrival(aGuess);
  let aT = aGuess;
  let phase0 = 0;
  let leg: EarthLeg = { samples: [] };
  if (r0) {
    let r1 = evalArrival(solveTli(tArr - r0.err, aGuess));
    for (let k = 0; k < 8 && r1 && Math.abs(r1.err) > 20; k++) {
      if (r1.err === r0!.err) break;
      const a2 = r1.a - (r1.err * (r1.a - r0!.a)) / (r1.err - r0!.err);
      const r2 = evalArrival(a2);
      if (!r2) break;
      r0 = r1;
      r1 = r2;
    }
    const best = r1 && Math.abs(r1.err) <= Math.abs(r0!.err) ? r1 : r0!;
    aT = best.a;
    phase0 = best.phase;
    leg = best.leg;
  }

  // 6) Trayectoria definitiva: TLI → tramo terrestre → tramo lunar.
  const sTliEnd = tliBurn(aT, samples);
  const vTli = hyp(sTliEnd[2], sTliEnd[3]);
  const entry = firstSoiEntry(leg, phase0);
  let tSoi = Infinity;
  let tPeri = tArr;
  let arrival = { vInfKmS: NaN, periapsisAltKm: NaN, periapsisSpeedKmS: NaN };
  if (entry) {
    tSoi = entry.t;
    for (const p of leg.samples) if (p.t > tl.tliEndS && p.t < entry.t) samples.push(p);
    samples.push({ t: entry.t, x: entry.s[0], y: entry.s[1], vx: entry.s[2], vy: entry.s[3], att: prograde(0, entry.s), thrust: 0 });
    const c = moonConic(relToMoon(phase0, entry.t, entry.s));
    const ml = moonLeg(phase0, entry.t, entry.s, samples);
    tPeri = ml.tPeri;
    arrival = { vInfKmS: c.vInf, periapsisAltKm: hyp(ml.rel[0], ml.rel[1]) - R_MOON, periapsisSpeedKmS: hyp(ml.rel[2], ml.rel[3]) };
  } else {
    for (const p of leg.samples) if (p.t > tl.tliEndS) samples.push(p);
  }

  const v0 = hyp(sTli0[2], sTli0[3]);
  return {
    tl,
    samples,
    padRadiusKm: padR,
    moonPhase0: phase0,
    tSoi,
    tPeri,
    meco,
    seco,
    tli: { deltaVKmS: vTli - v0, endSpeedKmS: vTli, accelG: aT / G0 },
    arrival,
  };
}

// ───────────────────────── Consulta del estado en un instante ─────────────────────────

export interface FlightStateAt {
  t: number;
  phase: FlightPhase;
  x: number;
  y: number;
  vx: number;
  vy: number;
  att: number;
  thrustG: number;
  altitudeKm: number;
  /** Rapidez inercial (respecto del centro de la Tierra). */
  speedKmS: number;
  /** Rapidez respecto del suelo / del aire (relevante durante el ascenso). */
  groundSpeedKmS: number;
  moonX: number;
  moonY: number;
  /** Ángulo de la Luna (rad): con rotación síncrona, también su giro. */
  moonAngle: number;
  moonDistanceKm: number;
  moonAltitudeKm: number;
  /** Rapidez respecto de la Luna. */
  moonSpeedKmS: number;
  /** Giro de la Tierra desde t = 0 (rad). */
  earthAngle: number;
}

export function flightStateAt(p: FlightProfile, tIn: number): FlightStateAt {
  const t = Math.min(tIn, p.tPeri);
  let st: State;
  let att: number;
  let thrust = 0;
  const S = p.samples;
  if (t <= 0 || S.length === 0) {
    st = padState(p.padRadiusKm, t);
    att = FLIGHT_GAME.padAngle0 + OMEGA_EARTH * t;
  } else {
    let lo = 0;
    let hi = S.length - 1;
    if (t >= S[hi].t) {
      lo = hi - 1;
    } else {
      while (hi - lo > 1) {
        const mid = (lo + hi) >> 1;
        if (S[mid].t <= t) lo = mid;
        else hi = mid;
      }
    }
    const a = S[lo];
    const b = S[Math.min(lo + 1, S.length - 1)];
    st = hermite(a, b, Math.min(t, b.t));
    const u = b.t > a.t ? (t - a.t) / (b.t - a.t) : 0;
    let da = b.att - a.att;
    if (da > Math.PI) da -= 2 * Math.PI;
    if (da < -Math.PI) da += 2 * Math.PI;
    att = a.att + da * Math.max(0, Math.min(1, u));
    thrust = a.thrust + (b.thrust - a.thrust) * Math.max(0, Math.min(1, u));
  }
  const tl = p.tl;
  const ses = tl.mecoS + 10;
  const phase: FlightPhase =
    t <= 0
      ? 'pad'
      : t <= tl.mecoS
        ? 'stage1'
        : t <= ses
          ? 'coast'
          : t <= tl.secoS
            ? 'stage2'
            : t <= tl.tliStartS
              ? 'parking'
              : t <= tl.tliEndS
                ? 'tli'
                : t < p.tSoi
                  ? 'cruise'
                  : 'approach';
  const [mx, my] = moonPosition(p.moonPhase0, t);
  const [mvx, mvy] = moonVelocity(p.moonPhase0, t);
  const md = hyp(st[0] - mx, st[1] - my);
  return {
    t,
    phase,
    x: st[0],
    y: st[1],
    vx: st[2],
    vy: st[3],
    att,
    thrustG: thrust / G0,
    altitudeKm: Math.max(0, hyp(st[0], st[1]) - p.padRadiusKm),
    speedKmS: hyp(st[2], st[3]),
    groundSpeedKmS: t <= 0 ? 0 : groundSpeed(st),
    moonX: mx,
    moonY: my,
    moonAngle: p.moonPhase0 + N_MOON * t,
    moonDistanceKm: md,
    moonAltitudeKm: md - R_MOON,
    moonSpeedKmS: hyp(st[2] - mvx, st[3] - mvy),
    earthAngle: OMEGA_EARTH * t,
  };
}

/** Trayectoria completa como lista de puntos (marco terrestre), para dibujarla. */
export function trajectoryPolyline(p: FlightProfile, maxPoints = 1500): Array<{ t: number; x: number; y: number }> {
  const S = p.samples;
  if (!S.length) return [];
  const out: Array<{ t: number; x: number; y: number }> = [];
  // Más densidad cerca de la Tierra (donde todo cambia rápido): muestreo por longitud de arco.
  let acc = 0;
  let last = S[0];
  const total = S.reduce((sum, q, i) => (i ? sum + hyp(q.x - S[i - 1].x, q.y - S[i - 1].y) : 0), 0);
  const stepKm = total / maxPoints;
  out.push({ t: last.t, x: last.x, y: last.y });
  for (let i = 1; i < S.length; i++) {
    acc += hyp(S[i].x - last.x, S[i].y - last.y);
    last = S[i];
    const r = hyp(S[i].x, S[i].y);
    const local = r < R_EARTH + 3000 ? stepKm / 40 : stepKm;
    if (acc >= local || i === S.length - 1) {
      out.push({ t: S[i].t, x: S[i].x, y: S[i].y });
      acc = 0;
    }
  }
  return out;
}

const cache = new Map<string, FlightProfile>();
/** Perfil con caché (la pantalla y la escena 3D comparten el mismo cálculo). */
export function getFlightProfile(launcher: Launcher, lunarAltitudeKm: number, padHeightKm = 0.005): FlightProfile {
  const key = `${launcher.id}|${lunarAltitudeKm}|${padHeightKm}`;
  let p = cache.get(key);
  if (!p) {
    p = buildFlightProfile(launcher, lunarAltitudeKm, padHeightKm);
    cache.set(key, p);
  }
  return p;
}

/**
 * Dirección del Sol (unitaria, marco físico x, y, z con z normal al plano del vuelo). Se elige para
 * que la Luna se vea iluminada al llegar; la escena 3D y la sombra de la Tierra usan la misma.
 */
export function sunDirection(p: FlightProfile): [number, number, number] {
  const [mx, my] = moonPosition(p.moonPhase0, p.tPeri);
  const a = Math.atan2(my, mx) - 0.5;
  const z = 0.22;
  const n = Math.hypot(1, z);
  return [Math.cos(a) / n, Math.sin(a) / n, z / n];
}

/** ¿La nave está en la sombra de la Tierra? (sombra cilíndrica). */
export function inEarthShadow(p: FlightProfile, x: number, y: number): boolean {
  const [sx, sy, sz] = sunDirection(p);
  const d = x * sx + y * sy; // proyección sobre el Sol (z = 0 en el plano)
  if (d >= 0) return false;
  const px = x - d * sx;
  const py = y - d * sy;
  const pz = -d * sz;
  return Math.hypot(px, py, pz) < R_EARTH;
}
