/**
 * Fase 8.1: la trayectoria del vuelo se integra con física real (no es una animación lineal).
 */
import { describe, expect, it } from 'vitest';
import { getLauncher } from '../data/launchers/launchers';
import {
  buildFlightProfile,
  EARTH_MOON_KM,
  flightStateAt,
  MU_EARTH,
  MU_MOON,
  OMEGA_EARTH,
  R_EARTH,
  R_MOON,
  trajectoryPolyline,
} from './FlightDynamics';
import { CRUISE_HOURS } from './LaunchSystem';

const F9 = buildFlightProfile(getLauncher('falcon-9')!, 75);
const MIN4 = buildFlightProfile(getLauncher('minotaur-iv')!, 75);
const energy = (s: { x: number; y: number; vx: number; vy: number }) => (s.vx ** 2 + s.vy ** 2) / 2 - MU_EARTH / Math.hypot(s.x, s.y);

describe('Dinámica de vuelo (física integrada)', () => {
  it('en la plataforma: quieto respecto del suelo, pero gira con la Tierra (~0,46 km/s en el ecuador)', () => {
    const s = flightStateAt(F9, -5);
    expect(s.phase).toBe('pad');
    expect(s.groundSpeedKmS).toBe(0);
    expect(s.speedKmS).toBeCloseTo(OMEGA_EARTH * F9.padRadiusKm, 6);
    expect(s.speedKmS).toBeGreaterThan(0.46);
    expect(s.speedKmS).toBeLessThan(0.47);
  });

  it('el ascenso no se desploma: la altitud crece durante la primera etapa', () => {
    for (const p of [F9, MIN4]) {
      let prev = -1;
      for (let t = 1; t <= p.tl.mecoS; t += 5) {
        const h = flightStateAt(p, t).altitudeKm;
        expect(h).toBeGreaterThan(prev);
        prev = h;
      }
      expect(p.meco.liftoffTW).toBeGreaterThan(1.1);
    }
  });

  it('la segunda etapa deja la nave en la órbita de aparcamiento de 200 km casi circular', () => {
    for (const p of [F9, MIN4]) {
      const s = flightStateAt(p, p.tl.secoS);
      const vc = Math.sqrt(MU_EARTH / (R_EARTH + 200));
      expect(Math.abs(p.seco.altitudeKm - 200)).toBeLessThan(1);
      expect(Math.abs(s.speedKmS - vc)).toBeLessThan(0.03);
      expect(p.seco.eccentricity).toBeLessThan(0.01);
    }
  });

  it('en la órbita de aparcamiento se conserva la energía (solo actúa la gravedad)', () => {
    const a = flightStateAt(F9, F9.tl.secoS + 30);
    const b = flightStateAt(F9, F9.tl.tliStartS - 30);
    expect(Math.abs(energy(b) / energy(a) - 1)).toBeLessThan(1e-6);
    expect(b.altitudeKm).toBeGreaterThan(150);
  });

  it('la inyección translunar suma ≈ 3,1 km/s y deja la nave a ≈ 10,9 km/s', () => {
    for (const p of [F9, MIN4]) {
      expect(p.tli.deltaVKmS).toBeGreaterThan(2.9);
      expect(p.tli.deltaVKmS).toBeLessThan(3.3);
      expect(p.tli.endSpeedKmS).toBeGreaterThan(10.7);
      expect(p.tli.endSpeedKmS).toBeLessThan(11.2);
    }
  });

  it('durante el crucero la gravedad terrestre frena la nave y la energía se conserva', () => {
    const a = flightStateAt(F9, F9.tl.endS);
    const b = flightStateAt(F9, F9.tl.endS + 48 * 3600);
    expect(b.speedKmS).toBeLessThan(a.speedKmS);
    expect(Math.abs(energy(b) / energy(a) - 1)).toBeLessThan(1e-5);
    expect(b.phase).toBe('cruise');
  });

  it('llega al periapsis lunar a la altitud del plan justo al terminar los 4 días de crucero', () => {
    for (const p of [F9, MIN4]) {
      expect(p.arrival.periapsisAltKm).toBeCloseTo(75, 0);
      expect(Math.abs(p.tPeri - (p.tl.endS + CRUISE_HOURS * 3600))).toBeLessThan(120);
      // Velocidad de llegada «en el infinito» ≈ 0,8 km/s (la misma del cálculo de inserción del Planner).
      expect(p.arrival.vInfKmS).toBeGreaterThan(0.6);
      expect(p.arrival.vInfKmS).toBeLessThan(1);
      const s = flightStateAt(p, p.tPeri);
      expect(s.phase).toBe('approach');
      expect(s.moonAltitudeKm).toBeCloseTo(75, 0);
    }
  });

  it('dentro de la esfera de influencia lunar la energía respecto de la Luna se conserva', () => {
    const e = (t: number) => {
      const s = flightStateAt(F9, t);
      const r = s.moonDistanceKm;
      const v = s.moonSpeedKmS;
      return (v * v) / 2 - MU_MOON / r;
    };
    const a = e(F9.tSoi + 600);
    const b = e(F9.tPeri - 600);
    expect(Math.abs(b / a - 1)).toBeLessThan(1e-4);
  });

  it('las fases siguen el orden del vuelo', () => {
    const tl = F9.tl;
    const ph = [-1, 5, tl.mecoS + 5, tl.secoS - 5, tl.secoS + 60, tl.tliStartS + 5, tl.endS + 3600, F9.tPeri].map((t) => flightStateAt(F9, t).phase);
    expect(ph).toEqual(['pad', 'stage1', 'coast', 'stage2', 'parking', 'tli', 'cruise', 'approach']);
  });

  it('otras altitudes del plan también se alcanzan', () => {
    for (const h of [30, 150]) {
      const p = buildFlightProfile(getLauncher('falcon-9')!, h);
      expect(p.arrival.periapsisAltKm).toBeCloseTo(h, 0);
    }
  });

  it('la polilínea recorre de la plataforma a la Luna', () => {
    const pl = trajectoryPolyline(F9);
    expect(pl.length).toBeGreaterThan(200);
    expect(Math.hypot(pl[0].x, pl[0].y)).toBeCloseTo(F9.padRadiusKm, 3);
    const last = pl[pl.length - 1];
    const s = flightStateAt(F9, last.t);
    expect(Math.hypot(last.x - s.moonX, last.y - s.moonY)).toBeLessThan(R_MOON + 200);
    expect(Math.hypot(s.moonX, s.moonY)).toBeCloseTo(EARTH_MOON_KM, 3);
  });
});
