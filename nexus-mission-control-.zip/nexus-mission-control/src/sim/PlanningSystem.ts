/**
 * PlanningSystem — verifica un plan de vuelo completo: lanzador, órbita, duración y ventana.
 * Combina las verificaciones propias de la planificación (masa frente a lanzador, cofia, Δv,
 * ventana, cobertura) con el análisis de ingeniería recalculado con la órbita y el lanzador ELEGIDOS.
 */
import { getLauncher, LUNAR_LAUNCHERS } from '../data/launchers/launchers';
import type { Launcher, MissionPlan, MissionTemplate, SpacecraftDesign } from '../data/schemas';
import type { ComponentLookup } from './BudgetSystem';
import type { DesignIssue } from './DesignSystem';
import { analyzeEngineering, type EngineeringReport } from './EngineeringAnalysis';
import { stowedEnvelope, type Envelope } from './EnvelopeSystem';
import { DRY_MASS_MARGIN } from './MassSystem';
import { referenceOrbit } from './OrbitSystem';
import { coverageFraction, deltaVBudget, firstOptimalDay, windowInfo, type DeltaVBudget, type WindowInfo } from './TrajectorySystem';
import { fmtNum } from './units';
import type { Difficulty } from '../data/difficulty';

export interface PlanReport {
  plan: MissionPlan;
  launcher: Launcher;
  engineering: EngineeringReport;
  envelope: Envelope | null;
  massWithMarginKg: number;
  massFits: boolean;
  fairingFits: boolean;
  deltaV: DeltaVBudget;
  window: WindowInfo;
  coverage: number;
  /** Problemas del plan + problemas del análisis de ingeniería con este plan. */
  issues: DesignIssue[];
  ready: boolean;
}

/** Plan inicial sensato: lanzador más barato que puede con la masa y cabe, órbita recomendada, primera ventana óptima. */
export function defaultPlan(design: SpacecraftDesign, lookup: ComponentLookup, template: MissionTemplate, objectiveId: string): MissionPlan {
  const objective = template.objectives.find((o) => o.id === objectiveId);
  const orbit = referenceOrbit(objective);
  const r = analyzeEngineering({ design, lookup, template, objectiveId });
  const env = stowedEnvelope(design, lookup);
  const mass = r.mass?.wetWithMarginKg ?? 0;
  const fit = [...LUNAR_LAUNCHERS]
    .sort((a, b) => (a.costMUSD ?? Infinity) - (b.costMUSD ?? Infinity))
    .find((l) => l.payloadToTLIKg >= mass && (!env || (env.diameterM <= l.fairing.innerDiameterM && env.heightM <= l.fairing.heightM)));
  return {
    launcherId: (fit ?? LUNAR_LAUNCHERS[LUNAR_LAUNCHERS.length - 1]).id,
    altitudeKm: Math.round(orbit.altitudeKm),
    inclinationDeg: Math.min(90, Math.round(orbit.inclinationDeg)),
    durationDays: template.durationDays,
    launchDay: firstOptimalDay(),
  };
}

const issue = (id: string, severity: DesignIssue['severity'], title: string, explanation: string): DesignIssue => ({
  id,
  severity,
  title,
  explanation,
  instanceIds: [],
});

export function analyzePlan(input: {
  design: SpacecraftDesign;
  lookup: ComponentLookup;
  template: MissionTemplate;
  objectiveId: string;
  plan: MissionPlan;
  difficulty?: Difficulty;
}): PlanReport {
  const { design, lookup, plan } = input;
  const template = { ...input.template, durationDays: plan.durationDays };
  const launcher = getLauncher(plan.launcherId) ?? LUNAR_LAUNCHERS[0];
  const objective = template.objectives.find((o) => o.id === input.objectiveId);
  const engineering = analyzeEngineering({
    design,
    lookup,
    template,
    objectiveId: input.objectiveId,
    orbit: { altitudeKm: plan.altitudeKm, inclinationDeg: plan.inclinationDeg },
    launcherId: launcher.id,
    difficulty: input.difficulty,
  });
  const envelope = stowedEnvelope(design, lookup);
  const massWithMarginKg = engineering.mass?.wetWithMarginKg ?? 0;
  const massFits = massWithMarginKg <= launcher.payloadToTLIKg;
  const fairingFits = !envelope || (envelope.diameterM <= launcher.fairing.innerDiameterM && envelope.heightM <= launcher.fairing.heightM);
  const deltaV = deltaVBudget(design, lookup, plan);
  const window = windowInfo(plan.launchDay);
  const coverage = coverageFraction(plan.inclinationDeg);

  const issues: DesignIssue[] = [...engineering.issues];

  if (!massFits) {
    issues.push(
      issue(
        'plan-mass',
        'critical',
        `${launcher.name} no puede llevar tu nave a la Luna`,
        `Con un margen del ${DRY_MASS_MARGIN * 100} % sobre la masa seca, la nave pesa ${fmtNum(massWithMarginKg)} kg y el ${launcher.name} envía como máximo ${launcher.payloadToTLIKg} kg en inyección translunar. Elige un lanzador mayor o aligera la nave.`,
      ),
    );
  }
  if (!fairingFits && envelope) {
    issues.push(
      issue(
        'plan-fairing',
        'critical',
        'La nave plegada no cabe en la cofia',
        `Plegada mide Ø ${fmtNum(envelope.diameterM, 2)} × ${fmtNum(envelope.heightM, 2)} m y la cofia del ${launcher.name} ofrece Ø ${fmtNum(launcher.fairing.innerDiameterM, 2)} × ${fmtNum(launcher.fairing.heightM, 2)} m. Reubica las piezas que sobresalen o usa un lanzador con cofia mayor.`,
      ),
    );
  }
  if (window.status === 'closed') {
    issues.push(
      issue(
        'plan-window',
        'critical',
        'Fecha fuera de ventana de lanzamiento',
        'La Luna no está en la posición adecuada: desde esa fecha la trayectoria de 4 días no llega. Elige un día dentro de una ventana (verde u ámbar).',
      ),
    );
  } else if (design.chassisId && deltaV.ispS === 0) {
    // Sin motor: ya lo marca el diseño (no-propulsion); no se duplica.
  } else if (design.chassisId && !deltaV.ok) {
    issues.push(
      issue(
        'plan-deltav',
        'critical',
        'No hay propelente suficiente para quedar en órbita',
        `Necesitas ${fmtNum(deltaV.requiredMS, 0)} m/s (inserción ${fmtNum(deltaV.loiMS, 0)} + mantenimiento ${fmtNum(deltaV.stationKeepingMS, 0)} + correcciones ${deltaV.tcmMS}${deltaV.windowPenaltyMS ? ` + fuera de ventana óptima ${fmtNum(deltaV.windowPenaltyMS, 0)}` : ''}) y tu nave dispone de ${fmtNum(deltaV.availableMS, 0)} m/s. Añade otro tanque, aligera la nave o acorta la misión.`,
      ),
    );
  } else if (design.chassisId && deltaV.marginFraction < 0.1) {
    issues.push(
      issue(
        'plan-deltav-margin',
        'optimization',
        `Margen de Δv de solo ${Math.round(deltaV.marginFraction * 100)} %`,
        'Una maniobra que no sale perfecta o una extensión de la misión consumiría ese margen. Las misiones reales reservan al menos un 10 %.',
      ),
    );
  }
  if (window.status === 'marginal') {
    issues.push(
      issue(
        'plan-window-marginal',
        'optimization',
        `Ventana marginal: +${fmtNum(window.penaltyMS, 0)} m/s`,
        `Lanzar ${fmtNum(window.offsetDays, 1)} días lejos del centro de la ventana exige una llegada más rápida y más frenado.`,
      ),
    );
  }

  // Cobertura y altitud frente al objetivo
  if (objective) {
    const [iMin] = objective.recommendedOrbit.inclinationDeg;
    const [hMin, hMax] = objective.recommendedOrbit.altitudeKm;
    if (objective.id === 'obj-polar-ice' && plan.inclinationDeg < 85) {
      issues.push(
        issue(
          'plan-polar',
          'critical',
          'La órbita nunca pasa sobre los polos',
          `Con ${plan.inclinationDeg}° de inclinación solo sobrevuelas latitudes hasta ±${plan.inclinationDeg}°. Los cráteres en sombra permanente están cerca de ±90°: necesitas una órbita casi polar.`,
        ),
      );
    } else if (plan.inclinationDeg < iMin) {
      issues.push(
        issue(
          'plan-coverage',
          'optimization',
          `Cobertura del ${Math.round(coverage * 100)} % de la superficie`,
          `Con ${plan.inclinationDeg}° de inclinación no sobrevuelas las latitudes altas. Una órbita polar cubre el 100 %.`,
        ),
      );
    }
    if (plan.altitudeKm > hMax) {
      issues.push(
        issue(
          'plan-altitude-high',
          'optimization',
          `Altitud por encima de la recomendada (${hMin}–${hMax} km)`,
          objective.primaryInstrumentId === 'radar'
            ? 'La señal del radar se debilita rápidamente con la distancia: más altitud significa sondeos de peor calidad.'
            : 'Desde más lejos los instrumentos ven más área pero con menos detalle (peor resolución).',
        ),
      );
    } else if (plan.altitudeKm < hMin) {
      issues.push(
        issue(
          'plan-altitude-low',
          'optimization',
          `Altitud por debajo de la recomendada (${hMin}–${hMax} km)`,
          `A ${plan.altitudeKm} km los mascons deforman la órbita muy rápido: mantenerla cuesta ${fmtNum(deltaV.stationKeepingMS, 0)} m/s en la misión.`,
        ),
      );
    }
  }
  if (plan.altitudeKm < 30) {
    issues.push(
      issue(
        'plan-altitude-risk',
        'critical',
        'Riesgo de impacto con la superficie',
        'Por debajo de 30 km, las irregularidades del campo gravitatorio lunar pueden hacer chocar la nave en pocas semanas si una corrección falla.',
      ),
    );
  }

  return {
    plan,
    launcher,
    engineering,
    envelope,
    massWithMarginKg,
    massFits,
    fairingFits,
    deltaV,
    window,
    coverage,
    issues,
    ready: !issues.some((i) => i.severity === 'critical'),
  };
}
