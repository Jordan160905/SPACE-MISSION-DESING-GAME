/**
 * Descubrimientos espaciales del viaje (Fase 8.4). Funciones puras.
 *
 * Cada objeto solo puede detectarse donde tiene sentido físico:
 *  - Satélites reales en sus órbitas reales: Estación Espacial (≈ 415 km), Hubble (≈ 520 km) y basura
 *    espacial en la órbita de aparcamiento; satélites GPS al cruzar los 20 200 km de altitud;
 *    satélites geoestacionarios al cruzar los 35 786 km (están sobre el ecuador, como nuestro vuelo).
 *    Se mueven con su velocidad orbital real (μ/r³).
 *  - Meteoroides y asteroides cercanos a la Tierra durante el crucero (objetos SIMULADOS, típicos de
 *    su clase: no son objetos catalogados).
 *  - Regiones de la Luna solo en la cara que mira hacia la nave, durante la aproximación.
 *  - Estrellas, constelaciones y nebulosas en sus coordenadas reales (ascensión recta y declinación),
 *    fuera de la atmósfera y nunca cerca del Sol. El plano del vuelo es el ecuador celeste.
 */
import { flightStateAt, inEarthShadow, MU_EARTH, R_EARTH, R_MOON, sunDirection, type FlightProfile } from './FlightDynamics';

export type DiscoveryKind = 'satellite' | 'debris' | 'rock' | 'asteroid' | 'lunar' | 'constellation' | 'star' | 'nebula';
export type DiscoveryModel = 'iss' | 'hubble' | 'sat-gps' | 'sat-geo' | 'debris' | 'rock' | 'asteroid' | 'lunar' | 'sky';
export type DiscoveryZone = 'leo' | 'gps' | 'geo' | 'cruise' | 'sky' | 'approach';

/** Estrella: [ascensión recta (h), declinación (°), nombre]. */
export type SkyStar = [number, number, string];

export interface DiscoveryDef {
  id: string;
  kind: DiscoveryKind;
  name: string;
  typeLabel: string;
  zone: DiscoveryZone;
  model: DiscoveryModel;
  /** Tamaño característico (km) para encuadrarlo con la cámara. */
  sizeKm: number;
  points: number;
  /** Objeto simulado (típico de su clase), no un objeto catalogado concreto. */
  simulated?: boolean;
  facts: string[];
  /** Órbita circular terrestre (altitud en km). */
  orbitAltKm?: number;
  /** Radio real de la órbita (km), cuando se conoce con precisión (GPS, geoestacionaria). */
  orbitRadiusKm?: number;
  /** Región lunar (latitud y longitud selenográficas, °). */
  lunar?: [number, number];
  /** Objetos del cielo. */
  stars?: SkyStar[];
  lines?: Array<[number, number]>;
  /** Tamaño aparente en el cielo (°), para encuadrar. */
  skySizeDeg?: number;
}

export const DISCOVERIES: DiscoveryDef[] = [
  {
    id: 'iss',
    kind: 'satellite',
    name: 'Estación Espacial Internacional',
    typeLabel: 'Satélite artificial tripulado',
    zone: 'leo',
    model: 'iss',
    sizeKm: 0.109,
    points: 120,
    orbitAltKm: 415,
    facts: [
      'Es el objeto más grande construido en el espacio: mide como un campo de fútbol (109 m).',
      'Da una vuelta a la Tierra cada 92 minutos: sus astronautas ven unos 16 amaneceres al día.',
      'Hay personas viviendo a bordo sin interrupción desde noviembre del año 2000.',
    ],
  },
  {
    id: 'hubble',
    kind: 'satellite',
    name: 'Telescopio espacial Hubble',
    typeLabel: 'Satélite artificial científico',
    zone: 'leo',
    model: 'hubble',
    sizeKm: 0.0132,
    points: 110,
    orbitAltKm: 520,
    facts: [
      'Lanzado en 1990, observa el universo por encima de la atmósfera, que distorsiona la luz.',
      'Su espejo principal mide 2,4 m y ha ayudado a medir la edad del universo.',
      'Mide 13,2 m de largo: como un autobús escolar.',
    ],
  },
  {
    id: 'debris',
    kind: 'debris',
    name: 'Fragmento de basura espacial',
    typeLabel: 'Restos de un cohete antiguo (simulado)',
    zone: 'leo',
    model: 'debris',
    sizeKm: 0.003,
    points: 50,
    simulated: true,
    orbitAltKm: 260,
    facts: [
      'Alrededor de la Tierra se siguen más de 30 000 objetos de basura espacial mayores de 10 cm.',
      'Viajan a unos 28 000 km/h: incluso un tornillo puede dañar una nave.',
      'Las agencias vigilan estos restos para que las naves puedan esquivarlos.',
    ],
  },
  {
    id: 'gps',
    kind: 'satellite',
    name: 'Satélite GPS',
    typeLabel: 'Satélite de navegación',
    zone: 'gps',
    model: 'sat-gps',
    sizeKm: 0.012,
    points: 80,
    orbitAltKm: 20200,
    orbitRadiusKm: 26560,
    facts: [
      'Los satélites GPS orbitan a 20 200 km y dan dos vueltas a la Tierra al día.',
      'Llevan relojes atómicos: tu teléfono calcula dónde estás midiendo cuánto tarda su señal.',
      'Hay unos 30 en funcionamiento para que siempre haya varios a la vista.',
    ],
  },
  {
    id: 'geo',
    kind: 'satellite',
    name: 'Satélite geoestacionario',
    typeLabel: 'Satélite de comunicaciones y meteorología',
    zone: 'geo',
    model: 'sat-geo',
    sizeKm: 0.03,
    points: 90,
    orbitAltKm: 35786,
    orbitRadiusKm: 42164,
    facts: [
      'A 35 786 km sobre el ecuador, tarda lo mismo que la Tierra en girar: parece quieto en el cielo.',
      'Por eso las antenas parabólicas de las casas no necesitan moverse.',
      'La idea la popularizó el escritor Arthur C. Clarke en 1945.',
    ],
  },
  {
    id: 'meteoroid',
    kind: 'rock',
    name: 'Meteoroide',
    typeLabel: 'Fragmento rocoso (simulado)',
    zone: 'cruise',
    model: 'rock',
    sizeKm: 0.006,
    points: 60,
    simulated: true,
    facts: [
      'Los meteoroides son trozos de roca de asteroides o cometas que viajan por el espacio.',
      'Si entran en la atmósfera, arden y los vemos como estrellas fugaces.',
      'Cada día llegan a la Tierra decenas de toneladas de polvo y pequeñas rocas espaciales.',
    ],
  },
  {
    id: 'asteroid',
    kind: 'asteroid',
    name: 'Asteroide cercano a la Tierra',
    typeLabel: 'Asteroide (simulado, típico de su clase)',
    zone: 'cruise',
    model: 'asteroid',
    sizeKm: 0.18,
    points: 150,
    simulated: true,
    facts: [
      'Los asteroides cercanos a la Tierra son rocas que orbitan el Sol y se acercan a nuestra órbita.',
      'La NASA conoce más de 35 000 y vigila los que podrían ser peligrosos.',
      'En 2022 la misión DART chocó contra el asteroide Dimorphos y cambió su órbita: ¡la primera prueba de defensa planetaria!',
    ],
  },
  {
    id: 'tranquility',
    kind: 'lunar',
    name: 'Mar de la Tranquilidad',
    typeLabel: 'Región lunar · llanura de lava',
    zone: 'approach',
    model: 'lunar',
    sizeKm: 700,
    points: 130,
    lunar: [0.67, 23.47],
    facts: [
      'Los «mares» lunares son llanuras de lava solidificada: por eso se ven oscuros.',
      'Aquí alunizó el Apolo 11 el 20 de julio de 1969: Neil Armstrong y Buzz Aldrin caminaron sobre la Luna.',
    ],
  },
  {
    id: 'tycho',
    kind: 'lunar',
    name: 'Cráter Tycho',
    typeLabel: 'Región lunar · cráter joven',
    zone: 'approach',
    model: 'lunar',
    sizeKm: 160,
    points: 120,
    lunar: [-43.3, -11.4],
    facts: [
      'Mide unos 85 km de ancho y se formó hace unos 100 millones de años: muy joven para la Luna.',
      'Sus rayos brillantes de material lanzado por el impacto se extienden más de 1 500 km.',
    ],
  },
  {
    id: 'copernicus',
    kind: 'lunar',
    name: 'Cráter Copérnico',
    typeLabel: 'Región lunar · cráter de impacto',
    zone: 'approach',
    model: 'lunar',
    sizeKm: 180,
    points: 110,
    lunar: [9.6, -20.1],
    facts: [
      'Tiene unos 93 km de ancho y montañas en su centro, levantadas por el impacto.',
      'Lo llaman «el monarca de la Luna» por sus paredes en terrazas.',
    ],
  },
  {
    id: 'south-pole',
    kind: 'lunar',
    name: 'Polo Sur lunar',
    typeLabel: 'Región lunar · cráteres en sombra',
    zone: 'approach',
    model: 'lunar',
    sizeKm: 400,
    points: 160,
    lunar: [-89.5, 0],
    facts: [
      'En el fondo de algunos cráteres del polo sur nunca da el Sol y podría haber hielo de agua.',
      'Por eso es el destino elegido por el programa Artemis de la NASA para volver a la Luna.',
    ],
  },
  {
    id: 'imbrium',
    kind: 'lunar',
    name: 'Mar de las Lluvias (Imbrium)',
    typeLabel: 'Región lunar · gran cuenca de impacto',
    zone: 'approach',
    model: 'lunar',
    sizeKm: 1100,
    points: 110,
    lunar: [32.8, -15.6],
    facts: [
      'Es una de las cuencas más grandes de la Luna: unos 1 100 km, ¡casi como España!',
      'Se formó por un impacto gigante y después se llenó de lava.',
    ],
  },
  {
    id: 'orion',
    kind: 'constellation',
    name: 'Constelación de Orión',
    typeLabel: 'Constelación',
    zone: 'sky',
    model: 'sky',
    sizeKm: 0,
    points: 70,
    skySizeDeg: 28,
    stars: [
      [5.919, 7.41, 'Betelgeuse'],
      [5.418, 6.35, 'Bellatrix'],
      [5.533, -0.3, 'Mintaka'],
      [5.603, -1.2, 'Alnilam'],
      [5.679, -1.94, 'Alnitak'],
      [5.796, -9.67, 'Saiph'],
      [5.242, -8.2, 'Rigel'],
    ],
    lines: [
      [0, 1],
      [1, 2],
      [2, 3],
      [3, 4],
      [0, 4],
      [4, 5],
      [2, 6],
    ],
    facts: [
      'Representa a un cazador: las tres estrellas del centro forman su cinturón.',
      'Betelgeuse es una supergigante roja tan grande que, en lugar del Sol, llegaría más allá de Marte.',
      'Desde el espacio, sin aire, las estrellas no parpadean.',
    ],
  },
  {
    id: 'crux',
    kind: 'constellation',
    name: 'Cruz del Sur',
    typeLabel: 'Constelación',
    zone: 'sky',
    model: 'sky',
    sizeKm: 0,
    points: 70,
    skySizeDeg: 12,
    stars: [
      [12.443, -63.1, 'Ácrux'],
      [12.52, -57.11, 'Gácrux'],
      [12.795, -59.69, 'Mimosa'],
      [12.252, -58.75, 'Delta Crucis'],
    ],
    lines: [
      [0, 1],
      [2, 3],
    ],
    facts: [
      'Es la constelación más pequeña del cielo, pero de las más fáciles de reconocer.',
      'Los navegantes la usaban para encontrar el sur.',
      'Aparece en las banderas de Australia, Brasil y Nueva Zelanda, entre otras.',
    ],
  },
  {
    id: 'ursa',
    kind: 'constellation',
    name: 'Osa Mayor (el Carro)',
    typeLabel: 'Asterismo',
    zone: 'sky',
    model: 'sky',
    sizeKm: 0,
    points: 70,
    skySizeDeg: 26,
    stars: [
      [11.062, 61.75, 'Dubhe'],
      [11.031, 56.38, 'Merak'],
      [11.897, 53.69, 'Phecda'],
      [12.257, 57.03, 'Megrez'],
      [12.9, 55.96, 'Alioth'],
      [13.399, 54.93, 'Mizar'],
      [13.792, 49.31, 'Alkaid'],
    ],
    lines: [
      [0, 1],
      [1, 2],
      [2, 3],
      [3, 0],
      [3, 4],
      [4, 5],
      [5, 6],
    ],
    facts: [
      'Sus siete estrellas forman un cucharón llamado «el Carro».',
      'Prolongando la línea de Merak a Dubhe se llega a la estrella Polar, que marca el norte.',
    ],
  },
  {
    id: 'sirius',
    kind: 'star',
    name: 'Sirio',
    typeLabel: 'Estrella',
    zone: 'sky',
    model: 'sky',
    sizeKm: 0,
    points: 60,
    skySizeDeg: 4,
    stars: [[6.752, -16.72, 'Sirio']],
    facts: [
      'Es la estrella más brillante del cielo nocturno.',
      'Está a unos 8,6 años luz: su luz que vemos salió hace casi 9 años.',
      'Es doble: tiene una compañera pequeña, una enana blanca.',
    ],
  },
  {
    id: 'm42',
    kind: 'nebula',
    name: 'Nebulosa de Orión (M42)',
    typeLabel: 'Nebulosa',
    zone: 'sky',
    model: 'sky',
    sizeKm: 0,
    points: 90,
    skySizeDeg: 3,
    stars: [[5.588, -5.39, 'M42']],
    facts: [
      'Es una nube gigante de gas y polvo donde están naciendo estrellas nuevas.',
      'Está a unos 1 300 años luz, en la «espada» de Orión.',
      'Es tan brillante que se ve a simple vista como una manchita borrosa.',
    ],
  },
  {
    id: 'm8',
    kind: 'nebula',
    name: 'Nebulosa de la Laguna (M8)',
    typeLabel: 'Nebulosa',
    zone: 'sky',
    model: 'sky',
    sizeKm: 0,
    points: 90,
    skySizeDeg: 3,
    stars: [[18.06, -24.38, 'M8']],
    facts: [
      'Es una nube de gas que brilla con la luz de las estrellas jóvenes que se forman dentro.',
      'Está a unos 4 000 años luz, en la constelación de Sagitario.',
    ],
  },
];

/** Radio de la órbita: el real si se conoce; si no, radio medio + altitud. */
export function orbitRadius(def: DiscoveryDef) {
  return def.orbitRadiusKm ?? R_EARTH + (def.orbitAltKm ?? 0);
}

export function discoveryById(id: string) {
  return DISCOVERIES.find((d) => d.id === id);
}

// ───────────────────────── Geometría ─────────────────────────

/** Dirección (unitaria, marco físico) de unas coordenadas celestes. */
export function skyDir(raH: number, decDeg: number): [number, number, number] {
  const a = (raH / 24) * 2 * Math.PI;
  const d = (decDeg * Math.PI) / 180;
  return [Math.cos(d) * Math.cos(a), Math.cos(d) * Math.sin(a), Math.sin(d)];
}

/** Dirección media de un objeto del cielo. */
export function skyCenter(def: DiscoveryDef): [number, number, number] {
  const s = def.stars ?? [];
  const v = s.reduce<[number, number, number]>(
    (acc, [ra, dec]) => {
      const [x, y, z] = skyDir(ra, dec);
      return [acc[0] + x, acc[1] + y, acc[2] + z];
    },
    [0, 0, 0],
  );
  const n = Math.hypot(...v) || 1;
  return [v[0] / n, v[1] / n, v[2] / n];
}

/** Punto de una región lunar en el marco físico (la Luna gira de forma síncrona). */
export function lunarPoint(p: FlightProfile, t: number, latDeg: number, lonDeg: number): [number, number, number] {
  const s = flightStateAt(p, t);
  // La longitud 0 mira a la Tierra: dirección Luna→Tierra = ángulo de la Luna + π.
  const a = s.moonAngle + Math.PI + (lonDeg * Math.PI) / 180;
  const la = (latDeg * Math.PI) / 180;
  return [s.moonX + R_MOON * Math.cos(la) * Math.cos(a), s.moonY + R_MOON * Math.cos(la) * Math.sin(a), R_MOON * Math.sin(la)];
}

export interface Sighting {
  id: string;
  t: number;
  /** Parámetros fijados al detectarlo (desfase orbital, distancia de paso…). */
  phase0?: number;
  zOff?: number;
  missDir?: [number, number, number];
  missKm?: number;
  vel?: [number, number, number];
  origin?: [number, number, number];
}

/** Posición (marco físico, km) de un objeto en el instante t; null para objetos del cielo. */
export function objectPosition(p: FlightProfile, s: Sighting, t: number): [number, number, number] | null {
  const def = discoveryById(s.id);
  if (!def) return null;
  if (def.orbitAltKm !== undefined) {
    const r = orbitRadius(def);
    const n = Math.sqrt(MU_EARTH / (r * r * r));
    const a = (s.phase0 ?? 0) + n * t;
    return [r * Math.cos(a), r * Math.sin(a), s.zOff ?? 0];
  }
  if (def.lunar) return lunarPoint(p, t, def.lunar[0], def.lunar[1]);
  if (s.origin && s.vel) {
    const dt = t - s.t;
    return [s.origin[0] + s.vel[0] * dt, s.origin[1] + s.vel[1] * dt, s.origin[2] + s.vel[2] * dt];
  }
  return null;
}

export function distanceTo(p: FlightProfile, s: Sighting, t: number): number {
  const o = objectPosition(p, s, t);
  const c = flightStateAt(p, t);
  if (!o) return Infinity;
  return Math.hypot(o[0] - c.x, o[1] - c.y, o[2]);
}

/** Ángulo (°) entre una dirección y el Sol. */
export function angleFromSun(p: FlightProfile, dir: [number, number, number]) {
  const s = sunDirection(p);
  return (Math.acos(Math.max(-1, Math.min(1, dir[0] * s[0] + dir[1] * s[1] + dir[2] * s[2]))) * 180) / Math.PI;
}

// ───────────────────────── Programación coherente ─────────────────────────

function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Primer instante (tras t0) en que la altitud cruza `altKm`. */
function crossingTime(p: FlightProfile, t0: number, altKm: number): number | null {
  let lo = t0;
  let hi = p.tPeri;
  if (flightStateAt(p, hi).altitudeKm < altKm) return null;
  for (let k = 0; k < 60; k++) {
    const m = (lo + hi) / 2;
    if (flightStateAt(p, m).altitudeKm < altKm) lo = m;
    else hi = m;
  }
  return hi;
}

/**
 * Elige las oportunidades de descubrimiento del vuelo (5–6), cada una en una zona donde es posible.
 * `busy`: instantes ya ocupados por otros eventos (se evitan).
 */
export function scheduleDiscoveries(p: FlightProfile, seed: number, busy: number[] = []): Sighting[] {
  const tl = p.tl;
  const r = rng(seed);
  const out: Sighting[] = [];
  const pickFrom = (ids: string[]) => ids[Math.floor(r() * ids.length)];
  const free = (t: number, gap: number) => busy.every((b) => Math.abs(b - t) > gap) && out.every((o) => Math.abs(o.t - t) > gap);
  const placeIn = (t0: number, t1: number, gap: number) => {
    for (let k = 0; k < 30; k++) {
      const t = t0 + (t1 - t0) * r();
      if (free(t, gap)) return t;
    }
    return null;
  };

  // 1) Órbita de aparcamiento: un satélite o basura que pasa cerca (distancia real de cientos de km).
  {
    const t = placeIn(tl.secoS + 200, tl.tliStartS - 300, 240);
    if (t !== null) {
      const id = pickFrom(['iss', 'hubble', 'debris']);
      const c = flightStateAt(p, t);
      const def = discoveryById(id)!;
      const rr = orbitRadius(def);
      const n = Math.sqrt(MU_EARTH / (rr * rr * rr));
      const ahead = (r() < 0.5 ? -1 : 1) * (0.012 + r() * 0.02);
      out.push({ id, t, phase0: Math.atan2(c.y, c.x) + ahead - n * t, zOff: (r() - 0.5) * 120 });
    }
  }
  // 2) Al cruzar la altitud de los satélites GPS o geoestacionarios.
  {
    const id = r() < 0.5 ? 'gps' : 'geo';
    const def = discoveryById(id)!;
    const t = crossingTime(p, tl.tliEndS, orbitRadius(def) - R_EARTH);
    if (t !== null && free(t, 600)) {
      const c = flightStateAt(p, t);
      const rr = orbitRadius(def);
      const n = Math.sqrt(MU_EARTH / (rr * rr * rr));
      const ahead = (r() < 0.5 ? -1 : 1) * (0.004 + r() * 0.006);
      out.push({ id, t, phase0: Math.atan2(c.y, c.x) + ahead - n * t, zOff: id === 'gps' ? (r() - 0.5) * 600 : (r() - 0.5) * 40 });
    }
  }
  // 3) Cielo: estrellas, constelación o nebulosa visibles (fuera del aire y lejos del Sol).
  const skyIds = DISCOVERIES.filter((d) => d.zone === 'sky').map((d) => d.id);
  const skyWindows: Array<[number, number]> = [
    [tl.secoS + 200, tl.tliStartS - 300],
    [tl.endS + 2 * 3600, p.tSoi - 6 * 3600],
  ];
  for (let k = 0; k < 2; k++) {
    const candidates = skyIds.filter((id) => !out.some((o) => o.id === id) && angleFromSun(p, skyCenter(discoveryById(id)!)) > 45);
    if (!candidates.length) break;
    const id = pickFrom(candidates);
    const [w0, w1] = skyWindows[k];
    // En la órbita, mejor en la sombra de la Tierra (cielo totalmente oscuro).
    let t: number | null = null;
    for (let j = 0; j < 40 && t === null; j++) {
      const c = placeIn(w0, w1, 900);
      if (c === null) break;
      const s = flightStateAt(p, c);
      if (k === 1 || inEarthShadow(p, s.x, s.y) || j > 25) t = c;
    }
    if (t !== null) out.push({ id, t });
  }
  // 4) Crucero: un meteoroide (pasa a decenas de km) o un asteroide (a decenas de miles de km).
  {
    const id = r() < 0.55 ? 'meteoroid' : 'asteroid';
    const t = placeIn(tl.endS + 8 * 3600, p.tSoi - 4 * 3600, 3 * 3600);
    if (t !== null) {
      const c = flightStateAt(p, t);
      const miss = id === 'asteroid' ? 30000 + r() * 30000 : 15 + r() * 60;
      // Dirección perpendicular a nuestra velocidad, con algo fuera del plano.
      const vx = c.vx / c.speedKmS;
      const vy = c.vy / c.speedKmS;
      const side = r() < 0.5 ? -1 : 1;
      const dz = (r() - 0.5) * 0.6;
      const nrm = Math.hypot(1, dz);
      const missDir: [number, number, number] = [(-vy * side) / nrm, (vx * side) / nrm, dz / nrm];
      const origin: [number, number, number] = [c.x + missDir[0] * miss, c.y + missDir[1] * miss, missDir[2] * miss];
      // Velocidad relativa típica (km/s), perpendicular a la línea de paso: el instante t es el de máximo acercamiento.
      const sp = id === 'asteroid' ? 6 + r() * 8 : 12 + r() * 20;
      const tilt = (r() - 0.5) * 0.8;
      const w = [vx * Math.cos(tilt), vy * Math.cos(tilt), Math.sin(tilt)];
      const dot = w[0] * missDir[0] + w[1] * missDir[1] + w[2] * missDir[2];
      const wx = w[0] - dot * missDir[0];
      const wy = w[1] - dot * missDir[1];
      const wz = w[2] - dot * missDir[2];
      const wn = Math.hypot(wx, wy, wz) || 1;
      const sgn = r() < 0.5 ? -1 : 1;
      const vel: [number, number, number] = [c.vx + (sgn * sp * wx) / wn, c.vy + (sgn * sp * wy) / wn, (sgn * sp * wz) / wn];
      out.push({ id, t, origin, vel, missKm: miss, missDir });
    }
  }
  // 5) Aproximación: una región lunar en la cara que mira hacia la nave.
  {
    const lunar = DISCOVERIES.filter((d) => d.zone === 'approach');
    const tA = Math.max(p.tSoi + 2 * 3600, p.tPeri - 9 * 3600);
    const t = placeIn(tA, p.tPeri - 1.5 * 3600, 2400);
    if (t !== null) {
      const c = flightStateAt(p, t);
      const visible = lunar.filter((d) => {
        const q = lunarPoint(p, t, d.lunar![0], d.lunar![1]);
        const nx = (q[0] - c.moonX) / R_MOON;
        const ny = (q[1] - c.moonY) / R_MOON;
        const nz = q[2] / R_MOON;
        const tx = c.x - q[0];
        const ty = c.y - q[1];
        const tz = -q[2];
        const d2 = Math.hypot(tx, ty, tz);
        return (nx * tx + ny * ty + nz * tz) / d2 > 0.15; // la región mira hacia la nave
      });
      if (visible.length) out.push({ id: pickFrom(visible.map((d) => d.id)), t });
    }
  }
  return out.sort((a, b) => a.t - b.t);
}

/** ¿El objeto es visible desde la nave en este momento? (para los del cielo y la Luna). */
export function isVisible(p: FlightProfile, s: Sighting, t: number): boolean {
  const def = discoveryById(s.id);
  if (!def) return false;
  if (def.zone === 'sky') return flightStateAt(p, t).altitudeKm > 100 && angleFromSun(p, skyCenter(def)) > 30;
  return true;
}

/** Puntos por registrar un descubrimiento: base + extra si se observó de cerca con la cámara. */
export function discoveryPoints(def: DiscoveryDef, observed: boolean) {
  return def.points + (observed ? Math.round(def.points * 0.5) : 0);
}

