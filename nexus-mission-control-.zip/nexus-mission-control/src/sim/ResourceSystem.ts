/**
 * ResourceSystem — los seis recursos de la misión en un solo lugar, con su margen y una
 * explicación sencilla, y cuáles son los MÁS CRÍTICOS para esta misión concreta (los de menor
 * margen). Solo reorganiza números del análisis existente: no calcula física nueva.
 */
import type { EngineeringReport } from './EngineeringAnalysis';
import type { PlanReport } from './PlanningSystem';
import { operationalLifetimeDays } from './ScheduleSystem';
import { fmtNum } from './units';
import { numLocale } from '../i18n/lang';

export type ResourceId = 'mass' | 'energy' | 'budget' | 'data' | 'comms' | 'time';
export type ResourceState = 'ok' | 'tight' | 'over' | 'unknown';

export interface MissionResource {
  id: ResourceId;
  label: string;
  /** Lo que se usa / necesita, en texto con unidades. */
  used: string;
  /** Lo que hay disponible, en texto con unidades. */
  available: string;
  /** Fracción usada (0–1+) para la barra. */
  usedFraction: number;
  /** Margen relativo: (disponible − usado) / disponible. Negativo = excedido. */
  margin: number;
  state: ResourceState;
  /** Qué es, en una frase sencilla. */
  plain: string;
  /** Por qué importa ahora, con los números de esta misión. */
  why: string;
}

export interface ResourceReport {
  resources: MissionResource[];
  /** Los dos recursos con menos margen: los que más condicionan esta misión. */
  critical: ResourceId[];
}

const TIGHT = 0.1;
const stateOf = (margin: number): ResourceState => (!Number.isFinite(margin) ? 'unknown' : margin < 0 ? 'over' : margin < TIGHT ? 'tight' : 'ok');

function res(r: Omit<MissionResource, 'state' | 'usedFraction'> & { usedFraction?: number }): MissionResource {
  return { ...r, usedFraction: r.usedFraction ?? Math.max(0, 1 - r.margin), state: stateOf(r.margin) };
}

export function missionResources(e: EngineeringReport, plan: PlanReport | null): ResourceReport {
  const out: MissionResource[] = [];

  // Masa: frente a la capacidad del lanzador elegido (o del mayor que cabe en el presupuesto).
  if (e.mass) {
    const cap = plan?.launcher.payloadToTLIKg ?? null;
    const used = plan?.massWithMarginKg ?? e.mass.wetWithMarginKg;
    const margin = cap ? (cap - used) / cap : Number.NaN;
    out.push(
      res({
        id: 'mass',
        label: 'Masa',
        used: `${fmtNum(used)} kg`,
        available: cap ? `${cap.toLocaleString(numLocale())} kg (${plan!.launcher.name})` : 'elige lanzador',
        usedFraction: cap ? used / cap : 0,
        margin,
        plain: 'Cuánto pesa la nave con propelente y margen, frente a lo que el cohete puede enviar a la Luna.',
        why: cap ? `Cada kilo extra exige un cohete más potente y caro. Te quedan ${fmtNum(cap - used)} kg de capacidad.` : 'Sin lanzador elegido aún.',
      }),
    );
  }
  // Energía: lo que sobra en cada órbita frente a lo necesario para recargar el eclipse.
  if (e.power) {
    const need = e.power.rechargeNeededWh;
    const avail = need + e.power.orbitBalanceWh;
    const margin = avail > 0 ? (avail - need) / avail : -1;
    out.push(
      res({
        id: 'energy',
        label: 'Energía',
        used: `${fmtNum(need)} Wh`,
        available: `${fmtNum(Math.max(0, avail))} Wh por órbita`,
        margin,
        plain: 'La energía que los paneles reúnen al sol para recargar la batería gastada en la sombra.',
        why: `El eclipse dura ${fmtNum(e.power.eclipseH * 60, 0)} min y descarga la batería un ${Math.round(e.power.depthOfDischarge * 100)} %. Sin margen, cualquier avería obliga a apagar instrumentos.`,
      }),
    );
  }
  // Presupuesto.
  if (e.budget) {
    const margin = e.budget.capMUSD > 0 ? e.budget.remainingMUSD / e.budget.capMUSD : -1;
    out.push(
      res({
        id: 'budget',
        label: 'Presupuesto',
        used: `${fmtNum(e.budget.committedMUSD)} MUSD`,
        available: `${e.budget.capMUSD} MUSD`,
        usedFraction: e.budget.usedFraction,
        margin,
        plain: 'El dinero para construir la nave, lanzarla y operarla cada día.',
        why: `Quedan ${fmtNum(e.budget.remainingMUSD)} MUSD para imprevistos. Un acontecimiento en vuelo puede costar dinero.`,
      }),
    );
  }
  // Datos: lo que llegará a Tierra frente al objetivo científico.
  if (e.data && e.data.targetGbit > 0) {
    const d = e.data.missionDeliveredGbit;
    const margin = d > 0 ? (d - e.data.targetGbit) / d : -1;
    out.push(
      res({
        id: 'data',
        label: 'Datos',
        used: `${e.data.targetGbit.toLocaleString(numLocale())} Gbit exigidos`,
        available: `${fmtNum(e.data.missionDeliveredGbit, 0)} Gbit previstos`,
        usedFraction: e.data.missionDeliveredGbit > 0 ? e.data.targetGbit / e.data.missionDeliveredGbit : 1,
        margin,
        plain: 'La información científica que los instrumentos producen y debe llegar a la Tierra.',
        why: `Los instrumentos producen ${fmtNum(e.data.genGbitPerDay, 0)} Gbit al día, pero solo cuenta lo que se transmite: ${fmtNum(e.data.deliveredGbitPerDay, 0)} Gbit/día.`,
      }),
    );
  }
  // Comunicaciones: capacidad diaria del enlace frente a lo que se genera.
  if (e.comms && e.data) {
    const cap = e.comms.downlinkGbitPerDay;
    const need = e.data.genGbitPerDay;
    const margin = cap > 0 ? (cap - need) / cap : -1;
    out.push(
      res({
        id: 'comms',
        label: 'Comunicaciones',
        used: `${fmtNum(need, 0)} Gbit/día generados`,
        available: `${fmtNum(cap, 0)} Gbit/día de enlace`,
        usedFraction: cap > 0 ? need / cap : 1,
        margin,
        plain: 'Cuánto puede enviar la antena a las estaciones en Tierra durante las horas de contacto.',
        why: `Solo hay contacto ${fmtNum(e.comms.contactHoursPerDay, 1)} h al día (la Luna tapa la Tierra parte de la órbita y la estación atiende otras misiones).`,
      }),
    );
  }
  // Tiempo: desarrollo antes del lanzamiento y vida útil en órbita.
  if (e.schedule) {
    const s = e.schedule;
    const margin = s.availableMonths > 0 ? s.reserveMonths / s.availableMonths : -1;
    const life = plan ? operationalLifetimeDays(plan.deltaV, plan.plan.altitudeKm, plan.plan.durationDays) : null;
    out.push(
      res({
        id: 'time',
        label: 'Tiempo',
        used: `${fmtNum(s.totalMonths, 1)} meses de desarrollo`,
        available: `${s.availableMonths} meses hasta la ventana`,
        usedFraction: s.availableMonths > 0 ? s.totalMonths / s.availableMonths : 1,
        margin,
        plain: 'Los meses para construir y probar la nave antes de que se cierre la ventana de lanzamiento, y cuánto puede durar en órbita.',
        why:
          `Marca el ritmo ${s.driver ? `«${s.driver.name}» (${s.driver.months} meses)` : 'la pieza más lenta'} más ${fmtNum(s.integrationMonths, 1)} meses de integración y pruebas.` +
          (life !== null ? ` Vida útil estimada en órbita: ${fmtNum(life, 0)} días (el propelente sobrante alarga la misión).` : ''),
      }),
    );
  }
  const critical = [...out]
    .filter((r) => r.state !== 'unknown')
    .sort((a, b) => a.margin - b.margin)
    .slice(0, 2)
    .map((r) => r.id);
  return { resources: out, critical };
}
