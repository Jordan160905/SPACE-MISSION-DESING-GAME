/**
 * ¿Puede este vehículo llevar ESTA nave a la Luna dentro de ESTE presupuesto?
 *
 * Compara lo que necesita la misión con lo que ofrece el vehículo, con los mismos datos que el
 * Planner (`analyzePlan`):
 *  1. Disponibilidad: se puede contratar hoy (estado real del vehículo).
 *  2. Órbita requerida: llega a la inyección translunar (la inserción en la órbita lunar la hace la nave).
 *  3. Masa de la carga útil: nave con propelente y margen frente a la capacidad hacia la Luna.
 *  4. Capacidad de lanzamiento: la nave plegada cabe en la cofia.
 *  5. Requisitos de la misión: su costo cabe en el presupuesto que queda.
 *
 * Las capacidades y costos son los valores del juego de cada vehículo (ver `gameNote`), no datos oficiales.
 */
import type { Launcher } from '../data/schemas';
import type { Envelope } from './EnvelopeSystem';
import { fmtNum } from './units';
import { numLocale } from '../i18n/lang';

export interface CompatCheck {
  id: 'availability' | 'orbit' | 'mass' | 'fairing' | 'budget';
  label: string;
  ok: boolean;
  /** Lo que necesita la misión. */
  need: string;
  /** Lo que ofrece el vehículo. */
  offer: string;
  detail: string;
}

export interface LauncherCompatibility {
  compatible: boolean;
  checks: CompatCheck[];
  /** El primer motivo de incompatibilidad, en una frase. */
  reason: string | null;
}

export interface CompatContext {
  massWithMarginKg: number;
  envelope: Envelope | null;
  /** Dinero disponible para el lanzador (null = sin presupuesto, modo libre). */
  budgetForLauncherMUSD: number | null;
  /** Órbita lunar elegida en el Planner (para explicarla). */
  orbit?: { altitudeKm: number; inclinationDeg: number };
}

export function launcherCompatibility(l: Launcher, ctx: CompatContext): LauncherCompatibility {
  const checks: CompatCheck[] = [];
  const hireable = l.costMUSD !== null && l.real.status === 'operational';
  checks.push({
    id: 'availability',
    label: 'Disponible para contratar',
    ok: hireable,
    need: 'Un vehículo en servicio',
    offer: l.real.status === 'operational' ? 'En servicio' : l.real.status === 'retired' ? 'Retirado' : l.real.status === 'retiring' ? 'En retirada (reservado)' : 'Nueva versión en desarrollo',
    detail: hireable ? 'Se puede contratar en el juego.' : (l.unavailableReason ?? 'No se puede contratar.'),
  });

  const reachesMoon = l.lunarCapable && l.payloadToTLIKg > 0;
  const orbitTxt = ctx.orbit ? `órbita lunar de ${ctx.orbit.altitudeKm} km y ${ctx.orbit.inclinationDeg}°` : 'órbita lunar';
  checks.push({
    id: 'orbit',
    label: 'Órbita requerida',
    ok: reachesMoon,
    need: 'Inyección translunar (camino a la Luna)',
    offer: reachesMoon ? 'Llega a la inyección translunar' : 'Solo órbita terrestre en el juego',
    detail: reachesMoon
      ? `Te deja en camino a la Luna; la ${orbitTxt} la alcanza tu nave con su propio motor (ver Δv).`
      : (l.unavailableReason ?? 'No tiene energía para enviar la nave hacia la Luna.'),
  });

  const massOk = reachesMoon && ctx.massWithMarginKg <= l.payloadToTLIKg;
  checks.push({
    id: 'mass',
    label: 'Masa de la carga útil',
    ok: massOk,
    need: `${fmtNum(ctx.massWithMarginKg)} kg (con propelente y margen)`,
    offer: reachesMoon ? `${l.payloadToTLIKg.toLocaleString(numLocale())} kg hacia la Luna` : '0 kg hacia la Luna',
    detail: massOk ? 'Puede llevar tu nave.' : reachesMoon ? 'Tu nave pesa más de lo que este vehículo envía a la Luna.' : 'No envía carga hacia la Luna.',
  });

  const e = ctx.envelope;
  const fairOk = !e || (e.diameterM <= l.fairing.innerDiameterM && e.heightM <= l.fairing.heightM);
  checks.push({
    id: 'fairing',
    label: 'Capacidad de lanzamiento (cofia)',
    ok: fairOk,
    need: e ? `Ø ${fmtNum(e.diameterM, 2)} × ${fmtNum(e.heightM, 2)} m plegada` : 'Sin nave que medir',
    offer: `Ø ${fmtNum(l.fairing.innerDiameterM, 2)} × ${fmtNum(l.fairing.heightM, 1)} m útiles`,
    detail: fairOk ? 'Tu nave plegada cabe en la cofia.' : 'Tu nave plegada no cabe en la cofia.',
  });

  if (ctx.budgetForLauncherMUSD !== null) {
    const budgetOk = l.costMUSD !== null && l.costMUSD <= ctx.budgetForLauncherMUSD + 1e-9;
    checks.push({
      id: 'budget',
      label: 'Requisitos de la misión (presupuesto)',
      ok: budgetOk,
      need: `≤ ${fmtNum(ctx.budgetForLauncherMUSD, 1)} MUSD libres tras nave y operación`,
      offer: l.costMUSD !== null ? `${fmtNum(l.costMUSD, 1)} MUSD` : 'Sin precio en el juego',
      detail: budgetOk ? 'Cabe en el presupuesto de la misión.' : l.costMUSD === null ? 'No se puede contratar.' : 'Su costo supera el dinero que queda.',
    });
  }

  const bad = checks.find((c) => !c.ok);
  const reason = !bad
    ? null
    : bad.id === 'availability' || bad.id === 'orbit'
      ? bad.detail
      : bad.id === 'mass'
        ? `Tu nave pesa demasiado para él (${bad.need} frente a ${bad.offer}).`
        : bad.id === 'fairing'
          ? `Tu nave plegada no cabe en su cofia (${bad.need} frente a ${bad.offer}).`
          : `No alcanza el presupuesto (cuesta ${bad.offer}; quedan ${fmtNum(ctx.budgetForLauncherMUSD ?? 0, 1)} MUSD).`;
  return { compatible: !bad, checks, reason };
}
