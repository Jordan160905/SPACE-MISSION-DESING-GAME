/**
 * TrajectorySystem — presupuesto de Δv, ventanas de lanzamiento y cobertura.
 *
 * Supuestos (ver docs/ASSUMPTIONS.md):
 *  - Transferencia directa de ~4 días; la nave llega a la Luna con v∞ = 0,8 km/s.
 *  - Inserción en órbita lunar (LOI) en una sola maniobra hasta una órbita circular de radio r:
 *        Δv_LOI = √(v∞² + 2μ/r) − √(μ/r)
 *  - Mantenimiento orbital (perturbaciones de los mascons): 0,4 m/s/día a 50 km, escalado como
 *    (50/h)^1,5 (aproximación de juego: las órbitas bajas se degradan mucho más rápido).
 *  - Correcciones de trayectoria (TCM): 30 m/s fijos.
 *  - Ventanas: una cada 29,53 días (mes sinódico), centrada en el día 7 de la campaña.
 *    ±1 día: óptima. ±3 días: marginal, +60 m/s por cada día fuera de la óptima. Resto: cerrada.
 *  - Δv disponible (Tsiolkovsky): Isp · g₀ · ln(masa húmeda / masa seca).
 */
import type { SpacecraftDesign } from '../data/schemas';
import type { ComponentLookup } from './BudgetSystem';
import { designComponents, designTotals } from './DesignSystem';
import { MOON_MU_KM3_S2, MOON_RADIUS_KM } from './OrbitSystem';

export const ARRIVAL_VINF_KMS = 0.8;
export const G0 = 9.80665;
export const TCM_MARGIN_MS = 30;
export const SK_MS_PER_DAY_AT_50KM = 0.4;
export const SYNODIC_MONTH_DAYS = 29.53;
export const FIRST_WINDOW_CENTER_DAY = 7;
export const WINDOW_PENALTY_MS_PER_DAY = 60;
export const TRANSFER_DAYS = 4;
/** Calendario de juego: el día 0 de la campaña. */
export const CAMPAIGN_START = new Date(Date.UTC(2027, 2, 1));

export function loiDeltaV(altitudeKm: number): number {
  const r = MOON_RADIUS_KM + altitudeKm;
  return (Math.sqrt(ARRIVAL_VINF_KMS ** 2 + (2 * MOON_MU_KM3_S2) / r) - Math.sqrt(MOON_MU_KM3_S2 / r)) * 1000;
}

export function stationKeepingDeltaV(altitudeKm: number, days: number): number {
  return SK_MS_PER_DAY_AT_50KM * Math.pow(50 / altitudeKm, 1.5) * days;
}

export type WindowStatus = 'optimal' | 'marginal' | 'closed';

export interface WindowInfo {
  day: number;
  status: WindowStatus;
  /** Días de distancia al centro de la ventana más cercana. */
  offsetDays: number;
  penaltyMS: number;
  date: Date;
  arrivalDate: Date;
}

export function windowInfo(day: number): WindowInfo {
  const k = Math.round((day - FIRST_WINDOW_CENTER_DAY) / SYNODIC_MONTH_DAYS);
  const center = FIRST_WINDOW_CENTER_DAY + k * SYNODIC_MONTH_DAYS;
  const offsetDays = Math.abs(day - center);
  const status: WindowStatus = offsetDays <= 1 ? 'optimal' : offsetDays <= 3 ? 'marginal' : 'closed';
  const date = new Date(CAMPAIGN_START.getTime() + day * 86400000);
  return {
    day,
    status,
    offsetDays,
    penaltyMS: status === 'closed' ? Number.POSITIVE_INFINITY : Math.max(0, offsetDays - 1) * WINDOW_PENALTY_MS_PER_DAY,
    date,
    arrivalDate: new Date(date.getTime() + TRANSFER_DAYS * 86400000),
  };
}

export function firstOptimalDay(): number {
  for (let d = 0; d < 60; d++) if (windowInfo(d).status === 'optimal') return d;
  return 0;
}

/** Fracción de la superficie sobrevolada: latitudes entre −i y +i → sin(i). */
export function coverageFraction(inclinationDeg: number): number {
  const i = Math.min(inclinationDeg, 180 - inclinationDeg);
  return Math.sin((i * Math.PI) / 180);
}

export interface DeltaVBudget {
  loiMS: number;
  stationKeepingMS: number;
  tcmMS: number;
  windowPenaltyMS: number;
  requiredMS: number;
  ispS: number;
  wetKg: number;
  dryKg: number;
  availableMS: number;
  marginMS: number;
  /** Margen relativo frente a lo requerido. */
  marginFraction: number;
  ok: boolean;
}

export function deltaVBudget(
  design: SpacecraftDesign,
  lookup: ComponentLookup,
  plan: { altitudeKm: number; durationDays: number; launchDay: number },
): DeltaVBudget {
  const comps = designComponents(design, lookup);
  const engines = comps.filter((c) => c.ispS > 0);
  const ispS = engines.length ? Math.max(...engines.map((c) => c.ispS)) : 0;
  const t = designTotals(design, lookup);
  const availableMS = ispS > 0 && t.propellantKg > 0 ? ispS * G0 * Math.log(t.massWetKg / t.massDryKg) : 0;
  const w = windowInfo(plan.launchDay);
  const loiMS = loiDeltaV(plan.altitudeKm);
  const stationKeepingMS = stationKeepingDeltaV(plan.altitudeKm, plan.durationDays);
  const windowPenaltyMS = w.penaltyMS;
  const requiredMS = loiMS + stationKeepingMS + TCM_MARGIN_MS + windowPenaltyMS;
  const marginMS = availableMS - requiredMS;
  return {
    loiMS,
    stationKeepingMS,
    tcmMS: TCM_MARGIN_MS,
    windowPenaltyMS,
    requiredMS,
    ispS,
    wetKg: t.massWetKg,
    dryKg: t.massDryKg,
    availableMS,
    marginMS,
    marginFraction: Number.isFinite(requiredMS) && requiredMS > 0 ? marginMS / requiredMS : Number.NEGATIVE_INFINITY,
    ok: marginMS >= 0,
  };
}
