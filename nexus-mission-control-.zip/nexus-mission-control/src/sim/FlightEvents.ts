/**
 * FlightEvents — sistemas de la nave y eventos inesperados durante el vuelo Tierra → Luna
 * (Fases 8.2 y 8.3). Funciones puras: el estado vive en ui/flight/flightSim.
 *
 * Variables simuladas (se actualizan con el tiempo de misión):
 *  - Combustible de la nave (kg), con la regla del cohete para las correcciones de trayectoria.
 *  - Batería (Wh): carga de los paneles al sol (con sombra de la Tierra) menos el consumo.
 *  - Temperatura interior estimada (°C): modelo simplificado según sol/sombra y control térmico.
 *  - Comunicaciones: red (estaciones terrestres, satélites TDRS, Red de Espacio Profundo), calidad,
 *    retardo de la señal (distancia / velocidad de la luz).
 *  - Dosis de radiación estimada (mSv): ≈ 0,5 mSv/día en órbita baja y ≈ 1,8 mSv/día en el espacio
 *    profundo (medido por el instrumento RAD de Curiosity en su crucero a Marte).
 *
 * Eventos: aleatorios pero reproducibles (semilla por misión e intento), elegidos según la etapa
 * del vuelo y el diseño (sin control térmico, más calor; poco margen de energía, más problemas de
 * energía…), sin repetir el mismo evento ni la misma categoría seguida. Las decisiones cambian
 * variables reales y nunca terminan la misión: el combustible para frenar en la Luna está protegido.
 */

export const LIGHT_KMS = 299792.458;
const G0_MS = 9.80665;
export const DOSE_MSV_PER_DAY = { leo: 0.5, deep: 1.8 };

export type FlightWindow = 'ascent' | 'orbit' | 'cruise' | 'approach';

/** Datos de la misión que necesitan los sistemas y los eventos. */
export interface FlightCtx {
  hasThermal: boolean;
  antennaMbps: number;
  /** Margen de energía por órbita (fracción) y de Δv del plan. */
  energyMargin: number;
  dvMargin: number;
  batteryMaxWh: number;
  busLoadW: number;
  /** Generación de los paneles iluminados (W). */
  genW: number;
  propellantKg: number;
  dryKg: number;
  ispS: number;
  /** Combustible que se puede gastar sin poner en riesgo el frenado en la Luna. */
  spendableKg: number;
  /** false en el modo sandbox: solo eventos positivos. */
  problemsEnabled: boolean;
}

export interface FlightVars {
  propellantKg: number;
  /** Combustible gastado en imprevistos (se descuenta al llegar a Operaciones). */
  spentKg: number;
  batteryWh: number;
  tempBaseC: number;
  tempOffsetC: number;
  heatFault: boolean;
  commsDownUntil: number;
  commsFactor: number;
  commsFactorUntil: number;
  sensorFaultUntil: number;
  powerFactor: number;
  powerFactorUntil: number;
  extraLoadW: number;
  extraLoadUntil: number;
  trajErrorKm: number;
  /** Corrección pendiente más barata tras una medición precisa. */
  trajPrecise: boolean;
  doseMSv: number;
  scienceGbit: number;
  safeMode: boolean;
}

export function initialVars(ctx: FlightCtx): FlightVars {
  return {
    propellantKg: ctx.propellantKg,
    spentKg: 0,
    batteryWh: ctx.batteryMaxWh,
    tempBaseC: 21,
    tempOffsetC: 0,
    heatFault: false,
    commsDownUntil: -Infinity,
    commsFactor: 1,
    commsFactorUntil: -Infinity,
    sensorFaultUntil: -Infinity,
    powerFactor: 1,
    powerFactorUntil: -Infinity,
    extraLoadW: 0,
    extraLoadUntil: -Infinity,
    trajErrorKm: 0,
    trajPrecise: false,
    doseMSv: 0,
    scienceGbit: 0,
    safeMode: false,
  };
}

// ───────────────────────── Sistemas a lo largo del tiempo ─────────────────────────

export interface FlightEnv {
  /** La nave ya se separó del cohete / ya desplegó paneles. */
  separated: boolean;
  deployed: boolean;
  /** Dentro de la cofia (protegida del Sol). */
  inFairing: boolean;
  sunlit: boolean;
  /** En órbita baja (dosis menor, cinturones aparte). */
  nearEarth: boolean;
}

/** Avanza los sistemas de t0 a t1 (segundos de misión). */
export function stepVars(v: FlightVars, ctx: FlightCtx, t0: number, t1: number, env: FlightEnv): FlightVars {
  const n = { ...v };
  const dt = Math.max(0, t1 - t0);
  const dtH = dt / 3600;
  // Efectos con fecha de caducidad: el sistema se recupera solo.
  if (t1 >= n.commsFactorUntil) n.commsFactor = 1;
  if (t1 >= n.powerFactorUntil) n.powerFactor = 1;
  if (t1 >= n.extraLoadUntil) n.extraLoadW = 0;
  if (dt === 0) return n;
  // Energía.
  const gen = env.deployed && env.sunlit ? ctx.genW * n.powerFactor : 0;
  const load = (env.separated ? ctx.busLoadW : ctx.busLoadW * 0.6) * (n.safeMode ? 0.6 : 1) + n.extraLoadW;
  n.batteryWh = Math.max(0, Math.min(ctx.batteryMaxWh, n.batteryWh + (gen - load) * dtH));
  const frac = ctx.batteryMaxWh > 0 ? n.batteryWh / ctx.batteryMaxWh : 0;
  if (frac < 0.15) n.safeMode = true;
  else if (frac > 0.4) n.safeMode = false;
  // Temperatura interior estimada (constante de tiempo ≈ 1,5 h).
  const target = env.inFairing ? 22 : ctx.hasThermal ? (env.sunlit ? 24 : 12) : env.sunlit ? 46 : -18;
  n.tempBaseC += (target - n.tempBaseC) * (1 - Math.exp(-dtH / 1.5));
  if (!n.heatFault) n.tempOffsetC *= Math.exp(-dtH / 2);
  // Radiación.
  n.doseMSv += (env.nearEarth ? DOSE_MSV_PER_DAY.leo : DOSE_MSV_PER_DAY.deep) * (dt / 86400);
  return n;
}

export function temperatureC(v: FlightVars) {
  return v.tempBaseC + v.tempOffsetC;
}

export type CommsNetwork = 'ground' | 'tdrs' | 'dsn';
export const NETWORK_LABEL: Record<CommsNetwork, string> = {
  ground: 'Estaciones de seguimiento en tierra',
  tdrs: 'Satélites de retransmisión TDRS',
  dsn: 'Red de Espacio Profundo (DSN)',
};

export function commsStatus(v: FlightVars, ctx: FlightCtx, t: number, distanceKm: number, phase: 'ascent' | 'orbit' | 'deep') {
  const down = t < v.commsDownUntil;
  const quality = down ? 0 : Math.max(0, Math.min(1, v.commsFactor));
  const network: CommsNetwork = phase === 'ascent' ? 'ground' : phase === 'orbit' ? 'tdrs' : 'dsn';
  return {
    network,
    down,
    quality,
    /** Retardo de ida de la señal (s). */
    delayS: distanceKm / LIGHT_KMS,
    rateMbps: down ? 0 : ctx.antennaMbps * quality,
  };
}

// ───────────────────────── Efectos de las decisiones ─────────────────────────

export interface EffectSpec {
  propellantKg?: number;
  batteryWh?: number;
  tempOffsetC?: number;
  heatFault?: boolean;
  commsDownS?: number;
  clearComms?: boolean;
  commsFactor?: number;
  commsFactorS?: number;
  sensorFaultS?: number;
  clearSensor?: boolean;
  powerFactor?: number;
  powerFactorS?: number;
  extraLoadW?: number;
  extraLoadS?: number;
  trajErrorKm?: number;
  /** Corrige la desviación ahora (Δv = error / tiempo restante). */
  correctTrajectory?: boolean;
  trajPrecise?: boolean;
  /** Tiempo que pasa mientras se aplica la decisión (solo en el crucero). */
  advanceS?: number;
  doseMSv?: number;
  scienceGbit?: number;
}

/** Combustible (kg) para un cambio de velocidad, por la ecuación del cohete. */
export function propellantForDv(dvMS: number, ctx: FlightCtx, propNowKg: number) {
  const m0 = ctx.dryKg + propNowKg;
  return m0 * (1 - Math.exp(-dvMS / (Math.max(1, ctx.ispS) * G0_MS)));
}

/** Δv (m/s) para anular una desviación de `errKm` con `tgoS` segundos de antelación. */
export function correctionDv(errKm: number, tgoS: number) {
  return (errKm * 1000) / Math.max(1800, tgoS);
}

export interface Applied {
  vars: FlightVars;
  /** Cambios reales aplicados (para mostrarlos al jugador). */
  changes: string[];
  /** Si se protegió la reserva para frenar en la Luna. */
  reserveProtected: boolean;
}

const fmt = (x: number, d = 1) => x.toFixed(d).replace('.', ',');

export function applyEffects(v: FlightVars, ctx: FlightCtx, spec: EffectSpec, t: number, tArr: number): Applied {
  const n = { ...v };
  const changes: string[] = [];
  let reserveProtected = false;
  const spend = (kg: number) => {
    const room = Math.max(0, ctx.spendableKg - n.spentKg);
    const used = Math.min(kg, room);
    if (used < kg - 1e-9) reserveProtected = true;
    n.propellantKg -= used;
    n.spentKg += used;
    return used;
  };
  if (spec.correctTrajectory && n.trajErrorKm > 0) {
    const dv = correctionDv(n.trajErrorKm, tArr - t) * (n.trajPrecise ? 0.7 : 1);
    const need = propellantForDv(dv, ctx, n.propellantKg);
    const used = spend(need);
    const fixed = need > 0 ? used / need : 1;
    changes.push(`Corrección de ${fmt(dv)} m/s: −${fmt(used, 2)} kg de combustible`);
    n.trajErrorKm = n.trajErrorKm * (1 - fixed);
    n.trajPrecise = false;
  }
  if (spec.trajPrecise) n.trajPrecise = true;
  if (spec.propellantKg) {
    if (spec.propellantKg < 0) {
      const used = spend(-spec.propellantKg);
      changes.push(`−${fmt(used, 2)} kg de combustible`);
    } else {
      n.propellantKg += spec.propellantKg;
      n.spentKg -= spec.propellantKg;
      changes.push(`+${fmt(spec.propellantKg, 2)} kg de combustible ahorrado`);
    }
  }
  if (spec.batteryWh) {
    const before = n.batteryWh;
    n.batteryWh = Math.max(0, Math.min(ctx.batteryMaxWh, n.batteryWh + spec.batteryWh));
    const d = n.batteryWh - before;
    if (Math.abs(d) > 0.05) changes.push(`${d > 0 ? '+' : '−'}${fmt(Math.abs(d), 0)} Wh de batería`);
  }
  if (spec.tempOffsetC) {
    n.tempOffsetC += spec.tempOffsetC;
    changes.push(`${spec.tempOffsetC > 0 ? '+' : '−'}${fmt(Math.abs(spec.tempOffsetC), 0)} °C`);
  }
  if (spec.heatFault !== undefined) n.heatFault = spec.heatFault;
  if (spec.clearComms) n.commsDownUntil = -Infinity;
  if (spec.commsDownS) {
    n.commsDownUntil = t + spec.commsDownS;
    changes.push(`Sin comunicación ${fmtDuration(spec.commsDownS)}`);
  }
  if (spec.commsFactor !== undefined) {
    n.commsFactor = spec.commsFactor;
    n.commsFactorUntil = spec.commsFactorS ? t + spec.commsFactorS : Infinity;
    if (spec.commsFactor < 1) changes.push(`Señal al ${Math.round(spec.commsFactor * 100)} %${spec.commsFactorS ? ` ${fmtDuration(spec.commsFactorS)}` : ''}`);
  }
  if (spec.clearSensor) n.sensorFaultUntil = -Infinity;
  if (spec.sensorFaultS) {
    n.sensorFaultUntil = t + spec.sensorFaultS;
    changes.push(`Sensor fuera de servicio ${fmtDuration(spec.sensorFaultS)}`);
  }
  if (spec.powerFactor !== undefined) {
    n.powerFactor = spec.powerFactor;
    n.powerFactorUntil = spec.powerFactorS ? t + spec.powerFactorS : Infinity;
    if (spec.powerFactor < 1) changes.push(`Paneles al ${Math.round(spec.powerFactor * 100)} %${spec.powerFactorS ? ` ${fmtDuration(spec.powerFactorS)}` : ''}`);
  }
  if (spec.extraLoadW) {
    n.extraLoadW = spec.extraLoadW;
    n.extraLoadUntil = t + (spec.extraLoadS ?? 3600);
    changes.push(`${spec.extraLoadW > 0 ? '+' : '−'}${fmt(Math.abs(spec.extraLoadW), 0)} W de consumo ${fmtDuration(spec.extraLoadS ?? 3600)}`);
  }
  if (spec.trajErrorKm) {
    n.trajErrorKm += spec.trajErrorKm;
    changes.push(`Desviación de ${fmt(n.trajErrorKm, 0)} km`);
  }
  if (spec.doseMSv) {
    n.doseMSv += spec.doseMSv;
    changes.push(`+${fmt(spec.doseMSv, 0)} mSv de radiación`);
  }
  if (spec.scienceGbit) {
    n.scienceGbit += spec.scienceGbit;
    changes.push(`+${fmt(spec.scienceGbit, 1)} Gbit de ciencia`);
  }
  if (spec.advanceS) changes.push(`Tiempo empleado: ${fmt(spec.advanceS / 3600, spec.advanceS % 3600 ? 1 : 0)} h`);
  if (reserveProtected) changes.push('La reserva para frenar en la Luna está protegida');
  return { vars: n, changes, reserveProtected };
}

export function fmtDuration(s: number) {
  if (s >= 3600) {
    const h = s / 3600;
    return `durante ${fmt(h, h < 10 && h % 1 ? 1 : 0)} h`;
  }
  return `durante ${Math.round(s / 60)} min`;
}

// ───────────────────────── Catálogo de eventos ─────────────────────────

export type EventKind = 'problem' | 'positive' | 'discovery';
export type EventCategory = 'comms' | 'heat' | 'trajectory' | 'sensor' | 'fuel' | 'power' | 'radiation' | 'good';

export interface EffectCtx {
  ctx: FlightCtx;
  vars: FlightVars;
  t: number;
  tArr: number;
  window: FlightWindow;
  /** Magnitud aleatoria del evento (0–1), fijada al programarlo. */
  mag: number;
}

export interface EventOption {
  id: string;
  label: string;
  effect: (c: EffectCtx) => EffectSpec;
  outcome: string;
}

export interface FlightEventDef {
  id: string;
  kind: EventKind;
  category: EventCategory;
  title: string;
  windows: FlightWindow[];
  weight: (ctx: FlightCtx) => number;
  /** Mensaje del centro de control (lenguaje sencillo). */
  message: (c: EffectCtx) => string;
  /** Explicación de qué pasa y por qué. */
  explain: string;
  /** Lo que ocurre en cuanto aparece el evento (antes de decidir). */
  onTrigger?: (c: EffectCtx) => EffectSpec;
  options: EventOption[];
}

const inCruise = (w: FlightWindow) => w === 'cruise' || w === 'approach';

export const FLIGHT_EVENTS: FlightEventDef[] = [
  {
    id: 'comms-loss',
    kind: 'problem',
    category: 'comms',
    title: 'Pérdida temporal de comunicación',
    windows: ['orbit', 'cruise'],
    weight: (c) => (c.antennaMbps < 10 ? 2 : 1),
    message: () => '¡Perdimos la señal de la nave! La antena dejó de apuntar bien hacia la Tierra.',
    explain: 'Las antenas de alta ganancia envían un haz muy estrecho, como una linterna: si la nave gira un poco, el haz ya no llega a la Tierra.',
    onTrigger: () => ({ commsDownS: 1e9 }),
    options: [
      {
        id: 'wait',
        label: 'Esperar a que la nave se reoriente sola',
        effect: (c) => ({ clearComms: true, commsDownS: inCruise(c.window) ? 4 * 3600 : 15 * 60 }),
        outcome: 'El control automático corrige la orientación poco a poco; mientras tanto no recibimos datos.',
      },
      {
        id: 'low-gain',
        label: 'Pasar a la antena de respaldo (más lenta)',
        effect: (c) => ({ clearComms: true, commsFactor: 0.25, commsFactorS: inCruise(c.window) ? 12 * 3600 : 30 * 60, batteryWh: -15 }),
        outcome: 'La antena de respaldo no necesita apuntar con precisión: hay señal, pero muy lenta.',
      },
      {
        id: 'reorient',
        label: 'Encender los propulsores y apuntar a la Tierra',
        effect: () => ({ clearComms: true, propellantKg: -0.25 }),
        outcome: 'Un pequeño encendido devuelve la antena hacia la Tierra: señal recuperada al instante.',
      },
    ],
  },
  {
    id: 'overheat',
    kind: 'problem',
    category: 'heat',
    title: 'Temperatura elevada',
    windows: ['ascent', 'cruise'],
    weight: (c) => (c.hasThermal ? 0.6 : 2.5),
    message: (c) =>
      c.window === 'ascent'
        ? 'La cofia se está calentando por el roce con el aire y la temperatura dentro sube.'
        : 'Un lado de la nave lleva demasiado tiempo al Sol y se está calentando.',
    explain: 'En el espacio no hay aire que enfríe: el calor del Sol solo se va por radiación. Los equipos electrónicos funcionan bien entre unos 0 y 40 °C.',
    onTrigger: () => ({ tempOffsetC: 16, heatFault: true }),
    options: [
      {
        id: 'roll',
        label: 'Girar la nave para repartir el calor',
        effect: (c) => (c.window === 'ascent' ? { heatFault: false, batteryWh: -8 } : { heatFault: false, propellantKg: -0.15, tempOffsetC: -8 }),
        outcome: 'Girando despacio, ningún lado se queda siempre al Sol: la temperatura baja.',
      },
      {
        id: 'radiators',
        label: 'Encender los ventiladores y radiadores',
        effect: () => ({ heatFault: false, extraLoadW: 25, extraLoadS: 3 * 3600, tempOffsetC: -6 }),
        outcome: 'Los radiadores expulsan el calor, pero gastan energía de la batería.',
      },
      {
        id: 'wait',
        label: 'Esperar y vigilar',
        effect: () => ({ heatFault: false, sensorFaultS: 2 * 3600 }),
        outcome: 'La temperatura baja sola, pero el calor hace fallar un sensor durante un rato.',
      },
    ],
  },
  {
    id: 'trajectory',
    kind: 'problem',
    category: 'trajectory',
    title: 'Desviación de trayectoria',
    windows: ['cruise'],
    weight: () => 1.6,
    message: (c) => `El radar de la Red de Espacio Profundo indica que llegaremos a la Luna ${Math.round(400 + c.mag * 1100)} km desviados.`,
    explain: 'Un pequeño error en el encendido hacia la Luna se agranda con la distancia. Cuanto antes se corrige, menos combustible hace falta: el cambio de velocidad es la distancia a corregir dividida entre el tiempo que queda.',
    onTrigger: (c) => ({ trajErrorKm: Math.round(400 + c.mag * 1100) }),
    options: [
      {
        id: 'now',
        label: 'Corregir ahora',
        effect: () => ({ correctTrajectory: true }),
        outcome: 'Encendido corto de los propulsores: la nave vuelve a su camino.',
      },
      {
        id: 'measure',
        label: 'Medir mejor primero (6 h) y corregir después',
        effect: (c) => (c.window === 'cruise' ? { trajPrecise: true, advanceS: 6 * 3600 } : { correctTrajectory: true }),
        outcome: 'Con más mediciones, la corrección será más precisa y gastará un 30 % menos. Se aplicará al acercarnos a la Luna.',
      },
      {
        id: 'later',
        label: 'Dejarlo para la llegada',
        effect: () => ({}),
        outcome: 'Se corregirá al acercarnos a la Luna: con menos tiempo, costará más combustible.',
      },
    ],
  },
  {
    id: 'sensor',
    kind: 'problem',
    category: 'sensor',
    title: 'Anomalía de sensores',
    windows: ['orbit', 'cruise', 'approach'],
    weight: () => 1,
    message: () => 'El sensor de estrellas envía datos extraños: la nave no está segura de hacia dónde mira.',
    explain: 'La nave se orienta fotografiando estrellas y comparándolas con un mapa. Un destello de luz o una partícula pueden confundirlo.',
    onTrigger: () => ({ sensorFaultS: 1e9 }),
    options: [
      {
        id: 'reboot',
        label: 'Reiniciar el sensor (30 min)',
        effect: () => ({ clearSensor: true, sensorFaultS: 1800, batteryWh: -5 }),
        outcome: 'Tras reiniciarse, el sensor vuelve a reconocer las estrellas.',
      },
      {
        id: 'backup',
        label: 'Usar el sensor de Sol de respaldo',
        effect: () => ({ clearSensor: true, propellantKg: -0.1 }),
        outcome: 'El sensor de Sol es menos preciso: hace falta un pequeño ajuste con los propulsores.',
      },
      {
        id: 'ignore',
        label: 'Seguir sin él',
        effect: (c) => ({ clearSensor: true, sensorFaultS: 8 * 3600, trajErrorKm: inCruise(c.window) ? 150 : 0 }),
        outcome: 'Sin el sensor, la nave navega «a ciegas» unas horas y se desvía un poco.',
      },
    ],
  },
  {
    id: 'fuel-leak',
    kind: 'problem',
    category: 'fuel',
    title: 'Consumo elevado de combustible',
    windows: ['cruise', 'approach'],
    weight: (c) => (c.dvMargin < 0.25 ? 1.5 : 1),
    message: () => 'Un propulsor pequeño se quedó encendido más de la cuenta y estamos gastando combustible.',
    explain: 'Los propulsores de orientación se abren con válvulas. Si una no cierra del todo, el combustible se escapa poco a poco.',
    onTrigger: () => ({ propellantKg: -0.3 }),
    options: [
      {
        id: 'backup-valve',
        label: 'Cerrar esa línea y usar la de respaldo',
        effect: () => ({ propellantKg: -0.1, advanceS: 3600 }),
        outcome: 'Línea aislada en una hora: la fuga se detiene.',
      },
      {
        id: 'wheels',
        label: 'Apagar los propulsores y orientar con las ruedas de reacción',
        effect: () => ({ extraLoadW: 20, extraLoadS: 10 * 3600 }),
        outcome: 'Las ruedas giran por dentro para orientar la nave: no gastan combustible, pero sí electricidad.',
      },
      {
        id: 'monitor',
        label: 'Seguir y vigilar',
        effect: () => ({ propellantKg: -1.2 }),
        outcome: 'La válvula termina cerrando sola, pero se perdió bastante combustible.',
      },
    ],
  },
  {
    id: 'power',
    kind: 'problem',
    category: 'power',
    title: 'Problemas de energía',
    windows: ['cruise'],
    weight: (c) => (c.energyMargin < 0.15 ? 2.5 : 0.8),
    message: () => 'Un panel solar no terminó de abrirse: la nave genera menos electricidad.',
    explain: 'Los paneles viajan plegados en la cofia y se abren con bisagras y muelles. Si uno se atasca, recibe menos luz.',
    onTrigger: () => ({ powerFactor: 0.55 }),
    options: [
      {
        id: 'shake',
        label: 'Girar la nave para sacudir el panel',
        effect: () => ({ powerFactor: 1, propellantKg: -0.3 }),
        outcome: 'El giro destraba la bisagra: el panel se abre del todo.',
      },
      {
        id: 'save',
        label: 'Apagar equipos que no son esenciales',
        effect: () => ({ powerFactor: 0.55, powerFactorS: 30 * 3600, extraLoadW: -12, extraLoadS: 30 * 3600 }),
        outcome: 'Con menos consumo, la batería aguanta hasta que el calor del Sol dilata la bisagra.',
      },
      {
        id: 'heat',
        label: 'Esperar a que el Sol caliente la bisagra (8 h)',
        effect: () => ({ powerFactor: 0.55, powerFactorS: 8 * 3600, advanceS: 8 * 3600 }),
        outcome: 'Tras unas horas al Sol, el metal se dilata y el panel termina de abrirse.',
      },
    ],
  },
  {
    id: 'interference',
    kind: 'problem',
    category: 'comms',
    title: 'Interferencia de comunicación',
    windows: ['orbit', 'cruise'],
    weight: () => 1,
    message: () => 'Hay mucho ruido en la señal: otras transmisiones se mezclan con la nuestra.',
    explain: 'La radio funciona en frecuencias concretas. Si otra emisora o el propio Sol emiten en la misma, la señal llega con errores.',
    onTrigger: () => ({ commsFactor: 0.35 }),
    options: [
      {
        id: 'band',
        label: 'Cambiar a otra frecuencia',
        effect: () => ({ commsFactor: 0.8, commsFactorS: 6 * 3600, batteryWh: -8 }),
        outcome: 'En la nueva frecuencia hay menos ruido, aunque es algo más lenta.',
      },
      {
        id: 'power-up',
        label: 'Aumentar la potencia del transmisor',
        effect: () => ({ commsFactor: 1, extraLoadW: 30, extraLoadS: 4 * 3600 }),
        outcome: 'Más potencia «grita» por encima del ruido, pero gasta más batería.',
      },
      {
        id: 'wait',
        label: 'Esperar a que pase',
        effect: (c) => ({ commsFactor: 0.35, commsFactorS: inCruise(c.window) ? 10 * 3600 : 20 * 60 }),
        outcome: 'La interferencia desaparece sola, pero mientras tanto llegan pocos datos.',
      },
    ],
  },
  {
    id: 'radiation',
    kind: 'problem',
    category: 'radiation',
    title: 'Radiación solar elevada',
    windows: ['cruise', 'approach'],
    weight: () => 0.9,
    message: () => 'El Sol lanzó una tormenta de partículas que llegará a la nave en unos minutos.',
    explain: 'En las tormentas solares el Sol expulsa protones muy rápidos. Pueden borrar memorias y dañar circuitos; la Tierra nos protege con su campo magnético, pero aquí no.',
    options: [
      {
        id: 'safe-mode',
        label: 'Modo seguro: apagar instrumentos y esperar (8 h)',
        effect: () => ({ doseMSv: 4, advanceS: 8 * 3600, batteryWh: 20 }),
        outcome: 'Con todo apagado, la tormenta pasa sin daños.',
      },
      {
        id: 'shield',
        label: 'Girar el lado más blindado hacia el Sol',
        effect: () => ({ doseMSv: 10, propellantKg: -0.2 }),
        outcome: 'El tanque y la estructura hacen de escudo: llega poca radiación.',
      },
      {
        id: 'continue',
        label: 'Seguir como si nada',
        effect: () => ({ doseMSv: 35, sensorFaultS: 6 * 3600 }),
        outcome: 'La radiación provoca errores en un sensor y la nave recibe más dosis.',
      },
    ],
  },
  // ── Eventos positivos y descubrimientos ──
  {
    id: 'good-alignment',
    kind: 'positive',
    category: 'good',
    title: '¡Trayectoria casi perfecta!',
    windows: ['cruise'],
    weight: () => 1,
    message: () => 'Las mediciones confirman que el encendido hacia la Luna fue muy preciso.',
    explain: 'El presupuesto de combustible guarda una reserva para correcciones. Si el encendido fue bueno, parte de esa reserva queda libre.',
    options: [
      {
        id: 'save',
        label: 'Guardar el combustible para la Luna',
        effect: () => ({ propellantKg: 0.4 }),
        outcome: 'Ese combustible servirá para mantener la órbita lunar más tiempo.',
      },
      {
        id: 'photo',
        label: 'Usarlo para girar y fotografiar la Tierra',
        effect: () => ({ scienceGbit: 1.5 }),
        outcome: 'Una foto de la Tierra entera, ¡vista desde lejos!',
      },
    ],
  },
  {
    id: 'earth-moon',
    kind: 'discovery',
    category: 'good',
    title: 'Descubrimiento: la Tierra y la Luna juntas',
    windows: ['cruise'],
    weight: () => 1,
    message: () => 'Desde aquí se ven la Tierra y la Luna en la misma imagen. ¡Pocas naves lo han fotografiado!',
    explain: 'Visto desde lejos, se aprecia que la Luna es mucho más oscura que la Tierra: refleja solo un 12 % de la luz, como el asfalto.',
    options: [
      {
        id: 'send',
        label: 'Tomar la foto y enviarla a la Tierra',
        effect: () => ({ scienceGbit: 2, batteryWh: -6 }),
        outcome: 'La foto llega a la Tierra y se comparte con todo el equipo.',
      },
      {
        id: 'skip',
        label: 'Ahorrar energía para la misión',
        effect: () => ({}),
        outcome: 'Decisión prudente: la batería queda intacta.',
      },
    ],
  },
  {
    id: 'dsn-bonus',
    kind: 'positive',
    category: 'good',
    title: 'Antena extra disponible',
    windows: ['cruise'],
    weight: (c) => (c.antennaMbps > 0 ? 1 : 0),
    message: () => 'Una antena gigante de la Red de Espacio Profundo quedó libre y nos la prestan unas horas.',
    explain: 'Las antenas de la DSN miden hasta 70 m. Cuanto más grande es la antena en tierra, más débil puede ser la señal que recibe.',
    options: [
      {
        id: 'download',
        label: 'Enviar datos de calibración',
        effect: () => ({ scienceGbit: 3, commsFactor: 1, batteryWh: -10 }),
        outcome: 'Se envían los datos de prueba de los instrumentos: útiles para la ciencia en la Luna.',
      },
      {
        id: 'skip',
        label: 'No hace falta, gracias',
        effect: () => ({}),
        outcome: 'La antena vuelve a otra misión.',
      },
    ],
  },
  {
    id: 'sun-boost',
    kind: 'positive',
    category: 'good',
    title: 'Paneles mejor de lo previsto',
    windows: ['cruise'],
    weight: () => 1,
    message: () => 'Los paneles solares están fríos y rinden más de lo calculado.',
    explain: 'Las células solares producen más electricidad cuando están frías: el espacio profundo es un buen lugar para ellas.',
    options: [
      {
        id: 'charge',
        label: 'Cargar la batería al máximo',
        effect: (c) => ({ batteryWh: c.ctx.batteryMaxWh }),
        outcome: 'Batería llena para la llegada a la Luna.',
      },
    ],
  },
  {
    id: 'lunar-flash',
    kind: 'discovery',
    category: 'good',
    title: 'Descubrimiento: destello en la Luna',
    windows: ['approach'],
    weight: () => 1,
    message: () => 'La cámara registró un destello en la cara oscura de la Luna. ¡Un meteorito acaba de chocar!',
    explain: 'La Luna no tiene atmósfera que frene los meteoritos: cuando chocan, se ven breves destellos de luz. La NASA los observa desde la Tierra.',
    options: [
      {
        id: 'record',
        label: 'Grabar y enviar el destello',
        effect: () => ({ scienceGbit: 2.5, batteryWh: -8 }),
        outcome: 'Las imágenes ayudarán a saber cuántos meteoritos llegan a la Luna.',
      },
      {
        id: 'skip',
        label: 'Concentrarse en la llegada',
        effect: () => ({}),
        outcome: 'Prioridad a la maniobra de frenado.',
      },
    ],
  },
  {
    id: 'meteor-shower',
    kind: 'discovery',
    category: 'good',
    title: 'Descubrimiento: lluvia de meteoros',
    windows: ['orbit'],
    weight: () => 1,
    message: () => 'Desde la órbita vemos estrellas fugaces por debajo de la nave, sobre la Tierra.',
    explain: 'Las estrellas fugaces son granos de polvo que arden al entrar en la atmósfera, a unos 100 km de altura: ¡por debajo de nuestra órbita!',
    options: [
      {
        id: 'record',
        label: 'Grabar con la cámara de la nave',
        effect: () => ({ scienceGbit: 0.8, batteryWh: -4 }),
        outcome: 'Un vídeo único de meteoros vistos desde arriba.',
      },
    ],
  },
];

export function eventById(id: string) {
  return FLIGHT_EVENTS.find((e) => e.id === id);
}

// ───────────────────────── Programación aleatoria coherente ─────────────────────────

export interface ScheduledFlightEvent {
  id: string;
  t: number;
  window: FlightWindow;
  mag: number;
}

export interface FlightWindows {
  ascent: [number, number];
  orbit: [number, number];
  cruise: [number, number];
  approach: [number, number];
}

function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function seedFrom(text: string, attempt: number) {
  let h = 2166136261;
  for (let i = 0; i < text.length; i++) h = Math.imul(h ^ text.charCodeAt(i), 16777619);
  return (h ^ (attempt * 0x9e3779b1)) >>> 0;
}

/**
 * Elige 3–4 eventos: uno en el ascenso u órbita (a veces), dos en el crucero (al menos uno positivo)
 * y uno en la aproximación. Sin repetir eventos ni el mismo tipo de problema seguido; con pesos según el diseño.
 */
export function scheduleFlightEvents(ctx: FlightCtx, w: FlightWindows, seed: number): ScheduledFlightEvent[] {
  const r = rng(seed);
  const used = new Set<string>();
  let lastCat: EventCategory | null = null;
  const pick = (win: FlightWindow, kind?: EventKind[]): FlightEventDef | null => {
    const pool = FLIGHT_EVENTS.filter(
      (e) => e.windows.includes(win) && !used.has(e.id) && (e.category === 'good' || e.category !== lastCat) && (!kind || kind.includes(e.kind)) && (ctx.problemsEnabled || e.kind !== 'problem'),
    );
    const weights = pool.map((e) => Math.max(0, e.weight(ctx)));
    const total = weights.reduce((a, b) => a + b, 0);
    if (!pool.length || total <= 0) return null;
    let x = r() * total;
    for (let i = 0; i < pool.length; i++) {
      x -= weights[i];
      if (x <= 0) return pool[i];
    }
    return pool[pool.length - 1];
  };
  const out: ScheduledFlightEvent[] = [];
  const add = (e: FlightEventDef | null, win: FlightWindow, t: number) => {
    if (!e) return;
    used.add(e.id);
    lastCat = e.category;
    out.push({ id: e.id, t, window: win, mag: r() });
  };
  const at = (win: [number, number], u: number) => win[0] + (win[1] - win[0]) * u;
  // Ascenso u órbita (70 %). En el ascenso solo cabe el calentamiento: más probable sin control térmico.
  if (r() < 0.7) {
    const heat = FLIGHT_EVENTS.find((e) => e.id === 'overheat')!.weight(ctx);
    const win: FlightWindow = ctx.problemsEnabled && r() < 0.35 * Math.min(1, heat / 2.5) ? 'ascent' : 'orbit';
    add(pick(win), win, at(w[win], 0.2 + r() * 0.6));
  }
  // Crucero: un problema y un evento positivo, en orden aleatorio y separados.
  const firstGood = r() < 0.5;
  const kindsA: EventKind[] = firstGood ? ['positive', 'discovery'] : ['problem'];
  const kindsB: EventKind[] = firstGood ? ['problem'] : ['positive', 'discovery'];
  add(pick('cruise', ctx.problemsEnabled ? kindsA : undefined), 'cruise', at(w.cruise, 0.1 + r() * 0.3));
  add(pick('cruise', ctx.problemsEnabled ? kindsB : undefined), 'cruise', at(w.cruise, 0.55 + r() * 0.35));
  // Aproximación.
  add(pick('approach'), 'approach', at(w.approach, 0.2 + r() * 0.5));
  return out.sort((a, b) => a.t - b.t);
}

/** Reparaciones disponibles desde el panel de sistemas (recuperar el funcionamiento). */
export const REPAIRS: Record<'comms' | 'sensor' | 'power' | 'heat', { label: string; effect: EffectSpec; text: string }> = {
  comms: { label: 'Reorientar la antena', effect: { clearComms: true, commsFactor: 1, propellantKg: -0.2 }, text: 'Antena reorientada: comunicación recuperada.' },
  sensor: { label: 'Reiniciar el sensor', effect: { clearSensor: true, batteryWh: -5 }, text: 'Sensor reiniciado.' },
  power: { label: 'Sacudir el panel', effect: { powerFactor: 1, propellantKg: -0.3 }, text: 'Panel desplegado del todo: energía recuperada.' },
  heat: { label: 'Girar la nave', effect: { heatFault: false, tempOffsetC: -8, propellantKg: -0.15 }, text: 'Calor repartido: temperatura bajando.' },
};
