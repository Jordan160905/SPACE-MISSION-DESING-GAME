/**
 * Pruebas del motor (Fase 3). Los valores esperados se calcularon de forma independiente
 * (hoja de cálculo / Python) a partir de las fórmulas documentadas en cada módulo.
 */
import { describe, expect, it } from 'vitest';
import { getComponent } from '../data/components/catalog';
import { LAUNCHERS } from '../data/launchers/launchers';
import { LUNA_01 } from '../data/missions/missions';
import type { SpacecraftDesign } from '../data/schemas';
import { analyzeComms, analyzeData } from './DataSystem';
import { EMPTY_DESIGN, placePart, setChassis } from './DesignSystem';
import { analyzeEngineering } from './EngineeringAnalysis';
import { analyzeMass } from './MassSystem';
import { analyzeOrbit, eclipseFraction, orbitalPeriodS, referenceOrbit } from './OrbitSystem';
import { analyzePower } from './PowerSystem';

const L = getComponent;
function build(chassisId: string, parts: Array<[string, string]>): SpacecraftDesign {
  let d = setChassis(EMPTY_DESIGN, chassisId, L).design;
  for (const [c, s] of parts) d = placePart(d, c, s, L).design;
  return d;
}

const CAMERA_REF = build('chassis-m', [
  ['camera', 'bottom-0'],
  ['thruster', 'bottom-1'],
  ['antenna-hg', 'top-0'],
  ['attitude-sensor', 'side-pz-0'],
  ['solar-adv', 'side-px-0'],
  ['solar-adv', 'side-nx-0'],
  ['battery-adv', 'bay-0'],
  ['obc', 'bay-1'],
  ['prop-tank', 'bay-2'],
  ['thermal', 'bay-3'],
]);

const RADAR_PARTS: Array<[string, string]> = [
  ['radar', 'bottom-0'],
  ['thruster', 'bottom-1'],
  ['antenna-hg', 'top-0'],
  ['attitude-sensor', 'side-pz-0'],
  ['thermal', 'side-nz-0'],
  ['solar-adv', 'side-px-0'],
  ['solar-adv', 'side-nx-0'],
  ['battery-adv', 'bay-0'],
  ['obc', 'bay-1'],
  ['prop-tank', 'bay-2'],
  ['reaction-wheels', 'bay-3'],
];

describe('OrbitSystem', () => {
  it('periodo de Kepler: 75 km → 115,40 min (LRO a ~50 km: ~113 min)', () => {
    expect(orbitalPeriodS(75)).toBeCloseTo(6923.71, 1);
    expect(orbitalPeriodS(55) / 60).toBeCloseTo(113.49, 2);
  });

  it('fracción de eclipse = asin(R/(R+h))/π, y disminuye con la altitud', () => {
    expect(eclipseFraction(75)).toBeCloseTo(0.408108, 5);
    expect(eclipseFraction(115)).toBeLessThan(eclipseFraction(75));
  });

  it('velocidad, contacto y hueco diario', () => {
    const o = analyzeOrbit({ altitudeKm: 75, inclinationDeg: 90 });
    expect(o.velocityKmS).toBeCloseTo(1.6447, 4);
    expect(o.contactFraction).toBeCloseTo((1 - 0.408108) * (8 / 24), 5);
    expect(o.maxGapH).toBe(16);
    expect(o.sunlitMin + o.eclipseMin).toBeCloseTo(o.periodMin, 9);
  });

  it('órbita de referencia = punto medio de la recomendada', () => {
    expect(referenceOrbit(LUNA_01.objectives[0])).toEqual({ altitudeKm: 75, inclinationDeg: 90 });
    expect(() => analyzeOrbit({ altitudeKm: 0, inclinationDeg: 90 })).toThrow();
  });
});

describe('PowerSystem', () => {
  const orbit = analyzeOrbit({ altitudeKm: 75, inclinationDeg: 90 });

  it('diseño de cámara: cargas, energía de eclipse y descarga calculadas a mano', () => {
    const p = analyzePower(CAMERA_REF, L, orbit);
    expect(p.nominalGenW).toBe(640);
    expect(p.sunlitGenW).toBeCloseTo(576, 9);
    expect(p.busLoadW).toBe(40); // computadora 20 + sensor 8 + térmico 12 (el propulsor no cuenta)
    expect(p.sunlitLoadW).toBeCloseTo(83.8784, 3); // + cámara 35 + antena 45 × contacto
    expect(p.eclipseLoadW).toBeCloseTo(48.8784, 3); // la cámara no trabaja en la sombra
    expect(p.eclipseEnergyWh).toBeCloseTo(38.3644, 3);
    expect(p.depthOfDischarge).toBeCloseTo(0.042627, 5);
    expect(p.orbitBalanceWh).toBeCloseTo(517.583, 2);
    expect(p.autonomyH).toBeCloseTo(12.889, 2);
    expect(p.sustainable).toBe(true);
  });

  it('radar a 55 km: funciona también en la sombra', () => {
    const o = analyzeOrbit({ altitudeKm: 55, inclinationDeg: 90 });
    const p = analyzePower(build('chassis-m', RADAR_PARTS), L, o);
    expect(p.eclipseLoadW).toBeCloseTo(253.686, 2);
    expect(p.eclipseEnergyWh).toBeCloseTo(201.988, 2);
    expect(p.depthOfDischarge).toBeCloseTo(0.2244, 3);
    expect(p.orbitBalanceWh).toBeCloseTo(128.597, 2);
  });

  it('radar con un solo panel avanzado: balance negativo', () => {
    const o = analyzeOrbit({ altitudeKm: 55, inclinationDeg: 90 });
    const parts = RADAR_PARTS.filter(([, s]) => s !== 'side-nx-0');
    const p = analyzePower(build('chassis-m', parts), L, o);
    expect(p.orbitBalanceWh).toBeCloseTo(-186.847, 2);
    expect(p.sustainable).toBe(false);
  });
});

describe('DataSystem', () => {
  it('cámara: produce 255,7 Gbit/día, el enlace admite 681,9 y llegan 15 342 Gbit en 60 días', () => {
    const o = analyzeOrbit({ altitudeKm: 75, inclinationDeg: 90 });
    const c = analyzeComms(CAMERA_REF, L, o);
    const d = analyzeData(CAMERA_REF, L, o, c, { durationDays: 60, targetGbit: 2000 });
    expect(c.downlinkGbitPerDay).toBeCloseTo(681.86, 1);
    expect(d.avgGenGbitPerH).toBeCloseTo(10.654, 2);
    expect(d.genGbitPerDay).toBeCloseTo(255.697, 2);
    expect(d.bufferNeededGbit).toBeCloseTo(170.465, 2);
    expect(d.lostPerDayGbit).toBe(0);
    expect(d.missionDeliveredGbit).toBeCloseTo(15341.84, 0);
    expect(d.targetMet).toBe(true);
  });

  it('radar: la memoria de 256 Gbit no cubre 16 h sin contacto → se pierden 224 Gbit/día', () => {
    const o = analyzeOrbit({ altitudeKm: 55, inclinationDeg: 90 });
    const design = build('chassis-m', RADAR_PARTS);
    const c = analyzeComms(design, L, o);
    const d = analyzeData(design, L, o, c, { durationDays: 60, targetGbit: 3000 });
    expect(d.lostPerDayGbit).toBeCloseTo(224, 9);
    expect(d.deliveredGbitPerDay).toBeCloseTo(496, 9);
    expect(d.targetMet).toBe(true);
  });

  it('antena básica con cámara: el enlace limita', () => {
    const o = analyzeOrbit({ altitudeKm: 75, inclinationDeg: 90 });
    const design = { ...CAMERA_REF, parts: CAMERA_REF.parts.map((p) => (p.componentId === 'antenna-hg' ? { ...p, componentId: 'antenna-basic' } : p)) };
    const c = analyzeComms(design, L, o);
    const d = analyzeData(design, L, o, c, { durationDays: 60, targetGbit: 2000 });
    expect(c.downlinkGbitPerDay).toBeCloseTo(681.86 / 20, 1); // 2 Mbps frente a 40 Mbps
    expect(d.deliveredGbitPerDay).toBeCloseTo(c.downlinkGbitPerDay, 9);
    expect(d.missionDeliveredGbit).toBeCloseTo(2045.58, 0); // apenas supera las 2000
  });
});

describe('MassSystem', () => {
  it('margen del 10 % sobre masa seca y lanzadores capaces', () => {
    const m = analyzeMass(CAMERA_REF, L, LAUNCHERS);
    expect(m.wetKg).toBe(260);
    expect(m.marginKg).toBeCloseTo(18, 9);
    expect(m.wetWithMarginKg).toBeCloseTo(278, 9);
    expect(m.launchersThatFit).toEqual(['minotaur-iv', 'falcon-9']);
  });
});

describe('EngineeringAnalysis', () => {
  it('el diseño de referencia es viable para cartografía', () => {
    const r = analyzeEngineering({ design: CAMERA_REF, lookup: L, template: LUNA_01, objectiveId: 'obj-mapping' });
    expect(r.issues.filter((i) => i.severity === 'critical')).toEqual([]);
    expect(r.viable).toBe(true);
    // presupuesto: nave 40,6 + operación 60 × 0,25 = 15 → 55,6 comprometidos
    expect(r.budget!.committedMUSD).toBeCloseTo(55.6, 9);
    expect(r.budget!.lines.find((l) => l.id === 'operations')!.amountMUSD).toBe(15);
  });

  it('sin chasis: no viable y sin análisis numérico', () => {
    const r = analyzeEngineering({ design: EMPTY_DESIGN, lookup: L, template: LUNA_01, objectiveId: 'obj-mapping' });
    expect(r.viable).toBe(false);
    expect(r.power).toBe(null);
  });

  it('balance energético negativo → crítico', () => {
    const parts = RADAR_PARTS.filter(([, s]) => s !== 'side-nx-0');
    const r = analyzeEngineering({ design: build('chassis-m', parts), lookup: L, template: LUNA_01, objectiveId: 'obj-polar-ice' });
    expect(r.issues.find((i) => i.id === 'energy-balance')?.severity).toBe('critical');
    expect(r.viable).toBe(false);
  });

  it('descarga de batería alta: batería básica con radar → optimización (50 %)', () => {
    const parts = RADAR_PARTS.map(([c, s]) => [c === 'battery-adv' ? 'battery-basic' : c, s] as [string, string]);
    const r = analyzeEngineering({ design: build('chassis-m', parts), lookup: L, template: LUNA_01, objectiveId: 'obj-polar-ice' });
    expect(r.issues.find((i) => i.id === 'battery-dod-high')?.severity).toBe('optimization');
    expect(r.issues.find((i) => i.id === 'data-buffer')?.severity).toBe('optimization');
    expect(r.viable).toBe(true);
  });

  it('objetivo de datos inalcanzable → crítico', () => {
    // Espectrómetro con antena básica en una campaña corta: 900 Gbit no llegan.
    const parts: Array<[string, string]> = [
      ['spectrometer', 'bottom-0'],
      ['thruster', 'bottom-1'],
      ['antenna-basic', 'top-0'],
      ['attitude-sensor', 'side-pz-0'],
      ['solar-adv', 'side-px-0'],
      ['battery-adv', 'bay-0'],
      ['obc', 'bay-1'],
      ['prop-tank', 'bay-2'],
      ['thermal', 'bay-3'],
    ];
    const short = { ...LUNA_01, durationDays: 20 };
    const r = analyzeEngineering({ design: build('chassis-m', parts), lookup: L, template: short, objectiveId: 'obj-mineral' });
    expect(r.issues.find((i) => i.id === 'data-target')?.severity).toBe('critical');
  });

  it('sin presupuesto para lanzador → crítico', () => {
    const tight = { ...LUNA_01, budgetCapMUSD: 70 }; // 55,6 comprometidos, el más barato cuesta 28
    const r = analyzeEngineering({ design: CAMERA_REF, lookup: L, template: tight, objectiveId: 'obj-mapping' });
    expect(r.issues.find((i) => i.id === 'budget-no-launcher')?.severity).toBe('critical');
  });

  it('el análisis sustituye los avisos simples de potencia de la Fase 2', () => {
    const r = analyzeEngineering({ design: CAMERA_REF, lookup: L, template: LUNA_01, objectiveId: 'obj-mapping' });
    expect(r.issues.some((i) => ['power-deficit', 'power-margin', 'downlink-bottleneck'].includes(i.id))).toBe(false);
  });
});

describe('coherencia entre pantallas', () => {
  it('con plan, el análisis usa su lanzador, su duración y su órbita', async () => {
    const { analysisInputForMission } = await import('./EngineeringAnalysis');
    const { getMissionTemplate } = await import('../data/missions/missions');
    const mission = {
      templateId: 'luna-01',
      objectiveId: 'obj-mapping',
      plan: { launcherId: 'minotaur-iv', altitudeKm: 120, inclinationDeg: 88, durationDays: 90, launchDay: 7 },
    };
    const r = analyzeEngineering(analysisInputForMission(CAMERA_REF, L, mission, getMissionTemplate));
    expect(r.orbit.altitudeKm).toBe(120);
    expect(r.budget!.lines.find((l) => l.id === 'operations')!.amountMUSD).toBeCloseTo(22.5, 9);
    expect(r.budget!.lines.find((l) => l.id === 'launch')!.amountMUSD).toBe(50);
    const noPlan = analyzeEngineering(analysisInputForMission(CAMERA_REF, L, { ...mission, plan: null }, getMissionTemplate));
    expect(noPlan.budget!.lines.find((l) => l.id === 'launch')!.amountMUSD).toBe(null);
  });
});
