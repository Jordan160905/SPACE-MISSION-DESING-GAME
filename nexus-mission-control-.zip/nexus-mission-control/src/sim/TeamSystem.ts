/**
 * TeamSystem — modo equipo para 2–4 personas en la misma computadora.
 *
 * Cada rol defiende una prioridad distinta, medida con los números reales del análisis. Las
 * prioridades chocan a propósito (más paneles = más energía pero más masa y costo; un cohete más
 * fiable = menos riesgo pero menos presupuesto), así que el equipo tiene que negociar.
 * Las decisiones clave se votan: gana la mayoría y, en empate, decide la dirección de misión.
 */
import type { TeamDecision, TeamRole } from '../data/schemas';
import type { EngineeringReport } from './EngineeringAnalysis';
import type { PlanReport } from './PlanningSystem';
import { fmtNum } from './units';

export interface RoleDef {
  id: TeamRole;
  label: string;
  priority: string;
  /** Recursos que vigila (ids de ResourceSystem). */
  watches: string[];
}

export const ROLES: RoleDef[] = [
  { id: 'director', label: 'Dirección de misión', priority: 'Que la misión quepa en el presupuesto y llegue a tiempo a la ventana de lanzamiento.', watches: ['budget', 'time'] },
  { id: 'scientist', label: 'Ciencia', priority: 'Devolver la mayor cantidad de datos útiles, desde la órbita que mejor sirve al instrumento.', watches: ['data'] },
  { id: 'engineer', label: 'Ingeniería de sistemas', priority: 'Márgenes sanos de energía, batería y propelente para que la nave sobreviva a lo inesperado.', watches: ['energy', 'mass'] },
  { id: 'operations', label: 'Operaciones', priority: 'Un lanzamiento fiable y un enlace que no pierda datos entre contactos.', watches: ['comms'] },
];

export const roleDef = (id: TeamRole): RoleDef => ROLES.find((r) => r.id === id)!;

export interface RoleGoal {
  role: TeamRole;
  met: boolean;
  /** Qué exige el rol, con umbral. */
  goal: string;
  /** Situación actual con números. */
  status: string;
}

/** Metas de cada rol con los números actuales. Sin plan, las que dependen de él quedan sin cumplir. */
export function roleGoals(e: EngineeringReport, plan: PlanReport | null): RoleGoal[] {
  const reserve = e.budget && e.budget.capMUSD > 0 ? e.budget.remainingMUSD / e.budget.capMUSD : -1;
  const sched = e.schedule?.reserveMonths ?? -1;
  const dataRatio = e.data && e.data.targetGbit > 0 ? e.data.missionDeliveredGbit / e.data.targetGbit : 0;
  const eMargin = e.power && e.power.rechargeNeededWh > 0 ? e.power.orbitBalanceWh / e.power.rechargeNeededWh : -1;
  const dvMargin = plan?.deltaV.marginFraction ?? -1;
  const reliability = plan?.launcher.reliability ?? 0;
  const lost = e.data?.lostPerDayGbit ?? Infinity;
  return [
    {
      role: 'director',
      met: reserve >= 0.1 && sched >= 3,
      goal: 'Reserva de presupuesto ≥ 10 % y de calendario ≥ 3 meses',
      status: `Reserva ${Math.round(reserve * 100)} % · ${Number.isFinite(sched) ? fmtNum(sched, 1) : '—'} meses`,
    },
    {
      role: 'scientist',
      met: dataRatio >= 1.3,
      goal: 'Datos previstos ≥ 130 % del objetivo (margen ante imprevistos)',
      status: `${Math.round(dataRatio * 100)} % del objetivo`,
    },
    {
      role: 'engineer',
      met: eMargin >= 0.2 && !!e.power && e.power.depthOfDischarge <= 0.4 && dvMargin >= 0.15,
      goal: 'Energía ≥ 20 %, descarga ≤ 40 % y Δv ≥ 15 % de margen',
      status: `Energía ${eMargin > 3 ? '> 300' : Math.round(eMargin * 100)} % · descarga ${e.power ? Math.round(e.power.depthOfDischarge * 100) : '—'} % · Δv ${plan && Number.isFinite(dvMargin) ? Math.round(dvMargin * 100) + ' %' : 'sin plan aún'}`,
    },
    {
      role: 'operations',
      met: reliability >= 0.97 && lost === 0,
      goal: 'Lanzador con fiabilidad ≥ 97 % y sin pérdida diaria de datos',
      status: `Fiabilidad ${plan ? Math.round(reliability * 100) + ' %' : '—'} · pérdida ${Number.isFinite(lost) ? fmtNum(lost, 1) : '—'} Gbit/día`,
    },
  ];
}

export interface VoteTally {
  outcome: string;
  counts: Record<string, number>;
  unanimous: boolean;
  /** true si hubo empate y lo resolvió la dirección de misión. */
  tieBrokenByDirector: boolean;
}

/** Mayoría simple; en empate decide la dirección (o, sin director en el equipo, el primer voto). */
export function tallyVotes(votes: Array<{ role: TeamRole; choice: string }>): VoteTally {
  if (!votes.length) throw new Error('No hay votos');
  const counts: Record<string, number> = {};
  for (const v of votes) counts[v.choice] = (counts[v.choice] ?? 0) + 1;
  const max = Math.max(...Object.values(counts));
  const leaders = Object.keys(counts).filter((k) => counts[k] === max);
  let outcome = leaders[0];
  let tie = false;
  if (leaders.length > 1) {
    tie = true;
    const tiebreak = votes.find((v) => v.role === 'director') ?? votes[0];
    outcome = leaders.includes(tiebreak.choice) ? tiebreak.choice : leaders[0];
  }
  return { outcome, counts, unanimous: leaders.length === 1 && max === votes.length, tieBrokenByDirector: tie };
}

export interface CoordinationSummary {
  decisions: number;
  unanimousShare: number;
  /** Fracción media de votos que fueron a la mejor opción en los acontecimientos (null si no hubo). */
  bestOptionShare: number | null;
  /** 0–100: acuerdo + acierto colectivo. */
  index: number;
  verdict: string;
}

export function coordination(log: TeamDecision[]): CoordinationSummary {
  const n = log.length;
  const unanimousShare = n ? log.filter((d) => d.unanimous).length / n : 0;
  const ev = log.filter((d) => d.bestShare !== undefined);
  const bestOptionShare = ev.length ? ev.reduce((s, d) => s + (d.bestShare ?? 0), 0) / ev.length : null;
  const index = Math.round(100 * (bestOptionShare === null ? unanimousShare : 0.4 * unanimousShare + 0.6 * bestOptionShare));
  const verdict =
    n === 0
      ? 'El equipo aún no ha votado ninguna decisión.'
      : index >= 75
        ? 'Equipo muy coordinado: discutieron los números y casi siempre eligieron lo mejor juntos.'
        : index >= 45
          ? 'Coordinación aceptable: hubo desacuerdos, pero la votación encauzó las decisiones.'
          : 'Poca coordinación: muchos votos divididos o alejados de la mejor opción. Hablen antes de votar.';
  return { decisions: n, unanimousShare, bestOptionShare, index, verdict };
}
