/**
 * EngineeringAnalysis — une todos los sistemas en un informe de viabilidad.
 *
 * Un diseño es VIABLE solo si no tiene ningún problema crítico. Los problemas de optimización
 * no bloquean, pero se explican. Cada problema incluye la relación de ingeniería que lo causa.
 */
import { getLauncher, LUNAR_LAUNCHERS } from '../data/launchers/launchers';
import type { Launcher, MissionTemplate, SpacecraftDesign } from '../data/schemas';
import { budgetSummary, type BudgetSummary, type ComponentLookup } from './BudgetSystem';
import { analyzeComms, analyzeData, type CommsAnalysis, type DataAnalysis } from './DataSystem';
import { hasCritical, validateDesign, type DesignIssue } from './DesignSystem';
import { analyzeMass, type MassAnalysis } from './MassSystem';
import { analyzeOrbit, referenceOrbit, type OrbitAnalysis, type OrbitParams } from './OrbitSystem';
import { analyzePower, MAX_DOD, RECOMMENDED_DOD, type PowerAnalysis } from './PowerSystem';
import { round } from './units';
import { analyzeSchedule, SCHEDULE_RESERVE_MONTHS, type ScheduleAnalysis } from './ScheduleSystem';
import { applyDifficulty, difficultyDef, isComponentAllowed, type Difficulty } from '../data/difficulty';
import { designComponents } from './DesignSystem';
import { numLocale } from '../i18n/lang';

/** Problemas de la Fase 2 sustituidos por el análisis completo por órbita. */
const SUPERSEDED = new Set(['power-deficit', 'power-margin', 'downlink-bottleneck']);

export interface EngineeringReport {
  orbit: OrbitAnalysis;
  /** null si el diseño no tiene chasis (no hay nada que analizar). */
  power: PowerAnalysis | null;
  comms: CommsAnalysis | null;
  data: DataAnalysis | null;
  mass: MassAnalysis | null;
  budget: BudgetSummary | null;
  /** Recurso tiempo: desarrollo antes del lanzamiento (null sin plantilla o sin chasis). */
  schedule: ScheduleAnalysis | null;
  issues: DesignIssue[];
  viable: boolean;
}

export interface AnalysisInput {
  design: SpacecraftDesign;
  lookup: ComponentLookup;
  template?: MissionTemplate;
  objectiveId?: string;
  /** Órbita elegida (Fase 4). Si no hay, se usa la recomendada por el objetivo. */
  orbit?: OrbitParams;
  launcherId?: string;
  difficulty?: Difficulty;
}

const pct = (x: number) => `${Math.round(x * 100)} %`;

export function analyzeEngineering(input: AnalysisInput): EngineeringReport {
  const { design, lookup, template } = input;
  const objective = template?.objectives.find((o) => o.id === input.objectiveId);
  const orbit = analyzeOrbit(input.orbit ?? referenceOrbit(objective));
  const issues = validateDesign(design, lookup, { objectiveInstrumentId: objective?.primaryInstrumentId }).filter((i) => !SUPERSEDED.has(i.id));

  if (!design.chassisId) {
    return { orbit, power: null, comms: null, data: null, mass: null, budget: null, schedule: null, issues, viable: false };
  }

  // ── Dificultad: gama de componentes ─────
  const locked = designComponents(design, lookup).filter((c) => !isComponentAllowed(c, input.difficulty));
  if (locked.length) {
    issues.push({
      id: 'tier-locked',
      severity: 'critical',
      title: `Componentes avanzados no disponibles en el nivel ${difficultyDef(input.difficulty).label}`,
      explanation: `${[...new Set(locked.map((c) => c.name))].join(', ')}: en este nivel solo se usan componentes simples. Sustitúyelos por su versión básica.`,
      instanceIds: design.parts.filter((p) => locked.some((c) => c.id === p.componentId)).map((p) => p.instanceId),
    });
  }

  // ── Tiempo de desarrollo ────────────────
  const schedule = template ? analyzeSchedule(design, lookup, template.developmentMonths) : null;
  if (schedule && !schedule.ok) {
    issues.push({
      id: 'schedule-late',
      severity: 'critical',
      title: 'La nave no estará lista para la ventana de lanzamiento',
      explanation:
        `Desarrollar ${schedule.driver?.name ?? 'las piezas'} lleva ${schedule.developmentMonths} meses y luego integrar y probar la nave ${round(schedule.integrationMonths, 1)} más: ` +
        `${round(schedule.totalMonths, 1)} meses frente a ${schedule.availableMonths} disponibles. Usa piezas con herencia de vuelo (ya probadas) o menos piezas.`,
      instanceIds: [],
    });
  } else if (schedule && schedule.reserveMonths < SCHEDULE_RESERVE_MONTHS) {
    issues.push({
      id: 'schedule-reserve',
      severity: 'optimization',
      title: `Solo ${round(schedule.reserveMonths, 1)} meses de reserva de calendario`,
      explanation: `Casi todos los proyectos sufren retrasos en las pruebas. Con menos de ${SCHEDULE_RESERVE_MONTHS} meses de reserva, un fallo en una prueba haría perder la ventana de lanzamiento.`,
      instanceIds: [],
    });
  }

  const power = analyzePower(design, lookup, orbit);
  const comms = analyzeComms(design, lookup, orbit);
  const data = analyzeData(design, lookup, orbit, comms, {
    durationDays: template?.durationDays ?? 60,
    targetGbit: objective?.dataTargetGbit ?? 0,
  });
  const mass = analyzeMass(design, lookup, LUNAR_LAUNCHERS);
  const launcher: Launcher | undefined = input.launcherId ? getLauncher(input.launcherId) : undefined;
  const opsCost = template ? template.durationDays * template.opsCostPerDayMUSD : null;
  const budget = template ? budgetSummary(template, design, lookup, launcher?.costMUSD ?? null, opsCost) : null;

  // ── Energía ─────────────────────────────
  if (power.nominalGenW > 0 && power.orbitBalanceWh < 0) {
    issues.push({
      id: 'energy-balance',
      severity: 'critical',
      title: 'La batería no se recarga en cada órbita',
      explanation:
        `En la parte iluminada (${round(power.sunlitH, 2)} h) sobran ${round(power.sunlitSurplusWh)} Wh, pero reponer el eclipse exige ` +
        `${round(power.rechargeNeededWh)} Wh. Órbita tras órbita la batería se vacía. Añade paneles o reduce el consumo.`,
      instanceIds: [],
    });
  }
  if (power.batteryWh > 0 && power.depthOfDischarge > 1) {
    issues.push({
      id: 'battery-empty',
      severity: 'critical',
      title: 'La batería se agota durante el eclipse',
      explanation: `El eclipse dura ${round(power.eclipseH * 60)} min y consume ${round(power.eclipseEnergyWh)} Wh, pero la batería solo tiene ${power.batteryWh} Wh. La nave se apagaría en la sombra.`,
      instanceIds: [],
    });
  } else if (power.batteryWh > 0 && power.depthOfDischarge > MAX_DOD) {
    issues.push({
      id: 'battery-dod',
      severity: 'critical',
      title: `Descarga de batería del ${pct(power.depthOfDischarge)} por órbita`,
      explanation: `Vaciar más del ${pct(MAX_DOD)} de una batería en cada uno de los ~${Math.round(orbit.orbitsPerDay)} eclipses diarios la degrada en semanas. Usa una batería mayor o reduce el consumo en la sombra.`,
      instanceIds: [],
    });
  } else if (power.batteryWh > 0 && power.depthOfDischarge > RECOMMENDED_DOD) {
    issues.push({
      id: 'battery-dod-high',
      severity: 'optimization',
      title: `Descarga de batería del ${pct(power.depthOfDischarge)} por órbita`,
      explanation: `Funciona, pero las misiones largas mantienen la descarga por debajo del ${pct(RECOMMENDED_DOD)} para que la batería dure años.`,
      instanceIds: [],
    });
  }
  if (power.sustainable && power.nominalGenW > 0 && power.orbitBalanceWh < power.rechargeNeededWh * 0.1) {
    issues.push({
      id: 'energy-margin',
      severity: 'optimization',
      title: 'Margen energético menor al 10 %',
      explanation: 'Los paneles pierden rendimiento con la radiación y cualquier anomalía reduce la generación. Sin margen, el primer imprevisto obliga a apagar instrumentos.',
      instanceIds: [],
    });
  }

  // ── Datos y comunicaciones ──────────────
  if (objective && data.storageGbit > 0 && comms.downlinkMbps > 0 && !data.targetMet) {
    issues.push({
      id: 'data-target',
      severity: 'critical',
      title: 'No se alcanzará el objetivo científico',
      explanation:
        `Llegarían ${Math.round(data.missionDeliveredGbit).toLocaleString(numLocale())} Gbit en ${data.missionDays} días y el objetivo exige ` +
        `${data.targetGbit.toLocaleString(numLocale())} Gbit. Al día llegan ${round(data.deliveredGbitPerDay)} Gbit: limita ` +
        `${data.deliveredGbitPerDay >= comms.downlinkGbitPerDay - 1e-9 ? 'el enlace (mejor antena)' : data.lostPerDayGbit > 0 ? 'la memoria (se pierden datos)' : 'la producción del instrumento'}.`,
      instanceIds: [],
    });
  }
  if (data.lostPerDayGbit > 0 && data.storageGbit > 0) {
    issues.push({
      id: 'data-buffer',
      severity: 'optimization',
      title: `Se pierden ${round(data.lostPerDayGbit)} Gbit al día entre contactos`,
      explanation: `Durante las ${orbit.maxGapH} h sin estación se generan ${round(data.bufferNeededGbit)} Gbit y la memoria solo guarda ${data.storageGbit} Gbit. Añade otra computadora (más memoria) o un enlace más rápido.`,
      instanceIds: [],
    });
  }
  if (data.backlogGbitPerDay > 0 && comms.downlinkMbps > 0) {
    issues.push({
      id: 'data-backlog',
      severity: 'optimization',
      title: 'El enlace no da abasto con lo que producen los instrumentos',
      explanation: `Cada día quedan ${round(data.backlogGbitPerDay)} Gbit sin transmitir. En operaciones podrás apagar instrumentos para no desperdiciar energía en datos que nunca llegarán.`,
      instanceIds: [],
    });
  }

  // ── Presupuesto ─────────────────────────
  if (budget && template) {
    const cheapestFit = mass.launchersThatFit.map((id) => getLauncher(id)!).sort((a, b) => (a.costMUSD ?? Infinity) - (b.costMUSD ?? Infinity))[0];
    if (budget.overBudget) {
      issues.push({
        id: 'budget-over',
        severity: 'critical',
        title: 'Presupuesto excedido',
        explanation: `Comprometido ${round(budget.committedMUSD)} MUSD de ${budget.capMUSD} MUSD. Elige piezas más baratas o un chasis menor.`,
        instanceIds: [],
      });
    } else if (!launcher && (!cheapestFit || budget.remainingMUSD < (cheapestFit.costMUSD ?? Infinity))) {
      issues.push({
        id: 'budget-no-launcher',
        severity: 'critical',
        title: 'No queda presupuesto para ningún lanzador capaz',
        explanation: cheapestFit
          ? `Tras la nave y ${round(opsCost ?? 0)} MUSD de operación quedan ${round(budget.remainingMUSD)} MUSD; el lanzador más barato que puede llevar ${round(mass.wetWithMarginKg)} kg (${cheapestFit.name}) cuesta ${cheapestFit.costMUSD} MUSD.`
          : `Con margen, la nave pesa ${round(mass.wetWithMarginKg)} kg y ningún lanzador disponible puede enviarla a la Luna.`,
        instanceIds: [],
      });
    }
  }

  return { orbit, power, comms, data, mass, budget, schedule, issues, viable: !hasCritical(issues) };
}

/**
 * Entrada del análisis para una misión: si ya tiene plan de vuelo, se usan SU órbita, SU lanzador
 * y SU duración. Es la única forma de construirla, para que todas las pantallas muestren lo mismo.
 */
export function analysisInputForMission(
  design: SpacecraftDesign,
  lookup: ComponentLookup,
  mission: {
    templateId: string;
    objectiveId: string;
    difficulty?: Difficulty;
    plan: { launcherId: string; altitudeKm: number; inclinationDeg: number; durationDays: number } | null;
  },
  getTemplate: (id: string) => MissionTemplate | undefined,
): AnalysisInput {
  const raw = getTemplate(mission.templateId);
  const base = raw && applyDifficulty(raw, mission.difficulty);
  const plan = mission.plan;
  const difficulty = mission.difficulty;
  if (!base || !plan) return { design, lookup, template: base, objectiveId: mission.objectiveId, difficulty };
  return {
    design,
    lookup,
    template: { ...base, durationDays: plan.durationDays },
    objectiveId: mission.objectiveId,
    orbit: { altitudeKm: plan.altitudeKm, inclinationDeg: plan.inclinationDeg },
    launcherId: plan.launcherId,
    difficulty,
  };
}
