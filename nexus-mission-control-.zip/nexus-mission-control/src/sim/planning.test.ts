/** Fase 4. Valores esperados calculados de forma independiente (Python) con las fórmulas documentadas. */
import { describe, expect, it } from 'vitest';
import { getComponent } from '../data/components/catalog';
import { LUNA_01 } from '../data/missions/missions';
import type { MissionPlan, SpacecraftDesign } from '../data/schemas';
import { EMPTY_DESIGN, placePart, setChassis } from './DesignSystem';
import { analyzePlan, defaultPlan } from './PlanningSystem';
import { coverageFraction, deltaVBudget, firstOptimalDay, loiDeltaV, stationKeepingDeltaV, windowInfo } from './TrajectorySystem';

const L = getComponent;
function build(chassisId: string, parts: Array<[string, string]>): SpacecraftDesign {
  let d = setChassis(EMPTY_DESIGN, chassisId, L).design;
  for (const [c, s] of parts) d = placePart(d, c, s, L).design;
  return d;
}
const CAMERA_REF = build('chassis-m', [
  ['camera', 'bottom-0'],
  ['thruster', 'bottom-1'],
  ['antenna-hg', 'top-0'],
  ['attitude-sensor', 'side-pz-0'],
  ['solar-adv', 'side-px-0'],
  ['solar-adv', 'side-nx-0'],
  ['battery-adv', 'bay-0'],
  ['obc', 'bay-1'],
  ['prop-tank', 'bay-2'],
  ['thermal', 'bay-3'],
]);
const RADAR = build('chassis-m', [
  ['radar', 'bottom-0'],
  ['thruster', 'bottom-1'],
  ['antenna-hg', 'top-0'],
  ['attitude-sensor', 'side-pz-0'],
  ['thermal', 'side-nz-0'],
  ['solar-adv', 'side-px-0'],
  ['solar-adv', 'side-nx-0'],
  ['battery-adv', 'bay-0'],
  ['obc', 'bay-1'],
  ['prop-tank', 'bay-2'],
  ['reaction-wheels', 'bay-3'],
]);
const plan = (p: Partial<MissionPlan>): MissionPlan => ({ launcherId: 'minotaur-iv', altitudeKm: 75, inclinationDeg: 90, durationDays: 60, launchDay: 7, ...p });

describe('TrajectorySystem', () => {
  it('Δv de inserción lunar: ~815 m/s y menor cuanto más alta la órbita', () => {
    expect(loiDeltaV(75)).toBeCloseTo(815.001, 2);
    expect(loiDeltaV(55)).toBeCloseTo(818.091, 2);
    expect(loiDeltaV(200)).toBeCloseTo(796.933, 2);
  });

  it('mantenimiento orbital: 0,4 m/s/día a 50 km, mucho más caro en órbitas bajas', () => {
    expect(stationKeepingDeltaV(50, 1)).toBeCloseTo(0.4, 9);
    expect(stationKeepingDeltaV(75, 60)).toBeCloseTo(13.064, 2);
    expect(stationKeepingDeltaV(55, 60)).toBeCloseTo(20.803, 2);
  });

  it('Tsiolkovsky: la nave de referencia dispone de 1136 m/s', () => {
    const b = deltaVBudget(CAMERA_REF, L, { altitudeKm: 75, durationDays: 60, launchDay: 7 });
    expect(b.ispS).toBe(315);
    expect(b.availableMS).toBeCloseTo(1135.937, 2);
    expect(b.requiredMS).toBeCloseTo(858.065, 2);
    expect(b.ok).toBe(true);
  });

  it('radar a 55 km: 954 m/s disponibles frente a 869 necesarios', () => {
    const b = deltaVBudget(RADAR, L, { altitudeKm: 55, durationDays: 60, launchDay: 7 });
    expect(b.availableMS).toBeCloseTo(954.368, 2);
    expect(b.requiredMS).toBeCloseTo(868.894, 2);
  });

  it('sin motor no hay Δv', () => {
    const d = build('chassis-m', [['prop-tank', 'bay-0']]);
    expect(deltaVBudget(d, L, { altitudeKm: 75, durationDays: 60, launchDay: 7 }).availableMS).toBe(0);
  });

  it('ventanas: óptimas 6–8 y 36–37, marginales con penalización, resto cerradas', () => {
    expect([6, 7, 8, 36, 37].every((d) => windowInfo(d).status === 'optimal')).toBe(true);
    expect(windowInfo(9).status).toBe('marginal');
    expect(windowInfo(9).penaltyMS).toBeCloseTo(60, 9);
    expect(windowInfo(10).penaltyMS).toBeCloseTo(120, 9);
    expect(windowInfo(35).penaltyMS).toBeCloseTo(31.8, 6);
    expect(windowInfo(20).status).toBe('closed');
    expect(firstOptimalDay()).toBe(6);
    expect(windowInfo(0).date.toISOString().slice(0, 10)).toBe('2027-03-01');
    expect(windowInfo(7).arrivalDate.toISOString().slice(0, 10)).toBe('2027-03-12');
  });

  it('cobertura = sin(i)', () => {
    expect(coverageFraction(90)).toBeCloseTo(1, 9);
    expect(coverageFraction(30)).toBeCloseTo(0.5, 9);
    expect(coverageFraction(72)).toBeCloseTo(0.9511, 4);
  });
});

describe('PlanningSystem', () => {
  it('plan por defecto: lanzador más barato que puede, órbita recomendada, primera ventana', () => {
    expect(defaultPlan(CAMERA_REF, L, LUNA_01, 'obj-mapping')).toEqual({
      launcherId: 'minotaur-iv',
      altitudeKm: 75,
      inclinationDeg: 90,
      durationDays: 60,
      launchDay: 6,
    });
    // el radar (Ø 1,85 m) cabe en la cofia útil del Minotaur IV (2,1 m) y pesa menos de 383 kg
    expect(defaultPlan(RADAR, L, LUNA_01, 'obj-polar-ice').launcherId).toBe('minotaur-iv');
  });

  it('el plan de referencia está listo para lanzar', () => {
    const r = analyzePlan({ design: CAMERA_REF, lookup: L, template: LUNA_01, objectiveId: 'obj-mapping', plan: plan({}) });
    expect(r.issues.filter((i) => i.severity === 'critical')).toEqual([]);
    expect(r.ready).toBe(true);
    // presupuesto con lanzador: 40,6 + 50 (Minotaur IV) + 15 = 105,6
    expect(r.engineering.budget!.committedMUSD).toBeCloseTo(105.6, 9);
  });

  it('el plan de radar es viable con el Minotaur IV (el objetivo más exigente: 117,2 de 140 MUSD) y con el Falcon 9', () => {
    const r = analyzePlan({ design: RADAR, lookup: L, template: LUNA_01, objectiveId: 'obj-polar-ice', plan: plan({ launcherId: 'minotaur-iv', altitudeKm: 55 }) });
    expect(r.ready, r.issues.filter((i) => i.severity === 'critical').map((i) => i.title).join('; ')).toBe(true);
    expect(r.engineering.budget!.committedMUSD).toBeCloseTo(52.2 + 50 + 15, 9);
    const f9 = analyzePlan({ design: RADAR, lookup: L, template: LUNA_01, objectiveId: 'obj-polar-ice', plan: plan({ launcherId: 'falcon-9', altitudeKm: 55 }) });
    expect(f9.ready).toBe(true);
    expect(f9.engineering.budget!.committedMUSD).toBeCloseTo(52.2 + 62 + 15, 9);
  });

  it('cofia demasiado pequeña y masa excesiva → críticos (Minotaur I: solo órbita baja)', () => {
    const r = analyzePlan({ design: RADAR, lookup: L, template: LUNA_01, objectiveId: 'obj-polar-ice', plan: plan({ launcherId: 'minotaur-i', altitudeKm: 55 }) });
    expect(r.issues.find((i) => i.id === 'plan-fairing')?.severity).toBe('critical');
    expect(r.massFits).toBe(false);
  });

  it('lanzador caro → presupuesto excedido', () => {
    const r = analyzePlan({ design: RADAR, lookup: L, template: { ...LUNA_01, budgetCapMUSD: 120 }, objectiveId: 'obj-polar-ice', plan: plan({ launcherId: 'falcon-9', altitudeKm: 55 }) });
    expect(r.issues.find((i) => i.id === 'budget-over')?.severity).toBe('critical');
  });

  it('fecha cerrada → crítico; marginal → optimización con penalización de Δv', () => {
    const closed = analyzePlan({ design: CAMERA_REF, lookup: L, template: LUNA_01, objectiveId: 'obj-mapping', plan: plan({ launchDay: 20 }) });
    expect(closed.issues.find((i) => i.id === 'plan-window')?.severity).toBe('critical');
    const marginal = analyzePlan({ design: CAMERA_REF, lookup: L, template: LUNA_01, objectiveId: 'obj-mapping', plan: plan({ launchDay: 10 }) });
    expect(marginal.deltaV.windowPenaltyMS).toBeCloseTo(120, 9);
    expect(marginal.issues.find((i) => i.id === 'plan-window-marginal')?.severity).toBe('optimization');
    expect(marginal.ready).toBe(true);
  });

  it('Δv insuficiente: misión larga en órbita muy baja', () => {
    const r = analyzePlan({
      design: RADAR,
      lookup: L,
      template: LUNA_01,
      objectiveId: 'obj-polar-ice',
      plan: plan({ launcherId: 'falcon-9', altitudeKm: 30, durationDays: 120, launchDay: 10 }),
    });
    // 30 km: LOI 821 + SK 0,4·(50/30)^1,5·120 = 103 + 30 + 120 > 954
    expect(r.issues.find((i) => i.id === 'plan-deltav')?.severity).toBe('critical');
  });

  it('hielo polar con órbita inclinada 60° → crítico (nunca ve los polos)', () => {
    const r = analyzePlan({ design: RADAR, lookup: L, template: LUNA_01, objectiveId: 'obj-polar-ice', plan: plan({ launcherId: 'falcon-9', altitudeKm: 55, inclinationDeg: 60 }) });
    expect(r.issues.find((i) => i.id === 'plan-polar')?.severity).toBe('critical');
  });

  it('cartografía con 30° → solo optimización (cobertura 50 %)', () => {
    const r = analyzePlan({ design: CAMERA_REF, lookup: L, template: LUNA_01, objectiveId: 'obj-mapping', plan: plan({ inclinationDeg: 30 }) });
    const c = r.issues.find((i) => i.id === 'plan-coverage');
    expect(c?.severity).toBe('optimization');
    expect(c?.title).toContain('50 %');
  });

  it('la órbita elegida cambia el análisis de energía (más alta → eclipse más corto)', () => {
    const low = analyzePlan({ design: CAMERA_REF, lookup: L, template: LUNA_01, objectiveId: 'obj-mapping', plan: plan({ altitudeKm: 50 }) });
    const high = analyzePlan({ design: CAMERA_REF, lookup: L, template: LUNA_01, objectiveId: 'obj-mapping', plan: plan({ altitudeKm: 200 }) });
    expect(high.engineering.power!.eclipseEnergyWh).toBeLessThan(low.engineering.power!.eclipseEnergyWh);
    expect(high.issues.some((i) => i.id === 'plan-altitude-high')).toBe(true);
  });

  it('la duración cambia operación y datos', () => {
    const r = analyzePlan({ design: CAMERA_REF, lookup: L, template: LUNA_01, objectiveId: 'obj-mapping', plan: plan({ durationDays: 120 }) });
    expect(r.engineering.budget!.lines.find((l) => l.id === 'operations')!.amountMUSD).toBe(30);
    expect(r.engineering.data!.missionDays).toBe(120);
  });

  it('por debajo de 30 km: riesgo de impacto', () => {
    const r = analyzePlan({ design: CAMERA_REF, lookup: L, template: LUNA_01, objectiveId: 'obj-mapping', plan: plan({ altitudeKm: 25 }) });
    expect(r.issues.find((i) => i.id === 'plan-altitude-risk')?.severity).toBe('critical');
  });
});
