/**
 * Minijuego de aterrizaje lunar (Fase 8.8): física del descenso final.
 * Gravedad lunar real (1,62 m/s²), sin aire, empuje según la orientación del módulo y consumo
 * por la ecuación del cohete (ṁ = F / (Isp·g₀)). El módulo es de juego, con valores típicos de un
 * módulo robótico pequeño. El jugador regula el empuje y la inclinación: no hay piloto automático.
 */
import { heightAt, inSafeZone, normalAt, rockNear, slopeAt, TERRAIN, mulberry, type Terrain } from './LunarTerrain';

export const G_MOON = 1.62;
const G0 = 9.80665;

export const LANDER = {
  dryKg: 1200,
  fuelKg: 300,
  thrustN: 6000,
  ispS: 320,
  /** Giro de la orientación (°/s) y máxima inclinación (°). */
  tiltRate: 18,
  maxTilt: 35,
  /** Cambio del empuje por segundo con W/S. */
  throttleRate: 0.6,
  /** Radio de las patas (m). */
  footprintM: 2.2,
};

/** Límites para un aterrizaje seguro (del orden de los que se usaron en las misiones Apolo). */
export const LIMITS = {
  verticalMS: 2,
  horizontalMS: 1,
  tiltDeg: 10,
  slopeDeg: TERRAIN.maxSlopeDeg,
};

export type LandingOutcome = 'perfect' | 'ok' | 'crash' | 'tipped' | 'rock' | 'away';

export interface LanderState {
  p: [number, number, number];
  v: [number, number, number];
  /** Inclinación hacia +x (adelante) y hacia +z (derecha), en grados. */
  pitch: number;
  roll: number;
  throttle: number;
  fuelKg: number;
  t: number;
  done: boolean;
  touchdown: Touchdown | null;
}

export interface Touchdown {
  outcome: LandingOutcome;
  success: boolean;
  verticalMS: number;
  horizontalMS: number;
  tiltDeg: number;
  slopeDeg: number;
  rock: boolean;
  inSafe: boolean;
  distanceToSafeM: number;
  fuelLeftKg: number;
  t: number;
  x: number;
  z: number;
}

export interface LanderInput {
  /** −1 baja el empuje, +1 lo sube. */
  throttle: number;
  /** Fijar el empuje (0–1); tiene prioridad sobre `throttle`. */
  setThrottle?: number;
  /** −1/0/+1: inclinar hacia atrás/adelante (x) y hacia la izquierda/derecha (z). */
  pitch: number;
  roll: number;
  /** Enderezar el módulo poco a poco. */
  level: boolean;
}
export const NO_LANDER_INPUT: LanderInput = { throttle: 0, pitch: 0, roll: 0, level: false };

/** Punto de partida: unos 1 200 m de altura, a ~650 m de la zona segura, bajando y avanzando. */
export function newLander(t: Terrain, attempt = 0): LanderState {
  const r = mulberry(1000 + attempt * 7919);
  const x = -650 + (r() - 0.5) * 120;
  const z = 120 + (r() - 0.5) * 160;
  return {
    p: [x, heightAt(t, x, z) + 1200, z],
    v: [16 + (r() - 0.5) * 4, -20, -2 + (r() - 0.5) * 4],
    pitch: 0,
    roll: 0,
    throttle: 0.3,
    fuelKg: LANDER.fuelKg,
    t: 0,
    done: false,
    touchdown: null,
  };
}

/** Dirección del empuje (unitaria) para una inclinación dada. */
export function thrustDir(pitchDeg: number, rollDeg: number): [number, number, number] {
  const a = (pitchDeg * Math.PI) / 180;
  const b = (rollDeg * Math.PI) / 180;
  const x = Math.sin(a) * Math.cos(b);
  const z = Math.sin(b);
  const y = Math.cos(a) * Math.cos(b);
  return [x, y, z];
}

export function tiltOf(s: Pick<LanderState, 'pitch' | 'roll'>) {
  const d = thrustDir(s.pitch, s.roll);
  return (Math.acos(Math.max(-1, Math.min(1, d[1]))) * 180) / Math.PI;
}

export function altitude(t: Terrain, s: LanderState) {
  return s.p[1] - heightAt(t, s.p[0], s.p[2]);
}

const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));

export function stepLander(t: Terrain, s: LanderState, input: LanderInput, dt: number): LanderState {
  if (s.done) return s;
  let pitch = s.pitch;
  let roll = s.roll;
  if (input.level) {
    const k = LANDER.tiltRate * dt;
    pitch = Math.abs(pitch) <= k ? 0 : pitch - Math.sign(pitch) * k;
    roll = Math.abs(roll) <= k ? 0 : roll - Math.sign(roll) * k;
  }
  pitch = clamp(pitch + input.pitch * LANDER.tiltRate * dt, -LANDER.maxTilt, LANDER.maxTilt);
  roll = clamp(roll + input.roll * LANDER.tiltRate * dt, -LANDER.maxTilt, LANDER.maxTilt);
  let throttle = input.setThrottle !== undefined ? input.setThrottle : s.throttle + input.throttle * LANDER.throttleRate * dt;
  throttle = clamp(throttle, 0, 1);
  if (s.fuelKg <= 0) throttle = 0;
  const m = LANDER.dryKg + s.fuelKg;
  const F = LANDER.thrustN * throttle;
  const burn = Math.min(s.fuelKg, (F / (LANDER.ispS * G0)) * dt);
  const d = thrustDir(pitch, roll);
  const a = F / m;
  const v: [number, number, number] = [s.v[0] + a * d[0] * dt, s.v[1] + (a * d[1] - G_MOON) * dt, s.v[2] + a * d[2] * dt];
  const p: [number, number, number] = [s.p[0] + v[0] * dt, s.p[1] + v[1] * dt, s.p[2] + v[2] * dt];
  const next: LanderState = { ...s, p, v, pitch, roll, throttle, fuelKg: s.fuelKg - burn, t: s.t + dt };
  const half = TERRAIN.size / 2 - 20;
  if (Math.abs(p[0]) > half || Math.abs(p[2]) > half) {
    return { ...next, done: true, touchdown: { ...evaluate(t, next), outcome: 'away', success: false } };
  }
  const ground = heightAt(t, p[0], p[2]);
  if (p[1] <= ground) {
    next.p = [p[0], ground, p[2]];
    return { ...next, done: true, touchdown: evaluate(t, { ...next, v }) };
  }
  return next;
}

/** Cómo fue el contacto con el suelo. */
export function evaluate(t: Terrain, s: LanderState): Touchdown {
  const [x, , z] = s.p;
  const verticalMS = Math.max(0, -s.v[1]);
  const horizontalMS = Math.hypot(s.v[0], s.v[2]);
  // Inclinación respecto del suelo: la del módulo combinada con la del terreno.
  const d = thrustDir(s.pitch, s.roll);
  const n = normalAt(t, x, z);
  const tiltDeg = (Math.acos(clamp(d[0] * n[0] + d[1] * n[1] + d[2] * n[2], -1, 1)) * 180) / Math.PI;
  const slopeDeg = slopeAt(t, x, z).deg;
  const rock = !!rockNear(t, x, z, LANDER.footprintM, 0.5);
  const inSafe = inSafeZone(x, z);
  let outcome: LandingOutcome;
  if (verticalMS > LIMITS.verticalMS || horizontalMS > LIMITS.horizontalMS * 2.5) outcome = 'crash';
  else if (rock) outcome = 'rock';
  else if (tiltDeg > LIMITS.tiltDeg || slopeDeg > LIMITS.slopeDeg || horizontalMS > LIMITS.horizontalMS) outcome = 'tipped';
  else outcome = inSafe ? 'perfect' : 'ok';
  return {
    outcome,
    success: outcome === 'perfect' || outcome === 'ok',
    verticalMS,
    horizontalMS,
    tiltDeg: tiltOf(s),
    slopeDeg,
    rock,
    inSafe,
    distanceToSafeM: Math.hypot(x - TERRAIN.safe.x, z - TERRAIN.safe.z),
    fuelLeftKg: s.fuelKg,
    t: s.t,
    x,
    z,
  };
}

/** Qué mejorar (o qué salió bien), en frases sencillas. */
export function landingAdvice(td: Touchdown): string[] {
  const out: string[] = [];
  const f = (n: number, k = 1) => n.toFixed(k).replace('.', ',');
  if (td.outcome === 'away') return ['Te alejaste demasiado de la zona de aterrizaje. Inclina el módulo hacia atrás pronto para frenar el avance y dirígete a la zona verde.'];
  if (td.verticalMS > LIMITS.verticalMS) out.push(`Bajaste a ${f(td.verticalMS)} m/s y el límite es ${LIMITS.verticalMS} m/s. Sube el empuje (W) antes, cuando aún estés alto, para llegar despacio.`);
  if (td.horizontalMS > LIMITS.horizontalMS) out.push(`Ibas de lado a ${f(td.horizontalMS)} m/s (límite: ${LIMITS.horizontalMS} m/s). Inclina el módulo en contra del movimiento para frenarlo y endereza justo antes de tocar el suelo.`);
  if (td.tiltDeg > LIMITS.tiltDeg) out.push(`El módulo estaba inclinado ${f(td.tiltDeg, 0)}° (límite: ${LIMITS.tiltDeg}°). Usa «Nivelar» (L) en los últimos metros.`);
  if (td.rock) out.push('Una pata cayó sobre una roca. Busca un sitio liso: la zona verde no tiene rocas.');
  if (td.slopeDeg > LIMITS.slopeDeg) out.push(`El suelo tenía una pendiente de ${f(td.slopeDeg, 0)}° (límite: ${LIMITS.slopeDeg}°). Los bordes de los cráteres son peligrosos: aterriza en la zona verde.`);
  if (td.fuelLeftKg <= 0.01 && !td.success) out.push('Te quedaste sin combustible. No subas y bajes muchas veces: baja de forma continua y frena al final.');
  if (td.success) {
    if (!td.inSafe) out.push(`Aterrizaste a ${f(td.distanceToSafeM, 0)} m de la zona verde, en un sitio aceptable. Para la puntuación máxima, aterriza dentro de ella.`);
    if (td.verticalMS < 1) out.push('¡Contacto muy suave!');
    out.push(`Te sobraron ${f(td.fuelLeftKg, 0)} kg de combustible.`);
  }
  return out;
}

export function landingPoints(td: Touchdown) {
  if (!td.success) return 0;
  const zone = td.inSafe ? 300 : 0;
  const soft = Math.round(Math.max(0, LIMITS.verticalMS - td.verticalMS) * 60);
  const fuel = Math.round((td.fuelLeftKg / LANDER.fuelKg) * 200);
  return 400 + zone + soft + fuel;
}

/** Lecturas para los indicadores. */
export function landerReadout(t: Terrain, s: LanderState) {
  const alt = altitude(t, s);
  const [x, , z] = s.p;
  const dx = TERRAIN.safe.x - x;
  const dz = TERRAIN.safe.z - z;
  const slope = slopeAt(t, x, z).deg;
  return {
    altitudeM: alt,
    verticalMS: s.v[1],
    horizontalMS: Math.hypot(s.v[0], s.v[2]),
    vx: s.v[0],
    vz: s.v[2],
    tiltDeg: tiltOf(s),
    fuelFrac: s.fuelKg / LANDER.fuelKg,
    safeDx: dx,
    safeDz: dz,
    safeDistM: Math.hypot(dx, dz),
    groundSlopeDeg: slope,
    groundRock: !!rockNear(t, x, z, LANDER.footprintM, 0.5),
    groundOk: slope <= LIMITS.slopeDeg && !rockNear(t, x, z, LANDER.footprintM, 0.5),
    /** Aceleración máxima del motor ahora (m/s²) y la que equilibra la gravedad (empuje de flotar). */
    hoverThrottle: Math.min(1, (G_MOON * (LANDER.dryKg + s.fuelKg)) / LANDER.thrustN),
  };
}
