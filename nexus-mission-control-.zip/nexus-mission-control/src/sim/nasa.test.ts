/**
 * Integración de referencias NASA: órbita elíptica (GMAT / Mission Viz), revisión de concepto
 * (CML, STM, MEL, riesgos — Mission Design Lab y JPL) y asesor del catálogo (juego del Webb).
 * Valores esperados calculados aparte en Python con las mismas fórmulas.
 */
import { describe, expect, it } from 'vitest';
import { getComponent } from '../data/components/catalog';
import { LUNA_01 } from '../data/missions/missions';
import { REAL_MISSIONS, similarRealMissions } from '../data/realMissions';
import type { Mission, MissionPlan, SpacecraftDesign } from '../data/schemas';
import { MissionSchema } from '../data/schemas';
import { recordTrade, withEllipticalStudy, withPlan } from '../state/missionLogic';
import { catalogAdvice } from './CatalogAdvisor';
import { conceptMaturity, equipmentList, LIFECYCLE, riskLevel, riskRegister, traceabilityMatrix, type ReviewInput } from './ConceptReview';
import { EMPTY_DESIGN, placePart, setChassis } from './DesignSystem';
import { disposalDeltaVMS, fractionBelowAltitude, makeEllipse, solveKepler, stateAt } from './EllipticalOrbit';
import { analyzeEngineering } from './EngineeringAnalysis';
import { analyzePlan } from './PlanningSystem';

const L = getComponent;
function build(chassisId: string, parts: Array<[string, string]>): SpacecraftDesign {
  let d = setChassis(EMPTY_DESIGN, chassisId, L).design;
  for (const [c, s] of parts) d = placePart(d, c, s, L).design;
  return d;
}
const CAMERA_REF = build('chassis-m', [
  ['camera', 'bottom-0'],
  ['thruster', 'bottom-1'],
  ['antenna-hg', 'top-0'],
  ['attitude-sensor', 'side-pz-0'],
  ['solar-adv', 'side-px-0'],
  ['solar-adv', 'side-nx-0'],
  ['battery-adv', 'bay-0'],
  ['obc', 'bay-1'],
  ['prop-tank', 'bay-2'],
  ['thermal', 'bay-3'],
]);
const PLAN: MissionPlan = { launcherId: 'minotaur-iv', altitudeKm: 75, inclinationDeg: 90, durationDays: 60, launchDay: 7 };

function mission(design: SpacecraftDesign, plan: MissionPlan | null, stage: Mission['stage'] = plan ? 'PLANNING' : 'DESIGN'): Mission {
  return MissionSchema.parse({
    id: 'm1',
    templateId: 'luna-01',
    objectiveId: 'obj-mapping',
    name: 'LUNA-01 · Intento 1',
    stage,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
    design,
    plan,
  });
}
function input(m: Mission): ReviewInput {
  const plan = m.plan ? analyzePlan({ design: m.design, lookup: L, template: LUNA_01, objectiveId: m.objectiveId, plan: m.plan }) : null;
  return { mission: m, template: LUNA_01, engineering: plan?.engineering ?? analyzeEngineering({ design: m.design, lookup: L, template: LUNA_01, objectiveId: m.objectiveId }), plan, lookup: L };
}

describe('EllipticalOrbit (Kepler)', () => {
  it('LRO cuasi-congelada 30 × 216 km: a, e, periodo y velocidades (vis-viva)', () => {
    const el = makeEllipse({ periapsisAltKm: 30, apoapsisAltKm: 216 });
    expect(el.aKm).toBeCloseTo(1860.4, 6);
    expect(el.e).toBeCloseTo(0.0499892, 6);
    expect(el.periodS / 60).toBeCloseTo(120.0096, 3);
    expect(el.vPeriKmS).toBeCloseTo(1.70666, 4);
    expect(el.vApoKmS).toBeCloseTo(1.54415, 4);
    // Conservación del momento angular: r_p · v_p = r_a · v_a
    expect(el.rpKm * el.vPeriKmS).toBeCloseTo(el.raKm * el.vApoKmS, 9);
  });

  it('la ecuación de Kepler se resuelve con precisión, también con excentricidad alta', () => {
    for (const e of [0, 0.05, 0.5, 0.9, 0.97]) {
      for (const M of [0.01, 1, 2.5, 3.14, 5]) {
        const E = solveKepler(M, e);
        expect(E - e * Math.sin(E)).toBeCloseTo(M, 10);
      }
    }
    expect(() => solveKepler(1, 1)).toThrow();
  });

  it('posición en el tiempo: periapsis en t = 0, apoapsis en T/2 y altitud a T/4', () => {
    const el = makeEllipse({ periapsisAltKm: 30, apoapsisAltKm: 216 });
    expect(stateAt(el, 0).altitudeKm).toBeCloseTo(30, 6);
    expect(stateAt(el, el.periodS / 2).altitudeKm).toBeCloseTo(216, 6);
    expect(stateAt(el, el.periodS / 4).altitudeKm).toBeCloseTo(127.6413, 3);
    expect(stateAt(el, el.periodS).altitudeKm).toBeCloseTo(30, 6); // periódica
    expect(stateAt(el, 0).speedKmS).toBeGreaterThan(stateAt(el, el.periodS / 2).speedKmS);
  });

  it('fracción del periodo por debajo de una altitud (exacta con Kepler)', () => {
    const el = makeEllipse({ periapsisAltKm: 30, apoapsisAltKm: 216 });
    expect(fractionBelowAltitude(el, 100)).toBeCloseTo(0.405035, 5);
    expect(fractionBelowAltitude(el, 20)).toBe(0);
    expect(fractionBelowAltitude(el, 300)).toBe(1);
  });

  it('Δv de fin de misión desde 50 km: ~11,8 m/s', () => {
    expect(disposalDeltaVMS(50)).toBeCloseTo(11.7887, 3);
    expect(disposalDeltaVMS(100)).toBeGreaterThan(disposalDeltaVMS(50));
  });

  it('rechaza periapsis demasiado bajos', () => {
    expect(() => makeEllipse({ periapsisAltKm: 2, apoapsisAltKm: 100 })).toThrow();
  });
});

describe('Misiones reales de referencia', () => {
  it('todas tienen fuente https y datos coherentes', () => {
    for (const m of REAL_MISSIONS) {
      expect(m.source.url.startsWith('https://'), m.id).toBe(true);
      expect(m.orbit.apoapsisKm).toBeGreaterThanOrEqual(m.orbit.periapsisKm);
    }
    expect(similarRealMissions('obj-mapping').map((m) => m.id)).toContain('lro');
    expect(similarRealMissions('obj-polar-ice').map((m) => m.id)).toContain('lunar-prospector');
  });
});

describe('Registro de compromisos (CML 3)', () => {
  it('withPlan anota alternativas sin duplicar y el simulador elíptico cuenta estudios', () => {
    let m = mission(CAMERA_REF, null);
    m = withPlan(m, PLAN, new Date());
    m = withPlan(m, { ...PLAN, launcherId: 'falcon-9' }, new Date());
    m = withPlan(m, { ...PLAN, launcherId: 'minotaur-iv', altitudeKm: 90 }, new Date());
    expect(m.trades.launchers).toEqual(['minotaur-iv', 'falcon-9']);
    expect(m.trades.altitudes).toEqual([75, 90]);
    expect(withEllipticalStudy(m, new Date()).trades.ellipticalStudies).toBe(1);
    expect(recordTrade(m.trades, PLAN)).toEqual(m.trades);
  });

  it('los guardados antiguos sin registro se leen con valores por defecto', () => {
    const m = mission(CAMERA_REF, null);
    const { trades: _omit, ...old } = m;
    expect(MissionSchema.parse(old).trades.launchers).toEqual([]);
  });
});

describe('Revisión de concepto', () => {
  it('STM del diseño de referencia: todos los requisitos trazados y cumplidos', () => {
    const stm = traceabilityMatrix(input(mission(CAMERA_REF, PLAN)));
    expect(stm.rows.map((r) => r.id)).toEqual(['instrument', 'altitude', 'coverage', 'volume', 'buffer', 'power']);
    expect(stm.complete).toBe(true);
    expect(stm.rows.find((r) => r.id === 'instrument')!.method).toBe('Inspección');
  });

  it('STM marca lo que falla: sin plan queda pendiente; órbita ecuatorial en polar no cumple', () => {
    const noPlan = traceabilityMatrix(input(mission(CAMERA_REF, null)));
    expect(noPlan.rows.find((r) => r.id === 'altitude')!.status).toBe('pending');
    const m = { ...mission(CAMERA_REF, { ...PLAN, inclinationDeg: 10 }), objectiveId: 'obj-polar-ice' };
    expect(traceabilityMatrix(input(m)).rows.find((r) => r.id === 'coverage')!.status).toBe('not-met');
  });

  it('MEL: contingencia por herencia de vuelo y comparación con el margen plano del 10 %', () => {
    const mel = equipmentList(CAMERA_REF, L);
    const solar = mel.rows.find((r) => r.componentId === 'solar-adv')!;
    expect(solar.qty).toBe(2);
    expect(solar.contingency).toBe(0.15);
    expect(solar.mevKg).toBeCloseTo(solar.cbeKg * 1.15, 9);
    expect(mel.cbeKg).toBeCloseTo(mel.rows.reduce((s, r) => s + r.cbeKg, 0), 9);
    expect(mel.mevKg).toBeGreaterThan(mel.cbeKg);
    expect(mel.flatMarginCovers).toBe(mel.effectiveContingency <= 0.1);
    expect(equipmentList(EMPTY_DESIGN, L).rows).toEqual([]);
  });

  it('riesgos 5 × 5: nivel por producto y probabilidad que sube al quitar margen', () => {
    expect(riskLevel(5, 3)).toBe('high');
    expect(riskLevel(2, 3)).toBe('medium');
    expect(riskLevel(1, 5)).toBe('low');
    const ok = riskRegister(input(mission(CAMERA_REF, PLAN)));
    const low = riskRegister(input(mission(CAMERA_REF, { ...PLAN, altitudeKm: 25 })));
    expect(low.find((r) => r.id === 'r-orbit')!.likelihood).toBeGreaterThan(ok.find((r) => r.id === 'r-orbit')!.likelihood);
    expect(ok.find((r) => r.id === 'r-launch')!.likelihood).toBe(4); // Minotaur IV: (8+1)/(8+2) = 90 %
  });

  it('CML: objetivo elegido = CML 1; sin exploración no se llega a CML 3; con exploración y plan confirmado sube', () => {
    const empty = conceptMaturity(input(mission(EMPTY_DESIGN, null)));
    expect(empty.level).toBe(1);
    const feasible = conceptMaturity(input(mission(CAMERA_REF, null)));
    expect(feasible.level).toBe(2);

    let m = withPlan(mission(CAMERA_REF, null, 'PLANNING'), PLAN, new Date());
    expect(conceptMaturity(input(m)).level).toBe(2); // una sola alternativa: no hay espacio de compromisos
    for (const p of [{ launcherId: 'falcon-9' }, { altitudeKm: 90 }, { inclinationDeg: 88 }, { durationDays: 70 }, PLAN]) m = withPlan(m, { ...PLAN, ...p }, new Date());
    m = withEllipticalStudy(m, new Date());
    const explored = conceptMaturity(input(m));
    expect(explored.level).toBeGreaterThanOrEqual(3);
    const s3 = explored.scores.find((s) => s.level === 3)!;
    expect(s3.passed).toBe(true);
    // CML 5 exige el plan confirmado (elemento clave)
    expect(explored.scores.find((s) => s.level === 5)!.passed).toBe(false);
  });

  it('un elemento clave en rojo bloquea el nivel aunque el resto esté en verde', () => {
    const noBattery = { ...CAMERA_REF, parts: CAMERA_REF.parts.filter((p) => p.componentId !== 'battery-adv') };
    const r = conceptMaturity(input(mission(noBattery, PLAN, 'DESIGN')));
    const s4 = r.scores.find((s) => s.level === 4)!;
    expect(s4.keyMissing.map((k) => k.id)).toContain('c4-approved');
    expect(s4.passed).toBe(false);
    for (const s of r.scores) if (s.passed) expect(s.keyMissing).toEqual([]);
  });

  it('ciclo de vida: cinco tramos en orden con revisiones de NASA y plazos CubeSat', () => {
    expect(LIFECYCLE.map((l) => l.id)).toEqual(['pre-a', 'a-b', 'c-d', 'e', 'f']);
    expect(LIFECYCLE[0].review).toMatch(/MCR/);
    expect(LIFECYCLE[2].review).toMatch(/CDR/);
  });
});

describe('CatalogAdvisor (estilo Webb)', () => {
  it('avisa antes de elegir: sin chasis, incompatibilidad y anclajes agotados', () => {
    expect(catalogAdvice(L('camera')!, EMPTY_DESIGN, L).kind).toBe('blocked');
    expect(catalogAdvice(L('chassis-s')!, EMPTY_DESIGN, L).kind).toBe('ok');
    const withBasicAntenna = build('chassis-m', [['antenna-basic', 'top-0']]);
    const radar = catalogAdvice(L('radar')!, withBasicAntenna, L);
    expect(radar.kind).toBe('blocked');
    expect(radar.label).toMatch(/Antena básica/);
    expect(catalogAdvice(L('camera')!, setChassis(EMPTY_DESIGN, 'chassis-m', L).design, L).kind).not.toBe('blocked');
  });
});
