/**
 * Fase 3 (LAB guiado): parámetros críticos, «Solucionar problema» y restricciones.
 * Todo se comprueba con piezas reales del catálogo y el análisis de ingeniería existente.
 */
import { describe, expect, it } from 'vitest';
import { COMPONENT_CATALOG, getComponent } from '../data/components/catalog';
import { LUNA_01 } from '../data/missions/missions';
import type { SpacecraftDesign } from '../data/schemas';
import { EMPTY_DESIGN, placePart, setChassis } from './DesignSystem';
import { analyzeEngineering } from './EngineeringAnalysis';
import { constraintChecks, fixFor, labParameters } from './LabGuidance';

const L = getComponent;
function build(chassisId: string | null, parts: Array<[string, string]>): SpacecraftDesign {
  if (!chassisId) return EMPTY_DESIGN;
  let d = setChassis(EMPTY_DESIGN, chassisId, L).design;
  for (const [c, s] of parts) d = placePart(d, c, s, L).design;
  return d;
}
const REF: Array<[string, string]> = [
  ['camera', 'bottom-0'],
  ['thruster', 'bottom-1'],
  ['antenna-hg', 'top-0'],
  ['attitude-sensor', 'side-pz-0'],
  ['solar-adv', 'side-px-0'],
  ['solar-adv', 'side-nx-0'],
  ['battery-adv', 'bay-0'],
  ['obc', 'bay-1'],
  ['prop-tank', 'bay-2'],
  ['thermal', 'bay-3'],
];
function guide(design: SpacecraftDesign, objectiveId = 'obj-mapping') {
  const report = analyzeEngineering({ design, lookup: L, template: LUNA_01, objectiveId });
  const objectiveInstrumentId = LUNA_01.objectives.find((o) => o.id === objectiveId)?.primaryInstrumentId;
  const ctx = { design, lookup: L, catalog: COMPONENT_CATALOG, objectiveInstrumentId };
  const params = labParameters(report, ctx);
  const state = Object.fromEntries(params.map((p) => [p.id, p.state]));
  return { report, ctx, params, state, checks: constraintChecks(LUNA_01, report, params) };
}

describe('Parámetros críticos del LAB', () => {
  it('sin chasis: todo «falta» (nada se marca como correcto sin evaluarlo)', () => {
    const g = guide(EMPTY_DESIGN);
    expect(Object.values(g.state).every((s) => s === 'missing')).toBe(true);
    expect(g.report.viable).toBe(false);
  });

  it('diseño de referencia: los seis correctos y el diseño es viable', () => {
    const g = guide(build('chassis-m', REF));
    expect(g.report.viable).toBe(true);
    expect(g.state).toEqual({ mass: 'ok', budget: 'ok', energy: 'ok', comms: 'ok', propulsion: 'ok', instrument: 'ok' });
    expect(g.checks.filter((c) => c.severity === 'hard').every((c) => c.state === 'ok')).toBe(true);
  });

  it('solo chasis: falta energía, comunicaciones, propulsión e instrumento', () => {
    const g = guide(build('chassis-m', []));
    expect(g.state.energy).toBe('missing');
    expect(g.state.comms).toBe('missing');
    expect(g.state.propulsion).toBe('missing');
    expect(g.state.instrument).toBe('missing');
    expect(g.state.mass).toBe('ok');
  });

  it('paneles sin batería: la energía «falta» y la solución abre baterías', () => {
    const g = guide(build('chassis-m', REF.filter(([c]) => c !== 'battery-adv')));
    const e = g.params.find((p) => p.id === 'energy')!;
    expect(e.state).toBe('missing');
    expect(e.fix.category).toBe('POWER');
    expect(e.fix.componentIds.every((id) => (L(id)?.energyStorageWh ?? 0) > 0)).toBe(true);
  });

  it('balance negativo con piezas instaladas: la energía «incumple»', () => {
    // Radar (180 W) con un solo panel básico (150 W) y batería básica: datos reales del catálogo.
    const weak: Array<[string, string]> = [['radar', 'bottom-0'], ['thruster', 'bottom-1'], ['antenna-hg', 'top-0'], ['attitude-sensor', 'side-pz-0'], ['solar-basic', 'side-px-0'], ['battery-basic', 'bay-0'], ['obc', 'bay-1'], ['prop-tank', 'bay-2'], ['thermal', 'bay-3']];
    const g = guide(build('chassis-m', weak), 'obj-ice');
    expect(g.report.issues.some((i) => i.severity === 'critical' && ['energy-balance', 'power-deficit', 'battery-empty', 'battery-dod'].includes(i.id))).toBe(true);
    expect(g.state.energy).toBe('fail');
    expect(g.report.viable).toBe(false);
  });

  it('el instrumento que necesita otras piezas «falta» y apunta a la pieza que falta', () => {
    const g = guide(build('chassis-m', REF.filter(([c]) => c !== 'attitude-sensor')));
    const i = g.params.find((p) => p.id === 'instrument')!;
    expect(i.state).toBe('missing');
    expect(i.fix.componentIds).toContain('attitude-sensor');
  });
});

describe('«Solucionar problema»', () => {
  it('cada problema crítico de un diseño incompleto tiene categoría y piezas permitidas', () => {
    const g = guide(build('chassis-m', [['camera', 'bottom-0']]));
    const crit = g.report.issues.filter((i) => i.severity === 'critical');
    expect(crit.length).toBeGreaterThan(0);
    for (const issue of crit) {
      const fix = fixFor(issue, g.ctx);
      expect(fix === null, issue.id).toBe(false);
      expect(fix!.componentIds.length, issue.id).toBeGreaterThan(0);
      for (const id of fix!.componentIds) expect(L(id)!.category).toBe(fix!.category);
    }
  });

  it('sin antena: abre Comunicaciones con las antenas del catálogo', () => {
    const g = guide(build('chassis-m', REF.filter(([c]) => c !== 'antenna-hg')));
    expect(g.state.comms).toBe('missing');
    const f = g.params.find((p) => p.id === 'comms')!.fix;
    expect(f.category).toBe('COMMS');
    expect(f.componentIds).toContain('antenna-basic');
    expect(f.componentIds).toContain('antenna-hg');
  });

  it('presupuesto: apunta a la pieza más cara y a alternativas más baratas de su familia', () => {
    const g = guide(build('chassis-m', REF));
    const f = fixFor({ id: 'budget-over' }, g.ctx)!;
    const installed = REF.map(([c]) => L(c)!);
    const top = [...installed].sort((a, b) => b.costMUSD - a.costMUSD)[0];
    expect(f.category).toBe(top.category);
    for (const id of f.componentIds) expect(L(id)!.costMUSD).toBeLessThan(top.costMUSD);
  });
});

describe('Restricciones de la misión', () => {
  it('las cinco restricciones de LUNA-01 tienen estado calculado', () => {
    const g = guide(build('chassis-m', REF));
    expect(g.checks.map((c) => c.id)).toEqual(LUNA_01.constraints.map((c) => c.id));
    expect(g.checks.find((c) => c.id === 'c-budget')!.state).toBe('ok');
  });
  it('con el presupuesto superado, la restricción obligatoria incumple', () => {
    const g = guide(build('chassis-m', REF));
    const tight = { ...LUNA_01, budgetCapMUSD: 20 };
    const r = analyzeEngineering({ design: build('chassis-m', REF), lookup: L, template: tight, objectiveId: 'obj-mapping' });
    const params = labParameters(r, g.ctx);
    expect(params.find((p) => p.id === 'budget')!.state).toBe('fail');
    expect(constraintChecks(tight, r, params).find((c) => c.id === 'c-budget')!.state).toBe('fail');
    expect(r.viable).toBe(false);
  });
});
