/**
 * ScoringSystem — informe final y puntuación con criterios TRANSPARENTES (Fase 6).
 *
 * Éxito de la misión = criterio técnico: datos en Tierra ≥ objetivo científico. La puntuación
 * (0–100) mide la calidad de la ejecución, pero NUNCA convierte un fracaso técnico en éxito:
 * sin éxito no se desbloquean misiones y la experiencia (XP) es solo parcial.
 *
 * Criterios (100 puntos):
 *   Ciencia 40   = 40 × mín(1, entregado / objetivo)
 *   Presupuesto 15 = 8 por no excederlo + 7 × mín(1, sobrante / 25 % del tope)
 *   Energía 15   = 15 − 4 × entradas en modo seguro − 2 × horas de apagón
 *   Datos 10     = 10 × (1 − perdidos / generados)
 *   Decisiones 20 = media por acontecimiento (mejor opción 1 · segunda 0,6 · otra 0,3) × 20
 */
import type { FlightState, MissionPlan, MissionTemplate, ScienceObjective } from '../data/schemas';
import type { BudgetSummary } from './BudgetSystem';
import type { DesignIssue } from './DesignSystem';
import type { FlightModel } from './MissionSystem';
import { coverageFraction } from './TrajectorySystem';
import { fmtNum } from './units';
import { numLocale } from '../i18n/lang';

export interface ScoreCriterion {
  id: 'science' | 'budget' | 'energy' | 'data' | 'decisions';
  label: string;
  points: number;
  max: number;
  explanation: string;
}

export interface MissionScore {
  criteria: ScoreCriterion[];
  total: number;
  grade: 'S' | 'A' | 'B' | 'C' | 'D';
  success: boolean;
  xp: number;
  spentMUSD: number;
}

export interface ScoreInput {
  template: MissionTemplate;
  objective: ScienceObjective;
  plan: MissionPlan;
  model: FlightModel;
  flight: FlightState;
  /** Presupuesto comprometido antes del vuelo (nave + lanzador + operación). */
  budget: BudgetSummary;
  /** Problemas de optimización que el análisis señaló en el diseño aprobado. */
  designOptimizations: DesignIssue[];
}

const r1 = (x: number) => Math.round(x * 10) / 10;

/** Calificación por puntuación total (reconocimiento por desempeño). */
export const GRADE_THRESHOLDS: Array<[MissionScore['grade'], number]> = [
  ['S', 90],
  ['A', 80],
  ['B', 65],
  ['C', 50],
  ['D', 0],
];
/** XP: con éxito, la base de la misión + 3 por punto; sin éxito, 1,5 por punto. */
export const XP_PER_POINT_SUCCESS = 3;
export const XP_PER_POINT_FAIL = 1.5;

export function scoreMission(i: ScoreInput): MissionScore {
  const f = i.flight;
  const target = i.objective.dataTargetGbit;
  const spent = i.budget.committedMUSD + f.extraCostMUSD;
  const cap = i.template.budgetCapMUSD;
  const success = f.deliveredGbit >= target;

  const science = 40 * Math.min(1, f.deliveredGbit / target);
  const budget = spent > cap ? 0 : 8 + 7 * Math.min(1, (cap - spent) / (0.25 * cap));
  const energy = Math.max(0, 15 - 4 * f.safeModeEntries - 2 * f.blackoutH);
  const data = f.generatedGbit > 0 ? 10 * (1 - f.lostGbit / f.generatedGbit) : 0;
  const rankValue = (rank: number) => (rank === 1 ? 1 : rank === 2 ? 0.6 : 0.3);
  const decisions = f.eventHistory.length ? (20 * f.eventHistory.reduce((a, e) => a + rankValue(e.rank), 0)) / f.eventHistory.length : 20;

  const criteria: ScoreCriterion[] = [
    { id: 'science', label: 'Ciencia', points: r1(science), max: 40, explanation: `${fmtNum(f.deliveredGbit, 0)} de ${target.toLocaleString(numLocale())} Gbit del objetivo llegaron a Tierra.` },
    {
      id: 'budget',
      label: 'Presupuesto',
      points: r1(budget),
      max: 15,
      explanation: spent > cap ? `Gastaste ${fmtNum(spent)} MUSD: excede el tope de ${cap}.` : `Gastaste ${fmtNum(spent)} de ${cap} MUSD (sobran ${fmtNum(cap - spent)}).`,
    },
    {
      id: 'energy',
      label: 'Energía y seguridad',
      points: r1(energy),
      max: 15,
      explanation: `${f.safeModeEntries} entrada(s) en modo seguro y ${fmtNum(f.blackoutH)} h de apagón. Batería mínima: ${Math.round(f.minBatteryFraction * 100)} %.`,
    },
    {
      id: 'data',
      label: 'Gestión de datos',
      points: r1(data),
      max: 10,
      explanation: `${fmtNum(f.lostGbit, 0)} de ${fmtNum(f.generatedGbit, 0)} Gbit generados se perdieron por memoria llena.`,
    },
    {
      id: 'decisions',
      label: 'Decisiones ante acontecimientos',
      points: r1(decisions),
      max: 20,
      explanation: f.eventHistory.length
        ? `${f.eventHistory.filter((e) => e.rank === 1).length} de ${f.eventHistory.length} decisiones fueron la mejor opción según la previsión.`
        : 'No hubo acontecimientos.',
    },
  ];
  const total = Math.round(criteria.reduce((a, c) => a + c.points, 0));
  const grade = GRADE_THRESHOLDS.find(([, min]) => total >= min)![0];
  // La progresión no sustituye el criterio técnico: sin éxito, solo una fracción de XP.
  const xp = success ? i.template.rewards.xp + total * XP_PER_POINT_SUCCESS : Math.round(total * XP_PER_POINT_FAIL);
  return { criteria, total, grade, success, xp, spentMUSD: spent };
}

export interface Insight {
  text: string;
  /** Relación de ingeniería que lo explica. */
  why: string;
}

export interface DebriefInsights {
  good: Insight[];
  errors: Insight[];
  recommendations: Insight[];
  coverage: number;
  daysToTarget: number | null;
}

export function debriefInsights(i: ScoreInput, score: MissionScore): DebriefInsights {
  const f = i.flight;
  const good: Insight[] = [];
  const errors: Insight[] = [];
  const recs: Insight[] = [];
  const target = i.objective.dataTargetGbit;
  const reached = f.log.find((e) => e.text.startsWith('Objetivo científico alcanzado'));
  const daysToTarget = reached ? reached.tH / 24 : null;
  const coverage = coverageFraction(i.plan.inclinationDeg);

  if (score.success) {
    good.push({
      text: `Objetivo científico cumplido${daysToTarget !== null ? ` el día ${fmtNum(daysToTarget, 1)}` : ''}.`,
      why: 'La cadena instrumento → memoria → antena tenía capacidad suficiente para devolver los datos a tiempo.',
    });
    if (f.deliveredGbit > target * 2) good.push({ text: `Devolviste ${fmtNum(f.deliveredGbit / target, 1)} veces los datos exigidos.`, why: 'Un enlace holgado deja margen para ciencia adicional.' });
  } else {
    errors.push({
      text: `No se alcanzó el objetivo: ${fmtNum(f.deliveredGbit, 0)} de ${target.toLocaleString(numLocale())} Gbit.`,
      why: 'Los datos que llegan a Tierra están limitados por el más débil entre producción, memoria y enlace.',
    });
    recs.push({ text: 'Revisa en el análisis qué limita los datos: producción, memoria o enlace.', why: 'Mejorar el eslabón que no limita no cambia el resultado.' });
  }

  const optimal = i.plan.inclinationDeg >= i.objective.recommendedOrbit.inclinationDeg[0];
  if (optimal) good.push({ text: `Órbita con cobertura del ${Math.round(coverage * 100)} % de la superficie.`, why: 'Con inclinación cercana a 90°, la Luna gira bajo la nave y se sobrevuela todo.' });
  else errors.push({ text: `Cobertura del ${Math.round(coverage * 100)} %: parte de la superficie nunca se observó.`, why: 'Una órbita inclinada solo sobrevuela latitudes entre −i y +i.' });

  if (f.safeModeEntries === 0 && f.minBatteryFraction > 0.4) {
    good.push({ text: `La batería nunca bajó del ${Math.round(f.minBatteryFraction * 100)} %.`, why: 'El margen energético absorbió eclipses y acontecimientos sin poner la nave en riesgo.' });
  }
  if (f.safeModeEntries > 0) {
    errors.push({ text: `La nave entró ${f.safeModeEntries} vez/veces en modo seguro.`, why: 'Cada modo seguro detiene la ciencia; en una misión real es una situación de riesgo.' });
    recs.push({ text: 'Añade generación (paneles avanzados) o batería, o apaga instrumentos ante caídas de energía.', why: 'El balance por órbita debe ser positivo incluso con un 40 % menos de generación.' });
  }
  if (f.lostGbit > 0) {
    errors.push({ text: `Se perdieron ${fmtNum(f.lostGbit, 0)} Gbit por memoria llena.`, why: 'Entre contactos con Tierra, todo debe caber en la memoria de a bordo.' });
    recs.push({ text: 'Una segunda computadora duplica la memoria; una antena de alta ganancia vacía la memoria más rápido.', why: 'Memoria necesaria ≈ producción × horas sin contacto.' });
  }
  if (score.spentMUSD <= i.template.budgetCapMUSD * 0.85) good.push({ text: `Misión ${fmtNum(i.template.budgetCapMUSD - score.spentMUSD)} MUSD por debajo del presupuesto.`, why: 'Elegir el lanzador más pequeño capaz y no sobredimensionar ahorra mucho.' });
  if (f.propellantKg < 2) {
    errors.push({ text: `Terminaste con solo ${fmtNum(f.propellantKg)} kg de propelente.`, why: 'Sin propelente no se puede mantener la órbita: los mascons la deforman.' });
    recs.push({ text: 'Más propelente u órbita algo más alta (menos mantenimiento).', why: 'El mantenimiento cuesta 0,4 m/s/día a 50 km y crece como (50/h)^1,5.' });
  }
  for (const e of f.eventHistory) {
    if (e.rank === 1) good.push({ text: `Buena decisión ante «${eventLabel(e.type)}»: ${e.choiceLabel}.`, why: e.summary });
    else errors.push({ text: `Ante «${eventLabel(e.type)}» había una opción mejor que «${e.choiceLabel}».`, why: `Tu elección quedó en el puesto ${e.rank} de ${e.optionCount} según la previsión.` });
  }
  for (const o of i.designOptimizations) recs.push({ text: `Diseño: ${o.title}.`, why: o.explanation });

  return { good, errors, recommendations: recs, coverage, daysToTarget };
}

export function eventLabel(t: FlightState['eventHistory'][number]['type']): string {
  return t === 'power-degradation' ? 'caída de generación' : t === 'comms-outage' ? 'avería de la estación terrestre' : 'anomalía del instrumento';
}
