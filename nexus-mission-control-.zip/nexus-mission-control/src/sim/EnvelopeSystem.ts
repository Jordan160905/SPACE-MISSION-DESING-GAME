/**
 * EnvelopeSystem — tamaño de la nave plegada, para comprobar si cabe en la cofia (Fase 4)
 * y para colocarla dentro del cohete en la vista de integración.
 *
 * Modelo: el chasis es una caja; cada pieza exterior añade su `outwardM` según la normal del
 * anclaje y su `halfWidthM` lateralmente. El diámetro necesario es el del círculo que contiene
 * la sección; la altura va de lo más bajo (anillo o piezas inferiores) a lo más alto.
 */
import { STOWED_ENVELOPE, SEPARATION_RING_M } from '../data/components/envelopes';
import type { SpacecraftDesign } from '../data/schemas';
import type { ComponentLookup } from './BudgetSystem';

export interface Envelope {
  /** Semiejes del chasis (m). */
  half: [number, number, number];
  diameterM: number;
  heightM: number;
  /** Lo que sobresale por debajo de la cara inferior del chasis (m), incluido el anillo. */
  belowM: number;
  /** Lo que sobresale por encima de la cara superior (m). */
  aboveM: number;
}

export function chassisHalf(sockets: Array<{ position: [number, number, number]; type: string }>): [number, number, number] {
  let hx = 0;
  let hy = 0;
  let hz = 0;
  for (const s of sockets) {
    if (s.type === 'internal') continue;
    hx = Math.max(hx, Math.abs(s.position[0]));
    hy = Math.max(hy, Math.abs(s.position[1]));
    hz = Math.max(hz, Math.abs(s.position[2]));
  }
  return [hx, hy, hz];
}

export function stowedEnvelope(design: SpacecraftDesign, lookup: ComponentLookup): Envelope | null {
  const chassis = design.chassisId ? lookup(design.chassisId) : undefined;
  if (!chassis) return null;
  const half = chassisHalf(chassis.sockets);
  const [hx, hy, hz] = half;
  let radius = Math.hypot(hx, hz);
  let above = 0;
  let below = SEPARATION_RING_M;
  for (const p of design.parts) {
    const s = chassis.sockets.find((x) => x.id === p.socketId);
    const env = STOWED_ENVELOPE[p.componentId];
    if (!s || !env || s.type === 'internal') continue;
    const [x, , z] = s.position;
    if (s.type === 'top') {
      above = Math.max(above, env.outwardM);
      radius = Math.max(radius, Math.hypot(x, z) + env.halfWidthM);
    } else if (s.type === 'bottom') {
      below = Math.max(below, env.outwardM);
      radius = Math.max(radius, Math.hypot(x, z) + env.halfWidthM);
    } else {
      // lateral: normal horizontal (±X o ±Z)
      const alongX = Math.abs(s.normal[0]) > 0.5;
      const out = (alongX ? hx : hz) + env.outwardM;
      const tangential = (alongX ? Math.abs(z) : Math.abs(x)) + env.halfWidthM;
      radius = Math.max(radius, Math.hypot(out, tangential));
    }
  }
  return { half, diameterM: radius * 2, heightM: hy * 2 + above + below, belowM: below, aboveM: above };
}
