/**
 * EventSystem — acontecimientos inesperados en operaciones (Fase 6).
 *
 * Principios:
 *  - Cada acontecimiento MODIFICA el estado real de la simulación (efectos en MissionSystem).
 *  - Cada uno ofrece alternativas con consecuencias cuantificables; algunas dependen del diseño
 *    (ruedas de reacción, batería disponible, presupuesto restante).
 *  - Antes de decidir, previewOptions() simula cada alternativa hasta el final de la campaña con el
 *    mismo motor, para que el jugador compare datos, batería, propelente y costo.
 *  - El calendario es determinista (semilla = id de la misión): la misma misión vive los mismos
 *    acontecimientos, lo que permite comparar diseños en igualdad de condiciones.
 */
import type { FlightEventType, FlightState, SpacecraftDesign } from '../data/schemas';
import type { ComponentLookup } from './BudgetSystem';
import { buildFlightModel, log, propellantAfterBurn, snapshot, stepFlight, type FlightModel } from './MissionSystem';

// ───────────────────────── Calendario ─────────────────────────

function hashSeed(text: string): number {
  let h = 2166136261;
  for (let i = 0; i < text.length; i++) {
    h ^= text.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Tres acontecimientos, uno de cada tipo, en orden pseudoaleatorio, a lo largo de la campaña. */
export function scheduleEvents(seedText: string, durationH: number, hasInstrument: boolean) {
  const r = rng(hashSeed(seedText));
  const types: FlightEventType[] = ['power-degradation', 'comms-outage', ...(hasInstrument ? (['instrument-anomaly'] as const) : [])];
  for (let i = types.length - 1; i > 0; i--) {
    const j = Math.floor(r() * (i + 1));
    [types[i], types[j]] = [types[j], types[i]];
  }
  const slots = [0.15, 0.42, 0.68];
  return types.map((type, k) => ({
    id: `ev-${k + 1}-${type}`,
    type,
    // ±4 % de jitter; nunca antes de 24 h ni en los últimos 3 días
    atH: Math.round(Math.min(durationH - 72, Math.max(24, durationH * (slots[k] + (r() - 0.5) * 0.08)))),
  }));
}

// ───────────────────────── Definiciones ─────────────────────────

export interface EventContext {
  design: SpacecraftDesign;
  lookup: ComponentLookup;
  model: FlightModel;
  /** Presupuesto que queda antes de este acontecimiento (MUSD). */
  remainingBudgetMUSD: number;
}

export interface EventOption {
  id: string;
  label: string;
  description: string;
  available: boolean;
  unavailableReason?: string;
  /** Costo directo en MUSD (si lo hay). */
  costMUSD: number;
  apply: (s: FlightState) => FlightState;
}

export interface EventDefinition {
  type: FlightEventType;
  title: string;
  /** Qué ha pasado y por qué (educativo). */
  description: string;
  engineering: string;
  options: EventOption[];
}

const DEGRADATION_H = 48;
const DEGRADED_FACTOR = 0.6;
const OUTAGE_H = 48;
const BACKUP_OUTAGE_H = 6;
const BACKUP_COST_MUSD = 1.5;
const REORIENT_DV_MS = 8;
const RECALIBRATION_ENERGY_FRACTION = 0.35;

function primaryInstrument(ctx: EventContext) {
  return ctx.model.instruments[0];
}

export function eventDefinition(type: FlightEventType, ctx: EventContext, state: FlightState): EventDefinition {
  const t = state.elapsedH;
  const allInstrumentsOff = (s: FlightState, hours: number): FlightState => ({
    ...s,
    effects: [...s.effects, ...ctx.model.instruments.map((i) => ({ kind: 'instrument-offline' as const, instanceId: i.instanceId, untilH: t + hours }))],
  });

  if (type === 'power-degradation') {
    const hasWheels = ctx.design.parts.some((p) => p.componentId === 'reaction-wheels');
    const dvLeft = snapshot(ctx.model, state).deltaVLeftMS;
    return {
      type,
      title: 'Caída de generación eléctrica',
      description: `Un impacto de micrometeoritos daña parte del cableado de los paneles: la generación cae un ${Math.round((1 - DEGRADED_FACTOR) * 100)} % durante ${DEGRADATION_H} h, hasta que el software de a bordo reconfigure los circuitos.`,
      engineering:
        'Con menos potencia, el excedente en la parte iluminada puede no bastar para recargar lo que consume el eclipse. El margen energético de tu diseño decide si puedes seguir trabajando.',
      options: [
        {
          id: 'keep',
          label: 'Mantener la operación científica',
          description: 'Seguir con todo encendido y confiar en el margen de la batería.',
          available: true,
          costMUSD: 0,
          apply: (s) => ({ ...s, effects: [...s.effects, { kind: 'gen-factor', factor: DEGRADED_FACTOR, untilH: t + DEGRADATION_H }] }),
        },
        {
          id: 'instruments-off',
          label: 'Apagar los instrumentos durante la avería',
          description: `Proteger la batería sacrificando ${DEGRADATION_H} h de ciencia.`,
          available: ctx.model.instruments.length > 0,
          unavailableReason: 'No hay instrumentos que apagar.',
          costMUSD: 0,
          apply: (s) => allInstrumentsOff({ ...s, effects: [...s.effects, { kind: 'gen-factor', factor: DEGRADED_FACTOR, untilH: t + DEGRADATION_H }] }, DEGRADATION_H),
        },
        {
          id: 'reorient',
          label: hasWheels ? 'Reorientar con las ruedas de reacción' : `Reorientar con los propulsores (${REORIENT_DV_MS} m/s)`,
          description: hasWheels
            ? 'Girar la nave para que los paneles sanos reciban luz perpendicular: la pérdida baja al 15 %, sin gastar propelente.'
            : `Sin ruedas de reacción, hay que girar con los propulsores: la pérdida baja al 15 % a cambio de ${REORIENT_DV_MS} m/s de propelente.`,
          available: hasWheels || dvLeft > REORIENT_DV_MS * 3,
          unavailableReason: 'No queda propelente suficiente para maniobrar.',
          costMUSD: 0,
          apply: (s) => ({
            ...s,
            propellantKg: hasWheels ? s.propellantKg : propellantAfterBurn(ctx.model.dryKg, s.propellantKg, ctx.model.ispS, REORIENT_DV_MS),
            effects: [...s.effects, { kind: 'gen-factor', factor: 0.85, untilH: t + DEGRADATION_H }],
          }),
        },
      ],
    };
  }

  if (type === 'comms-outage') {
    return {
      type,
      title: 'Avería en la estación terrestre',
      description: `La antena de tierra asignada a tu misión sufre una avería en su sistema de seguimiento: ${OUTAGE_H} h sin enlace.`,
      engineering:
        'Sin enlace, todo lo que producen los instrumentos se acumula en la memoria de a bordo. Si se llena, los datos nuevos se pierden. La capacidad de memoria y la tasa de producción de tu nave deciden cuánto se pierde.',
      options: [
        {
          id: 'wait',
          label: 'Esperar la reparación',
          description: 'Mantener los instrumentos encendidos y almacenar lo que quepa.',
          available: true,
          costMUSD: 0,
          apply: (s) => ({ ...s, effects: [...s.effects, { kind: 'station-outage', untilH: t + OUTAGE_H }] }),
        },
        {
          id: 'backup',
          label: `Contratar una antena de respaldo (+${BACKUP_COST_MUSD} MUSD)`,
          description: `Otra red de espacio profundo cubre a tu misión: solo ${BACKUP_OUTAGE_H} h sin enlace mientras se coordina.`,
          available: ctx.remainingBudgetMUSD >= BACKUP_COST_MUSD,
          unavailableReason: `Quedan ${ctx.remainingBudgetMUSD.toFixed(1)} MUSD: no alcanza para la antena de respaldo.`,
          costMUSD: BACKUP_COST_MUSD,
          apply: (s) => ({ ...s, extraCostMUSD: s.extraCostMUSD + BACKUP_COST_MUSD, effects: [...s.effects, { kind: 'station-outage', untilH: t + BACKUP_OUTAGE_H }] }),
        },
        {
          id: 'instruments-off',
          label: 'Apagar los instrumentos hasta la reparación',
          description: 'No producir datos que no se podrán guardar. Se ahorra energía, pero no se observa nada.',
          available: ctx.model.instruments.length > 0,
          unavailableReason: 'No hay instrumentos que apagar.',
          costMUSD: 0,
          apply: (s) => allInstrumentsOff({ ...s, effects: [...s.effects, { kind: 'station-outage', untilH: t + OUTAGE_H }] }, OUTAGE_H),
        },
      ],
    };
  }

  const inst = primaryInstrument(ctx);
  const batteryFrac = snapshot(ctx.model, state).batteryFraction;
  return {
    type,
    title: `Anomalía en ${inst ? inst.name.toLowerCase() : 'un instrumento'}`,
    description: `Una partícula de alta energía (radiación cósmica) alteró la electrónica de ${inst ? inst.name.toLowerCase() : 'el instrumento'}: sus datos salen con ruido y no son fiables.`,
    engineering:
      'Fuera del campo magnético terrestre, la radiación provoca «eventos de partícula única» que corrompen memorias y sensores. Recalibrar exige energía; reiniciar, tiempo; seguir así, aceptar datos de menor calidad.',
    options: [
      {
        id: 'reboot',
        label: 'Reinicio en frío',
        description: 'Apagar y encender el instrumento: queda 24 h fuera de servicio mientras se recalientan y prueban los detectores.',
        available: !!inst,
        costMUSD: 0,
        apply: (s) => (inst ? { ...s, effects: [...s.effects, { kind: 'instrument-offline', instanceId: inst.instanceId, untilH: t + 24 }] } : s),
      },
      {
        id: 'recalibrate',
        label: 'Recalibración intensiva',
        description: `Calibrar con lámparas internas: consume el ${Math.round(RECALIBRATION_ENERGY_FRACTION * 100)} % de la batería y deja el instrumento solo 4 h fuera de servicio.`,
        available: !!inst && batteryFrac >= 0.5,
        unavailableReason: `La batería está al ${Math.round(batteryFrac * 100)} %: se necesita al menos el 50 %.`,
        costMUSD: 0,
        apply: (s) =>
          inst
            ? {
                ...s,
                batteryWh: Math.max(0, s.batteryWh - ctx.model.batteryCapacityWh * RECALIBRATION_ENERGY_FRACTION),
                effects: [...s.effects, { kind: 'instrument-offline', instanceId: inst.instanceId, untilH: t + 4 }],
              }
            : s,
      },
      {
        id: 'degraded',
        label: 'Seguir en modo degradado',
        description: 'Descartar los canales dañados: el instrumento sigue trabajando, pero produce la mitad de datos útiles el resto de la misión.',
        available: !!inst,
        costMUSD: 0,
        apply: (s) => (inst ? { ...s, effects: [...s.effects, { kind: 'instrument-rate', instanceId: inst.instanceId, factor: 0.5 }] } : s),
      },
    ],
  };
}

// ───────────────────────── Previsión y resolución ─────────────────────────

export interface OptionPreview {
  optionId: string;
  /** Datos en Tierra al final de la campaña (sin más acontecimientos). */
  finalDeliveredGbit: number;
  lostGbit: number;
  /** Batería mínima desde ahora hasta el final. */
  minBatteryFraction: number;
  safeModeEntries: number;
  propellantKg: number;
  costMUSD: number;
  meetsTarget: boolean;
  /** Valor compuesto usado para ordenar opciones (transparente; ver optionValue). */
  value: number;
}

/**
 * Valor de una opción: datos útiles en Tierra, penalizando pérdidas, entradas en modo seguro
 * (riesgo para la nave), costo en dinero y no alcanzar el objetivo.
 */
export function optionValue(p: Omit<OptionPreview, 'value' | 'optionId'>, targetGbit: number): number {
  return p.finalDeliveredGbit - 0.5 * p.lostGbit - 400 * p.safeModeEntries - 100 * p.costMUSD - (p.meetsTarget ? 0 : targetGbit);
}

export function previewOptions(ctx: EventContext, state: FlightState, def: EventDefinition): OptionPreview[] {
  const base: FlightState = { ...state, pendingEventId: null, minBatteryFraction: snapshot(ctx.model, state).batteryFraction, safeModeEntries: 0, lostGbit: 0 };
  return def.options
    .filter((o) => o.available)
    .map((o) => {
      const end = stepFlight(ctx.model, o.apply(base), ctx.model.durationH, { ignoreEvents: true });
      const p = {
        finalDeliveredGbit: end.deliveredGbit,
        lostGbit: end.lostGbit,
        minBatteryFraction: end.minBatteryFraction,
        safeModeEntries: end.safeModeEntries,
        propellantKg: end.propellantKg,
        costMUSD: o.costMUSD,
        meetsTarget: end.deliveredGbit >= ctx.model.targetGbit,
      };
      return { optionId: o.id, ...p, value: optionValue(p, ctx.model.targetGbit) };
    });
}

/** Aplica la opción elegida, registra la decisión con su posición en la previsión y reanuda. */
export function resolveEvent(ctx: EventContext, state: FlightState, optionId: string): FlightState {
  const ev = state.scheduledEvents.find((e) => e.id === state.pendingEventId);
  if (!ev) return state;
  const def = eventDefinition(ev.type, ctx, state);
  const opt = def.options.find((o) => o.id === optionId && o.available);
  if (!opt) return state;
  const previews = previewOptions(ctx, state, def).sort((a, b) => b.value - a.value);
  const rank = previews.findIndex((p) => p.optionId === optionId) + 1;
  const chosen = previews.find((p) => p.optionId === optionId);
  let s = opt.apply({ ...state, pendingEventId: null });
  s = {
    ...s,
    eventHistory: [
      ...s.eventHistory,
      {
        id: ev.id,
        type: ev.type,
        atH: state.elapsedH,
        choiceId: opt.id,
        choiceLabel: opt.label,
        rank: Math.max(1, rank),
        optionCount: previews.length,
        summary: chosen ? `Previsión: ${Math.round(chosen.finalDeliveredGbit)} Gbit al final, ${Math.round(chosen.lostGbit)} perdidos.` : '',
      },
    ],
  };
  return log(s, 'info', `Decisión: ${opt.label}.`);
}

/** Ayuda para construir el contexto desde una misión. */
export function eventContext(design: SpacecraftDesign, lookup: ComponentLookup, model: FlightModel, remainingBudgetMUSD: number): EventContext {
  return { design, lookup, model, remainingBudgetMUSD };
}

export { buildFlightModel };
