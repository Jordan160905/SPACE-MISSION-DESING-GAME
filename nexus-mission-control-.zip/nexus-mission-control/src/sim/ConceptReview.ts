/**
 * ConceptReview — herramientas de revisión de concepto inspiradas en la práctica de NASA:
 *
 *  1. Matriz de Trazabilidad Científica (STM): objetivo → medición → instrumento → requisito
 *     de misión → desempeño previsto → método de verificación. («Design and Develop Science
 *     Missions»: los requisitos se derivan de los objetivos y cada uno se verifica por análisis,
 *     inspección, prueba o demostración.)
 *  2. Master Equipment List (MEL) con contingencia de masa según la herencia de vuelo de cada
 *     pieza, como la que produce un laboratorio de diseño concurrente (Mission Design Lab).
 *  3. Matriz de riesgos 5 × 5 (probabilidad × consecuencia) derivada de los márgenes calculados.
 *  4. Concept Maturity Levels (Wessen et al., JPL, «Space Mission Concept Development using
 *     Concept Maturity Levels»): lista de verificación por nivel, regla del 80 % en verde y
 *     elementos clave que bloquean el nivel aunque se supere el 80 % (juicio de ingeniería).
 *  5. Ciclo de vida y revisiones: equivalencia entre las etapas del juego, las fases de NASA y
 *     los pasos de desarrollo de una CubeSat («CubeSat 101», NASA CSLI).
 *
 * Todo es puro y se calcula a partir del análisis existente: aquí no se inventa ningún número.
 * Los umbrales didácticos están documentados en docs/ASSUMPTIONS.md.
 */
import type { ComponentDef, Mission, MissionTemplate, ScienceObjective } from '../data/schemas';
import type { ComponentLookup } from './BudgetSystem';
import { designComponents } from './DesignSystem';
import { disposalDeltaVMS } from './EllipticalOrbit';
import type { EngineeringReport } from './EngineeringAnalysis';
import { DRY_MASS_MARGIN } from './MassSystem';
import type { PlanReport } from './PlanningSystem';
import { MAX_DOD, RECOMMENDED_DOD } from './PowerSystem';
import { fmtNum } from './units';
import { numLocale } from '../i18n/lang';

// ───────────────────────── 1 · Matriz de trazabilidad ─────────────────────────

export type VerificationMethod = 'Análisis' | 'Inspección' | 'Prueba' | 'Demostración';
export type TraceStatus = 'met' | 'at-risk' | 'not-met' | 'pending';

export interface TraceRow {
  id: string;
  measurement: string;
  instrumentRequirement: string;
  missionRequirement: string;
  predicted: string;
  method: VerificationMethod;
  status: TraceStatus;
}

export interface TraceabilityMatrix {
  scienceGoal: string;
  scienceObjective: string;
  rows: TraceRow[];
  complete: boolean;
}

export interface ReviewInput {
  mission: Pick<Mission, 'stage' | 'objectiveId' | 'design' | 'plan' | 'flight' | 'trades'>;
  template: MissionTemplate;
  engineering: EngineeringReport;
  plan: PlanReport | null;
  lookup: ComponentLookup;
}

const objectiveOf = (i: ReviewInput): ScienceObjective | undefined => i.template.objectives.find((o) => o.id === i.mission.objectiveId);

export function traceabilityMatrix(i: ReviewInput): TraceabilityMatrix {
  const o = objectiveOf(i);
  const e = i.engineering;
  const instr = o ? i.lookup(o.primaryInstrumentId) : undefined;
  const comps = designComponents(i.mission.design, i.lookup);
  const rows: TraceRow[] = [];
  if (!o) return { scienceGoal: i.template.scenario, scienceObjective: '—', rows, complete: false };

  const hasInstr = comps.some((c) => c.id === o.primaryInstrumentId);
  rows.push({
    id: 'instrument',
    measurement: o.summary,
    instrumentRequirement: `${instr?.name ?? o.primaryInstrumentId} a bordo`,
    missionRequirement: 'Instrumento principal integrado en la nave',
    predicted: hasInstr ? 'Instalado' : 'No instalado',
    method: 'Inspección',
    status: hasInstr ? 'met' : 'not-met',
  });

  const [hMin, hMax] = o.recommendedOrbit.altitudeKm;
  const [iMin, iMax] = o.recommendedOrbit.inclinationDeg;
  const alt = i.plan?.plan.altitudeKm;
  const inc = i.plan?.plan.inclinationDeg;
  rows.push({
    id: 'altitude',
    measurement: o.primaryInstrumentId === 'radar' ? 'Señal de radar suficiente' : 'Resolución espacial suficiente',
    instrumentRequirement: o.primaryInstrumentId === 'radar' ? 'La potencia recibida cae con la distancia' : 'El detalle mejora al volar más bajo',
    missionRequirement: `Altitud entre ${hMin} y ${hMax} km`,
    predicted: alt === undefined ? 'Sin plan de vuelo' : `${alt} km`,
    method: 'Análisis',
    status: alt === undefined ? 'pending' : alt >= hMin && alt <= hMax ? 'met' : alt >= 30 ? 'at-risk' : 'not-met',
  });
  const polar = o.id === 'obj-polar-ice';
  rows.push({
    id: 'coverage',
    measurement: polar ? 'Sobrevolar los cráteres polares en sombra' : 'Cubrir las zonas de interés',
    instrumentRequirement: 'El instrumento solo ve lo que pasa bajo la nave',
    missionRequirement: `Inclinación entre ${iMin} y ${Math.min(90, iMax)}°`,
    predicted: inc === undefined ? 'Sin plan de vuelo' : `${inc}° · cobertura ${Math.round((i.plan?.coverage ?? 0) * 100)} %`,
    method: 'Análisis',
    status: inc === undefined ? 'pending' : inc >= iMin ? 'met' : polar && inc < 85 ? 'not-met' : 'at-risk',
  });

  const d = e.data;
  rows.push({
    id: 'volume',
    measurement: `${o.dataTargetGbit.toLocaleString(numLocale())} Gbit de datos científicos en Tierra`,
    instrumentRequirement: instr ? `Produce ${fmtNum(instr.dataGenGbitPerH, 1)} Gbit/h encendido` : '—',
    missionRequirement: `Enlace + memoria entregan ≥ ${o.dataTargetGbit.toLocaleString(numLocale())} Gbit en la campaña`,
    predicted: d ? `${fmtNum(d.missionDeliveredGbit, 0)} Gbit previstos` : 'Sin análisis',
    method: 'Análisis',
    status: !d ? 'pending' : !d.targetMet ? 'not-met' : d.missionDeliveredGbit < d.targetGbit * 1.1 ? 'at-risk' : 'met',
  });
  rows.push({
    id: 'buffer',
    measurement: 'No perder observaciones entre contactos',
    instrumentRequirement: 'Los datos se guardan a bordo hasta el siguiente pase',
    missionRequirement: 'Memoria ≥ datos generados en el hueco diario sin estación',
    predicted: d ? `${fmtNum(d.storageGbit, 0)} / ${fmtNum(d.bufferNeededGbit, 0)} Gbit` : 'Sin análisis',
    method: 'Análisis',
    status: !d ? 'pending' : d.lostPerDayGbit > 0 ? 'at-risk' : 'met',
  });
  const p = e.power;
  rows.push({
    id: 'power',
    measurement: 'Operar el instrumento durante toda la campaña',
    instrumentRequirement: instr ? `Consume ${instr.powerDrawW} W` : '—',
    missionRequirement: 'Balance energético positivo y batería que sobrevive al eclipse',
    predicted: p ? `${p.orbitBalanceWh >= 0 ? '+' : ''}${fmtNum(p.orbitBalanceWh)} Wh/órbita · descarga ${Math.round(p.depthOfDischarge * 100)} %` : 'Sin análisis',
    method: 'Análisis',
    status: !p ? 'pending' : !p.sustainable || p.depthOfDischarge > MAX_DOD ? 'not-met' : p.depthOfDischarge > RECOMMENDED_DOD ? 'at-risk' : 'met',
  });
  const f = i.mission.flight;
  if (f && (i.mission.stage === 'DEBRIEF' || i.mission.stage === 'COMPLETE')) {
    rows.push({
      id: 'flight',
      measurement: 'Ciencia devuelta realmente',
      instrumentRequirement: '—',
      missionRequirement: `≥ ${o.dataTargetGbit.toLocaleString(numLocale())} Gbit entregados en vuelo`,
      predicted: `${fmtNum(f.deliveredGbit, 0)} Gbit entregados`,
      method: 'Demostración',
      status: f.deliveredGbit >= o.dataTargetGbit ? 'met' : 'not-met',
    });
  }
  return {
    scienceGoal: i.template.name,
    scienceObjective: o.title,
    rows,
    complete: rows.every((r) => r.status === 'met' || r.status === 'at-risk'),
  };
}

// ───────────────────────── 2 · Master Equipment List ─────────────────────────

/** Contingencia didáctica por herencia (las tablas reales dependen también del subsistema). */
export const HERITAGE_CONTINGENCY: Record<ComponentDef['heritage'], number> = {
  'flight-proven': 0.05,
  modified: 0.15,
  new: 0.3,
};
export const HERITAGE_LABEL: Record<ComponentDef['heritage'], string> = {
  'flight-proven': 'Con herencia de vuelo',
  modified: 'Modificado',
  new: 'Desarrollo nuevo',
};

export interface MelRow {
  componentId: string;
  name: string;
  category: ComponentDef['category'];
  qty: number;
  unitKg: number;
  cbeKg: number;
  heritage: ComponentDef['heritage'];
  contingency: number;
  mevKg: number;
  powerW: number;
  costMUSD: number;
}

export interface EquipmentList {
  rows: MelRow[];
  /** Current Best Estimate: masa seca sin contingencia. */
  cbeKg: number;
  contingencyKg: number;
  /** Maximum Expected Value: CBE + contingencia por pieza. */
  mevKg: number;
  /** Contingencia efectiva frente a la masa seca. */
  effectiveContingency: number;
  /** El margen plano del juego (10 %) cubre la contingencia por herencia. */
  flatMarginCovers: boolean;
  propellantKg: number;
}

export function equipmentList(design: Mission['design'], lookup: ComponentLookup): EquipmentList {
  const byId = new Map<string, MelRow>();
  for (const c of designComponents(design, lookup)) {
    const row = byId.get(c.id);
    if (row) {
      row.qty += 1;
      continue;
    }
    byId.set(c.id, {
      componentId: c.id,
      name: c.name,
      category: c.category,
      qty: 1,
      unitKg: c.massKg,
      cbeKg: 0,
      heritage: c.heritage,
      contingency: HERITAGE_CONTINGENCY[c.heritage],
      mevKg: 0,
      powerW: 0,
      costMUSD: 0,
    });
  }
  let propellantKg = 0;
  for (const c of designComponents(design, lookup)) propellantKg += c.propellantKg;
  const rows = [...byId.values()].map((r) => {
    const c = lookup(r.componentId)!;
    const cbeKg = r.unitKg * r.qty;
    return { ...r, cbeKg, mevKg: cbeKg * (1 + r.contingency), powerW: c.powerDrawW * r.qty, costMUSD: c.costMUSD * r.qty };
  });
  const cbeKg = rows.reduce((s, r) => s + r.cbeKg, 0);
  const mevKg = rows.reduce((s, r) => s + r.mevKg, 0);
  const contingencyKg = mevKg - cbeKg;
  const effectiveContingency = cbeKg > 0 ? contingencyKg / cbeKg : 0;
  return { rows, cbeKg, contingencyKg, mevKg, effectiveContingency, flatMarginCovers: effectiveContingency <= DRY_MASS_MARGIN + 1e-9, propellantKg };
}

// ───────────────────────── 3 · Matriz de riesgos 5 × 5 ─────────────────────────

export type RiskLevel = 'low' | 'medium' | 'high';
export interface Risk {
  id: string;
  title: string;
  /** 1 (improbable) … 5 (casi seguro). */
  likelihood: number;
  /** 1 (menor) … 5 (pérdida de la misión). */
  consequence: number;
  level: RiskLevel;
  driver: string;
  mitigation: string;
}

export function riskLevel(l: number, c: number): RiskLevel {
  const s = l * c;
  return s >= 15 ? 'high' : s >= 6 ? 'medium' : 'low';
}

/** Probabilidad a partir de un margen relativo: cuanto menos margen, más probable el problema. */
function likelihoodFromMargin(margin: number, steps: [number, number, number]): number {
  if (!Number.isFinite(margin) || margin < 0) return 5;
  if (margin < steps[0]) return 4;
  if (margin < steps[1]) return 3;
  if (margin < steps[2]) return 2;
  return 1;
}

export function riskRegister(i: ReviewInput): Risk[] {
  const e = i.engineering;
  const o = objectiveOf(i);
  const out: Risk[] = [];
  const add = (r: Omit<Risk, 'level'>) => out.push({ ...r, level: riskLevel(r.likelihood, r.consequence) });

  if (e.power) {
    const m = e.power.rechargeNeededWh > 0 ? e.power.orbitBalanceWh / e.power.rechargeNeededWh : e.power.orbitBalanceWh >= 0 ? 1 : -1;
    add({
      id: 'r-energy',
      title: 'Déficit de energía en órbita',
      likelihood: e.power.sustainable ? likelihoodFromMargin(m, [0.05, 0.1, 0.25]) : 5,
      consequence: 4,
      driver: `Margen energético ${pctText(m)} por órbita`,
      mitigation: 'Más superficie de paneles o menos consumo; apagar instrumentos en el eclipse.',
    });
    const dod = e.power.depthOfDischarge;
    add({
      id: 'r-battery',
      title: 'Degradación de la batería',
      likelihood: dod > 1 ? 5 : dod > MAX_DOD ? 4 : dod > RECOMMENDED_DOD ? 3 : dod > 0.25 ? 2 : 1,
      consequence: 3,
      driver: `Descarga del ${Math.round(dod * 100)} % en cada eclipse`,
      mitigation: `Batería mayor para descargar menos del ${Math.round(RECOMMENDED_DOD * 100)} %.`,
    });
  }
  if (e.data && o) {
    const m = e.data.targetGbit > 0 ? e.data.missionDeliveredGbit / e.data.targetGbit - 1 : 1;
    add({
      id: 'r-science',
      title: 'No devolver la ciencia prometida',
      likelihood: likelihoodFromMargin(m, [0.1, 0.3, 0.5]),
      consequence: 5,
      driver: `Datos previstos ${pctText(m + 1)} del objetivo`,
      mitigation: 'Antena de mayor velocidad, más memoria o campaña más larga.',
    });
  }
  if (i.plan) {
    const dv = i.plan.deltaV;
    if (dv.ispS > 0) {
      add({
        id: 'r-propellant',
        title: 'Propelente insuficiente',
        likelihood: likelihoodFromMargin(dv.marginFraction, [0.05, 0.1, 0.25]),
        consequence: 5,
        driver: `Margen de Δv ${Number.isFinite(dv.marginFraction) ? Math.round(dv.marginFraction * 100) : '—'} %`,
        mitigation: 'Otro tanque, nave más ligera, ventana óptima o misión más corta.',
      });
    }
    const cap = i.plan.launcher.payloadToTLIKg;
    const mm = cap > 0 ? (cap - i.plan.massWithMarginKg) / cap : -1;
    add({
      id: 'r-mass',
      title: 'La nave crece por encima de la capacidad del lanzador',
      likelihood: likelihoodFromMargin(mm, [0.05, 0.1, 0.2]),
      consequence: 5,
      driver: `Reserva del lanzador ${Math.round(mm * 100)} %`,
      mitigation: 'Lanzador mayor o reducir masa; vigilar la contingencia de la MEL.',
    });
    const fail = 1 - i.plan.launcher.reliability;
    add({
      id: 'r-launch',
      title: 'Fallo del lanzador',
      likelihood: fail <= 0.02 ? 1 : fail <= 0.04 ? 2 : fail <= 0.06 ? 3 : 4,
      consequence: 5,
      driver: `Fiabilidad ${Math.round(i.plan.launcher.reliability * 100)} %`,
      mitigation: 'Elegir un vehículo con más historial de éxito (cuesta más).',
    });
    const h = i.plan.plan.altitudeKm;
    add({
      id: 'r-orbit',
      title: 'Órbita deformada por los mascons',
      likelihood: h < 30 ? 5 : h < 50 ? 3 : h < 80 ? 2 : 1,
      consequence: 4,
      driver: `Altitud ${h} km`,
      mitigation: 'Subir la órbita o reservar más Δv de mantenimiento.',
    });
  }
  if (e.budget) {
    const r = e.budget.capMUSD > 0 ? e.budget.remainingMUSD / e.budget.capMUSD : -1;
    add({
      id: 'r-cost',
      title: 'Sobrecosto',
      likelihood: e.budget.overBudget ? 5 : likelihoodFromMargin(r, [0.02, 0.05, 0.15]),
      consequence: 3,
      driver: `Reserva ${Math.round(r * 100)} % del presupuesto`,
      mitigation: 'Piezas más baratas o lanzador menor para recuperar reserva.',
    });
  }
  const order = { high: 0, medium: 1, low: 2 } as const;
  return out.sort((a, b) => order[a.level] - order[b.level] || b.likelihood * b.consequence - a.likelihood * a.consequence);
}

// ───────────────────────── 4 · Concept Maturity Levels ─────────────────────────

export type CmlArea = 'science' | 'technical' | 'management' | 'cost' | 'other';
export type CmlStatus = 'G' | 'Y' | 'R';

export const CML_AREA_LABEL: Record<CmlArea, string> = {
  science: 'Ciencia',
  technical: 'Técnica',
  management: 'Gestión',
  cost: 'Costo',
  other: 'Otros',
};

export interface CmlDefinition {
  level: number;
  name: string;
  description: string;
  /** Dónde se alcanza en NEXUS, o null si queda fuera del juego. */
  inGame: string | null;
}

export const CML_DEFINITIONS: CmlDefinition[] = [
  { level: 1, name: 'Servilleta', description: 'La pregunta científica y la idea de misión están claras y se ha esbozado el concepto.', inGame: 'Elegir el objetivo en el Briefing' },
  { level: 2, name: 'Viabilidad inicial', description: 'Se cuantifican los parámetros clave y los cálculos de primer orden muestran que la idea es viable.', inGame: 'Primer diseño analizado en el Lab' },
  { level: 3, name: 'Espacio de compromisos', description: 'Se exploran alternativas de nave, órbita y lanzador para entender ciencia, costo y riesgo.', inGame: 'Comparar opciones en el Planner' },
  { level: 4, name: 'Diseño puntual', description: 'Se elige un diseño concreto, definido por subsistemas, con márgenes y reservas aceptables.', inGame: 'Diseño aprobado y plan con márgenes' },
  { level: 5, name: 'Concepto de referencia', description: 'Enfoque de implementación definido. Nivel de una Revisión del Concepto de Misión (MCR).', inGame: 'Plan confirmado para el lanzamiento' },
  { level: 6, name: 'Concepto integrado', description: 'Detalle técnico, de gestión y de costo documentado (propuesta de paso 2).', inGame: null },
  { level: 7, name: 'Línea base preliminar', description: 'Requisitos y análisis preliminares, prototipos y planes de mitigación de riesgo.', inGame: null },
  { level: 8, name: 'PDR', description: 'Diseño y planificación a nivel de Revisión de Diseño Preliminar.', inGame: null },
  { level: 9, name: 'CDR', description: 'Diseño y planificación a nivel de Revisión de Diseño Crítico.', inGame: null },
];

export interface CmlItem {
  id: string;
  level: number;
  area: CmlArea;
  label: string;
  status: CmlStatus;
  detail: string;
  /** Si está en rojo, el nivel no se alcanza aunque se supere el 80 % (juicio de ingeniería). */
  key?: boolean;
}

export interface CmlLevelScore {
  level: number;
  green: number;
  total: number;
  fraction: number;
  keyMissing: CmlItem[];
  passed: boolean;
}

export interface CmlReport {
  level: number;
  items: CmlItem[];
  scores: CmlLevelScore[];
  next: CmlLevelScore | null;
}

export const CML_PASS_FRACTION = 0.8;
const STAGES: Mission['stage'][] = ['DESIGN', 'PLANNING', 'LAUNCH', 'OPERATIONS', 'DEBRIEF', 'COMPLETE'];
const stageAtLeast = (s: Mission['stage'], t: Mission['stage']) => STAGES.indexOf(s) >= STAGES.indexOf(t);

/** Porcentaje legible: los márgenes enormes se muestran como «> 300 %». */
export function pctText(x: number): string {
  if (!Number.isFinite(x)) return '—';
  return x > 3 ? '> 300 %' : `${Math.round(x * 100)} %`;
}

const tri = (g: boolean, y: boolean): CmlStatus => (g ? 'G' : y ? 'Y' : 'R');

export function conceptMaturity(i: ReviewInput, stm = traceabilityMatrix(i), risks = riskRegister(i), mel = equipmentList(i.mission.design, i.lookup)): CmlReport {
  const e = i.engineering;
  const o = objectiveOf(i);
  const comps = designComponents(i.mission.design, i.lookup);
  const hasChassis = !!i.mission.design.chassisId;
  const t = i.mission.trades;
  const items: CmlItem[] = [];
  const add = (it: CmlItem) => items.push(it);

  // CML 2 · Viabilidad inicial
  add({ id: 'c2-kpp', level: 2, area: 'science', label: 'Parámetros clave cuantificados', status: tri(!!o, false), detail: o ? `Objetivo: ${o.dataTargetGbit.toLocaleString(numLocale())} Gbit · órbita ${o.recommendedOrbit.altitudeKm.join('–')} km` : 'Sin objetivo' });
  add({
    id: 'c2-config',
    level: 2,
    area: 'technical',
    label: 'Configuración de nave con instrumento',
    status: tri(hasChassis && !!o && comps.some((c) => c.id === o.primaryInstrumentId), hasChassis),
    detail: hasChassis ? `${comps.length} piezas instaladas` : 'Sin chasis',
  });
  add({ id: 'c2-power', level: 2, area: 'technical', label: 'Balance de energía de primer orden', status: tri(!!e.power && e.power.nominalGenW > 0, !!e.power), detail: e.power ? `${fmtNum(e.power.orbitBalanceWh)} Wh/órbita` : 'Sin calcular' });
  add({ id: 'c2-link', level: 2, area: 'technical', label: 'Enlace y volumen de datos', status: tri(!!e.comms && e.comms.downlinkMbps > 0, !!e.comms), detail: e.comms ? `${fmtNum(e.comms.downlinkGbitPerDay)} Gbit/día de enlace` : 'Sin calcular' });
  add({
    id: 'c2-mass',
    level: 2,
    area: 'technical',
    label: 'Masa frente a los lanzadores',
    status: tri(!!e.mass && e.mass.launchersThatFit.length > 0, !!e.mass),
    detail: e.mass ? `${fmtNum(e.mass.wetWithMarginKg)} kg con margen · ${e.mass.launchersThatFit.length} lanzador(es) posibles` : 'Sin calcular',
  });
  add({ id: 'c2-cost', level: 2, area: 'cost', label: 'Costo estimado frente al tope', status: tri(!!e.budget && !e.budget.overBudget, !!e.budget), detail: e.budget ? `${fmtNum(e.budget.committedMUSD)} / ${e.budget.capMUSD} MUSD` : 'Sin calcular' });

  // CML 3 · Espacio de compromisos (lo que el equipo exploró de verdad)
  add({ id: 'c3-launchers', level: 3, area: 'technical', label: 'Lanzadores comparados', status: tri(t.launchers.length >= 2, t.launchers.length === 1), detail: `${t.launchers.length} evaluado(s)` });
  add({ id: 'c3-orbit', level: 3, area: 'science', label: 'Órbitas exploradas (altitud e inclinación)', status: tri(t.altitudes.length >= 2 && t.inclinations.length >= 2, t.altitudes.length + t.inclinations.length >= 3), detail: `${t.altitudes.length} altitudes · ${t.inclinations.length} inclinaciones` });
  add({ id: 'c3-duration', level: 3, area: 'cost', label: 'Sensibilidad costo–duración', status: tri(t.durations.length >= 2, false), detail: `${t.durations.length} duración(es) evaluada(s)` });
  add({ id: 'c3-ellipse', level: 3, area: 'technical', label: 'Alternativa de órbita elíptica estudiada', status: tri(t.ellipticalStudies > 0, false), detail: t.ellipticalStudies > 0 ? `${t.ellipticalStudies} estudio(s)` : 'Usa el simulador elíptico del Planner' });

  // CML 4 · Diseño puntual con márgenes y reservas
  const p = e.power;
  const eMargin = p && p.rechargeNeededWh > 0 ? p.orbitBalanceWh / p.rechargeNeededWh : -1;
  add({ id: 'c4-approved', level: 4, area: 'management', label: 'Diseño aprobado por el análisis', status: tri(stageAtLeast(i.mission.stage, 'PLANNING'), e.viable), detail: e.viable ? 'Sin problemas críticos' : 'Hay problemas críticos', key: true });
  add({ id: 'c4-stm', level: 4, area: 'science', label: 'Matriz de trazabilidad completa', status: tri(stm.complete && stm.rows.every((r) => r.status === 'met'), stm.complete), detail: `${stm.rows.filter((r) => r.status === 'met').length}/${stm.rows.length} requisitos cumplidos`, key: true });
  add({ id: 'c4-mel', level: 4, area: 'technical', label: 'Master Equipment List con contingencia', status: tri(hasChassis && mel.flatMarginCovers, hasChassis), detail: hasChassis ? `Contingencia ${Math.round(mel.effectiveContingency * 100)} % frente al margen del ${DRY_MASS_MARGIN * 100} %` : 'Sin piezas', key: true });
  add({ id: 'c4-energy', level: 4, area: 'technical', label: 'Margen energético ≥ 10 %', status: tri(!!p?.sustainable && eMargin >= 0.1, !!p?.sustainable), detail: p ? pctText(eMargin) : '—' });
  add({ id: 'c4-dod', level: 4, area: 'technical', label: `Descarga de batería ≤ ${Math.round(RECOMMENDED_DOD * 100)} %`, status: tri(!!p && p.depthOfDischarge <= RECOMMENDED_DOD, !!p && p.depthOfDischarge <= MAX_DOD), detail: p ? `${Math.round(p.depthOfDischarge * 100)} %` : '—' });
  const dv = i.plan?.deltaV;
  add({ id: 'c4-dv', level: 4, area: 'technical', label: 'Margen de Δv ≥ 10 %', status: tri(!!dv && dv.marginFraction >= 0.1, !!dv && dv.ok), detail: dv && Number.isFinite(dv.marginFraction) ? `${Math.round(dv.marginFraction * 100)} %` : 'Sin plan' });
  const cap = i.plan?.launcher.payloadToTLIKg ?? 0;
  const lm = i.plan && cap > 0 ? (cap - i.plan.massWithMarginKg) / cap : -1;
  add({ id: 'c4-lv', level: 4, area: 'technical', label: 'Reserva de capacidad del lanzador ≥ 10 %', status: tri(!!i.plan && lm >= 0.1 && i.plan.fairingFits, !!i.plan && lm >= 0 && i.plan.fairingFits), detail: i.plan ? `${Math.round(lm * 100)} %` : 'Sin plan' });
  const reserve = e.budget && e.budget.capMUSD > 0 ? e.budget.remainingMUSD / e.budget.capMUSD : -1;
  add({ id: 'c4-reserve', level: 4, area: 'cost', label: 'Reserva de presupuesto ≥ 5 %', status: tri(!!e.budget && reserve >= 0.05, !!e.budget && reserve >= 0), detail: e.budget ? `${Math.round(reserve * 100)} %` : '—' });
  const disposal = i.plan ? disposalDeltaVMS(i.plan.plan.altitudeKm) : NaN;
  add({
    id: 'c4-disposal',
    level: 4,
    area: 'other',
    label: 'Plan de fin de misión (impacto controlado)',
    status: tri(!!dv && dv.ispS > 0 && dv.marginMS >= disposal, !!dv && dv.ok),
    detail: i.plan ? `Requiere ${fmtNum(disposal, 0)} m/s · sobran ${dv && Number.isFinite(dv.marginMS) ? fmtNum(dv.marginMS, 0) : '—'} m/s` : 'Sin plan',
  });

  // CML 5 · Concepto de referencia (MCR)
  const highRisks = risks.filter((r) => r.level === 'high');
  add({ id: 'c5-risk', level: 5, area: 'management', label: 'Sin riesgos altos sin mitigar', status: tri(highRisks.length === 0, highRisks.length <= 1), detail: `${highRisks.length} riesgo(s) alto(s)`, key: true });
  add({ id: 'c5-window', level: 5, area: 'management', label: 'Calendario: ventana de lanzamiento óptima', status: tri(i.plan?.window.status === 'optimal', i.plan?.window.status === 'marginal'), detail: i.plan ? i.plan.window.status : 'Sin plan' });
  add({ id: 'c5-conops', level: 5, area: 'management', label: 'Concepto de operaciones (plan confirmado)', status: tri(stageAtLeast(i.mission.stage, 'LAUNCH'), !!i.plan?.ready), detail: stageAtLeast(i.mission.stage, 'LAUNCH') ? 'Confirmado' : i.plan?.ready ? 'Listo para confirmar' : 'Pendiente', key: true });
  add({ id: 'c5-ground', level: 5, area: 'other', label: 'Segmento terreno: contactos diarios', status: tri(!!e.comms && e.comms.contactHoursPerDay > 0 && !!e.data && e.data.lostPerDayGbit === 0, !!e.comms && e.comms.contactHoursPerDay > 0), detail: e.comms ? `${fmtNum(e.comms.contactHoursPerDay, 1)} h de contacto al día` : '—' });

  const scores: CmlLevelScore[] = [2, 3, 4, 5].map((level) => {
    const lv = items.filter((x) => x.level === level);
    const green = lv.filter((x) => x.status === 'G').length;
    const keyMissing = lv.filter((x) => x.key && x.status === 'R');
    const fraction = lv.length ? green / lv.length : 0;
    return { level, green, total: lv.length, fraction, keyMissing, passed: fraction >= CML_PASS_FRACTION && keyMissing.length === 0 };
  });
  let level = o ? 1 : 0;
  for (const s of scores) {
    if (s.level === level + 1 && s.passed) level = s.level;
  }
  return { level, items, scores, next: scores.find((s) => s.level === level + 1) ?? null };
}

// ───────────────────────── 5 · Ciclo de vida y revisiones ─────────────────────────

export interface LifecycleStep {
  id: string;
  nasaPhase: string;
  review: string;
  game: string;
  cubesat: string;
  stage: Mission['stage'] | null;
}

/**
 * Equivalencias. Las fases y revisiones son las del ciclo de vida de proyectos de NASA; los plazos
 * CubeSat son los típicos de «CubeSat 101» (NASA CSLI). El juego comprime años en minutos.
 */
export const LIFECYCLE: LifecycleStep[] = [
  { id: 'pre-a', nasaPhase: 'Pre-Fase A · Estudios de concepto', review: 'Revisión del Concepto de Misión (MCR)', game: 'Briefing, Lab y Planner (CML 1–5)', cubesat: 'Desarrollo del concepto (1–6 meses) y revisiones de mérito y viabilidad (1–2 meses)', stage: 'DESIGN' },
  { id: 'a-b', nasaPhase: 'Fases A y B · Requisitos y diseño preliminar', review: 'Revisión de Requisitos (SRR) y de Diseño Preliminar (PDR)', game: 'Comprimidas: el análisis de ingeniería hace de revisión', cubesat: 'Diseño de la CubeSat (1–6 meses)', stage: 'PLANNING' },
  { id: 'c-d', nasaPhase: 'Fases C y D · Diseño final, fabricación y pruebas', review: 'Revisión de Diseño Crítico (CDR) y de Preparación para el Vuelo (FRR)', game: 'Verificación previa al lanzamiento en Launch Control', cubesat: 'Fabricación y pruebas (2–12 meses), revisión de preparación (medio día), integración en el dispensador (1 día)', stage: 'LAUNCH' },
  { id: 'e', nasaPhase: 'Fase E · Operaciones', review: 'Revisiones de operación y decisiones ante anomalías', game: 'Operaciones en órbita lunar y acontecimientos', cubesat: 'Operaciones de la misión (variable)', stage: 'OPERATIONS' },
  { id: 'f', nasaPhase: 'Fase F · Cierre', review: 'Lecciones aprendidas y archivo de datos', game: 'Informe y Archivo', cubesat: 'Fin de misión y reentrada / desecho', stage: 'DEBRIEF' },
];

/** Referencia CubeSat (CubeSat 101): 1U = cubo de 10 cm de unos 1–1,33 kg. */
export const CUBESAT_1U = { edgeCm: 10, minKg: 1, maxKg: 1.33 } as const;
