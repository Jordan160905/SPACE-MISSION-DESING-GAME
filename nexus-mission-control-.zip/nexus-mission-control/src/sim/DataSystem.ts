/**
 * DataSystem + CommsSystem — cuántos datos se producen, cuántos caben y cuántos llegan a Tierra.
 *
 * Supuestos:
 *  - Instrumentos al 100 % de su ciclo (en la Fase 5 el jugador podrá encenderlos y apagarlos).
 *  - Pasivos: producen solo en la fracción iluminada; activos (radar): todo el tiempo.
 *  - Enlace por día = tasa (Gbit/h) × 24 h × fracción de contacto.
 *  - Cada día hay un hueco continuo sin estación (OrbitAnalysis.maxGapH): lo producido en ese hueco
 *    debe caber en la memoria; lo que no cabe se pierde.
 */
import type { SpacecraftDesign } from '../data/schemas';
import type { ComponentLookup } from './BudgetSystem';
import { designComponents } from './DesignSystem';
import type { OrbitAnalysis } from './OrbitSystem';
import { mbpsToGbitPerHour } from './units';

export interface CommsAnalysis {
  downlinkMbps: number;
  downlinkGbitPerH: number;
  contactHoursPerDay: number;
  downlinkGbitPerDay: number;
}

export interface DataAnalysis {
  /** Producción media (Gbit/h) teniendo en cuenta la iluminación. */
  avgGenGbitPerH: number;
  genGbitPerDay: number;
  storageGbit: number;
  /** Memoria necesaria para el hueco diario sin contacto. */
  bufferNeededGbit: number;
  lostPerDayGbit: number;
  deliveredGbitPerDay: number;
  /** Datos que quedan pendientes cada día porque el enlace no da abasto. */
  backlogGbitPerDay: number;
  missionDays: number;
  missionDeliveredGbit: number;
  targetGbit: number;
  targetMet: boolean;
  /** Días necesarios para alcanzar el objetivo (Infinity si nunca). */
  daysToTarget: number;
}

export function analyzeComms(design: SpacecraftDesign, lookup: ComponentLookup, orbit: OrbitAnalysis): CommsAnalysis {
  const comps = designComponents(design, lookup);
  const downlinkMbps = comps.reduce((m, c) => Math.max(m, c.downlinkMbps), 0);
  const downlinkGbitPerH = mbpsToGbitPerHour(downlinkMbps);
  const contactHoursPerDay = 24 * orbit.contactFraction;
  return { downlinkMbps, downlinkGbitPerH, contactHoursPerDay, downlinkGbitPerDay: downlinkGbitPerH * contactHoursPerDay };
}

export function analyzeData(
  design: SpacecraftDesign,
  lookup: ComponentLookup,
  orbit: OrbitAnalysis,
  comms: CommsAnalysis,
  mission: { durationDays: number; targetGbit: number },
): DataAnalysis {
  const comps = designComponents(design, lookup);
  const sunFraction = 1 - orbit.eclipseFraction;
  const avgGenGbitPerH = comps.reduce((s, c) => s + c.dataGenGbitPerH * (c.requiresSunlight ? sunFraction : 1), 0);
  const genGbitPerDay = avgGenGbitPerH * 24;
  const storageGbit = comps.reduce((s, c) => s + c.dataStorageGbit, 0);
  const bufferNeededGbit = avgGenGbitPerH * orbit.maxGapH;
  const lostPerDayGbit = Math.max(0, bufferNeededGbit - storageGbit);
  const deliveredGbitPerDay = Math.max(0, Math.min(comms.downlinkGbitPerDay, genGbitPerDay - lostPerDayGbit));
  const backlogGbitPerDay = Math.max(0, genGbitPerDay - lostPerDayGbit - comms.downlinkGbitPerDay);
  const missionDeliveredGbit = deliveredGbitPerDay * mission.durationDays;
  return {
    avgGenGbitPerH,
    genGbitPerDay,
    storageGbit,
    bufferNeededGbit,
    lostPerDayGbit,
    deliveredGbitPerDay,
    backlogGbitPerDay,
    missionDays: mission.durationDays,
    missionDeliveredGbit,
    targetGbit: mission.targetGbit,
    targetMet: missionDeliveredGbit >= mission.targetGbit,
    daysToTarget: deliveredGbitPerDay > 0 ? mission.targetGbit / deliveredGbitPerDay : Number.POSITIVE_INFINITY,
  };
}
