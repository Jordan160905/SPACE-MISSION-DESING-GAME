/**
 * OrbitSystem — órbita circular alrededor de la Luna (modelo simplificado y documentado).
 *
 * Supuestos (ver docs/ASSUMPTIONS.md):
 *  - Órbita circular; la Luna es una esfera de radio R = 1737,4 km y μ = 4902,8 km³/s².
 *  - Sombra cilíndrica y peor caso (el Sol en el plano de la órbita, β = 0):
 *      fracción de eclipse = asin(R / (R + h)) / π
 *  - Ocultación de la Tierra: mismo modelo geométrico, peor caso (la Tierra en el plano orbital).
 *  - Las estaciones terrestres dedican a la misión un bloque continuo de 8 h al día.
 */
import type { ScienceObjective } from '../data/schemas';

export const MOON_RADIUS_KM = 1737.4;
export const MOON_MU_KM3_S2 = 4902.8;
export const GROUND_STATION_HOURS_PER_DAY = 8;

export interface OrbitParams {
  altitudeKm: number;
  inclinationDeg: number;
}

export interface OrbitAnalysis extends OrbitParams {
  semiMajorAxisKm: number;
  periodS: number;
  periodMin: number;
  /** Velocidad orbital circular, km/s. */
  velocityKmS: number;
  eclipseFraction: number;
  sunlitMin: number;
  eclipseMin: number;
  /** Fracción de la órbita en que la Luna tapa la Tierra (sin enlace posible). */
  earthOcclusionFraction: number;
  /** Fracción del día con enlace posible = (1 − ocultación) × horas de estación / 24. */
  contactFraction: number;
  /** Mayor intervalo continuo sin contacto (h): el bloque diario sin estación. */
  maxGapH: number;
  orbitsPerDay: number;
}

export function orbitalPeriodS(altitudeKm: number): number {
  const a = MOON_RADIUS_KM + altitudeKm;
  return 2 * Math.PI * Math.sqrt((a * a * a) / MOON_MU_KM3_S2);
}

/** Peor caso (β = 0) con sombra cilíndrica. */
export function eclipseFraction(altitudeKm: number): number {
  return Math.asin(MOON_RADIUS_KM / (MOON_RADIUS_KM + altitudeKm)) / Math.PI;
}

export function analyzeOrbit(o: OrbitParams): OrbitAnalysis {
  if (!(o.altitudeKm > 0)) throw new Error('La altitud debe ser positiva');
  const a = MOON_RADIUS_KM + o.altitudeKm;
  const periodS = orbitalPeriodS(o.altitudeKm);
  const ecl = eclipseFraction(o.altitudeKm);
  const occ = ecl; // misma geometría, peor caso
  const stationShare = GROUND_STATION_HOURS_PER_DAY / 24;
  return {
    ...o,
    semiMajorAxisKm: a,
    periodS,
    periodMin: periodS / 60,
    velocityKmS: Math.sqrt(MOON_MU_KM3_S2 / a),
    eclipseFraction: ecl,
    sunlitMin: (periodS / 60) * (1 - ecl),
    eclipseMin: (periodS / 60) * ecl,
    earthOcclusionFraction: occ,
    contactFraction: (1 - occ) * stationShare,
    maxGapH: 24 - GROUND_STATION_HOURS_PER_DAY,
    orbitsPerDay: 86400 / periodS,
  };
}

/** Órbita de referencia del análisis: punto medio de la recomendada por el objetivo. */
export function referenceOrbit(objective: ScienceObjective | undefined): OrbitParams {
  if (!objective) return { altitudeKm: 100, inclinationDeg: 90 };
  const [a0, a1] = objective.recommendedOrbit.altitudeKm;
  const [i0, i1] = objective.recommendedOrbit.inclinationDeg;
  return { altitudeKm: (a0 + a1) / 2, inclinationDeg: (i0 + i1) / 2 };
}
