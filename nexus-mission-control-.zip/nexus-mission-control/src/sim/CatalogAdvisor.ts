/**
 * CatalogAdvisor — como en el juego «Build It Yourself» del telescopio Webb, el catálogo avisa
 * ANTES de elegir una pieza si no encaja con la nave actual y explica el porqué.
 * No bloquea la elección: el jugador puede aprender del error y el análisis lo marcará igual.
 */
import { difficultyDef, isComponentAllowed, type Difficulty } from '../data/difficulty';
import type { ComponentDef, SpacecraftDesign } from '../data/schemas';
import type { ComponentLookup } from './BudgetSystem';
import { chassisOf, compatibleSockets, designComponents } from './DesignSystem';

export type AdviceKind = 'ok' | 'warn' | 'blocked';
export interface CatalogAdvice {
  kind: AdviceKind;
  /** Texto corto para la tarjeta. */
  label: string;
  /** Explicación completa (tooltip / lector de pantalla). */
  reason: string;
}

const OK: CatalogAdvice = { kind: 'ok', label: '', reason: '' };

export function catalogAdvice(c: ComponentDef, design: SpacecraftDesign, lookup: ComponentLookup, difficulty?: Difficulty): CatalogAdvice {
  if (!isComponentAllowed(c, difficulty)) {
    return { kind: 'blocked', label: 'Gama avanzada', reason: `En dificultad ${difficultyDef(difficulty).label} solo se usan componentes simples: ${c.name} es de gama avanzada.` };
  }
  if (c.category === 'STRUCTURE') return OK;
  const chassis = chassisOf(design, lookup);
  if (!chassis) return { kind: 'blocked', label: 'Falta chasis', reason: 'Primero instala un chasis: es la estructura donde se anclan las piezas.' };
  const installed = designComponents(design, lookup);
  const clash = installed.find((p) => c.incompatibleWith.includes(p.id) || p.incompatibleWith.includes(c.id));
  if (clash) return { kind: 'blocked', label: `Choca con ${clash.name}`, reason: `${c.name} no puede convivir con ${clash.name}. ${c.engineeringNote}` };
  if (compatibleSockets(design, c.id, lookup).length === 0) {
    return {
      kind: 'blocked',
      label: 'Sin anclaje libre',
      reason: `No quedan anclajes libres de tipo ${c.mountsOn.join(' / ')} en el ${chassis.name.toLowerCase()}. Quita una pieza o usa un chasis mayor.`,
    };
  }
  const missing = c.requires.filter((id) => !installed.some((p) => p.id === id));
  if (missing.length) {
    const names = missing.map((id) => lookup(id)?.name ?? id).join(', ');
    return { kind: 'warn', label: `Necesita ${names}`, reason: `${c.name} solo funciona si la nave también lleva: ${names}.` };
  }
  return OK;
}
