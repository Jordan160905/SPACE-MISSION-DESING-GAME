/**
 * Fases 8.4 y 8.5: descubrimientos coherentes con la posición de la nave y rescate jugable.
 */
import { describe, expect, it } from 'vitest';
import { getLauncher } from '../data/launchers/launchers';
import {
  angleFromSun,
  discoveryById,
  discoveryPoints,
  DISCOVERIES,
  distanceTo,
  lunarPoint,
  objectPosition,
  scheduleDiscoveries,
  skyCenter,
  skyDir,
} from './Discoveries';
import { buildFlightProfile, flightStateAt, MU_EARTH, R_EARTH, R_MOON } from './FlightDynamics';
void R_EARTH;
import { bodyAxes, canAssist, newRescue, readout, RESCUE, rescuePoints, returnDv, stepRescue, type RescueInput, type RescueState } from './Rescue';

const P = buildFlightProfile(getLauncher('falcon-9')!, 75);

describe('Descubrimientos (coherentes con el entorno)', () => {
  it('el catálogo cubre todos los tipos pedidos y cada objeto explica algo', () => {
    const kinds = new Set(DISCOVERIES.map((d) => d.kind));
    for (const k of ['satellite', 'debris', 'rock', 'asteroid', 'lunar', 'constellation', 'star', 'nebula']) expect(kinds.has(k as never)).toBe(true);
    for (const d of DISCOVERIES) expect(d.facts.length).toBeGreaterThanOrEqual(2);
  });

  it('cada oportunidad está donde el objeto puede estar', () => {
    for (let seed = 1; seed < 40; seed++) {
      const list = scheduleDiscoveries(P, seed);
      expect(list.length).toBeGreaterThanOrEqual(4);
      expect(new Set(list.map((x) => x.id)).size).toBe(list.length);
      for (const s of list) {
        const def = discoveryById(s.id)!;
        const st = flightStateAt(P, s.t);
        if (def.zone === 'leo') {
          expect(st.phase).toBe('parking');
          expect(distanceTo(P, s, s.t)).toBeLessThan(1200); // pasa a cientos de km
        }
        if (def.zone === 'gps' || def.zone === 'geo') {
          expect(Math.abs(st.altitudeKm + R_EARTH - (def.orbitRadiusKm ?? 0))).toBeLessThan(5);
          expect(distanceTo(P, s, s.t)).toBeLessThan(800);
        }
        if (def.zone === 'cruise') {
          expect(st.phase).toBe('cruise');
          const d = distanceTo(P, s, s.t);
          if (def.id === 'meteoroid') expect(d).toBeLessThan(100);
          else expect(d).toBeGreaterThan(20000);
        }
        if (def.zone === 'approach') {
          // La región mira hacia la nave.
          const q = lunarPoint(P, s.t, def.lunar![0], def.lunar![1]);
          const n = [(q[0] - st.moonX) / R_MOON, (q[1] - st.moonY) / R_MOON, q[2] / R_MOON];
          const v = [st.x - q[0], st.y - q[1], -q[2]];
          expect((n[0] * v[0] + n[1] * v[1] + n[2] * v[2]) / Math.hypot(v[0], v[1], v[2])).toBeGreaterThan(0.1);
          expect(st.moonAltitudeKm).toBeLessThan(70000);
        }
        if (def.zone === 'sky') {
          expect(st.altitudeKm).toBeGreaterThan(100);
          expect(angleFromSun(P, skyCenter(def))).toBeGreaterThan(45);
        }
      }
    }
  });

  it('los satélites se mueven con su velocidad orbital real (los geoestacionarios giran con la Tierra)', () => {
    const geo = { id: 'geo', t: 0, phase0: 0 };
    const a = objectPosition(P, geo, 0)!;
    const b = objectPosition(P, geo, 86164.0905)!;
    expect(Math.hypot(a[0], a[1])).toBeCloseTo(42164, 6);
    expect(Math.hypot(b[0] - a[0], b[1] - a[1])).toBeLessThan(5); // una vuelta en un día sideral (42 164 km, real)
    const iss = { id: 'iss', t: 0, phase0: 0 };
    const r = R_EARTH + 415;
    const period = 2 * Math.PI * Math.sqrt((r * r * r) / MU_EARTH);
    expect(period / 60).toBeGreaterThan(91);
    expect(period / 60).toBeLessThan(94);
    const c = objectPosition(P, iss, period)!;
    expect(Math.hypot(c[0] - r, c[1])).toBeLessThan(1e-3);
  });

  it('el cielo usa coordenadas reales: el plano del vuelo es el ecuador celeste', () => {
    const [x, y, z] = skyDir(0, 90);
    expect(Math.abs(x) + Math.abs(y)).toBeLessThan(1e-12);
    expect(z).toBeCloseTo(1, 12);
    const orion = discoveryById('orion')!;
    const c = skyCenter(orion);
    expect(Math.asin(c[2]) * (180 / Math.PI)).toBeGreaterThan(-6);
    expect(Math.asin(c[2]) * (180 / Math.PI)).toBeLessThan(2);
  });

  it('observar con la cámara da más puntos', () => {
    const d = discoveryById('iss')!;
    expect(discoveryPoints(d, true)).toBeGreaterThan(discoveryPoints(d, false));
  });
});

const CRAFT = { massKg: 280, ispS: 220, budgetKg: 4 };
const idle: RescueInput = { main: false, fwd: 0, right: 0, up: 0, yaw: 0, pitch: 0 };

/** Piloto automático de prueba: usa exactamente los mismos mandos que el jugador. */
function pilot(s: RescueState): RescueInput {
  const r = readout(s);
  const inp: RescueInput = { ...idle };
  if (r.alignDeg > 4) {
    const { right, up } = bodyAxes(s.yaw, s.pitch);
    const u = s.rel.map((v) => v / r.distanceM);
    inp.yaw = u[0] * right[0] + u[1] * right[1] + u[2] * right[2] > 0 ? 1 : -1;
    inp.pitch = u[0] * up[0] + u[1] * up[1] + u[2] * up[2] > 0 ? 1 : -1;
  }
  const { right, up } = bodyAxes(s.yaw, s.pitch);
  const vr = s.relVel[0] * right[0] + s.relVel[1] * right[1] + s.relVel[2] * right[2];
  const vu = s.relVel[0] * up[0] + s.relVel[1] * up[1] + s.relVel[2] * up[2];
  if (Math.abs(vr) > 0.03) inp.right = vr > 0 ? 1 : -1;
  if (Math.abs(vu) > 0.03) inp.up = vu > 0 ? 1 : -1;
  const want = Math.min(r.limitMS * 0.7, Math.max(0.05, (r.distanceM - 60) / 120));
  if (r.closingMS < want - 0.05) inp.fwd = 1;
  if (r.closingMS > want + 0.05) inp.fwd = -1;
  return inp;
}

describe('Rescate espacial', () => {
  it('sin motores, el satélite se mueve en línea recta respecto de la nave', () => {
    const s0: RescueState = { ...newRescue(3), step: 'approach', plan: 'safe' };
    const s1 = stepRescue(s0, idle, 10, CRAFT);
    for (let i = 0; i < 3; i++) expect(s1.rel[i]).toBeCloseTo(s0.rel[i] + s0.relVel[i] * 10, 9);
    expect(s1.fuelKg).toBe(0);
  });

  it('encender el motor cambia la velocidad relativa y gasta combustible (ecuación del cohete)', () => {
    const s0: RescueState = { ...newRescue(3), step: 'approach', plan: 'safe' };
    const s1 = stepRescue(s0, { ...idle, main: true }, 10, CRAFT);
    const { nose } = bodyAxes(s0.yaw, s0.pitch);
    for (let i = 0; i < 3; i++) expect(s1.relVel[i]).toBeCloseTo(s0.relVel[i] - nose[i] * RESCUE.mainAccel * 10, 9);
    expect(s1.dvUsed).toBeCloseTo(0.6, 9);
    expect(s1.fuelKg).toBeCloseTo(280 * (1 - Math.exp(-0.6 / (220 * 9.80665))), 9);
  });

  it('chocar a más de 0,5 m/s falla el rescate (pero no la misión) y permite un reintento', () => {
    const s: RescueState = { ...newRescue(1), step: 'approach', plan: 'safe', rel: [30, 0, 0], relVel: [-2, 0, 0] };
    let x = s;
    for (let k = 0; k < 20; k++) x = stepRescue(x, idle, 0.5, CRAFT);
    expect(x.step).toBe('failed');
    expect(x.outcome).toBe('collision');
  });

  it('es jugable de principio a fin con los mandos: localizar, acercarse, asistir', () => {
    for (const seed of [1, 2, 5, 9]) {
      let s: RescueState = { ...newRescue(seed), step: 'locate' };
      for (let k = 0; k < 2000 && readout(s).alignDeg > RESCUE.lockDeg; k++) s = stepRescue(s, pilot(s), 0.1, CRAFT);
      expect(readout(s).alignDeg).toBeLessThanOrEqual(RESCUE.lockDeg);
      s = { ...s, step: 'approach', plan: 'safe' };
      for (let k = 0; k < 40000 && !canAssist(s) && s.step === 'approach'; k++) s = stepRescue(s, pilot(s), 0.1, CRAFT);
      expect(canAssist(s)).toBe(true);
      s = { ...s, step: 'assist', holdT: 0 };
      for (let k = 0; k < 4000 && s.step === 'assist'; k++) s = stepRescue(s, pilot(s), 0.1, CRAFT);
      expect(s.step).toBe('done');
      expect(rescuePoints(s)).toBeGreaterThan(300);
      expect(s.fuelKg).toBeLessThan(CRAFT.budgetKg);
      expect(returnDv(s)).toBeGreaterThan(0);
    }
  });
});
