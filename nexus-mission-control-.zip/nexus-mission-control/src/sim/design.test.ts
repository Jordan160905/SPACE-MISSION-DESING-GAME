import { describe, expect, it } from 'vitest';
import { getComponent } from '../data/components/catalog';
import { LUNA_01 } from '../data/missions/missions';
import { analyzeEngineering } from './EngineeringAnalysis';
import type { SpacecraftDesign } from '../data/schemas';
import {
  canPlace,
  compatibleSockets,
  DesignError,
  designTotals,
  EMPTY_DESIGN,
  hasCritical,
  movePart,
  placePart,
  removePart,
  setChassis,
  validateDesign,
} from './DesignSystem';

const L = getComponent;

/** Construye un diseño colocando piezas en orden; falla la prueba si alguna no cabe. */
function build(chassisId: string, parts: Array<[string, string]>): SpacecraftDesign {
  let d = setChassis(EMPTY_DESIGN, chassisId, L).design;
  for (const [comp, socket] of parts) d = placePart(d, comp, socket, L).design;
  return d;
}

/** Diseño de referencia viable para el objetivo de cartografía. */
const REFERENCE: Array<[string, string]> = [
  ['camera', 'bottom-0'],
  ['thruster', 'bottom-1'],
  ['antenna-hg', 'top-0'],
  ['attitude-sensor', 'side-pz-0'],
  ['solar-adv', 'side-px-0'],
  ['solar-adv', 'side-nx-0'],
  ['battery-adv', 'bay-0'],
  ['obc', 'bay-1'],
  ['prop-tank', 'bay-2'],
  ['thermal', 'bay-3'],
];

describe('colocación', () => {
  it('sin chasis no se puede colocar nada', () => {
    const r = canPlace(EMPTY_DESIGN, 'camera', 'bottom-0', L);
    expect(r.ok).toBe(false);
  });

  it('respeta el tipo de anclaje', () => {
    const d = build('chassis-m', []);
    expect(canPlace(d, 'solar-basic', 'side-px-0', L).ok).toBe(true);
    const r = canPlace(d, 'solar-basic', 'top-0', L);
    expect(r.ok).toBe(false);
    if (!r.ok) expect(r.reason).toContain('side');
  });

  it('no permite ocupar un anclaje dos veces', () => {
    const d = build('chassis-m', [['battery-basic', 'bay-0']]);
    expect(canPlace(d, 'obc', 'bay-0', L).ok).toBe(false);
    expect(() => placePart(d, 'obc', 'bay-0', L)).toThrow(DesignError);
  });

  it('no permite anclar un chasis', () => {
    expect(canPlace(build('chassis-m', []), 'chassis-s', 'top-0', L).ok).toBe(false);
  });

  it('genera IDs de instancia únicos para piezas repetidas', () => {
    const d = build('chassis-m', [
      ['solar-basic', 'side-px-0'],
      ['solar-basic', 'side-nx-0'],
    ]);
    expect(d.parts.map((p) => p.instanceId)).toEqual(['solar-basic#1', 'solar-basic#2']);
  });

  it('lista solo anclajes compatibles y libres', () => {
    const d = build('chassis-s', [['thruster', 'bottom-0']]);
    expect(compatibleSockets(d, 'radar', L)).toHaveLength(0); // el chasis pequeño solo tiene un anclaje inferior
    expect(compatibleSockets(d, 'solar-basic', L)).toHaveLength(4);
  });

  it('mover y retirar', () => {
    let d = build('chassis-m', [['solar-basic', 'side-px-0']]);
    d = movePart(d, 'solar-basic#1', 'side-nz-1', L);
    expect(d.parts[0].socketId).toBe('side-nz-1');
    expect(() => movePart(d, 'solar-basic#1', 'bay-0', L)).toThrow(DesignError);
    d = removePart(d, 'solar-basic#1');
    expect(d.parts).toHaveLength(0);
  });
});

describe('cambio de chasis', () => {
  it('conserva, reubica o retira piezas según quepan', () => {
    const big = build('chassis-l', [
      ['radar', 'bottom-1'],
      ['thruster', 'bottom-0'],
      ['battery-basic', 'bay-5'],
      ['obc', 'bay-0'],
    ]);
    const r = setChassis(big, 'chassis-s', L);
    // bottom-0 existe en el pequeño: el propulsor se queda; el radar no cabe; bay-5 → se reubica.
    expect(r.design.parts.find((p) => p.componentId === 'thruster')?.socketId).toBe('bottom-0');
    expect(r.removed.map((p) => p.componentId)).toEqual(['radar']);
    expect(r.relocated.map((p) => p.componentId)).toEqual(['battery-basic']);
    expect(r.design.parts).toHaveLength(3);
  });

  it('quitar el chasis vacía el diseño', () => {
    const r = setChassis(build('chassis-m', [['obc', 'bay-0']]), null, L);
    expect(r.design).toEqual(EMPTY_DESIGN);
    expect(r.removed).toHaveLength(1);
  });

  it('rechaza un componente que no es chasis', () => {
    expect(() => setChassis(EMPTY_DESIGN, 'camera', L)).toThrow(DesignError);
  });
});

describe('totales', () => {
  it('suma masa seca, propelente, costo, potencia y datos', () => {
    const t = designTotals(build('chassis-m', REFERENCE), L);
    expect(t.massDryKg).toBe(180);
    expect(t.propellantKg).toBe(80);
    expect(t.massWetKg).toBe(260);
    expect(t.costMUSD).toBeCloseTo(11 + 6 + 3 + 3.5 + 1.8 + 4 + 4 + 2.2 + 2.5 + 1.2 + 1.4, 10);
    expect(t.powerGenW).toBe(640);
    expect(t.powerDrawW).toBe(150);
    expect(t.energyStorageWh).toBe(900);
    expect(t.dataGenGbitPerH).toBe(18);
    expect(t.downlinkMbps).toBe(40);
    expect(t.downlinkGbitPerH).toBeCloseTo(144, 10);
    expect(t.socketsUsed).toBe(10);
  });

  it('el enlace usa la mejor antena, no la suma', () => {
    const t = designTotals(build('chassis-m', [['antenna-hg', 'top-0'], ['antenna-basic', 'side-px-0']]), L);
    expect(t.downlinkMbps).toBe(40);
  });
});

describe('validación', () => {
  const ctx = { objectiveInstrumentId: 'camera' };

  it('el diseño de referencia no tiene problemas', () => {
    expect(validateDesign(build('chassis-m', REFERENCE), L, ctx)).toEqual([]);
  });

  it('sin chasis: un único problema crítico', () => {
    const issues = validateDesign(EMPTY_DESIGN, L, ctx);
    expect(issues.map((i) => i.id)).toEqual(['no-chassis']);
  });

  it('chasis vacío: faltan instrumento y subsistemas esenciales', () => {
    const ids = validateDesign(build('chassis-m', []), L, ctx).map((i) => i.id);
    for (const id of ['objective-instrument', 'no-power', 'no-battery', 'no-comms', 'no-obc', 'no-propulsion']) expect(ids).toContain(id);
  });

  it('detecta requisitos sin cumplir y señala las piezas afectadas', () => {
    const d = build('chassis-m', REFERENCE.filter(([c]) => c !== 'attitude-sensor'));
    const issue = validateDesign(d, L, ctx).find((i) => i.id === 'requires:camera->attitude-sensor');
    expect(issue?.severity).toBe('critical');
    expect(issue?.instanceIds).toEqual(['camera#1']);
    expect(validateDesign(d, L, ctx).some((i) => i.id === 'requires:antenna-hg->attitude-sensor')).toBe(true);
  });

  it('detecta incompatibilidades una sola vez por par', () => {
    const parts: Array<[string, string]> = [...REFERENCE.map(([c, s]) => [c, s] as [string, string]), ['radar', 'bottom-0'], ['antenna-basic', 'side-pz-1']];
    const d = build('chassis-l', parts.filter(
      ([c, s]) => !(c === 'camera' && s === 'bottom-0'),
    ));
    const inc = validateDesign(d, L).filter((i) => i.id.startsWith('incompatible:'));
    expect(inc).toHaveLength(1);
    expect(inc[0].instanceIds).toHaveLength(2);
  });

  it('déficit de potencia a plena luz es crítico; margen escaso es optimización', () => {
    const deficit = build('chassis-m', [...REFERENCE.filter(([c]) => c !== 'solar-adv'), ['solar-basic', 'side-px-0']].map(([c, s]) => [c, s] as [string, string]));
    // 150 W de consumo contra 150 W: no es déficit, pero sin margen.
    const issues = validateDesign(deficit, L, ctx);
    expect(issues.some((i) => i.id === 'power-deficit')).toBe(false);
    expect(issues.find((i) => i.id === 'power-margin')?.severity).toBe('optimization');
    const worse = placePart(deficit, 'spectrometer', 'side-nx-1', L).design;
    expect(validateDesign(worse, L, ctx).find((i) => i.id === 'power-deficit')?.severity).toBe('critical');
  });

  it('cuello de botella de transmisión con antena básica y cámara', () => {
    const d = build('chassis-m', [...REFERENCE.filter(([c]) => c !== 'antenna-hg'), ['antenna-basic', 'top-0']]);
    const i = validateDesign(d, L, ctx).find((x) => x.id === 'downlink-bottleneck');
    expect(i?.severity).toBe('optimization');
  });

  it('hasCritical distingue críticos de optimizaciones', () => {
    expect(hasCritical(validateDesign(build('chassis-m', REFERENCE), L, ctx))).toBe(false);
    expect(hasCritical(validateDesign(EMPTY_DESIGN, L))).toBe(true);
  });
});

describe('jugabilidad: cada objetivo de LUNA-01 tiene al menos un diseño viable', () => {
  const cases: Array<{ objective: string; instrument: string; chassis: string; parts: Array<[string, string]> }> = [
    {
      objective: 'cartografía en chasis pequeño (sin térmico: solo optimización)',
      instrument: 'camera',
      chassis: 'chassis-s',
      parts: [
        ['camera', 'side-pz-0'],
        ['thruster', 'bottom-0'],
        ['antenna-hg', 'top-0'],
        ['attitude-sensor', 'side-nz-0'],
        ['solar-adv', 'side-px-0'],
        ['solar-basic', 'side-nx-0'],
        ['battery-adv', 'bay-0'],
        ['obc', 'bay-1'],
        ['prop-tank', 'bay-2'],
      ],
    },
    {
      objective: 'composición mineral en chasis mediano',
      instrument: 'spectrometer',
      chassis: 'chassis-m',
      parts: [
        ['spectrometer', 'bottom-0'],
        ['thruster', 'bottom-1'],
        ['antenna-hg', 'top-0'],
        ['attitude-sensor', 'side-pz-0'],
        ['solar-adv', 'side-px-0'],
        ['battery-adv', 'bay-0'],
        ['obc', 'bay-1'],
        ['prop-tank', 'bay-2'],
        ['thermal', 'bay-3'],
      ],
    },
    {
      objective: 'hielo polar en chasis mediano',
      instrument: 'radar',
      chassis: 'chassis-m',
      parts: [
        ['radar', 'bottom-0'],
        ['thruster', 'bottom-1'],
        ['antenna-hg', 'top-0'],
        ['attitude-sensor', 'side-pz-0'],
        ['thermal', 'side-nz-0'],
        ['solar-adv', 'side-px-0'],
        ['solar-adv', 'side-nx-0'],
        ['battery-adv', 'bay-0'],
        ['obc', 'bay-1'],
        ['prop-tank', 'bay-2'],
        ['reaction-wheels', 'bay-3'],
      ],
    },
  ];
  for (const c of cases) {
    it(c.objective, () => {
      const design = build(c.chassis, c.parts);
      const issues = validateDesign(design, L, { objectiveInstrumentId: c.instrument });
      expect(hasCritical(issues), issues.map((i) => i.title).join('; ')).toBe(false);
      // y también con el análisis completo de la Fase 3 (energía por órbita, datos, presupuesto)
      const objectiveId = LUNA_01.objectives.find((o) => o.primaryInstrumentId === c.instrument)!.id;
      const report = analyzeEngineering({ design, lookup: L, template: LUNA_01, objectiveId });
      expect(report.viable, report.issues.filter((i) => i.severity === 'critical').map((i) => i.title).join('; ')).toBe(true);
    });
  }
});
