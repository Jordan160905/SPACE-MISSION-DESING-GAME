/**
 * DesignSystem — reglas del constructor modular.
 *
 * Funciones puras sobre SpacecraftDesign. No conocen React ni Three.js, y reciben `lookup` para
 * resolver componentes (inyectable en pruebas).
 *
 * Modelo de ensamblaje (ver docs/DECISIONS.md D-08):
 *   - Un diseño tiene un chasis raíz y piezas montadas en sus sockets.
 *   - Una pieza puede ocupar un socket libre si el tipo del socket está en su `mountsOn`.
 *   - Se permite colocar piezas incompatibles o con requisitos sin cumplir: el jugador debe poder
 *     cometer el error y entenderlo. validateDesign() lo detecta y lo explica.
 */
import type { ComponentDef, PlacedPart, SocketDef, SpacecraftDesign } from '../data/schemas';
import type { ComponentLookup } from './BudgetSystem';
import { mbpsToGbitPerHour } from './units';

export class DesignError extends Error {}

export type PlaceCheck = { ok: true } | { ok: false; reason: string };

export const EMPTY_DESIGN: SpacecraftDesign = { chassisId: null, parts: [] };

function need(lookup: ComponentLookup, id: string): ComponentDef {
  const c = lookup(id);
  if (!c) throw new DesignError(`Componente desconocido: ${id}`);
  return c;
}

export function chassisOf(design: SpacecraftDesign, lookup: ComponentLookup): ComponentDef | null {
  return design.chassisId ? need(lookup, design.chassisId) : null;
}

export function getSocket(design: SpacecraftDesign, socketId: string, lookup: ComponentLookup): SocketDef | undefined {
  return chassisOf(design, lookup)?.sockets.find((s) => s.id === socketId);
}

export function partAt(design: SpacecraftDesign, socketId: string): PlacedPart | undefined {
  return design.parts.find((p) => p.socketId === socketId);
}

/** ¿Puede colocarse `componentId` en `socketId`? `ignoreInstanceId` permite comprobar un movimiento. */
export function canPlace(
  design: SpacecraftDesign,
  componentId: string,
  socketId: string,
  lookup: ComponentLookup,
  ignoreInstanceId?: string,
): PlaceCheck {
  const chassis = chassisOf(design, lookup);
  if (!chassis) return { ok: false, reason: 'Primero elige un chasis: es la estructura donde se anclan todas las piezas.' };
  const comp = lookup(componentId);
  if (!comp) return { ok: false, reason: `Componente desconocido: ${componentId}` };
  if (comp.category === 'STRUCTURE') return { ok: false, reason: 'Un chasis no se ancla a otro chasis; usa «Cambiar chasis».' };
  const socket = chassis.sockets.find((s) => s.id === socketId);
  if (!socket) return { ok: false, reason: `El ${chassis.name.toLowerCase()} no tiene el anclaje ${socketId}.` };
  const occupant = partAt(design, socketId);
  if (occupant && occupant.instanceId !== ignoreInstanceId) {
    return { ok: false, reason: `Ese anclaje ya está ocupado por ${lookup(occupant.componentId)?.name ?? occupant.componentId}.` };
  }
  if (!comp.mountsOn.includes(socket.type)) {
    return { ok: false, reason: `${comp.name} solo se monta en anclajes de tipo ${comp.mountsOn.join(' / ')}; este es ${socket.type}.` };
  }
  return { ok: true };
}

export function compatibleSockets(
  design: SpacecraftDesign,
  componentId: string,
  lookup: ComponentLookup,
  ignoreInstanceId?: string,
): SocketDef[] {
  const chassis = chassisOf(design, lookup);
  if (!chassis) return [];
  return chassis.sockets.filter((s) => canPlace(design, componentId, s.id, lookup, ignoreInstanceId).ok);
}

export function nextInstanceId(design: SpacecraftDesign, componentId: string): string {
  const used = new Set(design.parts.map((p) => p.instanceId));
  let n = 1;
  while (used.has(`${componentId}#${n}`)) n++;
  return `${componentId}#${n}`;
}

export function placePart(
  design: SpacecraftDesign,
  componentId: string,
  socketId: string,
  lookup: ComponentLookup,
): { design: SpacecraftDesign; instanceId: string } {
  const check = canPlace(design, componentId, socketId, lookup);
  if (!check.ok) throw new DesignError(check.reason);
  const instanceId = nextInstanceId(design, componentId);
  return { design: { ...design, parts: [...design.parts, { instanceId, componentId, socketId }] }, instanceId };
}

export function removePart(design: SpacecraftDesign, instanceId: string): SpacecraftDesign {
  return { ...design, parts: design.parts.filter((p) => p.instanceId !== instanceId) };
}

export function movePart(design: SpacecraftDesign, instanceId: string, socketId: string, lookup: ComponentLookup): SpacecraftDesign {
  const part = design.parts.find((p) => p.instanceId === instanceId);
  if (!part) throw new DesignError(`No existe la pieza ${instanceId}`);
  const check = canPlace(design, part.componentId, socketId, lookup, instanceId);
  if (!check.ok) throw new DesignError(check.reason);
  return { ...design, parts: design.parts.map((p) => (p.instanceId === instanceId ? { ...p, socketId } : p)) };
}

/**
 * Cambia el chasis conservando lo posible: cada pieza mantiene su socket si existe en el nuevo
 * chasis; si no, se reubica en el primer socket compatible libre; si no cabe, se retira.
 */
export function setChassis(
  design: SpacecraftDesign,
  chassisId: string | null,
  lookup: ComponentLookup,
): { design: SpacecraftDesign; removed: PlacedPart[]; relocated: PlacedPart[] } {
  if (chassisId === null) return { design: EMPTY_DESIGN, removed: design.parts, relocated: [] };
  const chassis = need(lookup, chassisId);
  if (chassis.category !== 'STRUCTURE') throw new DesignError(`${chassis.name} no es un chasis.`);

  let next: SpacecraftDesign = { chassisId, parts: [] };
  const removed: PlacedPart[] = [];
  const relocated: PlacedPart[] = [];
  const pending: PlacedPart[] = [];

  // 1) Mantener las que conservan socket válido.
  for (const p of design.parts) {
    if (canPlace(next, p.componentId, p.socketId, lookup).ok) next = { ...next, parts: [...next.parts, p] };
    else pending.push(p);
  }
  // 2) Reubicar el resto.
  for (const p of pending) {
    const target = compatibleSockets(next, p.componentId, lookup)[0];
    if (target) {
      const moved = { ...p, socketId: target.id };
      next = { ...next, parts: [...next.parts, moved] };
      relocated.push(moved);
    } else {
      removed.push(p);
    }
  }
  return { design: next, removed, relocated };
}

// ───────────────────────── Totales ─────────────────────────

export interface DesignTotals {
  partCount: number;
  socketsUsed: number;
  socketsTotal: number;
  massDryKg: number;
  propellantKg: number;
  massWetKg: number;
  costMUSD: number;
  powerGenW: number;
  powerDrawW: number;
  energyStorageWh: number;
  dataGenGbitPerH: number;
  dataStorageGbit: number;
  /** Mejor enlace disponible: la nave transmite por una antena a la vez (simplificación). */
  downlinkMbps: number;
  downlinkGbitPerH: number;
}

export function designComponents(design: SpacecraftDesign, lookup: ComponentLookup): ComponentDef[] {
  return [...(design.chassisId ? [design.chassisId] : []), ...design.parts.map((p) => p.componentId)].map((id) => need(lookup, id));
}

export function designTotals(design: SpacecraftDesign, lookup: ComponentLookup): DesignTotals {
  const comps = designComponents(design, lookup);
  const sum = (f: (c: ComponentDef) => number) => comps.reduce((s, c) => s + f(c), 0);
  const dry = sum((c) => c.massKg);
  const prop = sum((c) => c.propellantKg);
  const downlink = comps.reduce((m, c) => Math.max(m, c.downlinkMbps), 0);
  return {
    partCount: comps.length,
    socketsUsed: design.parts.length,
    socketsTotal: chassisOf(design, lookup)?.sockets.length ?? 0,
    massDryKg: dry,
    propellantKg: prop,
    massWetKg: dry + prop,
    costMUSD: sum((c) => c.costMUSD),
    powerGenW: sum((c) => c.powerGenW),
    powerDrawW: sum((c) => c.powerDrawW),
    energyStorageWh: sum((c) => c.energyStorageWh),
    dataGenGbitPerH: sum((c) => c.dataGenGbitPerH),
    dataStorageGbit: sum((c) => c.dataStorageGbit),
    downlinkMbps: downlink,
    downlinkGbitPerH: mbpsToGbitPerHour(downlink),
  };
}

// ───────────────────────── Validación ─────────────────────────

export type IssueSeverity = 'critical' | 'optimization';

export interface DesignIssue {
  id: string;
  severity: IssueSeverity;
  title: string;
  /** Relación de ingeniería que explica el problema y cómo corregirlo. */
  explanation: string;
  instanceIds: string[];
}

export interface ValidationContext {
  /** Instrumento exigido por el objetivo científico de la misión activa. */
  objectiveInstrumentId?: string;
}

const hasCat = (comps: ComponentDef[], cat: ComponentDef['category']) => comps.some((c) => c.category === cat);

export function validateDesign(design: SpacecraftDesign, lookup: ComponentLookup, ctx: ValidationContext = {}): DesignIssue[] {
  const issues: DesignIssue[] = [];
  if (!design.chassisId) {
    issues.push({
      id: 'no-chassis',
      severity: 'critical',
      title: 'Sin chasis',
      explanation: 'El chasis es la estructura que soporta y conecta todos los subsistemas. Elige uno para empezar.',
      instanceIds: [],
    });
    return issues;
  }
  const comps = designComponents(design, lookup);
  const ids = new Set(comps.map((c) => c.id));
  const totals = designTotals(design, lookup);

  // Objetivo científico
  if (ctx.objectiveInstrumentId && !ids.has(ctx.objectiveInstrumentId)) {
    const inst = lookup(ctx.objectiveInstrumentId);
    issues.push({
      id: 'objective-instrument',
      severity: 'critical',
      title: `Falta ${inst?.name ?? ctx.objectiveInstrumentId}`,
      explanation: `Tu objetivo científico depende de este instrumento. Sin él la misión no puede producir los datos que justifican su presupuesto.`,
      instanceIds: [],
    });
  }

  // Subsistemas esenciales
  if (totals.powerGenW === 0) {
    issues.push({
      id: 'no-power',
      severity: 'critical',
      title: 'Sin generación eléctrica',
      explanation: 'Lejos de la Tierra no hay enchufe: sin paneles solares, la batería se agota y la nave muere. Añade al menos un panel en un anclaje lateral.',
      instanceIds: [],
    });
  }
  if (totals.energyStorageWh === 0) {
    issues.push({
      id: 'no-battery',
      severity: 'critical',
      title: 'Sin batería',
      explanation: 'En cada órbita la nave pasa a la sombra de la Luna (eclipse). Los paneles no generan y solo la energía almacenada (Wh) mantiene vivos los sistemas.',
      instanceIds: [],
    });
  }
  if (!hasCat(comps, 'COMMS')) {
    issues.push({
      id: 'no-comms',
      severity: 'critical',
      title: 'Sin comunicaciones',
      explanation: 'Sin antena, ningún dato científico llega a Tierra y no se pueden enviar órdenes a la nave.',
      instanceIds: [],
    });
  }
  if (!ids.has('obc')) {
    issues.push({
      id: 'no-obc',
      severity: 'critical',
      title: 'Sin computadora de a bordo',
      explanation: 'La computadora ejecuta las órdenes, controla los subsistemas y almacena los datos científicos hasta poder transmitirlos.',
      instanceIds: [],
    });
  }
  if (!ids.has('thruster')) {
    issues.push({
      id: 'no-propulsion',
      severity: 'critical',
      title: 'Sin propulsión',
      explanation: 'Para quedar en órbita lunar hay que frenar al llegar (inserción orbital) y corregir la órbita periódicamente. Eso requiere un propulsor con su tanque.',
      instanceIds: [],
    });
  }

  // Requisitos por pieza (agrupados: «la cámara requiere sensor de orientación»)
  const reqSeen = new Set<string>();
  for (const part of design.parts) {
    const c = need(lookup, part.componentId);
    for (const req of c.requires) {
      if (ids.has(req)) continue;
      if (req === 'obc' && !ids.has('obc')) continue; // ya cubierto por no-obc
      const key = `${c.id}->${req}`;
      const affected = design.parts.filter((p) => p.componentId === c.id).map((p) => p.instanceId);
      if (reqSeen.has(key)) continue;
      reqSeen.add(key);
      issues.push({
        id: `requires:${key}`,
        severity: 'critical',
        title: `${c.name} requiere ${lookup(req)?.name ?? req}`,
        explanation: c.engineeringNote,
        instanceIds: affected,
      });
    }
  }

  // Incompatibilidades (una vez por par)
  const pairSeen = new Set<string>();
  for (const part of design.parts) {
    const c = need(lookup, part.componentId);
    for (const other of c.incompatibleWith) {
      if (!ids.has(other)) continue;
      const key = [c.id, other].sort().join('|');
      if (pairSeen.has(key)) continue;
      pairSeen.add(key);
      const o = need(lookup, other);
      issues.push({
        id: `incompatible:${key}`,
        severity: 'critical',
        title: `${c.name} y ${o.name} son incompatibles`,
        explanation: `${c.engineeringNote} Retira uno de los dos.`,
        instanceIds: design.parts.filter((p) => p.componentId === c.id || p.componentId === other).map((p) => p.instanceId),
      });
    }
  }

  // Balance de potencia a plena luz (el análisis por órbita con eclipse llega en la Fase 3).
  if (totals.powerGenW > 0 && totals.powerDrawW > totals.powerGenW) {
    issues.push({
      id: 'power-deficit',
      severity: 'critical',
      title: 'Consumo mayor que la generación, incluso a plena luz',
      explanation: `Consumo ${totals.powerDrawW} W > generación ${totals.powerGenW} W. Si ni con el Sol de frente alcanza, la batería nunca se recarga. Añade paneles o usa paneles avanzados.`,
      instanceIds: [],
    });
  }

  // Optimización
  if (!hasCat(comps, 'PROTECTION')) {
    issues.push({
      id: 'no-thermal',
      severity: 'optimization',
      title: 'Sin control térmico',
      explanation: 'En órbita lunar la cara iluminada se calienta y la sombra se enfría bruscamente. Un sistema térmico protege la electrónica y alarga su vida.',
      instanceIds: [],
    });
  }
  if (totals.dataGenGbitPerH > 0 && totals.downlinkGbitPerH > 0 && totals.dataGenGbitPerH > totals.downlinkGbitPerH) {
    issues.push({
      id: 'downlink-bottleneck',
      severity: 'optimization',
      title: 'Los instrumentos producen más de lo que la antena puede enviar',
      explanation: `Generas ${totals.dataGenGbitPerH} Gbit/h y el enlace transmite como máximo ${totals.downlinkGbitPerH} Gbit/h, y solo cuando hay contacto con Tierra. La memoria se llenará: considera una antena de alta ganancia o alternar instrumentos.`,
      instanceIds: [],
    });
  }
  if (totals.powerGenW > 0 && totals.powerDrawW <= totals.powerGenW && totals.powerDrawW > totals.powerGenW * 0.9) {
    issues.push({
      id: 'power-margin',
      severity: 'optimization',
      title: 'Margen de potencia menor al 10 %',
      explanation: 'Los paneles se degradan con el tiempo y cualquier anomalía reduce la generación. Los ingenieros reservan margen.',
      instanceIds: [],
    });
  }

  return issues;
}

export function hasCritical(issues: DesignIssue[]): boolean {
  return issues.some((i) => i.severity === 'critical');
}
