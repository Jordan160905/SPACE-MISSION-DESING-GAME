/**
 * Misiones lunares reales usadas como referencia en el Informe y en el simulador de órbita elíptica.
 * Datos verificados en fuentes públicas (NASA, NTRS, eoPortal) en noviembre de 2026; las URLs se
 * muestran en la interfaz. NEXUS solo compara rasgos generales (tipo de órbita, altitud, objetivo):
 * no pretende reproducir el diseño de estas naves.
 */

export interface RealMission {
  id: string;
  name: string;
  agency: string;
  launchYear: number;
  /** Clase de nave, para contrastar escala. */
  spacecraftClass: string;
  orbit: { periapsisKm: number; apoapsisKm: number; inclinationDeg: number | null; label: string };
  /** Objetivos científicos del juego a los que se parece (ids de LUNA-01). */
  relatedObjectives: string[];
  summary: string;
  lesson: string;
  source: { title: string; url: string };
  /** true si la órbita no es una elipse kepleriana de dos cuerpos (no se simula). */
  nonKeplerian?: boolean;
}

export const REAL_MISSIONS: RealMission[] = [
  {
    id: 'lro',
    name: 'Lunar Reconnaissance Orbiter (LRO)',
    agency: 'NASA',
    launchYear: 2009,
    spacecraftClass: 'Orbitador de ~1,9 t',
    orbit: { periapsisKm: 50, apoapsisKm: 50, inclinationDeg: 90, label: 'Polar circular de ~50 km (fase de cartografía)' },
    relatedObjectives: ['obj-mapping', 'obj-polar-ice'],
    summary:
      'Lanzado el 18 de junio de 2009. Tras unos dos meses de puesta en servicio en una órbita excéntrica pasó a una órbita polar circular de unos 50 km para cartografiar la Luna, polos incluidos.',
    lesson: 'Su cámara busca sitios de alunizaje seguros: es la misma lógica de «órbita polar y baja» que recomienda NEXUS para la cartografía.',
    source: { title: 'eoPortal · LRO', url: 'https://eoportal.org/satellite-missions/lro' },
  },
  {
    id: 'lro-frozen',
    name: 'LRO · órbita cuasi-congelada',
    agency: 'NASA',
    launchYear: 2009,
    spacecraftClass: 'Orbitador de ~1,9 t',
    orbit: { periapsisKm: 30, apoapsisKm: 216, inclinationDeg: 90, label: 'Elíptica de 30 × 216 km' },
    relatedObjectives: ['obj-mapping'],
    summary: 'Para la puesta en servicio y para alargar la misión, LRO usa una órbita elíptica «cuasi-congelada» de 30 × 216 km que la gravedad lunar apenas deforma.',
    lesson: 'Una órbita elíptica bien elegida ahorra propelente de mantenimiento, a cambio de perder resolución lejos del periapsis.',
    source: { title: 'eoPortal · LRO', url: 'https://eoportal.org/satellite-missions/lro' },
  },
  {
    id: 'lunar-prospector',
    name: 'Lunar Prospector',
    agency: 'NASA (programa Discovery)',
    launchYear: 1998,
    spacecraftClass: 'Orbitador pequeño',
    orbit: { periapsisKm: 100, apoapsisKm: 100, inclinationDeg: 90, label: 'Polar de 100 km' },
    relatedObjectives: ['obj-mineral', 'obj-polar-ice'],
    summary:
      'Lanzado el 7 de enero de 1998 en un Athena 2. Tras tres maniobras de inserción y una de circularización quedó en una órbita polar de 100 km para cartografiar la composición de la superficie.',
    lesson: 'Una nave pequeña y barata puede hacer ciencia global si la órbita (polar) y los instrumentos están bien escogidos.',
    source: { title: 'NASA NTRS · Lunar Prospector mission design', url: 'https://ntrs.nasa.gov/citations/19980203799' },
  },
  {
    id: 'ladee',
    name: 'LADEE',
    agency: 'NASA',
    launchYear: 2013,
    spacecraftClass: 'Orbitador de 383 kg',
    orbit: { periapsisKm: 20, apoapsisKm: 60, inclinationDeg: 0, label: 'Ecuatorial de ~20 × 60 km' },
    relatedObjectives: [],
    summary:
      'Lanzado en septiembre de 2013. Estudió la tenue atmósfera lunar y el polvo desde una órbita ecuatorial de unos 20 × 60 km y terminó con un impacto controlado el 18 de abril de 2014.',
    lesson: 'Una órbita ecuatorial nunca ve los polos, pero cruza a menudo el amanecer y el anochecer lunar: el objetivo científico decide la inclinación.',
    source: { title: 'NASA Science · LADEE', url: 'https://science.nasa.gov/mission/ladee/in-depth/' },
  },
  {
    id: 'capstone',
    name: 'CAPSTONE',
    agency: 'NASA / Advanced Space',
    launchYear: 2022,
    spacecraftClass: 'CubeSat 12U de ~25 kg',
    orbit: { periapsisKm: 1500, apoapsisKm: 70000, inclinationDeg: null, label: 'Halo casi rectilínea (NRHO)' },
    relatedObjectives: [],
    summary:
      'CubeSat de 12U lanzado el 28 de junio de 2022 en un Electron. Fue la primera nave en operar en la órbita halo casi rectilínea que usará la estación Gateway.',
    lesson: 'Demuestra que una CubeSat puede llegar a la Luna. Su órbita depende de la gravedad de la Tierra y de la Luna a la vez: no es una elipse simple.',
    source: { title: 'Wikipedia · CAPSTONE', url: 'https://en.wikipedia.org/wiki/CAPSTONE' },
    nonKeplerian: true,
  },
];

/** Misiones reales parecidas al objetivo jugado (si no hay ninguna, las de referencia general). */
export function similarRealMissions(objectiveId: string): RealMission[] {
  const related = REAL_MISSIONS.filter((m) => m.relatedObjectives.includes(objectiveId) && m.id !== 'lro-frozen');
  return related.length ? related : REAL_MISSIONS.filter((m) => m.id === 'lro');
}
