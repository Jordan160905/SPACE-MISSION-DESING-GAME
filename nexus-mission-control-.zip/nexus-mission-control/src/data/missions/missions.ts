/**
 * Plantillas de misión. LUNA-01 es la única jugable en el MVP; el resto aparecen bloqueadas
 * para mostrar la progresión, con el motivo explícito del bloqueo.
 */
import { applyDifficulty, type Difficulty } from '../difficulty';
import type { MissionTemplate } from '../schemas';

export const LUNA_01: MissionTemplate = {
  id: 'luna-01',
  code: 'LUNA-01',
  name: 'Lunar Reconnaissance Mission',
  tagline: 'Diseña y opera un orbitador para estudiar la superficie lunar.',
  target: 'MOON',
  available: true,
  scenario:
    'La agencia necesita datos de reconocimiento para elegir futuros sitios de alunizaje. ' +
    'Tu equipo debe diseñar un orbitador pequeño, colocarlo en órbita lunar y devolver a Tierra ' +
    'datos científicos suficientes antes de que termine la campaña de observación. ' +
    'La Luna no tiene atmósfera: todo el calor se gana o se pierde por radiación, y en cada órbita ' +
    'la nave pasa por un eclipse en el que solo dispone de la energía almacenada en sus baterías.',
  inspiration:
    'Inspirada en Lunar Reconnaissance Orbiter (NASA, lanzado en 2009), que cartografía la Luna desde una órbita polar baja. ' +
    'NEXUS usa una escala de nave mucho menor y un modelo simplificado.',
  budgetCapMUSD: 140,
  durationDays: 60,
  opsCostPerDayMUSD: 0.25,
  developmentMonths: 36,
  objectives: [
    {
      id: 'obj-mapping',
      title: 'Cartografía de alta resolución',
      summary: 'Fotografiar zonas candidatas a alunizaje con resolución métrica.',
      primaryInstrumentId: 'camera',
      dataTargetGbit: 2000,
      recommendedOrbit: {
        altitudeKm: [50, 100],
        inclinationDeg: [85, 95],
        rationale:
          'Una órbita polar hace que la Luna gire bajo la nave: con el tiempo se sobrevuela toda la superficie. Volar bajo mejora la resolución.',
      },
      scienceValue: 'Identifica rocas, pendientes y cráteres peligrosos para futuros módulos de aterrizaje.',
    },
    {
      id: 'obj-mineral',
      title: 'Composición mineral',
      summary: 'Medir la firma espectral de los minerales de la superficie.',
      primaryInstrumentId: 'spectrometer',
      dataTargetGbit: 900,
      recommendedOrbit: {
        altitudeKm: [80, 150],
        inclinationDeg: [80, 100],
        rationale: 'Una altitud algo mayor amplía el campo de visión del espectrómetro y reduce el consumo de propelente para mantener la órbita.',
      },
      scienceValue: 'Localiza recursos útiles (como ilmenita, fuente potencial de oxígeno) y ayuda a entender la historia geológica lunar.',
    },
    {
      id: 'obj-polar-ice',
      title: 'Búsqueda de hielo polar',
      summary: 'Sondear con radar el interior de cráteres en sombra permanente.',
      primaryInstrumentId: 'radar',
      dataTargetGbit: 3000,
      recommendedOrbit: {
        altitudeKm: [30, 80],
        inclinationDeg: [88, 92],
        rationale: 'Solo una órbita casi exactamente polar pasa sobre ambos polos en cada vuelta. El radar pierde señal rápidamente con la distancia.',
      },
      scienceValue: 'El hielo de agua en los polos podría abastecer a futuras bases con agua, oxígeno y combustible.',
    },
  ],
  constraints: [
    {
      id: 'c-budget',
      label: 'Presupuesto máximo: 140 MUSD',
      severity: 'hard',
      description: 'Incluye componentes, lanzamiento y operación. Superarlo hace la misión inviable.',
    },
    {
      id: 'c-launcher',
      label: 'Masa dentro de la capacidad del lanzador',
      severity: 'hard',
      description: 'La masa húmeda total (con propelente) no puede superar lo que el lanzador elegido puede enviar a la Luna.',
    },
    {
      id: 'c-power',
      label: 'Balance energético positivo',
      severity: 'hard',
      description: 'La generación media por órbita debe cubrir el consumo; la batería debe sobrevivir al eclipse.',
    },
    {
      id: 'c-instrument',
      label: 'Instrumento principal a bordo',
      severity: 'hard',
      description: 'El instrumento asociado al objetivo científico elegido debe estar instalado y con sus requisitos cumplidos.',
    },
    {
      id: 'c-downlink',
      label: 'Capacidad de transmisión suficiente',
      severity: 'soft',
      description: 'Si el enlace no puede vaciar la memoria a tiempo, la misión producirá menos ciencia de la posible.',
    },
    {
      id: 'c-margin',
      label: 'Margen de masa y energía ≥ 10 %',
      severity: 'soft',
      description: 'Los ingenieros reservan margen para imprevistos. Sin margen, cualquier anomalía puede ser crítica.',
    },
  ],
  rewards: {
    xp: 500,
    xpPerExtraObjective: 200,
    unlocks: ['luna-02'],
    description: 'Experiencia de agencia, puntuación científica y acceso a la misión LUNA-02.',
  },
};

const LOCKED_LUNA_02: MissionTemplate = {
  id: 'luna-02',
  code: 'LUNA-02',
  name: 'Polar Relay',
  tagline: 'Satélite de comunicaciones para el polo sur lunar.',
  target: 'MOON',
  available: false,
  lockReason: 'Completa LUNA-01 para desbloquear.',
  scenario: 'Escenario en preparación.',
  budgetCapMUSD: 150,
  durationDays: 90,
  opsCostPerDayMUSD: 0.3,
  developmentMonths: 48,
  objectives: [],
  constraints: [],
  rewards: { xp: 700, xpPerExtraObjective: 250, unlocks: [], description: 'Por definir.' },
};

const LOCKED_MARS_01: MissionTemplate = {
  id: 'mars-01',
  code: 'ARES-01',
  name: 'Mars Atmospheric Survey',
  tagline: 'Orbitador para estudiar la atmósfera marciana.',
  target: 'MARS',
  available: false,
  lockReason: 'Escenario previsto tras el MVP.',
  scenario: 'Escenario en preparación.',
  budgetCapMUSD: 300,
  durationDays: 365,
  opsCostPerDayMUSD: 0.4,
  developmentMonths: 48,
  objectives: [],
  constraints: [],
  rewards: { xp: 1500, xpPerExtraObjective: 400, unlocks: [], description: 'Por definir.' },
};

export const MISSION_TEMPLATES: MissionTemplate[] = [LUNA_01, LOCKED_LUNA_02, LOCKED_MARS_01];

export function getMissionTemplate(id: string): MissionTemplate | undefined {
  return MISSION_TEMPLATES.find((m) => m.id === id);
}

/** Plantilla efectiva de una misión: la base ajustada a su nivel de dificultad. */
export function templateForMission(m: { templateId: string; difficulty?: Difficulty }): MissionTemplate | undefined {
  const base = getMissionTemplate(m.templateId);
  return base && applyDifficulty(base, m.difficulty);
}
