/**
 * Vehículos de lanzamiento: los 8 cohetes estadounidenses de la figura 7 de «CubeSat 101»
 * (NASA CSLI, 2017), «U.S. Launch Vehicles Used for CubeSat Launches», que ya habían volado
 * CubeSats cuando se escribió el documento.
 *
 * Cada vehículo separa:
 *  - `real`: datos verificados en fuentes públicas (noviembre de 2026), con sus enlaces.
 *    Que un dato sea aproximado se indica (`record.approx`, notas).
 *  - valores de JUEGO (`payloadToTLIKg`, `costMUSD`, `reliability`, `fairing`, `stages`), explicados
 *    en `gameNote`. Ningún valor de juego se presenta como dato oficial.
 *
 * La figura de 2017 marcaba con * otros cuatro vehículos (Electron, Falcon 9 Heavy, LauncherOne y SLS)
 * que aún no habían volado CubeSats y solo los tenían en manifiestos futuros. No forman parte de este
 * catálogo; `CUBESAT101_MANIFEST_ONLY` los conserva como referencia. Los 8 de aquí son
 * `cubesat2017: 'flown'`. Estar en la figura NO significa estar en servicio hoy: ver `real.status`.
 */
import type { Launcher } from '../schemas';

/** Fiabilidad estimada con la regla de sucesión de Laplace: (éxitos + 1) / (vuelos + 2). */
export function laplaceReliability(flights: number, successes: number): number {
  return (successes + 1) / (flights + 2);
}

type Def = Omit<Launcher, 'reliability'>;
const v = (d: Def): Launcher => ({ ...d, reliability: laplaceReliability(d.real.record.flights, d.real.record.successes) });

const SOLID = 'Combustible sólido';
const KERO = 'Queroseno + oxígeno líquido';
const HYDRO = 'Hidrógeno + oxígeno líquido';
const GEOM = 'La geometría 3D y los tiempos de combustión son aproximaciones visuales.';

export const LAUNCHERS: Launcher[] = [
  v({
    id: 'super-strypi',
    name: 'Super Strypi',
    class: 'small',
    description: 'Cohete experimental de la Fuerza Aérea, lanzado desde un raíl en Hawái, para satélites muy pequeños.',
    real: {
      operator: 'Universidad de Hawái, Sandia y Aerojet Rocketdyne (Fuerza Aérea de EE. UU.)',
      heightM: 17,
      diameterM: 1.5,
      leoKg: 300,
      leoNote: 'previsto: «hasta unos 300 kg» a órbita baja',
      launchType: 'Lanzado desde un raíl; tres etapas de combustible sólido',
      firstFlight: '3 nov 2015',
      status: 'retired',
      statusNote: 'Su único vuelo (ORS-4, 2015) falló durante la primera etapa y no se ha vuelto a usar.',
      cubesat2017: 'flown',
      record: { flights: 1, successes: 0, asOf: '2015', approx: false },
      priceMUSD: null,
      priceNote: 'Sin precio comercial; la misión ORS-4 costó más de 45 MUSD.',
      facts: ['Llevaba 13 satélites pequeños, entre ellos 8 CubeSats de la misión EDSN de NASA: se perdieron todos.'],
      sources: [
        { title: 'Wikipedia · SPARK (Super Strypi)', url: 'https://en.wikipedia.org/wiki/SPARK_(rocket)' },
        { title: 'Space.com · Super Strypi falla en su debut', url: 'https://www.space.com/31021-rail-launched-super-strypi-rocket-cubesats-fails.html' },
      ],
    },
    lunarCapable: false,
    unavailableReason: 'Retirado tras su único vuelo fallido, y con ~300 kg a órbita baja no tendría energía para llegar a la Luna.',
    payloadToTLIKg: 0,
    costMUSD: null,
    fairing: { innerDiameterM: 1.3, heightM: 2 },
    gameNote: `No se puede contratar en el juego. ${GEOM}`,
    stages: [
      { name: 'Etapas 1 y 2', lengthM: 11.5, diameterM: 1.5, engines: 1, engineName: 'Motores sólidos', propellant: SOLID, burnTimeS: 80 },
      { name: 'Etapa superior', lengthM: 2.5, diameterM: 1.1, engines: 1, engineName: 'Motor sólido', propellant: SOLID, burnTimeS: 60 },
    ],
  }),
  v({
    id: 'minotaur-i',
    name: 'Minotaur I',
    class: 'small',
    description: 'Cohete pequeño de cuatro etapas sólidas; las dos primeras son motores del misil Minuteman II.',
    real: {
      operator: 'Northrop Grumman',
      heightM: 19.21,
      diameterM: 1.67,
      leoKg: 580,
      leoNote: '185 km, 28,5°',
      launchType: 'Cuatro etapas de combustible sólido',
      firstFlight: '27 ene 2000',
      status: 'operational',
      statusNote: 'Vuela de forma esporádica para el gobierno de EE. UU.; 13 lanzamientos, todos con éxito.',
      cubesat2017: 'flown',
      record: { flights: 13, successes: 13, asOf: 'jun 2024', approx: false },
      priceMUSD: null,
      facts: ['En 2013 (ORS-3) puso en órbita 28 CubeSats en un solo vuelo.'],
      sources: [
        { title: 'Wikipedia · Minotaur I', url: 'https://en.wikipedia.org/wiki/Minotaur_I' },
        { title: 'Northrop Grumman · Minotaur (hoja técnica)', url: 'https://ams.confex.com/ams/102ANNUAL/mediafile/Handout/Session59713/Minotaur%20Space%20Launch%20Vehicles%20DS-18009.pdf' },
      ],
    },
    lunarCapable: false,
    unavailableReason: 'Solo llega a órbita baja (580 kg): no tiene la energía necesaria para escapar hacia la Luna.',
    payloadToTLIKg: 0,
    costMUSD: null,
    fairing: { innerDiameterM: 1.4, heightM: 2.5 },
    gameNote: `No se puede usar para ir a la Luna en el juego. ${GEOM}`,
    stages: [
      { name: 'Etapas 1 y 2 (Minuteman II)', lengthM: 12.5, diameterM: 1.67, engines: 1, engineName: 'M55A1 + SR19', propellant: SOLID, burnTimeS: 120 },
      { name: 'Etapas 3 y 4', lengthM: 3.5, diameterM: 1.3, engines: 1, engineName: 'Orion 50XL + Orion 38', propellant: SOLID, burnTimeS: 140 },
    ],
  }),
  v({
    id: 'minotaur-iv',
    name: 'Minotaur IV',
    class: 'small',
    description: 'Cuatro etapas sólidas (tres del misil Peacekeeper). Con una quinta etapa (Minotaur V) envió LADEE a la Luna.',
    real: {
      operator: 'Northrop Grumman',
      heightM: 23.88,
      diameterM: 2.34,
      leoKg: 1735,
      leoNote: '185 km, 28,5°',
      launchType: 'Cuatro etapas de combustible sólido (quinta opcional)',
      firstFlight: '22 abr 2010',
      status: 'operational',
      statusNote: 'En servicio; vuelo más reciente conocido: NROL-174 (abril de 2025).',
      cubesat2017: 'flown',
      record: { flights: 8, successes: 8, asOf: 'abr 2025', approx: false },
      priceMUSD: 50,
      priceNote: 'precio publicado en 2010',
      facts: [
        'Su variante de cinco etapas, Minotaur V, lanzó la sonda lunar LADEE (383 kg) en septiembre de 2013.',
        'Usa motores de misiles retirados, así que solo puede lanzar misiones del gobierno de EE. UU. (como una misión de NASA).',
      ],
      sources: [
        { title: 'Wikipedia · Minotaur IV', url: 'https://en.wikipedia.org/wiki/Minotaur_IV' },
        { title: 'Northrop Grumman · Minotaur (hoja técnica)', url: 'https://ams.confex.com/ams/102ANNUAL/mediafile/Handout/Session59713/Minotaur%20Space%20Launch%20Vehicles%20DS-18009.pdf' },
      ],
    },
    lunarCapable: true,
    payloadToTLIKg: 383,
    costMUSD: 50,
    fairing: { innerDiameterM: 2.1, heightM: 5.8 },
    gameNote:
      'El juego supone la configuración con quinta etapa (Minotaur V) y limita la carga a lo que LADEE demostró: 383 kg hacia la Luna. ' +
      `Costo: precio publicado de 2010. Cofia útil: 90 % de las medidas publicadas (Ø 2,34 × 6,4 m). ${GEOM}`,
    stages: [
      { name: 'Etapas 1 a 3 (Peacekeeper)', lengthM: 15, diameterM: 2.34, engines: 1, engineName: 'SR-118 + SR-119 + SR-120', propellant: SOLID, burnTimeS: 175 },
      { name: 'Etapas superiores', lengthM: 2.8, diameterM: 2.34, engines: 1, engineName: 'Orion 38 (+ Star 48 en la versión lunar)', propellant: SOLID, burnTimeS: 120 },
    ],
  }),
  v({
    id: 'taurus-xl',
    name: 'Taurus XL',
    class: 'small',
    description: 'Cohete sólido de cuatro etapas con «etapa cero» Castor 120. Hoy la familia se llama Minotaur-C.',
    real: {
      operator: 'Orbital Sciences (hoy Northrop Grumman)',
      heightM: 27.9,
      diameterM: 2.35,
      leoKg: 1320,
      leoNote: 'según la versión (1.320–1.458 kg)',
      launchType: 'Cuatro etapas de combustible sólido',
      firstFlight: '13 mar 1994 (familia Taurus)',
      status: 'retired',
      statusNote: 'Tras perder OCO (2009) y Glory (2011) porque la cofia no se separó, no volvió a volar como Taurus XL.',
      cubesat2017: 'flown',
      record: { flights: 10, successes: 7, asOf: '2017', approx: true },
      priceMUSD: 40,
      priceNote: '40–50 MUSD (Minotaur-C)',
      facts: ['El vuelo de Glory (2011) llevaba tres CubeSats universitarios de NASA (ELaNa I): se perdieron con él.'],
      sources: [
        { title: 'NASA · Informe del fallo de Taurus XL (Glory)', url: 'https://www.nasa.gov/pdf/728836main_T9_MIB_Public_Release_Summary.pdf' },
        { title: 'Wikipedia · Glory (satélite)', url: 'https://en.wikipedia.org/wiki/Glory_(satellite)' },
      ],
    },
    lunarCapable: false,
    unavailableReason: 'Retirado como Taurus XL y pensado para órbita baja (~1,3 t): no se usa para ir a la Luna.',
    payloadToTLIKg: 0,
    costMUSD: null,
    fairing: { innerDiameterM: 1.4, heightM: 3 },
    gameNote: `No se puede contratar en el juego. ${GEOM}`,
    stages: [
      { name: 'Etapa 0 y 1', lengthM: 17, diameterM: 2.35, engines: 1, engineName: 'Castor 120 + Orion 50SXLG', propellant: SOLID, burnTimeS: 150 },
      { name: 'Etapas 2 y 3', lengthM: 5, diameterM: 1.6, engines: 1, engineName: 'Orion 50XL + Orion 38', propellant: SOLID, burnTimeS: 140 },
    ],
  }),
  v({
    id: 'delta-ii',
    name: 'Delta II',
    class: 'medium',
    description: 'El gran caballo de batalla de NASA durante casi 30 años, con propulsores sólidos acoplados.',
    real: {
      operator: 'United Launch Alliance',
      heightM: 38.9,
      diameterM: 2.44,
      leoKg: 6100,
      leoNote: '2.700–6.100 kg según configuración',
      launchType: 'Dos o tres etapas con propulsores sólidos acoplados',
      firstFlight: '14 feb 1989',
      status: 'retired',
      statusNote: 'Último vuelo: ICESat-2, 15 sep 2018, con 4 CubeSats a bordo.',
      cubesat2017: 'flown',
      record: { flights: 155, successes: 153, asOf: '2018', approx: true },
      priceMUSD: 137,
      priceNote: 'en 2018, antes de retirarse',
      facts: ['Envió a la Luna las sondas gemelas GRAIL en 2011.', 'Se retiró con 100 lanzamientos con éxito seguidos.'],
      sources: [
        { title: 'NASA · ICESat-2 en el último Delta II', url: 'https://blogs.nasa.gov/icesat2/2018/09/' },
        { title: 'Wikipedia · Delta II', url: 'https://en.wikipedia.org/wiki/Delta_II' },
      ],
    },
    lunarCapable: false,
    unavailableReason: 'Retirado en 2018: ya no se puede contratar (aunque en 2011 llevó GRAIL a la Luna).',
    payloadToTLIKg: 0,
    costMUSD: null,
    fairing: { innerDiameterM: 2.7, heightM: 7.5 },
    gameNote: `No se puede contratar en el juego. ${GEOM}`,
    stages: [
      { name: 'Primera etapa', lengthM: 26, diameterM: 2.44, engines: 1, engineName: 'RS-27A', propellant: KERO, burnTimeS: 265 },
      { name: 'Segunda etapa', lengthM: 6, diameterM: 2.44, engines: 1, engineName: 'AJ10', propellant: 'Hipergólicos', burnTimeS: 430 },
    ],
    boosters: { count: 4, lengthM: 13, diameterM: 1 },
  }),
  v({
    id: 'antares',
    name: 'Antares',
    class: 'medium',
    description: 'Cohete medio de Northrop Grumman usado para llevar carga Cygnus a la Estación Espacial.',
    real: {
      operator: 'Northrop Grumman',
      heightM: 42.5,
      diameterM: 3.9,
      leoKg: 8000,
      leoNote: 'versión 230+',
      launchType: 'Primera etapa líquida (2 motores RD-181) y segunda etapa sólida Castor 30XL',
      firstFlight: '21 abr 2013',
      status: 'in-development',
      statusNote: 'La versión 230+ voló por última vez el 2 ago 2023. La nueva Antares 330 aún no ha volado (su primer vuelo está previsto para finales de 2026 o después).',
      cubesat2017: 'flown',
      record: { flights: 18, successes: 17, asOf: 'ago 2023', approx: false },
      priceMUSD: 80,
      priceNote: '80–85 MUSD',
      facts: ['Hasta 2023 solo se usó para enviar la nave de carga Cygnus a la Estación Espacial Internacional.'],
      sources: [
        { title: 'Northrop Grumman · Antares', url: 'https://www.northropgrumman.com/what-we-do/space/launch-vehicles/antares-rocket' },
        { title: 'NASASpaceflight · Último vuelo de Antares 230+', url: 'https://www.nasaspaceflight.com/2023/08/antares-230-farewell-launch/' },
      ],
    },
    lunarCapable: false,
    unavailableReason: 'No hay versión en servicio (la 330 está en desarrollo) y nunca ha volado a la Luna: está pensado para la órbita baja.',
    payloadToTLIKg: 0,
    costMUSD: null,
    fairing: { innerDiameterM: 3.5, heightM: 9 },
    gameNote: `No se puede contratar en el juego. ${GEOM}`,
    stages: [
      { name: 'Primera etapa', lengthM: 28, diameterM: 3.9, engines: 2, engineName: 'RD-181', propellant: KERO, burnTimeS: 215 },
      { name: 'Segunda etapa', lengthM: 5, diameterM: 3.9, engines: 1, engineName: 'Castor 30XL', propellant: SOLID, burnTimeS: 155 },
    ],
  }),
  v({
    id: 'falcon-9',
    name: 'Falcon 9',
    class: 'medium',
    description: 'Cohete de dos etapas con primera etapa reutilizable; el más usado del mundo hoy.',
    real: {
      operator: 'SpaceX',
      heightM: 70,
      diameterM: 3.7,
      leoKg: 22800,
      leoNote: 'desechable; 8.300 kg a GTO y 4.020 kg hacia Marte',
      launchType: 'Dos etapas de queroseno y oxígeno; primera etapa reutilizable',
      firstFlight: '4 jun 2010',
      status: 'operational',
      statusNote: 'En servicio: unas 688 misiones a septiembre de 2026, con dos o tres lanzamientos por semana.',
      cubesat2017: 'flown',
      record: { flights: 688, successes: 686, asOf: 'sep 2026', approx: true },
      priceMUSD: 62,
      priceNote: 'precio de lista en 2020, más costos de misión',
      facts: ['Lleva CubeSats a menudo en viajes compartidos.', 'Ha lanzado misiones lunares comerciales.'],
      sources: [
        { title: 'AIAA · Falcon (guía de vehículos)', url: 'https://aiaa.org/vehicle-guide/vehicles/falcon' },
        { title: 'Wevolver · Falcon 9 Block 5', url: 'https://wevolver.com/specs/falcon-9-v12-or-full-thrust-block-5' },
        { title: 'KeepTrack · historial de lanzamientos de Falcon 9', url: 'https://keeptrack.space/launches/vehicles/falcon-9' },
      ],
    },
    lunarCapable: true,
    payloadToTLIKg: 4020,
    costMUSD: 62,
    fairing: { innerDiameterM: 4.6, heightM: 11.8 },
    gameNote:
      'SpaceX no publica la capacidad hacia la Luna; el juego usa, de forma conservadora, la publicada hacia Marte (4.020 kg), que exige más energía. ' +
      `Costo: precio de lista de 2020. Cofia útil: 90 % de Ø 5,2 × 13,1 m. Fiabilidad calculada con un historial aproximado. ${GEOM}`,
    stages: [
      { name: 'Primera etapa', lengthM: 41.2, diameterM: 3.7, engines: 9, engineName: 'Merlin 1D', propellant: KERO, burnTimeS: 162 },
      { name: 'Segunda etapa', lengthM: 13.8, diameterM: 3.7, engines: 1, engineName: 'Merlin Vacuum', propellant: KERO, burnTimeS: 397 },
    ],
  }),
  v({
    id: 'atlas-v',
    name: 'Atlas V',
    class: 'heavy',
    description: 'Cohete de ULA con etapa superior Centaur de hidrógeno; lanzó LRO y LCROSS hacia la Luna.',
    real: {
      operator: 'United Launch Alliance',
      heightM: 58.3,
      diameterM: 3.81,
      leoKg: 18850,
      leoNote: '8.210–18.850 kg según configuración',
      launchType: 'Dos etapas (Centaur de hidrógeno) con 0 a 5 propulsores sólidos',
      firstFlight: '21 ago 2002',
      status: 'retiring',
      statusNote: 'En retirada: dejó de fabricarse en 2024; su último vuelo comercial fue el 2 jul 2026 y los seis que quedan están reservados para la cápsula Starliner.',
      cubesat2017: 'flown',
      record: { flights: 110, successes: 109, asOf: 'jul 2026', approx: true },
      priceMUSD: 110,
      priceNote: '110–153 MUSD (2016)',
      facts: ['El 18 de junio de 2009 lanzó juntas LRO y LCROSS hacia la Luna (versión 401).'],
      sources: [
        { title: 'Wikipedia · Atlas V', url: 'https://en.wikipedia.org/wiki/Atlas_V' },
        { title: 'SpacePolicyOnline · Quedan seis Atlas V, todos para Starliner', url: 'https://spacepolicyonline.com/news/atlas-v-launches-more-amazon-leos-with-only-six-starliner-flights-left-on-the-books/' },
      ],
    },
    lunarCapable: false,
    unavailableReason: 'Ya no se puede contratar: los últimos Atlas V están reservados. En 2009 llevó LRO a la Luna.',
    payloadToTLIKg: 0,
    costMUSD: null,
    fairing: { innerDiameterM: 3.75, heightM: 12 },
    gameNote: `No se puede contratar en el juego. ${GEOM}`,
    stages: [
      { name: 'Primera etapa', lengthM: 32.5, diameterM: 3.81, engines: 1, engineName: 'RD-180', propellant: KERO, burnTimeS: 253 },
      { name: 'Centaur', lengthM: 12.7, diameterM: 3.05, engines: 1, engineName: 'RL10', propellant: HYDRO, burnTimeS: 842 },
    ],
  }),
];

/** Vehículos que el juego permite contratar para ir a la Luna (ordenados por costo). */
export const LUNAR_LAUNCHERS: Launcher[] = LAUNCHERS.filter((l) => l.lunarCapable && l.costMUSD !== null).sort((a, b) => a.costMUSD! - b.costMUSD!);

export function getLauncher(id: string): Launcher | undefined {
  return LAUNCHERS.find((l) => l.id === id);
}

export const STATUS_LABEL: Record<Launcher['real']['status'], string> = {
  operational: 'En servicio',
  retired: 'Retirado',
  retiring: 'En retirada',
  'in-development': 'Nueva versión en desarrollo',
};

/**
 * Vehículos marcados con * en la figura 7 de «CubeSat 101» (2017): no habían volado CubeSats y solo
 * los tenían en manifiestos de vuelos futuros. Se muestran como nota de referencia, no se usan en el juego.
 */
export const CUBESAT101_MANIFEST_ONLY = ['Electron', 'Falcon 9 Heavy', 'LauncherOne', 'Space Launch System (SLS)'] as const;
