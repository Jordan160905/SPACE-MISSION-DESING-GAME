/**
 * Esquemas de datos (Zod) — fuente única de verdad para la forma de los datos del juego.
 *
 * Convención de unidades (ver docs/ARCHITECTURE.md §Unidades):
 *   masa ............ kg
 *   dinero .......... MUSD (millones de dólares, escala de juego)
 *   potencia ........ W  (tasa instantánea)
 *   energía ......... Wh (cantidad acumulada)
 *   datos ........... Gbit
 *   tasa de datos ... Gbit/h (generación) y Mbps (enlace)
 *   tiempo .......... h (simulación) / días (planificación)
 */
import { z } from 'zod';

// ───────────────────────── Componentes de nave ─────────────────────────

export const ComponentCategorySchema = z.enum([
  'STRUCTURE',
  'POWER',
  'COMMS',
  'PROPULSION',
  'CONTROL',
  'INSTRUMENT',
  'PROTECTION',
]);
export type ComponentCategory = z.infer<typeof ComponentCategorySchema>;

/** Tipos de punto de anclaje. Un chasis ofrece sockets; cada pieza declara en qué tipos puede montarse. */
export const SocketTypeSchema = z.enum(['top', 'side', 'bottom', 'internal']);
export type SocketType = z.infer<typeof SocketTypeSchema>;

const Vec3Schema = z.tuple([z.number(), z.number(), z.number()]);

export const SocketDefSchema = z.object({
  id: z.string().min(1),
  type: SocketTypeSchema,
  /** Posición local en el chasis (unidades de escena, 1 = 1 m). */
  position: Vec3Schema,
  /** Normal hacia fuera; orienta la pieza montada. */
  normal: Vec3Schema,
});
export type SocketDef = z.infer<typeof SocketDefSchema>;

export const ModelRefSchema = z.object({
  /** 'procedural' = geometría original generada con Three.js; 'gltf' = archivo GLB en /public/models. */
  kind: z.enum(['procedural', 'gltf']),
  key: z.string().min(1),
  /** true si el modelo es provisional y debe sustituirse por un asset definitivo. */
  provisional: z.boolean(),
});

export const ComponentDefSchema = z
  .object({
    id: z.string().regex(/^[a-z0-9-]+$/, 'id en kebab-case'),
    name: z.string().min(1),
    category: ComponentCategorySchema,
    description: z.string().min(1),
    massKg: z.number().positive(),
    costMUSD: z.number().nonnegative(),
    /** Consumo en operación nominal. */
    powerDrawW: z.number().nonnegative(),
    /** Generación nominal (paneles a 1 UA, iluminación directa). */
    powerGenW: z.number().nonnegative(),
    /** Capacidad de almacenamiento de energía (baterías). */
    energyStorageWh: z.number().nonnegative(),
    /** Datos científicos producidos mientras el instrumento está activo. */
    dataGenGbitPerH: z.number().nonnegative(),
    /** Instrumento pasivo: solo observa la superficie iluminada (cámara, espectrómetro). */
    requiresSunlight: z.boolean().default(false),
    /** Memoria de a bordo para datos pendientes de transmitir. */
    dataStorageGbit: z.number().nonnegative(),
    /** Velocidad del enlace descendente cuando hay contacto con Tierra. */
    downlinkMbps: z.number().nonnegative(),
    /** Propelente que aporta (tanques). Cuenta como masa húmeda. */
    propellantKg: z.number().nonnegative(),
    /** Impulso específico del motor (s). 0 si no es un motor. */
    ispS: z.number().nonnegative().default(0),
    /** Tipos de socket en los que puede montarse. Los chasis no se montan (raíz). */
    mountsOn: z.array(SocketTypeSchema),
    /** Sockets que ofrece (solo chasis). */
    sockets: z.array(SocketDefSchema),
    /** IDs de componentes que deben estar presentes en la nave para que funcione. */
    requires: z.array(z.string()),
    /** IDs de componentes con los que no puede coexistir. */
    incompatibleWith: z.array(z.string()),
    /**
     * Herencia de vuelo (madurez del componente). Determina la contingencia de masa en la
     * Master Equipment List: lo ya volado se conoce mejor que lo nuevo.
     */
    heritage: z.enum(['flight-proven', 'modified', 'new']).default('flight-proven'),
    /** Gama: los componentes avanzados no están disponibles en dificultad Explorador. */
    tier: z.enum(['simple', 'advanced']).default('simple'),
    /** Valor científico del instrumento (0 = no es instrumento; 1–5). */
    scienceValue: z.number().int().min(0).max(5).default(0),
    /** Explicación educativa de por qué existen esos requisitos/incompatibilidades. */
    engineeringNote: z.string().min(1),
    model: ModelRefSchema,
  })
  .superRefine((c, ctx) => {
    if (c.category === 'STRUCTURE' && c.sockets.length === 0) {
      ctx.addIssue({ code: z.ZodIssueCode.custom, message: `${c.id}: un chasis necesita sockets` });
    }
    if (c.category !== 'STRUCTURE' && c.mountsOn.length === 0) {
      ctx.addIssue({ code: z.ZodIssueCode.custom, message: `${c.id}: la pieza debe declarar mountsOn` });
    }
  });
export type ComponentDef = z.infer<typeof ComponentDefSchema>;

// ───────────────────────── Misiones (plantillas) ─────────────────────────

export const ScienceObjectiveSchema = z.object({
  id: z.string().min(1),
  title: z.string().min(1),
  summary: z.string().min(1),
  /** Instrumento principal necesario (id de componente). */
  primaryInstrumentId: z.string().min(1),
  /** Volumen mínimo de datos científicos que debe llegar a Tierra. */
  dataTargetGbit: z.number().positive(),
  /** Órbita recomendada y por qué. */
  recommendedOrbit: z.object({
    altitudeKm: z.tuple([z.number().positive(), z.number().positive()]),
    inclinationDeg: z.tuple([z.number().min(0).max(180), z.number().min(0).max(180)]),
    rationale: z.string().min(1),
  }),
  scienceValue: z.string().min(1),
});
export type ScienceObjective = z.infer<typeof ScienceObjectiveSchema>;

export const ConstraintSchema = z.object({
  id: z.string().min(1),
  label: z.string().min(1),
  /** 'hard' bloquea la viabilidad; 'soft' es una recomendación de optimización. */
  severity: z.enum(['hard', 'soft']),
  description: z.string().min(1),
});
export type Constraint = z.infer<typeof ConstraintSchema>;

export const MissionTemplateSchema = z.object({
  id: z.string().min(1),
  code: z.string().min(1),
  name: z.string().min(1),
  tagline: z.string().min(1),
  target: z.enum(['MOON', 'MARS', 'EARTH']),
  available: z.boolean(),
  lockReason: z.string().optional(),
  scenario: z.string().min(1),
  inspiration: z.string().optional(),
  budgetCapMUSD: z.number().positive(),
  durationDays: z.number().positive(),
  /** Costo de operación por día (equipo de control + tiempo de antena), MUSD/día. */
  opsCostPerDayMUSD: z.number().nonnegative(),
  /** Tiempo disponible para desarrollar, integrar y probar la nave antes del lanzamiento (meses). */
  developmentMonths: z.number().positive().default(36),
  objectives: z.array(ScienceObjectiveSchema),
  constraints: z.array(ConstraintSchema),
  rewards: z.object({
    xp: z.number().nonnegative(),
    xpPerExtraObjective: z.number().nonnegative(),
    unlocks: z.array(z.string()),
    description: z.string().min(1),
  }),
});
export type MissionTemplate = z.infer<typeof MissionTemplateSchema>;

// ───────────────────────── Misiones del jugador (estado guardado) ─────────────────────────

export const MissionStageSchema = z.enum([
  'DESIGN',
  'PLANNING',
  'LAUNCH',
  'OPERATIONS',
  'DEBRIEF',
  'COMPLETE',
]);
export type MissionStage = z.infer<typeof MissionStageSchema>;

export const PlacedPartSchema = z.object({
  instanceId: z.string().min(1),
  componentId: z.string().min(1),
  /** Socket del chasis en el que está montada. */
  socketId: z.string().min(1),
});
export type PlacedPart = z.infer<typeof PlacedPartSchema>;

export const SpacecraftDesignSchema = z.object({
  chassisId: z.string().nullable(),
  parts: z.array(PlacedPartSchema),
});
export type SpacecraftDesign = z.infer<typeof SpacecraftDesignSchema>;

/** Plan de vuelo elegido en el Mission Planner (Fase 4). */
/** Ids de los lanzadores ficticios de versiones anteriores → vehículos reales equivalentes. */
export const LEGACY_LAUNCHER_IDS: Record<string, string> = { 'condor-s': 'minotaur-iv', 'condor-m': 'falcon-9', 'condor-h': 'falcon-9' };

export const MissionPlanSchema = z.object({
  launcherId: z
    .string()
    .min(1)
    .transform((id) => LEGACY_LAUNCHER_IDS[id] ?? id),
  altitudeKm: z.number().min(20).max(300),
  inclinationDeg: z.number().min(0).max(90),
  durationDays: z.number().int().min(30).max(120),
  /** Día de lanzamiento contado desde el inicio de la campaña (calendario de juego). */
  launchDay: z.number().int().min(0).max(59),
});
export type MissionPlan = z.infer<typeof MissionPlanSchema>;

/** Estado de la nave en vuelo (Fase 5). Se guarda con la misión. */
export const FlightLogEntrySchema = z.object({
  tH: z.number(),
  level: z.enum(['info', 'warn', 'critical']),
  text: z.string(),
});
export type FlightLogEntry = z.infer<typeof FlightLogEntrySchema>;

export const FlightEventTypeSchema = z.enum(['power-degradation', 'comms-outage', 'instrument-anomaly']);
export type FlightEventType = z.infer<typeof FlightEventTypeSchema>;

/** Efectos activos de los acontecimientos sobre la nave (modifican la simulación real). */
export const FlightEffectSchema = z.discriminatedUnion('kind', [
  z.object({ kind: z.literal('gen-factor'), factor: z.number().min(0).max(1), untilH: z.number() }),
  z.object({ kind: z.literal('station-outage'), untilH: z.number() }),
  z.object({ kind: z.literal('instrument-offline'), instanceId: z.string(), untilH: z.number() }),
  z.object({ kind: z.literal('instrument-rate'), instanceId: z.string(), factor: z.number().min(0).max(1) }),
]);
export type FlightEffect = z.infer<typeof FlightEffectSchema>;

export const FlightEventRecordSchema = z.object({
  id: z.string(),
  type: FlightEventTypeSchema,
  atH: z.number(),
  choiceId: z.string(),
  choiceLabel: z.string(),
  /** Posición de la opción elegida según la previsión (1 = la mejor). */
  rank: z.number().int().min(1),
  optionCount: z.number().int().min(1),
  summary: z.string(),
});
export type FlightEventRecord = z.infer<typeof FlightEventRecordSchema>;

export const FlightStateSchema = z.object({
  /** Horas desde la llegada a la órbita lunar. */
  elapsedH: z.number().nonnegative(),
  batteryWh: z.number().nonnegative(),
  storageGbit: z.number().nonnegative(),
  generatedGbit: z.number().nonnegative(),
  deliveredGbit: z.number().nonnegative(),
  lostGbit: z.number().nonnegative(),
  propellantKg: z.number().nonnegative(),
  /** Instrumentos (instanceId) apagados por el jugador. */
  instrumentsOff: z.array(z.string()),
  safeMode: z.boolean(),
  /** Horas sin energía ni para los sistemas básicos. */
  blackoutH: z.number().nonnegative(),
  minBatteryFraction: z.number().min(0).max(1),
  propellantDepleted: z.boolean(),
  complete: z.boolean(),
  log: z.array(FlightLogEntrySchema),
  // ── Fase 6 (con valores por defecto para leer guardados anteriores) ──
  scheduledEvents: z.array(z.object({ id: z.string(), type: FlightEventTypeSchema, atH: z.number() })).default([]),
  pendingEventId: z.string().nullable().default(null),
  eventHistory: z.array(FlightEventRecordSchema).default([]),
  effects: z.array(FlightEffectSchema).default([]),
  extraCostMUSD: z.number().nonnegative().default(0),
  safeModeEntries: z.number().int().nonnegative().default(0),
});
export type FlightState = z.infer<typeof FlightStateSchema>;

/**
 * Registro del espacio de compromisos explorado (CML 3 · Trade Space): qué alternativas evaluó
 * el equipo antes de fijar el diseño puntual. Se rellena solo al cambiar el plan.
 */
export const TradeLogSchema = z.object({
  launchers: z.array(z.string()).default([]),
  altitudes: z.array(z.number()).default([]),
  inclinations: z.array(z.number()).default([]),
  durations: z.array(z.number()).default([]),
  /** Órbitas elípticas estudiadas en el simulador del Planner. */
  ellipticalStudies: z.number().int().nonnegative().default(0),
});
export type TradeLog = z.infer<typeof TradeLogSchema>;

export const DifficultySchema = z.enum(['explorer', 'engineer', 'expert', 'sandbox']);

/** Roles del modo equipo (hasta 4 personas en la misma computadora). */
export const TeamRoleSchema = z.enum(['director', 'scientist', 'engineer', 'operations']);
export type TeamRole = z.infer<typeof TeamRoleSchema>;

export const TeamSchema = z.object({
  name: z.string().min(1).max(40),
  members: z
    .array(z.object({ name: z.string().min(1).max(30), role: TeamRoleSchema }))
    .min(2)
    .max(4)
    .refine((m) => new Set(m.map((x) => x.role)).size === m.length, 'Cada rol solo puede tenerlo una persona'),
});
export type Team = z.infer<typeof TeamSchema>;

/** Votación del equipo ante una decisión colectiva. */
export const TeamDecisionSchema = z.object({
  kind: z.enum(['design', 'plan', 'event']),
  atISO: z.string(),
  label: z.string(),
  votes: z.array(z.object({ role: TeamRoleSchema, choice: z.string() })),
  outcome: z.string(),
  /** true si todos votaron lo mismo. */
  unanimous: z.boolean(),
  /** Solo en acontecimientos: fracción de votos que eligieron la mejor opción según la previsión. */
  bestShare: z.number().min(0).max(1).optional(),
});
export type TeamDecision = z.infer<typeof TeamDecisionSchema>;

/** Resultado guardado al archivar (para la clasificación y la comparación). */
export const MissionResultSchema = z.object({
  score: z.number(),
  grade: z.string(),
  success: z.boolean(),
  xp: z.number(),
  deliveredGbit: z.number(),
  spentMUSD: z.number(),
  archivedAt: z.string(),
});

export const MissionSchema = z.object({
  id: z.string().min(1),
  templateId: z.string().min(1),
  objectiveId: z.string().min(1),
  name: z.string().min(1),
  stage: MissionStageSchema,
  createdAt: z.string().datetime(),
  updatedAt: z.string().datetime(),
  design: SpacecraftDesignSchema,
  /** null hasta que el jugador abre el Mission Planner. Opcional para leer guardados antiguos. */
  plan: MissionPlanSchema.nullable().default(null),
  flight: FlightStateSchema.nullable().default(null),
  trades: TradeLogSchema.default({}),
  difficulty: DifficultySchema.default('engineer'),
  team: TeamSchema.nullable().default(null),
  teamLog: z.array(TeamDecisionSchema).default([]),
  result: MissionResultSchema.nullable().default(null),
});
export type Mission = z.infer<typeof MissionSchema>;

export const AgencyProfileSchema = z.object({
  xp: z.number().nonnegative(),
  completedMissionIds: z.array(z.string()),
  tutorialDone: z.boolean(),
  /** Ya colocó su primera pieza en el LAB: la mano que enseña a arrastrar no vuelve a salir sola. */
  labHintSeen: z.boolean().default(false),
});
export type AgencyProfile = z.infer<typeof AgencyProfileSchema>;

/** Forma del archivo de guardado en localStorage. Versionado para migraciones futuras. */
export const SaveFileSchema = z.object({
  version: z.literal(1),
  profile: AgencyProfileSchema,
  missions: z.array(MissionSchema),
  activeMissionId: z.string().nullable(),
});
export type SaveFile = z.infer<typeof SaveFileSchema>;

// ───────────────────────── Glosario ─────────────────────────

export const GlossaryEntrySchema = z.object({
  term: z.string().min(1),
  short: z.string().min(1),
  detail: z.string().min(1),
  unit: z.string().optional(),
  tags: z.array(z.string()),
});
export type GlossaryEntry = z.infer<typeof GlossaryEntrySchema>;

// ───────────────────────── Vehículos de lanzamiento ─────────────────────────

export const StageSchema = z.object({
  name: z.string().min(1),
  lengthM: z.number().positive(),
  diameterM: z.number().positive(),
  engines: z.number().int().positive(),
  engineName: z.string().min(1),
  propellant: z.string().min(1),
  burnTimeS: z.number().positive(),
});
export type Stage = z.infer<typeof StageSchema>;

/** Datos REALES verificables de un vehículo (con fuentes). Nada aquí es un valor de juego. */
export const LauncherRealSchema = z.object({
  operator: z.string().min(1),
  heightM: z.number().positive(),
  diameterM: z.number().positive(),
  /** Capacidad publicada a órbita baja, kg (null si no hay dato verificado). */
  leoKg: z.number().positive().nullable(),
  leoNote: z.string().optional(),
  launchType: z.string().min(1),
  firstFlight: z.string().min(1),
  /** Estado actual del vehículo (noviembre de 2026). */
  status: z.enum(['operational', 'retired', 'retiring', 'in-development']),
  statusNote: z.string().min(1),
  /** En la figura de «CubeSat 101» (2017): ya había volado CubeSats o solo figuraba en manifiestos futuros (*). */
  cubesat2017: z.enum(['flown', 'manifest']),
  /** Historial usado para estimar la fiabilidad. */
  record: z.object({ flights: z.number().int().nonnegative(), successes: z.number().int().nonnegative(), asOf: z.string(), approx: z.boolean() }),
  /** Precio publicado (MUSD, con su año) si existe. */
  priceMUSD: z.number().positive().nullable(),
  priceNote: z.string().optional(),
  facts: z.array(z.string()).min(1),
  sources: z.array(z.object({ title: z.string(), url: z.string().url() })).min(1),
});

export const LauncherSchema = z.object({
  id: z.string().regex(/^[a-z0-9-]+$/),
  name: z.string().min(1),
  class: z.enum(['small', 'medium', 'heavy', 'super-heavy']),
  description: z.string().min(1),
  real: LauncherRealSchema,
  /**
   * ¿Puede usarse en NEXUS para una misión lunar? false si está retirado, reservado o no puede
   * llegar a la Luna; `unavailableReason` lo explica.
   */
  lunarCapable: z.boolean(),
  unavailableReason: z.string().optional(),
  // ─── Valores SIMPLIFICADOS del juego (ver `gameNote`) ───
  /** Masa máxima que el juego permite enviar en inyección translunar (TLI), kg (0 = no llega a la Luna). */
  payloadToTLIKg: z.number().nonnegative(),
  /** Costo que el juego cobra por el lanzamiento (MUSD); null si no se puede contratar en el juego. */
  costMUSD: z.number().positive().nullable(),
  /** Fiabilidad estimada a partir del historial real (regla de sucesión de Laplace). */
  reliability: z.number().min(0).max(1),
  fairing: z.object({ innerDiameterM: z.number().positive(), heightM: z.number().positive() }),
  /** Qué valores son simplificaciones del juego y de dónde salen. */
  gameNote: z.string().min(1),
  /** Geometría visual en dos tramos para la escena 3D (proporciones aproximadas). */
  stages: z.array(StageSchema).min(2),
  boosters: z.object({ count: z.number().int().nonnegative(), lengthM: z.number().positive(), diameterM: z.number().positive() }).optional(),
});
export type Launcher = z.infer<typeof LauncherSchema>;
