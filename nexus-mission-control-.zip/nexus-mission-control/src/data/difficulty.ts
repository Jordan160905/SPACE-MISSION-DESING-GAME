/**
 * Niveles de dificultad y modo sandbox. Una misión guarda su nivel; la plantilla efectiva se
 * deriva de la base con `applyDifficulty` (función pura, sin estado oculto).
 *
 *  - Explorador: solo componentes simples, más presupuesto y tiempo, objetivo de datos menor.
 *  - Ingeniero: la misión tal como está diseñada (referencia).
 *  - Experto: menos presupuesto y tiempo, más datos exigidos; más XP.
 *  - Sandbox: sin límites prácticos ni acontecimientos, para experimentar. No suma XP ni clasifica.
 */
import type { ComponentDef, MissionTemplate } from './schemas';
import type { z } from 'zod';
import type { DifficultySchema } from './schemas';

export type Difficulty = z.infer<typeof DifficultySchema>;

export interface DifficultyDef {
  id: Difficulty;
  label: string;
  /** Nombre de rol que acompaña al nivel (Explorador, Ingeniero, Experto). */
  persona: string;
  summary: string;
  budgetFactor: number;
  scheduleFactor: number;
  dataTargetFactor: number;
  xpFactor: number;
  /** Componentes permitidos según su gama. */
  allowAdvanced: boolean;
  events: boolean;
  ranked: boolean;
  /** Abre por defecto las explicaciones «¿por qué?». */
  guided: boolean;
}

export const DIFFICULTIES: DifficultyDef[] = [
  {
    id: 'explorer',
    label: 'Fácil',
    persona: 'Explorador',
    summary: 'Primera misión: solo componentes simples, +25 % de presupuesto y tiempo, objetivo de datos −20 % y explicaciones abiertas.',
    budgetFactor: 1.25,
    scheduleFactor: 1.25,
    dataTargetFactor: 0.8,
    xpFactor: 0.75,
    allowAdvanced: false,
    events: true,
    ranked: true,
    guided: true,
  },
  {
    id: 'engineer',
    label: 'Intermedio',
    persona: 'Ingeniero',
    summary: 'La misión tal cual: todos los componentes, presupuesto y calendario de referencia.',
    budgetFactor: 1,
    scheduleFactor: 1,
    dataTargetFactor: 1,
    xpFactor: 1,
    allowAdvanced: true,
    events: true,
    ranked: true,
    guided: false,
  },
  {
    id: 'expert',
    label: 'Difícil',
    persona: 'Experto',
    summary: '−15 % de presupuesto y de tiempo de desarrollo y +20 % de datos exigidos. Cada decisión cuenta; ×1,5 XP.',
    budgetFactor: 0.85,
    scheduleFactor: 0.85,
    dataTargetFactor: 1.2,
    xpFactor: 1.5,
    allowAdvanced: true,
    events: true,
    ranked: true,
    guided: false,
  },
  {
    id: 'sandbox',
    label: 'Sandbox',
    persona: 'Modo libre',
    summary: 'Laboratorio libre: presupuesto y tiempo casi ilimitados, sin acontecimientos. Para experimentar; no suma XP ni entra en la clasificación.',
    budgetFactor: 10,
    scheduleFactor: 10,
    dataTargetFactor: 1,
    xpFactor: 0,
    allowAdvanced: true,
    events: false,
    ranked: false,
    guided: true,
  },
];

export function difficultyDef(id: Difficulty | undefined): DifficultyDef {
  return DIFFICULTIES.find((d) => d.id === id) ?? DIFFICULTIES[1];
}

/** Componentes de gama avanzada: no disponibles en Explorador. */
export function isComponentAllowed(c: ComponentDef, difficulty: Difficulty | undefined): boolean {
  return difficultyDef(difficulty).allowAdvanced || c.tier !== 'advanced';
}

const cache = new Map<string, MissionTemplate>();

/** Plantilla efectiva para un nivel. Memorizada: misma entrada → mismo objeto (selectores estables). */
export function applyDifficulty(base: MissionTemplate, difficulty: Difficulty | undefined): MissionTemplate {
  const d = difficultyDef(difficulty);
  if (d.id === 'engineer') return base;
  const key = `${base.id}|${d.id}`;
  const hit = cache.get(key);
  if (hit) return hit;
  const t: MissionTemplate = {
    ...base,
    budgetCapMUSD: Math.round(base.budgetCapMUSD * d.budgetFactor),
    developmentMonths: Math.round(base.developmentMonths * d.scheduleFactor),
    objectives: base.objectives.map((o) => ({ ...o, dataTargetGbit: Math.round(o.dataTargetGbit * d.dataTargetFactor) })),
    constraints: base.constraints.map((c) => (c.id === 'c-budget' ? { ...c, label: `Presupuesto máximo: ${Math.round(base.budgetCapMUSD * d.budgetFactor)} MUSD` } : c)),
    rewards: {
      ...base.rewards,
      xp: Math.round(base.rewards.xp * d.xpFactor),
      xpPerExtraObjective: Math.round(base.rewards.xpPerExtraObjective * d.xpFactor),
      unlocks: d.ranked ? base.rewards.unlocks : [],
    },
  };
  cache.set(key, t);
  return t;
}
