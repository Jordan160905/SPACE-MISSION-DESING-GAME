import { describe, expect, it } from 'vitest';
import { COMPONENT_CATALOG, getComponent } from './components/catalog';
import { GLOSSARY } from './glossary';
import { LUNA_01, MISSION_TEMPLATES } from './missions/missions';
import { ComponentCategorySchema, ComponentDefSchema, GlossaryEntrySchema, MissionTemplateSchema } from './schemas';

describe('catálogo de componentes', () => {
  it('cada componente cumple el esquema', () => {
    for (const c of COMPONENT_CATALOG) {
      const r = ComponentDefSchema.safeParse(c);
      expect(r.success, `${c.id}: ${r.success ? '' : r.error.message}`).toBe(true);
    }
  });

  it('los IDs son únicos', () => {
    const ids = COMPONENT_CATALOG.map((c) => c.id);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it('contiene los 18 componentes iniciales y todas las categorías', () => {
    expect(COMPONENT_CATALOG).toHaveLength(18);
    for (const cat of ComponentCategorySchema.options) {
      expect(COMPONENT_CATALOG.some((c) => c.category === cat), cat).toBe(true);
    }
  });

  it('requisitos e incompatibilidades apuntan a componentes existentes', () => {
    for (const c of COMPONENT_CATALOG) {
      for (const id of [...c.requires, ...c.incompatibleWith]) {
        expect(getComponent(id), `${c.id} → ${id}`).toBeTruthy();
      }
    }
  });

  it('las incompatibilidades son simétricas', () => {
    for (const c of COMPONENT_CATALOG) {
      for (const id of c.incompatibleWith) {
        expect(getComponent(id)!.incompatibleWith, `${id} debería declarar ${c.id}`).toContain(c.id);
      }
    }
  });

  it('cada pieza puede montarse en al menos un tipo de socket que ofrece algún chasis', () => {
    const offered = new Set(COMPONENT_CATALOG.flatMap((c) => c.sockets.map((s) => s.type)));
    for (const c of COMPONENT_CATALOG.filter((x) => x.category !== 'STRUCTURE')) {
      expect(c.mountsOn.some((t) => offered.has(t)), c.id).toBe(true);
    }
  });

  it('los sockets de cada chasis tienen IDs únicos', () => {
    for (const c of COMPONENT_CATALOG.filter((x) => x.category === 'STRUCTURE')) {
      const ids = c.sockets.map((s) => s.id);
      expect(new Set(ids).size, c.id).toBe(ids.length);
    }
  });

  it('los modelos son procedurales y están marcados como provisionales (Fase 1)', () => {
    for (const c of COMPONENT_CATALOG) {
      expect(c.model.provisional).toBe(true);
    }
  });
});

describe('plantillas de misión', () => {
  it('todas cumplen el esquema', () => {
    for (const m of MISSION_TEMPLATES) {
      const r = MissionTemplateSchema.safeParse(m);
      expect(r.success, m.id).toBe(true);
    }
  });

  it('LUNA-01 es jugable y sus objetivos usan instrumentos del catálogo', () => {
    expect(LUNA_01.available).toBe(true);
    expect(LUNA_01.objectives.length).toBeGreaterThan(0);
    for (const o of LUNA_01.objectives) {
      const inst = getComponent(o.primaryInstrumentId);
      expect(inst?.category, o.id).toBe('INSTRUMENT');
      expect(o.recommendedOrbit.altitudeKm[0]).toBeLessThan(o.recommendedOrbit.altitudeKm[1]);
    }
  });

  it('las misiones bloqueadas explican por qué', () => {
    for (const m of MISSION_TEMPLATES.filter((x) => !x.available)) {
      expect(m.lockReason, m.id).toBeTruthy();
    }
  });

  it('las recompensas de desbloqueo apuntan a misiones existentes', () => {
    for (const id of LUNA_01.rewards.unlocks) {
      expect(MISSION_TEMPLATES.some((m) => m.id === id), id).toBe(true);
    }
  });

  it('existen restricciones críticas y de optimización', () => {
    expect(LUNA_01.constraints.some((c) => c.severity === 'hard')).toBe(true);
    expect(LUNA_01.constraints.some((c) => c.severity === 'soft')).toBe(true);
  });
});

describe('glosario', () => {
  it('cada entrada cumple el esquema y no hay términos repetidos', () => {
    for (const g of GLOSSARY) expect(GlossaryEntrySchema.safeParse(g).success, g.term).toBe(true);
    expect(new Set(GLOSSARY.map((g) => g.term)).size).toBe(GLOSSARY.length);
  });
});

describe('lanzadores (figura 7 de «CubeSat 101»)', () => {
  it('son los 12 vehículos pedidos, cumplen el esquema y tienen IDs únicos', async () => {
    const { LAUNCHERS } = await import('./launchers/launchers');
    const { LauncherSchema } = await import('./schemas');
    for (const l of LAUNCHERS) expect(LauncherSchema.safeParse(l).success, l.id).toBe(true);
    expect(new Set(LAUNCHERS.map((l) => l.id)).size).toBe(8);
    expect(LAUNCHERS.map((l) => l.name)).toEqual([
      'Super Strypi',
      'Minotaur I',
      'Minotaur IV',
      'Taurus XL',
      'Delta II',
      'Antares',
      'Falcon 9',
      'Atlas V',
    ]);
  });

  it('distingue los que ya habían volado CubeSats en 2017 de los que solo estaban en manifiesto (*)', async () => {
    const { LAUNCHERS, CUBESAT101_MANIFEST_ONLY } = await import('./launchers/launchers');
    // Los 8 del catálogo ya habían volado CubeSats; los 4 marcados con * quedan solo como nota.
    expect(LAUNCHERS.every((l) => l.real.cubesat2017 === 'flown')).toBe(true);
    expect([...CUBESAT101_MANIFEST_ONLY]).toEqual(['Electron', 'Falcon 9 Heavy', 'LauncherOne', 'Space Launch System (SLS)']);
    for (const n of CUBESAT101_MANIFEST_ONLY) expect(LAUNCHERS.some((l) => l.name === n)).toBe(false);
  });

  it('no presenta como operativos a los retirados, y solo los contratables tienen valores lunares de juego', async () => {
    const { LAUNCHERS, LUNAR_LAUNCHERS } = await import('./launchers/launchers');
    const retired = LAUNCHERS.filter((l) => l.real.status === 'retired').map((l) => l.id);
    expect(retired).toEqual(['super-strypi', 'taurus-xl', 'delta-ii']);
    expect(LAUNCHERS.filter((l) => l.real.status === 'operational').map((l) => l.id)).toEqual(['minotaur-i', 'minotaur-iv', 'falcon-9']);
    for (const l of LAUNCHERS) {
      if (l.lunarCapable) {
        expect(l.real.status, l.id).toBe('operational');
        expect(l.payloadToTLIKg, l.id).toBeGreaterThan(0);
        expect(l.costMUSD, l.id).not.toBe(null);
      } else {
        expect(l.payloadToTLIKg, l.id).toBe(0);
        expect(l.costMUSD, l.id).toBe(null);
        expect((l.unavailableReason ?? '').length, l.id).toBeGreaterThan(20);
      }
      expect(l.real.sources.length, l.id).toBeGreaterThan(0);
      expect(l.gameNote.length, l.id).toBeGreaterThan(20);
    }
    expect(LUNAR_LAUNCHERS.map((l) => l.id)).toEqual(['minotaur-iv', 'falcon-9']);
    // más caro → más capacidad hacia la Luna
    for (let i = 1; i < LUNAR_LAUNCHERS.length; i++) expect(LUNAR_LAUNCHERS[i].payloadToTLIKg).toBeGreaterThan(LUNAR_LAUNCHERS[i - 1].payloadToTLIKg);
  });

  it('la fiabilidad sale del historial real con la regla de Laplace', async () => {
    const { getLauncher, laplaceReliability } = await import('./launchers/launchers');
    expect(laplaceReliability(8, 8)).toBeCloseTo(0.9, 12);
    expect(getLauncher('minotaur-iv')!.reliability).toBeCloseTo(0.9, 12); // 8 de 8: pocos vuelos → estimación prudente
    expect(getLauncher('falcon-9')!.reliability).toBeGreaterThan(0.99);
    expect(getLauncher('super-strypi')!.reliability).toBeCloseTo(1 / 3, 12);
  });

  it('los planes guardados con los lanzadores ficticios antiguos se migran', async () => {
    const { MissionPlanSchema } = await import('./schemas');
    const p = MissionPlanSchema.parse({ launcherId: 'condor-m', altitudeKm: 75, inclinationDeg: 90, durationDays: 60, launchDay: 6 });
    expect(p.launcherId).toBe('falcon-9');
  });
});
