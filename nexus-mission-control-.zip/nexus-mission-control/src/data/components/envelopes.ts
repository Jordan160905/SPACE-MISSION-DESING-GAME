/**
 * Dimensiones exteriores de cada pieza EN CONFIGURACIÓN DE LANZAMIENTO (plegada), en metros.
 * outwardM  = cuánto sobresale desde el anclaje a lo largo de la normal.
 * halfWidthM = semiancho máximo perpendicular a la normal.
 * Deben coincidir con los modelos de scene/spacecraft/partModels.tsx (comprobado a mano; ver docs).
 */
export const STOWED_ENVELOPE: Record<string, { outwardM: number; halfWidthM: number }> = {
  'solar-basic': { outwardM: 0.08, halfWidthM: 0.23 },
  'solar-adv': { outwardM: 0.14, halfWidthM: 0.23 },
  'battery-basic': { outwardM: 0.2, halfWidthM: 0.12 },
  'battery-adv': { outwardM: 0.22, halfWidthM: 0.13 },
  'antenna-basic': { outwardM: 0.5, halfWidthM: 0.14 },
  'antenna-hg': { outwardM: 0.47, halfWidthM: 0.39 },
  thruster: { outwardM: 0.38, halfWidthM: 0.125 },
  'prop-tank': { outwardM: 0.4, halfWidthM: 0.2 },
  obc: { outwardM: 0.12, halfWidthM: 0.13 },
  'attitude-sensor': { outwardM: 0.22, halfWidthM: 0.1 },
  'reaction-wheels': { outwardM: 0.24, halfWidthM: 0.13 },
  camera: { outwardM: 0.57, halfWidthM: 0.135 },
  spectrometer: { outwardM: 0.35, halfWidthM: 0.21 },
  radar: { outwardM: 0.21, halfWidthM: 0.625 },
  thermal: { outwardM: 0.07, halfWidthM: 0.18 },
};

/** Altura del anillo de separación bajo el chasis (coincide con ChassisModel). */
export const SEPARATION_RING_M = 0.12;
