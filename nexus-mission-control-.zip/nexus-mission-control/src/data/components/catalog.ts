/**
 * Catálogo inicial de componentes.
 *
 * IMPORTANTE (honestidad científica): los valores son de ESCALA DE JUEGO, elegidos para que las
 * relaciones de ingeniería sean coherentes (p. ej. una antena de alta ganancia transmite más pero
 * consume y pesa más y necesita apuntamiento). Están inspirados en órdenes de magnitud de
 * pequeños satélites científicos, pero NO son especificaciones de hardware real.
 * Ver docs/ASSUMPTIONS.md.
 */
import type { ComponentDef, SocketDef } from '../schemas';

/** Reparte n posiciones a lo largo de un eje de semilongitud h (centrado si n = 1). */
function spread(n: number, h: number, i: number): number {
  return n === 1 ? 0 : -h * 0.5 + (h * i) / (n - 1);
}

/**
 * Genera sockets para un chasis con forma de caja de semiejes hx, hy, hz (m).
 * top = cara cenital (hacia el espacio), bottom = cara nadir (hacia la superficie / popa).
 */
function boxSockets(
  hx: number,
  hy: number,
  hz: number,
  opts: { top: number; bottom: number; sidesPerFace: number; internal: number },
): SocketDef[] {
  const s: SocketDef[] = [];
  for (let i = 0; i < opts.top; i++) s.push({ id: `top-${i}`, type: 'top', position: [spread(opts.top, hx * 1.2, i), hy, 0], normal: [0, 1, 0] });
  for (let i = 0; i < opts.bottom; i++)
    s.push({ id: `bottom-${i}`, type: 'bottom', position: [spread(opts.bottom, hx * 1.2, i), -hy, 0], normal: [0, -1, 0] });
  const sidesPerFace = opts.sidesPerFace;
  const internal = opts.internal;
  const faces: Array<{ key: string; n: [number, number, number] }> = [
    { key: 'px', n: [1, 0, 0] },
    { key: 'nx', n: [-1, 0, 0] },
    { key: 'pz', n: [0, 0, 1] },
    { key: 'nz', n: [0, 0, -1] },
  ];
  for (const f of faces) {
    for (let i = 0; i < sidesPerFace; i++) {
      // Reparte los sockets verticalmente sobre la cara.
      const y = spread(sidesPerFace, hy, i);
      s.push({
        id: `side-${f.key}-${i}`,
        type: 'side',
        position: [f.n[0] * hx, y, f.n[2] * hz],
        normal: f.n,
      });
    }
  }
  // Bahías internas en rejilla 2×N sobre el plano medio, para que las piezas no se solapen.
  for (let i = 0; i < internal; i++) {
    const col = i % 2;
    const row = Math.floor(i / 2);
    const rows = Math.ceil(internal / 2);
    s.push({
      id: `bay-${i}`,
      type: 'internal',
      position: [internal === 1 ? 0 : (col === 0 ? -1 : 1) * hx * 0.45, spread(rows, hy * 1.1, row) - hy * 0.25, 0],
      normal: [0, 1, 0],
    });
  }
  return s;
}

/** Nombre legible de un socket a partir de su id. */
export function socketLabel(id: string): string {
  const [kind, a, b] = id.split('-');
  const n = (x: string | undefined) => (x === undefined ? '' : ` ${Number(x) + 1}`);
  switch (kind) {
    case 'top':
      return `Superior${n(a)}`;
    case 'bottom':
      return `Inferior${n(a)}`;
    case 'bay':
      return `Bahía interna${n(a)}`;
    case 'side': {
      const faces: Record<string, string> = { px: '+X', nx: '−X', pz: '+Z', nz: '−Z' };
      const face = faces[a] ?? a;
      return `Lateral ${face}${n(b)}`;
    }
    default:
      return id;
  }
}

/** Valores neutros para no repetir campos en cada definición. */
const base = {
  powerDrawW: 0,
  powerGenW: 0,
  energyStorageWh: 0,
  dataGenGbitPerH: 0,
  requiresSunlight: false,
  dataStorageGbit: 0,
  downlinkMbps: 0,
  propellantKg: 0,
  ispS: 0,
  sockets: [] as SocketDef[],
  requires: [] as string[],
  incompatibleWith: [] as string[],
  heritage: 'flight-proven' as const,
  tier: 'simple' as const,
  scienceValue: 0,
} satisfies Partial<ComponentDef>;

const proc = (key: string) => ({ kind: 'procedural' as const, key, provisional: true });

export const COMPONENT_CATALOG: ComponentDef[] = [
  // ── ESTRUCTURA ──────────────────────────────────────────────
  {
    ...base,
    id: 'chassis-s',
    name: 'Chasis pequeño',
    category: 'STRUCTURE',
    description: 'Bus ligero de aluminio en panal. Pocos puntos de anclaje.',
    massKg: 40,
    costMUSD: 6,
    mountsOn: [],
    sockets: boxSockets(0.35, 0.35, 0.35, { top: 1, bottom: 1, sidesPerFace: 1, internal: 3 }),
    engineeringNote: 'Menos estructura significa menos masa, pero también menos espacio para instrumentos y subsistemas.',
    model: proc('chassis-s'),
  },
  {
    ...base,
    id: 'chassis-m',
    name: 'Chasis mediano',
    category: 'STRUCTURE',
    description: 'Bus equilibrado para misiones orbitales con varios instrumentos.',
    massKg: 90,
    costMUSD: 11,
    mountsOn: [],
    sockets: boxSockets(0.5, 0.55, 0.5, { top: 1, bottom: 2, sidesPerFace: 2, internal: 4 }),
    engineeringNote: 'El chasis es la columna vertebral: su masa se paga en cada kilogramo que el lanzador debe acelerar.',
    model: proc('chassis-m'),
  },
  {
    ...base,
    id: 'chassis-l',
    name: 'Chasis grande',
    category: 'STRUCTURE',
    description: 'Bus robusto capaz de alojar instrumentos pesados como el radar.',
    massKg: 180,
    costMUSD: 18,
    mountsOn: [],
    sockets: boxSockets(0.7, 0.8, 0.7, { top: 2, bottom: 2, sidesPerFace: 3, internal: 6 }),
    engineeringNote: 'Más anclajes permiten redundancia, pero la masa adicional puede exigir un lanzador más caro.',
    model: proc('chassis-l'),
  },

  // ── ENERGÍA ─────────────────────────────────────────────────
  {
    ...base,
    id: 'solar-basic',
    name: 'Panel solar básico',
    category: 'POWER',
    description: 'Ala fija de células de silicio.',
    massKg: 8,
    costMUSD: 1.5,
    powerGenW: 150,
    mountsOn: ['side'],
    engineeringNote: 'La potencia (W) es una tasa. Solo produce mientras está iluminado: en eclipse la nave vive de la batería.',
    model: proc('solar-basic'),
  },
  {
    ...base,
    id: 'solar-adv',
    tier: 'advanced',
    heritage: 'modified',
    name: 'Panel solar avanzado',
    category: 'POWER',
    description: 'Ala desplegable de células de triple unión, mayor eficiencia por kg.',
    massKg: 10,
    costMUSD: 4,
    powerGenW: 320,
    mountsOn: ['side'],
    engineeringNote: 'Más potencia por kilogramo a cambio de un costo mayor: una decisión típica de compromiso.',
    model: proc('solar-adv'),
  },
  {
    ...base,
    id: 'battery-basic',
    name: 'Batería básica',
    category: 'POWER',
    description: 'Paquete de ion-litio de capacidad modesta.',
    massKg: 6,
    costMUSD: 0.8,
    energyStorageWh: 400,
    mountsOn: ['internal'],
    engineeringNote: 'La energía (Wh) es una cantidad almacenada. Autonomía en eclipse ≈ capacidad (Wh) ÷ consumo (W).',
    model: proc('battery-basic'),
  },
  {
    ...base,
    id: 'battery-adv',
    tier: 'advanced',
    heritage: 'modified',
    name: 'Batería avanzada',
    category: 'POWER',
    description: 'Celdas de alta densidad energética.',
    massKg: 7,
    costMUSD: 2.2,
    energyStorageWh: 900,
    mountsOn: ['internal'],
    engineeringNote: 'Mayor densidad energética permite sobrevivir eclipses largos sin añadir mucha masa.',
    model: proc('battery-adv'),
  },

  // ── COMUNICACIONES ──────────────────────────────────────────
  {
    ...base,
    id: 'antenna-basic',
    name: 'Antena básica',
    category: 'COMMS',
    description: 'Antena omnidireccional de baja ganancia.',
    massKg: 2,
    costMUSD: 0.6,
    powerDrawW: 15,
    downlinkMbps: 2,
    mountsOn: ['top', 'side'],
    incompatibleWith: ['radar'],
    engineeringNote:
      'No necesita apuntar a la Tierra, pero su baja ganancia limita la tasa de datos. Comparte banda con el radar (simplificación del juego): no pueden coexistir.',
    model: proc('antenna-basic'),
  },
  {
    ...base,
    id: 'antenna-hg',
    heritage: 'modified',
    name: 'Antena de alta ganancia',
    category: 'COMMS',
    description: 'Plato parabólico orientable.',
    massKg: 9,
    costMUSD: 3.5,
    powerDrawW: 45,
    downlinkMbps: 40,
    mountsOn: ['top'],
    requires: ['attitude-sensor'],
    engineeringNote: 'Concentra la señal en un haz estrecho: transmite mucho más, pero debe apuntar con precisión, por eso requiere sensor de orientación.',
    model: proc('antenna-hg'),
  },

  // ── PROPULSIÓN ──────────────────────────────────────────────
  {
    ...base,
    id: 'thruster',
    name: 'Propulsor',
    category: 'PROPULSION',
    description: 'Motor bipropelente (hidracina + tetróxido de nitrógeno) para inserción y mantenimiento orbital.',
    massKg: 12,
    costMUSD: 3,
    powerDrawW: 30,
    ispS: 315,
    mountsOn: ['bottom'],
    requires: ['prop-tank'],
    engineeringNote: 'Sin propelente no hay empuje. Su impulso específico (315 s) dice cuánto cambio de velocidad obtiene por kilo de propelente. La Luna tiene un campo gravitatorio irregular: las órbitas bajas necesitan correcciones periódicas.',
    model: proc('thruster'),
  },
  {
    ...base,
    id: 'prop-tank',
    name: 'Tanque de propelente',
    category: 'PROPULSION',
    description: 'Tanque esférico de titanio, se entrega cargado.',
    massKg: 15,
    costMUSD: 1.2,
    propellantKg: 80,
    mountsOn: ['internal'],
    engineeringNote: 'Masa seca 15 kg + 80 kg de propelente: la masa húmeda es la que importa para el lanzador. Un segundo tanque da más Δv, pero también más masa que frenar.',
    model: proc('prop-tank'),
  },

  // ── CONTROL ─────────────────────────────────────────────────
  {
    ...base,
    id: 'obc',
    name: 'Computadora de a bordo',
    category: 'CONTROL',
    description: 'Procesador endurecido a la radiación con memoria masiva.',
    massKg: 4,
    costMUSD: 2.5,
    powerDrawW: 20,
    dataStorageGbit: 256,
    mountsOn: ['internal'],
    engineeringNote: 'Almacena los datos hasta que haya contacto con Tierra. Si la memoria se llena, los instrumentos pierden datos.',
    model: proc('obc'),
  },
  {
    ...base,
    id: 'attitude-sensor',
    name: 'Sensor de orientación',
    category: 'CONTROL',
    description: 'Rastreador estelar que determina la orientación de la nave.',
    massKg: 3,
    costMUSD: 1.8,
    powerDrawW: 8,
    mountsOn: ['top', 'side'],
    engineeringNote: 'Saber hacia dónde apunta la nave es imprescindible para cámaras de alta resolución y antenas direccionales.',
    model: proc('attitude-sensor'),
  },
  {
    ...base,
    id: 'reaction-wheels',
    heritage: 'modified',
    name: 'Ruedas de reacción',
    category: 'CONTROL',
    description: 'Tres volantes de inercia para girar la nave sin gastar propelente.',
    massKg: 10,
    costMUSD: 2.6,
    powerDrawW: 25,
    mountsOn: ['internal'],
    requires: ['attitude-sensor'],
    engineeringNote: 'Conservación del momento angular: acelerar una rueda hace girar la nave en sentido contrario. Necesitan saber la orientación para corregirla.',
    model: proc('reaction-wheels'),
  },

  // ── INSTRUMENTOS ────────────────────────────────────────────
  {
    ...base,
    id: 'camera',
    scienceValue: 3,
    name: 'Cámara científica',
    category: 'INSTRUMENT',
    description: 'Cámara de ángulo estrecho para cartografía de alta resolución.',
    massKg: 14,
    costMUSD: 6,
    powerDrawW: 35,
    dataGenGbitPerH: 18,
    requiresSunlight: true,
    mountsOn: ['bottom', 'side'],
    requires: ['obc', 'attitude-sensor'],
    engineeringNote: 'Es un instrumento pasivo: solo fotografía la superficie iluminada. Genera muchos datos: sin un enlace suficiente, la memoria se satura.',
    model: proc('camera'),
  },
  {
    ...base,
    id: 'spectrometer',
    scienceValue: 4,
    heritage: 'modified',
    name: 'Espectrómetro',
    category: 'INSTRUMENT',
    description: 'Espectrómetro de infrarrojo para identificar minerales.',
    massKg: 22,
    costMUSD: 9,
    powerDrawW: 50,
    dataGenGbitPerH: 6,
    requiresSunlight: true,
    mountsOn: ['bottom', 'side'],
    requires: ['obc', 'thermal'],
    engineeringNote: 'Su detector infrarrojo debe mantenerse frío; sin control térmico el ruido térmico arruina la medición.',
    model: proc('spectrometer'),
  },
  {
    ...base,
    id: 'radar',
    scienceValue: 5,
    heritage: 'new',
    name: 'Radar de observación',
    category: 'INSTRUMENT',
    description: 'Radar activo capaz de sondear sombras permanentes en los polos.',
    massKg: 45,
    costMUSD: 15,
    powerDrawW: 180,
    dataGenGbitPerH: 30,
    mountsOn: ['bottom'],
    requires: ['obc', 'reaction-wheels'],
    incompatibleWith: ['antenna-basic'],
    engineeringNote:
      'Un radar emite su propia energía: ve dentro de cráteres en sombra, pero consume mucha potencia y exige control de orientación preciso.',
    model: proc('radar'),
  },

  // ── PROTECCIÓN ──────────────────────────────────────────────
  {
    ...base,
    id: 'thermal',
    name: 'Sistema térmico',
    category: 'PROTECTION',
    description: 'Mantas multicapa, radiadores y calentadores.',
    massKg: 6,
    costMUSD: 1.4,
    powerDrawW: 12,
    mountsOn: ['internal', 'side'],
    engineeringNote: 'En órbita lunar la cara iluminada supera los 100 °C y la sombra baja de −150 °C; la electrónica necesita un rango estable.',
    model: proc('thermal'),
  },
];

export const CATEGORY_LABELS: Record<ComponentDef['category'], string> = {
  STRUCTURE: 'Estructura',
  POWER: 'Energía',
  COMMS: 'Comunicaciones',
  PROPULSION: 'Propulsión',
  CONTROL: 'Control',
  INSTRUMENT: 'Instrumentos',
  PROTECTION: 'Protección',
};

const byId = new Map(COMPONENT_CATALOG.map((c) => [c.id, c]));

export function getComponent(id: string): ComponentDef | undefined {
  return byId.get(id);
}
