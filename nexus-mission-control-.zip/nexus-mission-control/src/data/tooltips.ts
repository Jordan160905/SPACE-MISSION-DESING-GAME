import { getLang } from '../i18n/lang';
import { translate } from '../i18n/translator';

/**
 * Glosario interactivo: definiciones MUY sencillas para los tooltips (pasar el cursor o tocar una
 * palabra subrayada). Cada entrada enlaza, si existe, con el término completo del glosario.
 * `match` son las formas en minúscula que se reconocen en los textos (singular/plural).
 */
export interface Tooltip {
  id: string;
  label: string;
  match: string[];
  simple: string;
  /** Término del glosario completo (GlossaryScreen), si lo hay. */
  glossaryTerm?: string;
}

export const TOOLTIPS: Tooltip[] = [
  { id: 'orbita', label: 'Órbita', match: ['órbita', 'órbitas', 'orbitar'], simple: 'Camino que sigue un objeto alrededor de un planeta o una luna, como una pista circular invisible.' },
  { id: 'orbitador', label: 'Orbitador', match: ['orbitador', 'orbitadores'], simple: 'Nave que se queda dando vueltas alrededor de un astro para estudiarlo desde arriba.' },
  { id: 'satelite', label: 'Satélite', match: ['satélite', 'satélites'], simple: 'Objeto construido para quedarse en el espacio y hacer un trabajo: observar, comunicar, medir.' },
  { id: 'telemetria', label: 'Telemetría', match: ['telemetría'], simple: 'Información que la nave envía para contar cómo está funcionando: energía, temperatura, posición…' },
  { id: 'polar', label: 'Órbita polar', match: ['órbita polar', 'polar'], simple: 'Órbita que pasa por encima de los dos polos. Como el astro gira debajo, con el tiempo se ve toda la superficie.', glossaryTerm: 'Órbita polar' },
  { id: 'inclinacion', label: 'Inclinación', match: ['inclinación'], simple: 'Ángulo de la órbita respecto al ecuador: 0° va por el ecuador y 90° pasa por los polos.', glossaryTerm: 'Inclinación' },
  { id: 'altitud', label: 'Altitud', match: ['altitud', 'altitudes'], simple: 'Altura de la nave sobre la superficie. Más baja = más detalle, pero más correcciones de órbita.', glossaryTerm: 'Altitud' },
  { id: 'eclipse', label: 'Eclipse', match: ['eclipse', 'eclipses'], simple: 'Parte de cada vuelta en la que la Luna tapa el Sol: los paneles no generan y la nave vive de su batería.', glossaryTerm: 'Eclipse' },
  { id: 'bateria', label: 'Batería', match: ['batería', 'baterías'], simple: 'Guarda energía cuando hay Sol para usarla en la sombra.' },
  { id: 'panel', label: 'Panel solar', match: ['panel solar', 'paneles solares', 'paneles'], simple: 'Placas que convierten la luz del Sol en electricidad.' },
  { id: 'energia', label: 'Energía', match: ['energía', 'energético', 'energética'], simple: 'La electricidad disponible para que funcionen los equipos de la nave.', glossaryTerm: 'Energía' },
  { id: 'presupuesto', label: 'Presupuesto', match: ['presupuesto'], simple: 'Todo el dinero de la misión: construir la nave, lanzarla y operarla cada día.' },
  { id: 'musd', label: 'MUSD', match: ['musd'], simple: 'Millones de dólares estadounidenses.' },
  { id: 'gbit', label: 'Gbit', match: ['gbit'], simple: 'Gigabit: unidad de cantidad de información. 8 Gbit son 1 gigabyte, como unas 250 fotos de móvil.', glossaryTerm: 'Gbit' },
  { id: 'datos', label: 'Datos científicos', match: ['datos científicos'], simple: 'La información que miden los instrumentos y que hay que enviar a la Tierra para que los científicos la estudien.' },
  { id: 'instrumento', label: 'Instrumento científico', match: ['instrumento', 'instrumentos'], simple: 'El aparato que hace la ciencia: una cámara, un espectrómetro o un radar.' },
  { id: 'camara', label: 'Cámara científica', match: ['cámara científica', 'cámara'], simple: 'Toma fotografías muy detalladas de la superficie; solo funciona con luz del Sol.' },
  { id: 'espectrometro', label: 'Espectrómetro', match: ['espectrómetro', 'espectral'], simple: 'Separa la luz en colores para saber de qué materiales está hecha la superficie.', glossaryTerm: 'Espectrómetro' },
  { id: 'radar', label: 'Radar', match: ['radar'], simple: 'Envía ondas de radio y escucha el eco: puede «ver» dentro de cráteres a oscuras.' },
  { id: 'resolucion', label: 'Resolución', match: ['resolución'], simple: 'El tamaño del detalle más pequeño que se distingue en una imagen.' },
  { id: 'carga', label: 'Carga útil', match: ['carga útil'], simple: 'Lo que el cohete lleva al espacio: en NEXUS, tu nave.' },
  { id: 'lanzador', label: 'Vehículo de lanzamiento', match: ['lanzador', 'lanzadores', 'vehículo de lanzamiento', 'cohete', 'cohetes'], simple: 'El cohete que sube la nave al espacio y la empuja hacia la Luna.' },
  { id: 'cofia', label: 'Cofia', match: ['cofia'], simple: 'La «nariz» del cohete que protege la nave del aire durante el ascenso. La nave debe caber dentro.', glossaryTerm: 'Cofia' },
  { id: 'masa', label: 'Masa húmeda', match: ['masa húmeda', 'masa'], simple: 'Cuánto pesa la nave, incluido el combustible. El cohete solo puede llevar cierta masa.', glossaryTerm: 'Masa húmeda' },
  { id: 'propelente', label: 'Propelente', match: ['propelente', 'combustible'], simple: 'El combustible de los motores de la nave, para frenar al llegar y corregir la órbita.' },
  { id: 'dv', label: 'Delta-v (Δv)', match: ['δv', 'delta-v'], simple: 'Cuánto puede cambiar la nave su velocidad con su combustible. Cada maniobra «gasta» Δv.', glossaryTerm: 'Delta-v (Δv)' },
  { id: 'tli', label: 'Inyección translunar', match: ['inyección translunar', 'tli'], simple: 'El último empujón del cohete que pone la nave en camino hacia la Luna.', glossaryTerm: 'Inyección translunar (TLI)' },
  { id: 'enlace', label: 'Enlace con la Tierra', match: ['enlace', 'transmisión'], simple: 'La comunicación por radio entre la nave y las antenas de la Tierra para enviar datos.', glossaryTerm: 'Enlace descendente' },
  { id: 'estacion', label: 'Estación terrestre', match: ['estación terrestre', 'estaciones terrestres'], simple: 'Antena gigante en la Tierra que habla con la nave. Atiende a muchas misiones, así que solo tienes unas horas al día.' },
  { id: 'margen', label: 'Margen', match: ['margen', 'márgenes'], simple: 'Reserva extra por si algo sale peor de lo previsto. Los ingenieros nunca diseñan «justo».', glossaryTerm: 'Margen' },
  { id: 'crater', label: 'Cráter en sombra permanente', match: ['sombra permanente'], simple: 'Cráteres cerca de los polos donde el Sol nunca llega al fondo: pueden guardar hielo.' },
  { id: 'alunizaje', label: 'Alunizaje', match: ['alunizaje'], simple: 'Aterrizar en la Luna.' },
  { id: 'ventana', label: 'Ventana de lanzamiento', match: ['ventana de lanzamiento', 'ventana'], simple: 'Los días en que la Tierra y la Luna están bien colocadas para despegar gastando poco combustible.', glossaryTerm: 'Ventana de lanzamiento' },
  { id: 'cubesat', label: 'CubeSat', match: ['cubesat', 'cubesats'], simple: 'Satélite pequeño hecho de cubos de 10 cm. Suele viajar como pasajero de otro cohete.', glossaryTerm: 'CubeSat' },
];

const BY_MATCH = new Map<string, Tooltip>();
for (const t of TOOLTIPS) for (const m of t.match) BY_MATCH.set(m, t);

/** Formas reconocidas, de la más larga a la más corta (para que «órbita polar» gane a «órbita»). */
const MATCHES = [...BY_MATCH.keys()].sort((a, b) => b.length - a.length);
const escape = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const RE = new RegExp(`(?<![\\p{L}\\p{N}])(${MATCHES.map(escape).join('|')})(?![\\p{L}\\p{N}])`, 'giu');

export type GlossSegment = { text: string; tip?: Tooltip };

/** En inglés: la frase se traduce entera y los términos se reconocen por su forma en inglés. */
const ENGLISH: { re: RegExp; by: Map<string, Tooltip> } = { re: /$^/, by: new Map() };
function englishMatcher() {
  if (ENGLISH.by.size) return ENGLISH;
  const forms = (t: Tooltip) => [t.label, ...t.match].map((m) => translate(m).toLowerCase()).filter((m, i, a) => m && !/[áéíóúñ]/.test(m) && a.indexOf(m) === i);
  for (const t of TOOLTIPS) for (const f of forms(t)) for (const v of [f, `${f}s`]) if (!ENGLISH.by.has(v)) ENGLISH.by.set(v, t);
  const all = [...ENGLISH.by.keys()].sort((a, b) => b.length - a.length);
  ENGLISH.re = new RegExp(`(?<![\\p{L}\\p{N}])(${all.map(escape).join('|')})(?![\\p{L}\\p{N}])`, 'giu');
  return ENGLISH;
}

/**
 * Parte un texto en segmentos y marca la PRIMERA aparición de cada término (las siguientes quedan
 * como texto normal para no saturar). `seen` permite compartir el «ya marcado» entre párrafos.
 */
export function glossSegments(text: string, seen: Set<string> = new Set()): GlossSegment[] {
  const en = getLang() === 'en';
  if (en) text = translate(text);
  const re = en ? englishMatcher().re : RE;
  const by = en ? englishMatcher().by : BY_MATCH;
  const out: GlossSegment[] = [];
  let last = 0;
  for (const m of text.matchAll(re)) {
    const tip = by.get(m[0].toLowerCase());
    if (!tip || seen.has(tip.id)) continue;
    seen.add(tip.id);
    if (m.index! > last) out.push({ text: text.slice(last, m.index) });
    out.push({ text: m[0], tip });
    last = m.index! + m[0].length;
  }
  if (last < text.length) out.push({ text: text.slice(last) });
  return out;
}

export function tooltipById(id: string): Tooltip | undefined {
  return TOOLTIPS.find((t) => t.id === id);
}
