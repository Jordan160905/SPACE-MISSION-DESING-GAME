/**
 * Traductor de la interfaz (español → inglés).
 *
 * El juego está escrito en español. Cuando el idioma es inglés, esta capa traduce el texto visible
 * (nodos de texto y los atributos aria-label, title, placeholder y alt) con el diccionario `EN`:
 *  - frases exactas;
 *  - plantillas con datos («Masa {0} / {1} kg»): los huecos se rellenan con lo que muestra la
 *    pantalla y, si son palabras del diccionario, también se traducen;
 *  - frases compuestas: si no hay coincidencia exacta, se traduce oración por oración y por
 *    segmentos separados por « · ».
 * Guarda el texto original de cada nodo para volver al español al instante.
 *
 * Solo cambia el valor de nodos de texto existentes (nunca crea ni elimina nodos), así que no
 * interfiere con React.
 */
import { EN } from './en';
import { getLang, subscribeLang } from './lang';

type Pattern = { re: RegExp; out: string; words: string[]; litLen: number };

const exact = new Map<string, string>();
const patterns: Pattern[] = [];
const byWord = new Map<string, Pattern[]>();
const WORD_RE = /[A-Za-zÁÉÍÓÚÜÑáéíóúüñ]{2,}/g;
const lowerExact = new Map<string, string>();

const norm = (s: string) => s.replace(/\s+/g, ' ').trim();
const escapeRe = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

function build() {
  for (const [es, en] of Object.entries(EN)) {
    const key = norm(es);
    if (!/\{\d+\}/.test(key)) {
      exact.set(key, en);
      const lk = key.toLowerCase();
      if (!lowerExact.has(lk)) lowerExact.set(lk, en);
      continue;
    }
    const lit = key.replace(/\{\d+\}/g, '');
    const words = (lit.match(WORD_RE) ?? []).map((w) => w.toLowerCase());
    if (!words.length) continue; // una plantilla sin palabras atraparía cualquier texto
    const order: number[] = [];
    const src = key
      .split(/(\{\d+\})/)
      .map((part) => {
        const m = /^\{(\d+)\}$/.exec(part);
        if (m) {
          order.push(Number(m[1]));
          return '([\\s\\S]+?)';
        }
        return escapeRe(part);
      })
      .join('');
    // Los huecos se renumeran en orden de aparición: {n} del inglés → grupo correspondiente.
    let out = en;
    order.forEach((n, i) => {
      out = out.split(`{${n}}`).join(`\u0000${i + 1}\u0000`);
    });
    const p: Pattern = { re: new RegExp(`^${src}$`), out, words, litLen: lit.length };
    patterns.push(p);
    const w = words.reduce((a, b) => (b.length > a.length ? b : a));
    if (!byWord.has(w)) byWord.set(w, []);
    byWord.get(w)!.push(p);
  }
  for (const list of byWord.values()) list.sort((a, b) => b.litLen - a.litLen);
}

const cache = new Map<string, string>();

function lookupExact(core: string): string | null {
  const hit = exact.get(core);
  if (hit !== undefined) return hit;
  // La misma frase sin el punto final (a veces una plantilla se lo queda).
  const dot = exact.get(`${core}.`);
  if (dot !== undefined) return dot.replace(/\.$/, '');
  // Misma frase con otra mayúscula inicial («cámara científica» / «Cámara científica»).
  const low = lowerExact.get(core.toLowerCase());
  if (low !== undefined) {
    const lowerFirst = core[0] === core[0].toLowerCase() && core[0] !== core[0].toUpperCase();
    return lowerFirst ? low[0].toLowerCase() + low.slice(1) : low[0].toUpperCase() + low.slice(1);
  }
  return null;
}

function trPattern(core: string, depth: number): string | null {
  const words = new Set((core.match(WORD_RE) ?? []).map((w) => w.toLowerCase()));
  const candidates: Pattern[] = [];
  for (const w of words) {
    const list = byWord.get(w);
    if (list) candidates.push(...list);
  }
  candidates.sort((a, b) => b.litLen - a.litLen);
  for (const p of candidates) {
    const m = p.re.exec(core);
    if (!m) continue;
    return p.out.replace(/\u0000(\d+)\u0000/g, (_, i) => {
      const cap = m[Number(i)] ?? '';
      const t = trCore(norm(cap), depth + 1);
      return t ?? cap;
    });
  }
  return null;
}

/** Separadores, del más grande al más pequeño: oraciones, cláusulas, segmentos y listas. */
const SPLITTERS: Array<{ re: RegExp; join: (sep: string) => string }> = [
  { re: /((?<=[.!?])\s+)/, join: (x) => x },
  { re: /((?<=[:;])\s+)/, join: (x) => x },
  { re: /(\s·\s)/, join: (x) => x },
  { re: /(\s\+\s|,\s)/, join: (x) => x },
  { re: /(\sy\s)/, join: () => ' and ' },
];

function trCore(core: string, depth = 0): string | null {
  const hit = lookupExact(core);
  if (hit !== null) return hit;
  if (depth > 4) return null;
  // Varias oraciones: si todas se traducen por separado, es la traducción más fiable.
  const sentences = core.split(SPLITTERS[0].re);
  if (sentences.length >= 3) {
    const out = sentences.map((pt, i) => (i % 2 === 1 ? pt : trCore(norm(pt), depth + 1)));
    if (out.every((x) => x !== null)) return out.join('');
  }
  const pat = trPattern(core, depth);
  if (pat !== null) return pat;
  // Puntuación final: «Sensor de orientación.» → «Attitude sensor.»
  const tail = /^(.*?)([.:;,!?…]+)$/.exec(core);
  if (tail && tail[1]) {
    const t = lookupExact(tail[1]) ?? trPattern(tail[1], depth);
    if (t !== null) return t + tail[2];
  }
  // Frases compuestas: se prueba cada nivel de separación y se traducen las partes.
  for (const sp of SPLITTERS) {
    const parts = core.split(sp.re);
    if (parts.length < 3) continue;
    let any = false;
    const out = parts.map((pt, i) => {
      if (i % 2 === 1) return sp.join(pt);
      const t = trCore(norm(pt), depth + 1);
      if (t !== null) any = true;
      return t ?? pt;
    });
    if (any) return out.join('');
  }
  return null;
}

/** Traduce un texto al inglés conservando los espacios de los extremos (devuelve el original si no sabe). */
export function translate(text: string): string {
  if (!/[A-Za-zÁÉÍÓÚáéíóúñÑ¿¡]/.test(text)) return text;
  const c = cache.get(text);
  if (c !== undefined) return c;
  const m = /^(\s*)([\s\S]*?)(\s*)$/.exec(text)!;
  const t = trCore(norm(m[2]));
  const res = t === null ? text : m[1] + t + m[3];
  if (cache.size > 20000) cache.clear();
  cache.set(text, res);
  return res;
}

// ── Aplicación sobre el DOM ─────────────────────────────────────────────
const ATTRS = ['aria-label', 'title', 'placeholder', 'alt'];
const SKIP = new Set(['SCRIPT', 'STYLE', 'TEXTAREA', 'CODE']);
const origText = new WeakMap<Text, string>();
const shownText = new WeakMap<Text, string>();
const origAttr = new WeakMap<Element, Record<string, string>>();
const shownAttr = new WeakMap<Element, Record<string, string>>();

function skipNode(n: Node): boolean {
  const el = n.nodeType === 1 ? (n as Element) : n.parentElement;
  return !el || SKIP.has(el.tagName) || !!el.closest('[data-no-translate]');
}

function applyText(node: Text) {
  if (skipNode(node)) return;
  const cur = node.nodeValue ?? '';
  // Si el valor actual no es el que pusimos nosotros, React lo actualizó: es el nuevo original.
  if (shownText.get(node) !== cur) origText.set(node, cur);
  const orig = origText.get(node) ?? cur;
  const want = getLang() === 'en' ? translate(orig) : orig;
  if (want !== cur) node.nodeValue = want;
  shownText.set(node, want);
}

function applyAttrs(el: Element) {
  if (skipNode(el)) return;
  let o = origAttr.get(el);
  let s = shownAttr.get(el);
  for (const a of ATTRS) {
    const cur = el.getAttribute(a);
    if (cur === null) continue;
    if (!o) origAttr.set(el, (o = {}));
    if (!s) shownAttr.set(el, (s = {}));
    if (s[a] !== cur) o[a] = cur;
    const want = getLang() === 'en' ? translate(o[a]) : o[a];
    if (want !== cur) el.setAttribute(a, want);
    s[a] = want;
  }
}

function walk(root: Node) {
  if (root.nodeType === 3) return applyText(root as Text);
  if (root.nodeType !== 1 && root.nodeType !== 11) return;
  if (root.nodeType === 1) applyAttrs(root as Element);
  const tw = document.createTreeWalker(root, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT);
  let n = tw.nextNode();
  while (n) {
    if (n.nodeType === 3) applyText(n as Text);
    else applyAttrs(n as Element);
    n = tw.nextNode();
  }
}

let installed = false;

/** Activa la traducción en vivo de toda la página. Se llama una vez al arrancar. */
export function installTranslator(): void {
  if (installed || typeof document === 'undefined') return;
  installed = true;
  build();
  // Acceso para herramientas de verificación (comprobar qué textos quedan sin traducir).
  (window as unknown as { __nexusTranslate?: (t: string) => string }).__nexusTranslate = translate;
  document.documentElement.lang = getLang();
  const obs = new MutationObserver((records) => {
    obs.disconnect();
    for (const r of records) {
      if (r.type === 'characterData') applyText(r.target as Text);
      else if (r.type === 'attributes') applyAttrs(r.target as Element);
      else r.addedNodes.forEach((n) => walk(n));
    }
    observe();
  });
  const observe = () =>
    obs.observe(document.body, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ATTRS });
  walk(document.body);
  observe();
  subscribeLang(() => {
    obs.disconnect();
    walk(document.body);
    observe();
  });
}
