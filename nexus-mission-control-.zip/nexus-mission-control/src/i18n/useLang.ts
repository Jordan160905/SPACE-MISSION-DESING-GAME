import { useEffect, useState } from 'react';
import { getLang, subscribeLang, type Lang } from './lang';

/** Idioma actual; el componente se vuelve a dibujar cuando cambia. */
export function useLang(): Lang {
  const [lang, set] = useState(getLang());
  useEffect(() => subscribeLang(() => set(getLang())), []);
  return lang;
}
