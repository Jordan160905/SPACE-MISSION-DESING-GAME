/**
 * Idioma del juego (español / inglés). Sin dependencias de React para que el motor de simulación
 * pueda formatear números según el idioma (`numLocale`). Se recuerda en el navegador.
 */
export type Lang = 'es' | 'en';
export const LANGS: Array<{ id: Lang; label: string; name: string }> = [
  { id: 'es', label: 'ES', name: 'Español' },
  { id: 'en', label: 'EN', name: 'English' },
];
const KEY = 'nexus-lang';

function load(): Lang {
  try {
    const v = typeof localStorage !== 'undefined' ? localStorage.getItem(KEY) : null;
    return v === 'en' ? 'en' : 'es';
  } catch {
    return 'es';
  }
}

let current: Lang = load();
const listeners = new Set<() => void>();

export function getLang(): Lang {
  return current;
}

export function setLang(lang: Lang): void {
  if (lang === current) return;
  current = lang;
  try {
    localStorage.setItem(KEY, lang);
  } catch {
    /* el idioma solo no se recordará */
  }
  if (typeof document !== 'undefined') document.documentElement.lang = lang;
  listeners.forEach((l) => l());
}

export function subscribeLang(fn: () => void): () => void {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

/** Configuración regional para números y fechas: coma decimal en español, punto en inglés. */
export function numLocale(): string {
  return current === 'en' ? 'en-US' : 'es';
}
