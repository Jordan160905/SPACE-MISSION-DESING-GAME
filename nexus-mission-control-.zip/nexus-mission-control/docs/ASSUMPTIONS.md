# Supuestos, simplificaciones y recursos provisionales

## Valores de componentes
Los valores del catálogo (`src/data/components/catalog.ts`) son **de escala de juego**. Se inspiran en órdenes de magnitud de pequeños satélites científicos, pero no son especificaciones de hardware real. Lo importante es que las **relaciones** sean coherentes:
- más ganancia de antena → más datos, pero más masa y consumo, y necesita apuntamiento;
- un instrumento activo (radar) → más consumo y más datos;
- un panel más eficiente → más W por kg, pero más caro.

Simplificación explícita: el radar y la antena básica se declaran incompatibles por "compartir banda". Es una regla de juego que enseña que los sistemas de radiofrecuencia pueden interferirse, no un dato técnico concreto.

## Constructor (Fase 2)
- **Enlace:** la nave transmite por una antena a la vez, así que el enlace es el de la **mejor** antena, no la suma de todas.
- **Potencia:** el diagnóstico de la Fase 2 compara consumo y generación **a plena luz**. El balance medio por órbita (con eclipse) y la autonomía llegan en la Fase 3.
- **Propulsión obligatoria:** se considera crítica porque llegar a la órbita lunar requiere una maniobra de frenado (inserción orbital). El Δv se calculará en la Fase 4.
- **Anclajes:** pequeño 9, mediano 15, grande 22. El chasis pequeño solo tiene un anclaje inferior, por lo que propulsor y radar no caben juntos. Es un compromiso de diseño intencionado.
- Las pruebas garantizan que cada objetivo de LUNA-01 tiene al menos un diseño viable.

## Motor de simulación (Fase 3)
| Modelo | Fórmula / valor | Simplificación |
|---|---|---|
| Luna | R = 1 737,4 km, μ = 4 902,8 km³/s² | Esfera sin perturbaciones (mascons en la Fase 5 como eventos) |
| Periodo | T = 2π·√(a³/μ) | Órbita circular |
| Eclipse | fracción = asin(R/a)/π | Sombra cilíndrica, peor caso β = 0 |
| Ocultación de la Tierra | misma geometría | Peor caso |
| Estaciones terrestres | 8 h/día, un bloque continuo | Hueco de 16 h sin contacto |
| Paneles | generación × 0,9 | Pérdidas por orientación y temperatura agrupadas |
| Batería | eficiencia de carga 0,9; descarga ≤ 70 % (crítico), ≤ 40 % (recomendado) | Sin modelo de envejecimiento |
| Cargas | pasivos solo con luz; antena solo en contacto; propulsor solo en maniobras | Ciclo de trabajo 100 % (ajustable en la Fase 5) |
| Datos | enlace = mejor antena; lo que no cabe en memoria durante el hueco se pierde | Sin compresión |
| Masa | margen 10 % sobre masa seca | — |
| Operación | 0,25 MUSD/día en LUNA-01 | Escala de juego |

Validación: a 55 km el modelo da un periodo de 113,5 min, coherente con el de Lunar Reconnaissance Orbiter en su órbita de ~50 km (≈ 113 min). Todos los valores de las pruebas se calcularon de forma independiente.

## Planificación y trayectoria (Fase 4)
| Modelo | Fórmula / valor | Simplificación |
|---|---|---|
| Transferencia | directa, 4 días, llegada con v∞ = 0,8 km/s | Sin trayectorias de baja energía |
| Inserción lunar (LOI) | Δv = √(v∞² + 2μ/r) − √(μ/r) → ~815 m/s a 75 km | Una sola maniobra impulsiva |
| Mantenimiento orbital | 0,4 m/s/día a 50 km × (50/h)^1,5 | Aproximación de juego del efecto de los mascons |
| Correcciones de trayectoria | 30 m/s fijos | — |
| Δv disponible | Tsiolkovsky: Isp · g₀ · ln(m_húmeda / m_seca), Isp = 315 s (bipropelente) | Masa seca con margen del 10 % |
| Ventanas | cada 29,53 días (mes sinódico); ±1 día óptima; ±3 días marginal (+60 m/s por día); resto cerrada | Calendario de juego desde el 1-mar-2027 |
| Cobertura | fracción de superficie = sin(i) | Sin efecto de la duración en la cobertura |
| Riesgo de impacto | < 30 km: aviso | — |

Ajustes de datos de la Fase 4: tanque de propelente de 80 kg (antes 60), motor bipropelente de 315 s, y costos de lanzadores 28 / 48 / 95 MUSD. Con ellos, los tres objetivos de LUNA-01 son alcanzables. El más exigente es el radar: 115,2 de 120 MUSD con el Cóndor M, que es el único donde cabe.

## Vuelo (Fase 5)
| Modelo | Valor / regla | Simplificación |
|---|---|---|
| Paso de integración | 2 minutos | — |
| Fase orbital | iluminada si φ < 1 − f_eclipse; la Tierra se oculta en el mismo arco | Peor caso (Sol y Tierra del mismo lado) |
| Estación terrestre | primeras 8 h de cada día de campaña | Un único bloque diario |
| Instrumentos pasivos | en espera durante el eclipse (sin consumo ni datos) | Conmutación automática |
| Modo seguro | batería a 0 → instrumentos apagados; se restablecen al 60 % | Sin intervención de tierra |
| Apagón | si en modo seguro la batería sigue a 0, se cuentan las horas sin energía | Sin daños permanentes (Fase 6) |
| Llegada | propelente tras correcciones + penalización de ventana + inserción lunar (Tsiolkovsky) | Crucero de 4 días no simulado paso a paso |
| Lanzamiento | tiempos de los datos del lanzador; altitud y velocidad con curvas de juego (≈ 70 km y 2,2 km/s en MECO; 200 km y 7,8 km/s en órbita de aparcamiento; ≈ 10,9 km/s tras la TLI) | No es una integración de trayectoria |
| Meteorología | siempre GO | Indicado en la propia pantalla |

## Acontecimientos y puntuación (Fase 6)
| Acontecimiento | Efecto | Opciones (consecuencia cuantificada por previsión) |
|---|---|---|
| Caída de generación | −40 % de generación durante 48 h | Mantener · apagar instrumentos 48 h · reorientar (−15 %; con ruedas gratis, sin ruedas 8 m/s de Δv) |
| Avería de estación | 48 h sin enlace | Esperar · antena de respaldo (+1,5 MUSD, 6 h) · apagar instrumentos 48 h |
| Anomalía de instrumento | datos no fiables | Reinicio (24 h fuera) · recalibrar (−35 % batería, 4 h; exige ≥ 50 %) · modo degradado (−50 % de datos el resto) |

- Calendario: 3 acontecimientos (uno por tipo) hacia el 15 %, 42 % y 68 % de la campaña (±4 %), con orden según la semilla de la misión.
- Valor de una opción = datos al final − 0,5 × perdidos − 400 × modos seguros − 100 × MUSD − (objetivo, si no se alcanza).
- Puntuación: Ciencia 40 · Presupuesto 15 · Energía 15 · Datos 10 · Decisiones 20 (fórmulas en `ScoringSystem.ts` y visibles en el informe).
- XP: con éxito, recompensa de la misión + 3 × puntuación; sin éxito, 1,5 × puntuación. LUNA-02 se marca como desbloqueada, aunque su contenido aún está en preparación.

## Lanzadores (Fase 6)
Los Cóndor ficticios se sustituyeron por los **8 vehículos estadounidenses** de la figura 7 de *CubeSat 101* (NASA, 2017) que ya habían volado CubeSats: Super Strypi, Minotaur I, Minotaur IV, Taurus XL, Delta II, Antares, Falcon 9 y Atlas V. Los otros cuatro de la figura (Electron, Falcon 9 Heavy, LauncherOne y SLS) llevaban un * porque en 2017 solo figuraban en manifiestos de vuelos futuros. No forman parte del catálogo; se mencionan en una nota (`CUBESAT101_MANIFEST_ONLY`).

Cada vehículo separa dos bloques:
- **Datos reales** (`real`): operador, altura, diámetro, carga a órbita baja, tipo de lanzamiento, primer vuelo, estado actual, historial y fuentes. Estado verificado en noviembre de 2026:
  - En servicio: Minotaur I, Minotaur IV (8 de 8, último vuelo NROL-174 en abril de 2025) y Falcon 9 (≈ 688 misiones a septiembre de 2026).
  - Retirados: Super Strypi, Taurus XL y Delta II.
  - Atlas V: en retirada; terminó sus vuelos comerciales el 2 de julio de 2026 y quedan seis, reservados para Starliner.
  - Antares: la versión 230+ voló por última vez en 2023 y la 330 aún no ha volado.
- **Valores del juego** (simplificados y rotulados así en la interfaz):
  - Solo 2 se pueden contratar para ir a la Luna: Minotaur IV (383 kg, la masa de LADEE en su variante de cinco etapas, Minotaur V; 50 MUSD, precio publicado de 2010) y Falcon 9 (4.020 kg, su capacidad publicada hacia Marte usada como cota conservadora; 62 MUSD, precio de lista de 2020).
  - Los otros 6 se ven, se comparan y se pueden ver en 3D, pero no se pueden elegir; cada uno explica por qué.
  - Cofia útil = 90 % de las medidas publicadas.
  - Fiabilidad = (éxitos + 1) / (vuelos + 2), regla de Laplace sobre el historial real.
  - La geometría 3D es una aproximación visual.
- Los guardados antiguos migran: condor-s → Minotaur IV; condor-m y condor-h → Falcon 9.

Las dimensiones de las piezas plegadas siguen en `src/data/components/envelopes.ts`.

## Misión LUNA-01
- Presupuesto recalibrado a **140 MUSD** (Fácil 175, Difícil 119, Sandbox 1400) en la Fase 6. Los precios reales de los lanzadores (50 y 62 MUSD) son mayores que los de los Cóndor (28 y 48), y con 120 MUSD el nivel Difícil dejaba de ser alcanzable.
- Inspirada en Lunar Reconnaissance Orbiter (NASA, 2009, órbita polar baja). La escala y el presupuesto de NEXUS son ficticios.
- Los rangos de órbita recomendados son pedagógicos.

## Visualización
- **Holograma:** la órbita se dibuja a 1,4 radios lunares para que sea visible. A escala real, una altitud de 50–100 km equivale a solo un 3–6 % del radio lunar (1 737 km).
- La Tierra de fondo no está a escala ni en su posición astronómica real.

## Recursos gráficos provisionales (sustituibles)
| Recurso | Implementación actual | Sustitución prevista |
|---|---|---|
| Superficie lunar | Textura procedural (ruido + cráteres) | Mosaico lunar de dominio público de NASA en `/public/textures` |
| Tierra | Textura procedural + atmósfera Fresnel | Mapa Blue Marble (NASA, dominio público) |
| Consolas, mesa, plataforma | Geometría Three.js original | GLB definitivos |
| Chasis | Caja con manta MLI (textura de relieve arrugada), cubiertas de aluminio, largueros, 4 cuádruples de RCS, anillo de separación con abrazadera y pernos | GLB definitivos |
| Cohetes | Geometría procedural a partir de los datos del lanzador; rótulo, patrón de balanceo, túnel de cables, plataforma y torre de celosía | GLB definitivos |
| Piezas de nave | 18 geometrías procedurales diferenciadas (`scene/spacecraft/partModels.tsx`): alas solares de 1 y 3 paneles, plato parabólico con bocina, tobera de revolución, tanque esférico, rastreador estelar doble, ruedas en 3 ejes, telescopio con parasol, radar plano, radiador con persianas… | GLB definitivos (cambiar `model.kind` a `gltf`) |

## Fuentes tipográficas
Chakra Petch, IBM Plex Sans e IBM Plex Mono (Google Fonts, licencia OFL), cargadas desde CDN. Sin conexión se usan fuentes del sistema. Para la demostración conviene alojarlas localmente.

## Revisión de concepto y órbita elíptica (referencias NASA)
- **Simulador elíptico:** problema de dos cuerpos (sin mascons ni gravedad terrestre). Es una herramienta de estudio: la misión sigue volando la órbita circular del plan. El dibujo puede exagerar ×5 la altitud para que se vea la forma (se puede desactivar). Órbitas de tres cuerpos como la NRHO de CAPSTONE no se simulan.
- **Contingencia de masa por herencia:** 5 % (con herencia de vuelo), 15 % (modificado), 30 % (nuevo). Valores didácticos; las tablas reales (p. ej. AIAA S-120) dependen además del subsistema y de la fase del proyecto.
- **Riesgos 5 × 5:** la probabilidad se deriva de márgenes con umbrales didácticos (p. ej. Δv: < 5 % → 4, < 10 % → 3, < 25 % → 2). Alto si probabilidad × consecuencia ≥ 15; medio si ≥ 6.
- **CML:** las listas de los niveles 2–5 son una adaptación al juego de las del artículo de JPL (que define listas para CML 2–6). Regla del 80 % en verde más elementos clave, como recomienda el artículo («aplicar juicio de ingeniería»). Los niveles se alcanzan en orden.
- **Fin de misión:** Δv para bajar el periapsis hasta la superficie desde la órbita circular (impacto controlado); se compara con el Δv sobrante del plan.

## Dificultad, tiempo y equipo
- **Plazos de desarrollo:** 6 meses (con herencia de vuelo), 12 (modificada), 20 (nueva); integración y pruebas 6 meses + 0,25 por pieza. Valores didácticos; «CubeSat 101» da 2–12 meses de fabricación y pruebas.
- **LUNA-01:** 36 meses de desarrollo disponibles (Explorador 45, Experto 31, Sandbox 360).
- **Vida útil:** campaña + días de mantenimiento orbital que pagaría el Δv sobrante (mismo modelo de mantenimiento que el Planner).
- **Metas de los roles:** dirección (reserva ≥ 10 % y ≥ 3 meses), ciencia (datos ≥ 130 %), ingeniería (energía ≥ 20 %, descarga ≤ 40 %, Δv ≥ 15 %), operaciones (fiabilidad ≥ 97 %, sin pérdida de datos). Umbrales didácticos elegidos para que choquen entre sí.
- **Índice de coordinación:** 40 % unanimidad + 60 % votos a la mejor opción de los acontecimientos (solo unanimidad si no hubo acontecimientos).

## Vuelo físico Tierra → Luna (Fase 8.1)

**Datos reales** (`src/sim/FlightDynamics.ts`): μ Tierra = 398 600,4 km³/s², radio medio 6 371 km, día sideral 86 164,1 s; μ Luna = 4 902,8 km³/s², radio 1 737,4 km; distancia media Tierra-Luna 384 400 km; mes sideral 27,32 días; esfera de influencia lunar 66 100 km; atmósfera estándar a nivel del mar ρ₀ = 1,225 kg/m³, altura de escala 8,5 km.

**Método:** integración numérica (Runge-Kutta 4) de las leyes de Newton; cónicas enlazadas (fuera de la esfera de influencia lunar solo atrae la Tierra, dentro solo la Luna). Las pruebas comprueban la conservación de la energía en los tramos sin motor.

**Simplificaciones (juego):**
- Vuelo en un solo plano: lanzamiento desde el ecuador (la plataforma está en la costa del Amapá, Brasil, en la textura) y Luna en ese mismo plano. Por eso la órbita lunar de llegada es ecuatorial; la inclinación del plan se aplica en Operaciones.
- El catálogo no tiene empuje ni masas por etapa: la 1.ª etapa usa una relación de masas típica (3,4) y un programa de cabeceo ajustado para apagarse a una velocidad y altitud razonables (proporcionales al reparto de tiempos de combustión); la 2.ª etapa usa un guiado en lazo cerrado que llega a 200 km en el tiempo de la cronología. La aceleración del motor que muestra la telemetría sale de ese guiado, no del motor real.
- Coeficiente balístico para el arrastre: 40 000 kg/m² (valor de juego).
- La inyección translunar se ajusta para pasar por el periapsis lunar a la altitud del plan justo al acabar los 4 días de crucero del juego; la posición de la Luna al despegar la elige ese cálculo (equivale a lanzar dentro de la ventana).
- Dirección del Sol elegida para que la Luna se vea iluminada al llegar.

**Texturas:** continentes dibujados a mano con coordenadas aproximadas de las costas (`src/scene/flight/geography.ts`), mares lunares principales y cráteres con rayos (Tycho, Copérnico, Kepler, Aristarco) en posiciones selenográficas aproximadas. Son reconocibles, no cartográficas; sustituibles por mapas reales de NASA (Blue Marble, LRO) en `public/textures`.

## Sistemas y eventos del vuelo (Fases 8.2 y 8.3)

**Datos reales:** velocidad de la luz (retardo de la señal), dosis de radiación de referencia ≈ 0,5 mSv/día en órbita baja y ≈ 1,8 mSv/día en el espacio profundo (instrumento RAD de Curiosity), redes de comunicación reales (estaciones terrestres, satélites TDRS, Red de Espacio Profundo con antenas de hasta 70 m), albedo de la Luna ≈ 12 %, destellos de impacto lunar observados por la NASA.

**Valores de juego:** temperatura interior por un modelo de equilibrio simplificado (con control térmico 12–24 °C; sin él −18 a 46 °C), consumo de la nave en el cohete al 60 %, costes de cada decisión (kg, Wh, horas), número y momento de los eventos. El combustible de las etapas del cohete se muestra según el tiempo de encendido (el catálogo no tiene sus masas).

## Descubrimientos y rescate (Fases 8.4 y 8.5)

**Datos reales:** altitudes y tamaños de la Estación Espacial (≈ 415 km, 109 m) y del Hubble (≈ 520 km, 13,2 m); radios de las órbitas GPS (26 560 km) y geoestacionaria (42 164 km); periodos por la tercera ley de Kepler; coordenadas selenográficas aproximadas de las regiones lunares; ascensión recta y declinación de las estrellas de Orión, la Cruz del Sur, la Osa Mayor y Sirio, y de las nebulosas M42 y M8; datos de las fichas (fechas, distancias, tamaños) de fuentes divulgativas de la NASA.

**Simulados (y así se indica en el juego):** la basura espacial, el meteoroide y el asteroide son típicos de su clase, no objetos catalogados; el CubeSat del rescate es ficticio. Los satélites reales están en sus órbitas reales, pero su posición en la órbita en ese momento es de juego.

**Valores de juego:** puntos de cada descubrimiento, distancia de paso de meteoroides (15–75 km) y asteroides (30 000–60 000 km), aceleración de los propulsores del rescate (0,015 m/s²) y del motor principal (0,06 m/s²), velocidad de giro (15 °/s), condiciones de la asistencia (120 m, 0,3 m/s, 15°, 12 s), límites de velocidad de cada plan (regla real de los acoplamientos: más cerca, más despacio) y combustible máximo del rescate (60 % de la reserva para imprevistos, hasta 4 kg).

## Contrarreloj, aterrizaje y rover (Fases 8.6, 8.8 y 8.9)

**Datos reales:** gravedad lunar 1,62 m/s²; ausencia de atmósfera; consumo por la ecuación del cohete (ṁ = F/(Isp·g₀)); límites de contacto del orden de los de los módulos Apolo (≈ 2–3 m/s de bajada, ≈ 1 m/s de lado, ≈ 10° de inclinación); perfil de los cráteres simples (cuenco con borde levantado); polvo lunar fino y afilado por la falta de erosión.

**Valores de juego:** módulo de descenso de 1 200 kg en seco con 300 kg de combustible, 6 000 N de empuje e Isp de 320 s (orden de magnitud de un módulo robótico pequeño); altura y distancia iniciales; terreno, cráteres y rocas procedurales; rover de 4 m/s de máxima, subida de 22°, consumo y carga solar simplificados; puntos y datos de cada misión; tiempos de las situaciones contrarreloj (15–25 s) y sus efectos.

**Simulados (y así se indica):** el módulo de descenso y el rover no forman parte del diseño de la nave del LAB: son una actividad de demostración en la superficie. El terreno no es un lugar real de la Luna.

