# Estado por fases

## FASE 1: base, identidad visual, navegación y entorno 3D ✅

### Verificación realizada
| Comprobación | Resultado |
|---|---|
| 38 pruebas unitarias (datos, unidades, presupuesto, ciclo de misión, guardado, distribución 3D) | 38/38 ✅ |
| Comprobación de tipos estricta de `data/`, `sim/`, `state/` y `scene/layout` | ✅ |
| Empaquetado completo de la app (todas las importaciones resuelven) | ✅ |
| Recorrido en navegador (Chromium): tutorial → selección → misión bloqueada → briefing → objetivo → creación → pestañas → Lab → Archivo → Glosario → recarga con persistencia → 2.º intento → cargar → eliminar → guardado corrupto → vista móvil | 25/25 ✅ |

### Limitación de la verificación (importante)
El entorno donde se desarrolló esta fase no tenía acceso a npm, así que **three.js, React Three Fiber, drei, Zustand, Vite y Vitest no se pudieron instalar allí**. Se hizo lo siguiente:
- Las pruebas se ejecutaron con un intérprete compatible con la API de Vitest. Usan la misma sintaxis, así que `npm test` debería dar el mismo resultado.
- El recorrido de la interfaz se hizo con un Zustand mínimo equivalente y con la escena 3D sustituida por un fondo.
- **La escena 3D (Three.js/R3F) no se ha ejecutado todavía.** El código usa la API estándar de R3F v9 y drei v10. La primera tarea al abrir el proyecto es `npm install && npm run dev` y comprobar la escena.

### Lista de comprobación al instalar
1. `npm install`, luego `npm test` y `npm run typecheck`.
2. `npm run dev`: la sala de mando se ve, el holograma lunar gira y la órbita es polar.
3. Al pasar el cursor por el holograma o las consolas aparece una etiqueta y el cursor cambia a mano. Al hacer clic, se navega.
4. Al cambiar de sección, la cámara se desplaza hacia la consola correspondiente.
5. La órbita del holograma usa el punto medio de la inclinación recomendada del objetivo activo. Los tres objetivos de LUNA-01 son polares (unos 90°).

## FASE 2: constructor modular 3D ✅

### Qué incluye
- **Distribución:** catálogo a la izquierda, escena 3D en el centro y propiedades y estadísticas a la derecha.
- **Colocar piezas:** arrastrar y soltar con el ratón; clic para elegir pieza y clic en un anclaje verde; o una lista accesible de anclajes compatibles. Los anclajes incompatibles se ven en rojo y, al pasar el cursor, explican el motivo.
- **Editar la nave:** rotar y acercar la cámara (OrbitControls), seleccionar piezas (en 3D o desde la lista), moverlas, eliminarlas (botón o Supr), Esc para cancelar, cambiar de chasis (las piezas se conservan, se reubican o se retiran con aviso) y vista interna (rayos X) de las bahías.
- **Ingeniería en vivo:** masa húmeda, costo frente al presupuesto, potencia, batería, datos y enlace.
- **Diagnóstico:** separa problemas *críticos* de *optimizaciones*, cada uno con su explicación educativa. Al hacer clic en un problema se selecciona la pieza afectada, que también se marca en rojo en 3D.
- **Guardado:** *Guardar* y *Descartar*; el diseño guardado se refleja en Progreso, Presupuesto y Archivo. Sin misión, el Lab funciona en modo libre, sin guardado.

### Verificación realizada
| Comprobación | Resultado |
|---|---|
| Pruebas unitarias (Fase 1 + reglas de diseño + jugabilidad de los 3 objetivos) | 61/61 ✅ |
| Comprobación de tipos de **toda** la app, interfaz y escenas incluidas (con declaraciones mínimas de React/three) | ✅ |
| Recorrido del constructor en navegador (instalar chasis, anclajes por tipo, requisito → corrección → 0 críticos, totales exactos, guardar, mover, Supr, descartar, Progreso/Presupuesto/Archivo, recarga, cambio de chasis, incompatibilidad, modo libre) | 31/31 ✅ |
| Regresión de la Fase 1 | 25/25 ✅ |

### Limitación de la verificación
Como en la Fase 1, three.js, R3F y drei no se pudieron instalar en el entorno de desarrollo. **La escena 3D del Lab (modelos, anclajes, arrastre sobre el canvas, contornos) no se ha ejecutado.** Toda la lógica que la alimenta sí está probada.

### Lista de comprobación al instalar
1. `npm install`, luego `npm test` (deberían pasar 61) y `npm run typecheck`.
2. Crea una misión y abre el Lab: se ve el hangar con la cuna; la cámara rota con arrastre y hace zoom con la rueda.
3. Clic en *Chasis mediano*: aparece la caja dorada con anillos (anclajes) en sus caras.
4. Arrastra *Panel solar avanzado* hacia la nave: los anclajes laterales se ponen verdes y los demás rojos. Al soltar sobre uno verde, el ala solar aparece orientada hacia fuera.
5. Arma *Batería avanzada*: el chasis se vuelve translúcido y aparecen las bahías internas.
6. Clic en una pieza: contorno cian. Con un requisito sin cumplir, la pieza tiene contorno rojo.

## Mejora visual (entre las Fases 2 y 3) ✅
- **Nave:** mantas térmicas multicapa con relieve arrugado y rugosidad variable, cubiertas de aluminio, propulsores RCS en las esquinas, anillo de separación con abrazadera, paneles solares con bisagras, cara trasera, marco y yugo, y **configuración plegada** para el lanzamiento.
- **Vista del cohete** (botón *Cohete* del Lab): lanzadores Cóndor S, M y H. Incluye racimo de motores con escudo térmico, sección de empuje, patrón de balanceo, túnel de cables, rótulo, interetapa de carbono, motor de vacío, segunda etapa, adaptador de carga, tu nave plegada y cofia en dos mitades (*Cerrada / Corte / Abierta*). Tiene **vista explosionada** con etiquetas de cada componente, plataforma con foso de llamas y torre de servicio. Indica si tu nave cabe en la cofia y si su masa cabe en el lanzador.

## FASE 3: motor de simulación y validaciones ✅

### Qué incluye
- Motor con módulos independientes y unidades consistentes: `OrbitSystem`, `PowerSystem`, `DataSystem` (+ comunicaciones), `MassSystem`, `EnvelopeSystem`, `BudgetSystem` y `EngineeringAnalysis`.
- **Engineering Analysis** (pestaña *Análisis* del Lab): veredicto, problemas críticos y de optimización, y bloques de Órbita, Energía, Datos, Masa y Presupuesto, cada uno con su desplegable *¿Cómo se calcula?*.
- **Aprobación del diseño** (en el Lab o en el Progreso del Mission Center): solo si el diseño guardado no tiene críticos; pasa la misión a Planificación. Si luego se cambia el diseño, la misión vuelve a Diseño.
- El presupuesto incluye la operación (60 días × 0,25 MUSD) en todas las pantallas.

### Verificación realizada
| Comprobación | Resultado |
|---|---|
| Pruebas unitarias, con valores del motor calculados de forma independiente | 89/89 ✅ |
| Jugabilidad: un diseño viable por cada objetivo de LUNA-01 con el análisis completo | ✅ |
| Comprobación de tipos de toda la app | ✅ |
| Navegador, Fase 3 + vista del cohete (cofia, explosionada, ajuste de cofia, no viable → viable, cifras, aprobación, re-aprobación) | 26/26 ✅ |
| Regresión Fase 1 / Fase 2 | 25/25 ✅ · 31/31 ✅ |

### Limitación de la verificación
Sin three.js en el entorno de desarrollo, **los modelos 3D nuevos (nave mejorada y cohete) no se han visto renderizados**. Su geometría (apilado de etapas, racimo de motores sin solapes, motor de vacío dentro de la interetapa, ajuste en la cofia) está comprobada por pruebas.

### Lista de comprobación al instalar
1. En el Lab, la manta dorada debe verse arrugada y metálica, no lisa.
2. Pulsa *Cohete*: el cohete debe verse completo sobre la plataforma, con la torre a un lado.
3. *Corte*: la mitad derecha de la cofia es translúcida y deja ver tu nave plegada sobre el adaptador.
4. *Vista explosionada*: las piezas se separan verticalmente con etiquetas a la derecha.
5. Cambia a Cóndor H: aparecen los dos propulsores laterales.

## FASE 4: Mission Planner ✅

### Qué incluye
- Pantalla **Planner** (barra lateral, o desde el Progreso del Mission Center). Se desbloquea al aprobar el diseño y propone un plan por defecto: el lanzador más barato que puede llevar la nave, la órbita recomendada y la primera ventana óptima.
- **Decisiones:** lanzador (con indicación de si la masa y la cofia valen), altitud de 20 a 300 km, inclinación de 0 a 90° (con cobertura y explicación educativa del tipo de órbita), duración de 30 a 120 días y día de lanzamiento en un calendario de 60 días (óptima, marginal o cerrada).
- **Verificaciones en vivo:** masa, cofia, Δv, ventana, energía en *esta* órbita, datos del objetivo en *esta* duración y presupuesto total. Incluye un presupuesto de Δv desglosado (inserción, mantenimiento, correcciones, penalización) frente al disponible.
- **Confirmar plan → Lanzamiento.** Cambiar un plan confirmado obliga a reconfirmarlo. El holograma del Mission Center muestra la altitud y la inclinación elegidas.

### Nota sobre el desarrollo
Un primer intento de esta fase se interrumpió por un reinicio del entorno de trabajo. Al retomarla se encontró su código, se revisó, se eliminaron las duplicaciones que provocó el segundo intento y se completó: pruebas de navegador, corrección de coherencia (D-19), umbral de órbita ecuatorial y documentación.

### Verificación realizada
| Comprobación | Resultado |
|---|---|
| Pruebas unitarias (incluidas trayectoria, ventanas, cobertura, planes viables y no viables, y coherencia del análisis con el plan) | 109/109 ✅ |
| Comprobación de tipos de toda la app | ✅ |
| Navegador, Mission Planner (bloqueo previo, plan por defecto, 7 verificaciones, lanzador caro, ventana cerrada/marginal, cobertura, altitud → eclipse, confirmar, persistencia, reconfirmar, presupuesto coherente) | 27/27 ✅ |
| Regresión Fases 1 / 2 / 3 | 25/25 ✅ · 31/31 ✅ · 26/26 ✅ |

## FASE 5: lanzamiento y operaciones ✅

### Qué incluye
- **Pantalla Vuelo** (barra lateral). Se desbloquea al confirmar el plan.
- **Launch Control:**
  - Verificación previa con cinco responsables (Vehículo, Trayectoria, Nave, Presupuesto, Meteorología) que dan GO o NO-GO a partir del análisis real.
  - Cuenta regresiva de 10 s, que se puede abortar.
  - Lanzamiento en 3D del cohete elegido con **tu nave dentro**: chorros de motor, separación de propulsores laterales y etapas, apertura y descarte de la cofia, el cielo que se oscurece con la altitud, la separación de la nave y el despliegue de sus paneles.
  - Cronología con tiempos T+, telemetría de altitud y velocidad, aceleración ×1/×10/×30/×60, pausa y "siguiente evento".
- **Llegada:** 4 días de crucero y la inserción en órbita lunar, que consume propelente según Tsiolkovsky.
- **Operaciones:**
  - Vista 3D de la Luna con tu órbita, el arco de eclipse en rojo y tu nave en la posición que dicta la simulación. Una línea marca el enlace cuando hay contacto con la Tierra.
  - Consola con energía (batería, generación, consumo, luz o eclipse), comunicaciones y datos (contacto, memoria, perdidos), instrumentos con interruptor y propulsión (propelente y Δv restante).
  - Control del tiempo (+1 órbita, +6 h, +1 día, +1 semana, reproducción continua), progreso científico, gráficos de batería y memoria, y registro de la misión.
  - Modo seguro automático si se agota la batería.
- Con la nave en vuelo, el diseño y el plan quedan bloqueados. Al terminar la campaña, la misión pasa a **Informe**.

### Verificación realizada
| Comprobación | Resultado |
|---|---|
| Pruebas unitarias: conservación de datos y batería, mismo resultado en 1 o en 24 pasos, coincidencia con el análisis (±3 %), modo seguro y recuperación, propelente, fin de campaña, cronología de los 3 lanzadores, perfil de ascenso, separaciones visuales y geometría de sombra frente al simulador | 135/135 ✅ |
| Comprobación de tipos de toda la app | ✅ |
| Navegador, flujo completo de crear a completar la campaña (bloqueo, 5 GO, cuenta regresiva, abortar, despegue, cronología, inserción, avanzar, datos día 1 = 88 + 175 en memoria, interruptor, gráficos, plan bloqueado en vuelo, persistencia tras recargar, fin de campaña) | 26/26 ✅ |
| Regresión Fases 1–4 | 25 · 31 · 26 · 27 ✅ |

**Errores encontrados y corregidos:** bucle infinito de renders al recargar en operaciones (D-24), mutación del historial de telemetría, avisos que tapaban el reloj de vuelo.

### Lista de comprobación al instalar (3D)
1. Vuelo → cuenta regresiva: el cohete despega con chorro naranja, la plataforma se aleja y el cielo pasa de azul a negro.
2. En la separación de etapas, la primera etapa cae; con el Cóndor H, los propulsores laterales se separan antes.
3. La cofia se abre en dos mitades y deja ver tu nave plegada; al final la nave queda sola y despliega los paneles.
4. En Operaciones, la nave recorre la órbita: el marcador se pone rojo en el arco de eclipse y aparece la línea de enlace cuando hay contacto.

## Pantalla de trayectoria (petición tras la Fase 5) ✅
Mini mapa Tierra–Luna, esquemático y no a escala, en Launch Control y en Operaciones. Muestra el ascenso, la órbita de aparcamiento, la inyección translunar, el **crucero animado de 4 días** con la distancia a la Tierra, y la nave girando en órbita lunar con la línea de enlace cuando hay contacto. El reloj de misión y la telemetría usan el mismo tiempo que el mapa.

## FASE 6: acontecimientos dinámicos e informe final ✅

### Qué incluye
- **Tres acontecimientos por campaña** (caída de generación, avería de la estación, anomalía del instrumento) que pausan la simulación y modifican su estado real.
- **Panel de decisión:** qué pasó, por qué importa (relación de ingeniería) y 3 opciones con su **previsión simulada** hasta el final de la campaña (datos que llegarán frente al objetivo, datos perdidos, batería mínima, modo seguro, propelente y costo). Las opciones dependen de la nave: ruedas de reacción, batería disponible y presupuesto restante.
- Los efectos activos se ven en la consola, y todo queda en el registro.
- **Mission Debrief:**
  - puntuación de 0 a 100 con 5 criterios explicados y una nota de S a D;
  - objetivos y resultados científicos, datos y comunicaciones, energía, masa, recursos y presupuesto (con los costos de los acontecimientos);
  - acontecimientos vividos con la decisión tomada y su calidad;
  - decisiones acertadas, errores de diseño y de operación, y recomendaciones, cada una con su porqué.
- **Archivar** suma la XP al perfil y desbloquea la siguiente misión si hubo éxito. **Nuevo intento** permite copiar el diseño, modificarlo y volver a volar, o empezar desde cero.

### Verificación realizada
| Comprobación | Resultado |
|---|---|
| Pruebas unitarias (calendario, pausa, opciones según diseño, efectos reales y su fin, previsiones, campaña con 3 acontecimientos, puntuación por criterio, éxito frente a puntuación, informe con porqués, mini mapa sin saltos) | 155/155 ✅ |
| Comprobación de tipos de toda la app | ✅ |
| Navegador, Fase 6 (pausa, 3 opciones con previsión, tiempo bloqueado, 3 decisiones distintas, informe, puntuación 97 S, costos, archivar → XP, nuevo intento con el diseño copiado, LUNA-02 desbloqueada) | 27/27 ✅ |
| Regresión Fases 1–5 (incluido el crucero animado) | 25 · 31 · 26 · 27 · 29 ✅ |

**Errores encontrados y corregidos:** el panel de decisión no recibía clics (D-28), el panel dejaba ver el fondo a través, y durante el crucero el reloj y la telemetría no coincidían con el mapa.

## CRITERIOS DE ACEPTACIÓN DEL MVP (documento del proyecto, §11)
| # | Criterio | Dónde se demuestra (prueba de navegador) |
|---|---|---|
| 1 | Iniciar una nueva misión | e2e: «LUNA-01 abre briefing» |
| 2 | Seleccionar el objetivo científico | e2e: «aceptar deshabilitado sin objetivo» → elegir |
| 3 | Construir una nave 3D modular | e2e2: chasis, anclajes, colocar, mover, eliminar |
| 4 | Incorporar instrumentos | e2e2: «la cámara suma 18 Gbit/h» |
| 5 | Ver cambios reales en las estadísticas | e2e2: masa, potencia, costo y enlace exactos |
| 6 | Detectar y corregir incompatibilidades | e2e2: requisito → corrección → 0 críticos; radar/antena |
| 7 | Seleccionar un lanzador | e2e4: lanzador, masa, cofia, presupuesto |
| 8 | Configurar el destino orbital | e2e4: altitud, inclinación, cobertura, eclipse |
| 9 | Validar la viabilidad | e2e3/e2e4: aprobación y confirmación bloqueadas con críticos |
| 10 | Ejecutar el lanzamiento | e2e5: GO/NO-GO, cuenta regresiva, secuencia completa |
| 11 | Ver la nave construida en el espacio | LaunchScene/OpsScene usan el `SpacecraftModel` del jugador (comprobación visual pendiente en tu equipo) |
| 12 | Operar sus sistemas | e2e5: instrumentos, tiempo, telemetría |
| 13 | Resolver acontecimientos inesperados | e2e6: 3 acontecimientos con decisiones |
| 14 | Completar experimentos científicos | e2e5/e2e6: objetivo alcanzado |
| 15 | Transmitir los datos | e2e5: datos día 1 = enlace + memoria |
| 16 | Consultar el informe de resultados | e2e6: debrief completo |
| 17 | Modificar el diseño y volver a ejecutar | e2e6: «el diseño se copió» → intento 2 en el Lab |

## Integración de referencias técnicas de NASA (petición entre las Fases 6 y 7) ✅

| Recurso | Qué se incorporó al juego |
|---|---|
| *Design and Develop Science Missions* | **Matriz de Trazabilidad Científica** (Revisión → Trazabilidad): medición → requisito del instrumento → requisito de misión → previsto → método de verificación (análisis, inspección, demostración). Ciclo de vida por fases con sus revisiones. |
| *Concept Maturity Levels* (JPL, 13-3547) | Pestaña **Madurez (CML)**: escala 1–9, listas de verificación de los niveles 2–5 por área (ciencia, técnica, gestión, costo, otros) en verde, amarillo o rojo, regla del 80 % y elementos clave que bloquean el nivel. Los niveles 6–9 aparecen marcados como fuera del alcance del juego. El nivel 3 mide lo que el jugador **explora de verdad**: lanzadores, órbitas y duraciones probados en el Planner (`mission.trades`). |
| *Mission Design Lab* (NASA GSFC) | **Master Equipment List** con contingencia de masa según la herencia de vuelo de cada pieza (nuevo campo `heritage`), comparada con el margen plano del 10 %. **Matriz de riesgos 5 × 5** a partir de los márgenes calculados, con mitigaciones. **Plan de fin de misión**: Δv de impacto controlado. |
| *GMAT* | Órbitas descritas por **elementos keplerianos** (a, e) y resueltas con la ecuación de Kepler (Newton con arranque de Murison). |
| *NASA Mission Viz · Elliptical Orbit Simulator* | **Simulador de órbita elíptica** en el Planner: periapsis y apoapsis, animación con la 2.ª ley de Kepler, línea de tiempo, velocidad vis-viva, fracción de órbita útil y órbitas de misiones reales (LRO, Lunar Prospector, LADEE). |
| *Webb · Build It Yourself* | El **catálogo del Lab avisa antes de elegir** una pieza que no encaja (falta chasis, incompatible, sin anclaje libre, requiere otra pieza) y explica el porqué. El informe final muestra **misiones reales parecidas** con su fuente. |
| *CubeSat 101* (NASA CSLI) | Escala CubeSat (1U = cubo de 10 cm, 1–1,33 kg) en la MEL; **ruta CubeSat** con los plazos típicos de cada paso en el ciclo de vida; CAPSTONE como ejemplo de CubeSat lunar; glosario (CubeSat, dispensador P-POD). |

Glosario: +10 términos (CML, STM, MEL, matriz de riesgos, revisiones, órbita elíptica, ecuación de Kepler, CubeSat, dispensador, fin de misión). Los datos de misiones reales se verificaron en fuentes públicas (enlaces en `src/data/realMissions.ts` y en la interfaz).

### Verificación realizada
| Prueba | Resultado |
|---|---|
| Pruebas unitarias (`src/sim/nasa.test.ts`: Kepler, vis-viva, fracción bajo altitud, Δv de fin de misión, STM, MEL, riesgos, CML, registro de compromisos, asesor del catálogo) | 172/172 en total ✅ |
| e2e7 (navegador): CML 1 → 2 → 4, avisos del catálogo, simulador elíptico (preset LRO 30 × 216 km: 1,707 km/s en el periapsis, 216 km a mitad del periodo, animación), 5 pestañas de la revisión, glosario, móvil | 22/22 ✅ |
| Regresión e2e 1–6 | 25 · 31 · 26 · 27 · 29 · 29 ✅ (e2e1 solo registra el bloqueo de Google Fonts del entorno de pruebas) |

## Requisitos del reto NASA (entrega A de 2) ✅

Comparación de la lista del reto con lo que ya existía y lo añadido en esta entrega:

| Requisito del reto | Estado |
|---|---|
| Componentes (estructura, energía, baterías, comunicaciones, computadora, actitud, instrumentos) | Ya existía (18 componentes) |
| Instrumentos con masa, energía, costo, datos **y valor científico** | Añadido `scienceValue` (1–5) visible en catálogo e inspector |
| Componentes simples o avanzados según la dificultad | **Nuevo**: dificultades Explorador (solo gama simple), Ingeniero, Experto y **Sandbox**. Probado que cada objetivo es alcanzable en Explorador. |
| Opciones orbitales explicadas; efecto en cobertura, comunicaciones y vida útil | Ya existía; añadida la **vida útil estimada** en el recurso Tiempo |
| Lanzadores con capacidad, costo y verificación de masa y órbita | Ya existía (masa, cofia, Δv por órbita) |
| Recursos claros: masa, energía, presupuesto, datos, comunicaciones, **tiempo** | **Nuevo**: panel de 6 recursos (Planner y Revisión) y recurso **Tiempo** (camino crítico de desarrollo + integración y pruebas frente a los meses disponibles, con problema crítico si no llega) |
| Identificar los recursos más críticos de cada misión | **Nuevo**: los dos de menor margen se destacan con su explicación |
| Modo equipo hasta 4, roles, decisiones colectivas, negociación, resultado según la coordinación | **Nuevo** (misma computadora): 4 roles con metas que chocan, votaciones para aprobar el diseño, confirmar el plan y responder a cada acontecimiento; empate → dirección; índice de coordinación en el informe |
| Valor educativo, explicaciones sencillas, «por qué» | Ya existía; cada recurso explica qué es y por qué importa con los números de la misión; +3 términos de glosario |
| Eventos inesperados, informe final, análisis de éxito/fracaso | Ya existía |
| Clasificación, escenarios competitivos | **Nuevo**: clasificación local por objetivo (los equipos compiten por el mismo objetivo) |
| Guardar, compartir y comparar diseños | **Nuevo**: código `NEXUS1.` para compartir/importar (validado con Zod) y comparación lado a lado |
| Modo sandbox | **Nuevo** (dificultad Sandbox: sin acontecimientos, sin XP ni clasificación) |
| Múltiples escenarios / tipos de viaje (flyby, orbitador, aterrizador, rover, retorno de muestras) | **Pendiente: entrega B** (todo en la Luna) |

### Verificación realizada
| Prueba | Resultado |
|---|---|
| Unitarias (`nasa2.test.ts`: dificultades, viabilidad en Explorador, calendario, vida útil, recursos y críticos, votos y coordinación, códigos) | 186/186 en total ✅ |
| e2e8 (navegador): dificultad, equipo de 3 con roles, votación que rechaza y luego aprueba, plan por unanimidad, 3 acontecimientos votados, coordinación en el informe, clasificación, compartir → importar, comparar, código dañado, sandbox | 28/28 ✅ |
| Regresión e2e 1–7 | 25 · 31 · 26 · 27 · 29 · 29 · 23 ✅ |

## Mejora de experiencia — Fase 1: nueva misión guiada ✅

Se aplica solo la Fase 1 del documento «Mejora de experiencia de usuario y flujo de juego». Las fases 2 a 7 (botón al LAB, LAB simplificado, pantalla de análisis, navegación, lanzadores reales, rediseño general) se harán una por una; el resto del juego sigue exactamente como estaba.

| Qué pide la Fase 1 | Qué se hizo |
|---|---|
| Flujo en pasos: Escenario, Modo de juego, Dificultad, Objetivo, Restricciones, Recompensas | Asistente de 6 pasos con indicador de progreso, botones *← Volver* / *Siguiente →* y transición animada en ambas direcciones |
| No continuar sin elegir modo | *Siguiente* desactivado hasta elegir modo (individual o equipo con roles válidos) y dificultad |
| Fácil / Intermedio / Difícil que cambian parámetros reales | Las tarjetas muestran presupuesto, meses de desarrollo, datos exigidos y piezas permitidas calculados con `applyDifficulty`; Sandbox aparte como «Modo libre» |
| Objetivo con glosario interactivo (también táctil) | Términos subrayados con definición sencilla al pasar el cursor, con el teclado o al tocar; enlace al glosario completo |
| Restricciones solo con valores reales | Presupuesto, lanzadores Cóndor (capacidad y costo), energía (eclipse calculado), comunicación, órbita, instrumento, datos y tiempo, todos de la plantilla de la misión |
| Recompensas solo de la progresión existente | XP base, XP por punto (misma tabla que la puntuación), calificaciones S–D, desbloqueo y clasificación |
| «Comenzar diseño» | Crea la misión y deja al jugador en el Centro, etapa Diseño (igual que el antiguo «Aceptar misión») |

Las dificultades pasan a llamarse **Fácil / Intermedio / Difícil** en todo el juego (Archivo, Revisión, Informe); cada una conserva su rol (Explorador, Ingeniero, Experto).

### Verificación realizada
| Prueba | Resultado |
|---|---|
| Unitarias (nuevo `wizard.test.ts`: glosario, dificultades, recompensas) | 193/193 ✅ |
| TypeScript | sin errores ✅ |
| e2e-f1 (asistente completo, tooltips con cursor/clic/toque, volver conserva lo elegido, móvil táctil) | 17/17 ✅ |
| Regresión e2e 1–8 con el asistente nuevo | 22 · 31 · 26 · 27 · 29 · 28 · 23 · 29 ✅ (e2e1: el único aviso es la fuente de Google bloqueada por la red del entorno) |

## Mejora de experiencia — Fase 2: del Diseño al LAB ✅

| Qué pide la Fase 2 | Qué se hizo |
|---|---|
| Botón «Siguiente: Construir nave» en la pantalla de Diseño que lleve al LAB | Mientras la misión está en Diseño, el Centro muestra «Siguiente: Construir nave →» destacado (con brillo suave) en la portada y en la pestaña Progreso del expediente; lleva al Spacecraft Lab sin cambiar la etapa ni el diseño guardado |
| No cambiar el resto | En las demás etapas el Centro conserva su botón «Spacecraft Lab» de siempre; la aprobación del diseño sigue igual |

En móvil, la tarjeta del expediente ya cubría la portada en la versión anterior; allí el botón se usa desde la pestaña Progreso. Reordenar la portada en móvil queda para la Fase 7 (interfaz).

### Verificación realizada
| Prueba | Resultado |
|---|---|
| e2e-f2 (botón en portada y Progreso, lleva al LAB, conserva el diseño al ir y volver, desaparece fuera de Diseño, móvil táctil) | 13/13 ✅ |
| Unitarias · TypeScript | 193/193 ✅ · sin errores ✅ |
| Regresión e2e-f1 y e2e 1–8 | 17 · 22 · 31 · 26 · 27 · 29 · 28 · 23 · 29 ✅ (e2e1: solo el aviso de la fuente de Google bloqueada por la red del entorno) |

## Mejora de experiencia — Fase 3: LAB guiado ✅

El catálogo conserva su estructura (categorías, tarjetas, clic o arrastre, avisos del asesor). Toda la lógica técnica sigue en el análisis de ingeniería existente: `sim/LabGuidance.ts` solo lo interpreta, así que no hay validaciones duplicadas ni comprobaciones solo visuales.

| Qué pide la Fase 3 | Qué se hizo |
|---|---|
| 3.1 Mano animada | Sale de la primera pieza del catálogo, la lleva al área de construcción y la suelta. Se repite hasta 3 veces mientras no se toque nada y desaparece al tocar, arrastrar o usar el teclado. Vuelve a salir al entrar al LAB hasta que se coloca la primera pieza (`profile.labHintSeen`). En pantallas táctiles enseña «tocar la pieza y luego el anclaje». Se puede repetir con «¿Cómo se construye?». Mensaje: «¡Construye tu nave! Arrastra los componentes del catálogo hacia el área de construcción para comenzar». |
| 3.2 Columna derecha simplificada | Pestaña **Construcción**: estado general, parámetros críticos, recursos (presupuesto disponible, masa total frente a cada lanzador, generación frente a consumo con descarga de batería), cumplimiento de restricciones, problemas y componentes instalados con su estado. Lo técnico completo queda en «Detalles técnicos» y en la pestaña **Análisis**, que no cambia. |
| 3.3 Parámetros interactivos | Masa, Presupuesto, Energía, Comunicaciones, Propulsión e Instrumento con tres estados: **Correcto**, **Falta** (todavía no está la pieza que lo resuelve) e **Incumple** (las piezas están, pero los números violan una restricción). Al pulsar uno se abre su categoría con las piezas que lo resuelven marcadas. Se conservan la selección, la vista interna y la cámara. |
| 3.4 Validación inteligente | Se recalcula al añadir, quitar o mover piezas. Sin problemas críticos aparece «¡Diseño listo! Has cumplido los requisitos de construcción de esta misión» y se habilita «Siguiente: Analizar diseño», que guarda y abre el análisis. Si no se cumple, el botón queda desactivado y se indica el siguiente paso. Cada problema explica **por qué** y **cómo**, y trae «Solucionar problema → categoría». |

Desde la Fase 4, «Siguiente: Analizar diseño» guarda el diseño y abre la pantalla de análisis y aprobación.

### Verificación realizada
| Prueba | Resultado |
|---|---|
| Unitarias (`labGuidance.test.ts`: estados con piezas reales, energía que incumple con radar de 180 W y panel de 150 W, «Solucionar problema» para cada problema, restricciones) | 204/204 ✅ |
| TypeScript | sin errores ✅ |
| e2e-f3 (mano: aparece, se repite, desaparece al tocar o arrastrar y sola tras enseñar; parámetros; foco del catálogo sin perder contexto; diseño que incumple; diseño listo; analizar → aprobar; conserva el diseño; móvil táctil) | 51/51 ✅ |
| Regresión e2e-f1, e2e-f2 y e2e 1–8 | 17 · 13 · 22 · 31 · 26 · 27 · 29 · 28 · 23 · 29 ✅ (e2e1: solo el aviso de la fuente de Google bloqueada por la red del entorno) |

## Mejora de experiencia — Fase 4: análisis y aprobación del diseño ✅

| Qué pide la Fase 4 | Qué se hizo |
|---|---|
| «Siguiente: Analizar diseño» abre la sección de análisis | Pantalla nueva `AnalysisScreen`. El LAB guarda el diseño antes de abrirla (`labGoAnalyze`). |
| Vista 3D de la nave | La escena del LAB sigue de fondo, desplazada a la izquierda; el análisis ocupa la derecha. |
| Masa, presupuesto, consumo y capacidad energética, comunicaciones, instrumentos, propulsión, restricciones, estado general | Tarjetas con barras frente al límite: masa frente a cada lanzador; presupuesto por partidas (nave, operación y lanzador, estimado con el más barato capaz si aún no hay plan); consumo frente a generación; descarga de batería frente al 70 %; datos que llegarán frente a los exigidos; instrumentos con su valor científico; Δv por Tsiolkovsky con el Isp del motor instalado; restricciones obligatorias y recomendadas. El estado general es un indicador circular de los 6 parámetros. |
| Evaluación de viabilidad | La misma del juego (`analyzeEngineering` interpretada por `LabGuidance`). Si se cumplen todas las restricciones obligatorias se muestra «DISEÑO APROBADO»; si no, «NO APROBADO» y la lista de aspectos a corregir. |
| Regresar directamente al LAB | «← Volver al LAB», y en cada aspecto «Solucionar en el LAB → categoría», que abre la categoría con las piezas marcadas. |
| «Continuar con la planificación de lanzamiento» → PLANNER | Botón destacado. Aprueba el diseño (con votación si se juega en equipo) y abre el Planner. Si ya estaba aprobado, va directo. |

La aprobación ocurre solo en esta pantalla. El Centro («Analizar y aprobar el diseño →») y la pestaña Análisis del LAB llevan a ella. Si el LAB tiene cambios sin guardar, la pantalla lo avisa y no deja continuar hasta guardarlos.

### Verificación realizada
| Prueba | Resultado |
|---|---|
| e2e-f4 (no aprobado con aspectos a corregir → LAB en la categoría correcta; aprobado con las 8 tarjetas; masa igual a la del LAB; usado + libre = tope; Δv comprobado con Isp·g₀·ln(húmeda/seca); cambios sin guardar; continuar → Planner; ya aprobado sin volver a votar; móvil) | 36/36 ✅ |
| Unitarias · TypeScript | 204/204 ✅ · sin errores ✅ |
| Regresión e2e-f1 a e2e-f3 y e2e 1–8 (la votación en equipo ahora ocurre en la pantalla de análisis) | 17 · 13 · 51 · 22 · 31 · 28 · 27 · 29 · 28 · 23 · 30 ✅ (e2e1: solo el aviso de la fuente de Google bloqueada por la red del entorno) |
| Nave 3D en la pantalla de análisis | ⚠️ No verificable aquí (sin WebGL): revisar en un equipo real |

## Mejora de experiencia — Fase 6: catálogo de vehículos de lanzamiento ✅

| Qué pide la Fase 6 | Qué se hizo |
|---|---|
| Sustituir el catálogo por los 8 vehículos de la imagen | Super Strypi, Minotaur I, Minotaur IV, Taurus XL, Delta II, Antares, Falcon 9 y Atlas V, con datos reales y fuentes |
| Distinguir los que volaron CubeSats de los que solo estaban en manifiestos | Los 8 del catálogo ya los habían volado en 2017. Una nota explica que los 4 marcados con * (Electron, Falcon 9 Heavy, LauncherOne, SLS) solo estaban en manifiestos y por eso no se incluyen. |
| No presentar todos como operativos | Cada tarjeta muestra el estado actual: 3 en servicio, 3 retirados, 1 en retirada y 1 con nueva versión en desarrollo |
| Tarjeta: nombre, imagen o 3D, altura, carga útil, tipo de lanzamiento, información y compatibilidad | Silueta a escala, todos esos datos y el resultado de compatibilidad. «Ver en 3D» abre el cohete en la vista de integración del LAB. |
| Al seleccionar, ver características y compararlas con las restricciones | La ficha incluye una tabla misión frente a vehículo con 5 requisitos (disponibilidad, órbita requerida, masa, capacidad de la cofia y presupuesto), los datos reales, los valores del juego y las fuentes |
| No permitir seleccionar un incompatible sin explicación | La tarjeta queda desactivada con «No seleccionable: motivo», y el estado del juego también lo rechaza |
| No inventar especificaciones | Datos verificados con fuentes; los valores del juego están rotulados y explicados (`gameNote`) |
| Planner por ventanas | 1 Vehículo + recursos · 2 Órbita lunar + simulador · 3 Ventana de lanzamiento · 4 Verificaciones, Δv y problemas, con estado en cada pestaña y «Anterior / Siguiente» |

### Verificación realizada
| Prueba | Resultado |
|---|---|
| Unitarias (catálogo de 8, estados, Laplace, migración Cóndor → reales, compatibilidad con 5 requisitos, plan y presupuesto) | 219/219 ✅ |
| TypeScript | sin errores ✅ |
| e2e-f6 (8 tarjetas y su contenido, 6 no seleccionables con motivo, ficha comparativa, datos reales y del juego, fuentes, «Ver en 3D», 4 ventanas con navegación, confirmar, móvil) | 31/31 ✅ |
| Regresión e2e-f1 a e2e-f4 y e2e 1–8 | todas ✅ (e2e1: solo el aviso de la fuente de Google bloqueada por la red del entorno) |
| Cohetes en 3D | ⚠️ No verificable aquí (sin WebGL): revisar en un equipo real |

## Corrección de la Fase 6 e idioma del juego ✅

| Pedido | Qué se hizo |
|---|---|
| «Ver en el cohete»: que solo se vea el cohete | La información y los controles (vehículo, cofia, vista explosionada, etiquetas, si cabe la nave) pasan a la pestaña **Cohete** de la columna derecha, que se abre sola con la vista del cohete. En el centro solo queda el cohete. Las etiquetas 3D empiezan apagadas y se activan con «Etiquetas en 3D». |
| Cambiar el idioma (español ↔ inglés) | Selector **ES / EN** en la parte superior derecha. Todo el juego se traduce: pantallas, mensajes del análisis y del vuelo, glosario, piezas, misiones, acontecimientos, lanzadores y tutorial. Los números y las fechas usan el formato del idioma y la elección se recuerda en el navegador. |
| Planner | Sin cambios |

**Cómo funciona la traducción** (`src/i18n/`):
- El juego sigue escrito en español. `translator.ts` traduce en vivo el texto visible con el diccionario `en.ts` (≈ 2.700 frases y plantillas con datos).
- No crea ni elimina nodos, así que no interfiere con React. Guarda el original para volver al español al instante.
- El glosario emergente funciona también en inglés: reconoce los términos en inglés y muestra su definición traducida.
- Los nombres propios (vehículos, misiones reales, nombres de integrantes) no se traducen.

### Verificación realizada
| Prueba | Resultado |
|---|---|
| e2e-i18n (selector arriba a la derecha, español por defecto, cambio a inglés, se recuerda al recargar, glosario en inglés, recorrido completo en inglés y vuelta al español) | 8/8 ✅ · 0 textos en español sin traducir en las pantallas recorridas |
| Recorrido de todas las pruebas buscando textos sin traducir | todos los textos encontrados añadidos al diccionario |
| Rendimiento del traductor | ≈ 17 µs por texto nuevo (con caché, inmediato) |
| e2e3 (vista del cohete: el centro sin información, pestaña «Cohete» activa, etiquetas apagadas) | 32/32 ✅ |
| Unitarias · TypeScript · regresión e2e completa | 219/219 ✅ · sin errores ✅ · todas ✅ (e2e1: solo el aviso de la fuente de Google bloqueada por la red del entorno) |

## Fase 6 (corrección) y Fase 7: Revisión gamificada ✅

| Pedido | Qué se hizo |
|---|---|
| Vista del cohete sin catálogo | En la vista «Cohete» del LAB desaparecen el catálogo de componentes, la barra de colocación y la guía de arrastre: el cohete ocupa el centro y la información sigue en la pestaña «Cohete» de la derecha. Al volver a «Nave» reaparece todo. |
| Aprobar el lanzamiento en el LAB lleva al Planner | Botón **«Aprobar lanzamiento en {vehículo} → Planner»** en la pestaña «Cohete». Guarda ese vehículo en el plan y abre el Planner. Si el vehículo no va a la Luna, la nave no cabe o pesa demasiado, el botón se desactiva y dice por qué. Sin diseño aprobado, lleva primero al análisis. |
| Planner: «Siguiente» lleva a la Revisión | El Planner no cambia salvo el final: en la ventana 4 el botón es **«Siguiente: Revisión →»**, que confirma el plan (con votación en modo equipo) y abre la Revisión. En las otras ventanas, «Confirmar plan → Revisión» hace lo mismo. |
| Revisión gamificada para estudiantes | Siete pestañas técnicas → **4 pasos**: Nivel, Poderes de la nave, Peligros y ¡Despegue!. Una **directora de vuelo** (ilustración original) comenta cada paso según tus resultados y ofrece un «¿Sabías que…?» con un dato verificable. |
| Términos sencillos e imágenes lúdicas | Niveles CML con nombres fáciles («La idea», «¿Es posible?»…), seis «poderes» (Energía, Batería, Ciencia enviada, Peso, Dinero, Combustible) con iconos, barra con límite y «¿Por qué importa?»; estrellas por cada poder en verde; peligros como meteoritos con «Posibilidad», «Daño» y «Escudo»; veredicto con cohete animado e insignias. |
| Divulgación progresiva | Primero lo esencial; el detalle se abre a demanda: lista de cada nivel al tocarlo, 3 peligros principales y «Ver todos», y desplegables **«Para expertos»** con todas las tablas de antes (escala CML 1–9, recursos, trazabilidad, MEL, matriz 5 × 5, ciclo de vida, roles y votos). |
| Al terminar la Revisión, al vuelo | En el paso 4, **«🚀 Ir al vuelo»** abre Launch Control. Si el plan no está confirmado, lleva al Planner; si el diseño no está aprobado, al LAB. |

**Sin datos inventados:** los poderes, las estrellas y los mensajes salen del mismo análisis de la junta (`src/ui/review/reviewGame.ts`), con los umbrales de la lista CML 4 (márgenes ≥ 10 %, reserva de presupuesto ≥ 5 %, descarga de batería ≤ 40 %, datos ≥ 110 % del objetivo).

### Verificación realizada
| Prueba | Resultado |
|---|---|
| Unitarias nuevas `reviewGame.test.ts` (poderes con los números del análisis, estrellas, puerta al vuelo, mensajes de la directora) | 5/5 ✅ |
| e2e-f7 (cohete sin catálogo, aprobar lanzamiento → Planner, «Siguiente: Revisión», 4 pasos, NPC, poderes, peligros, para expertos, ir al vuelo, móvil) | 33/33 ✅ |
| e2e-f7-en (Revisión y vista del cohete en inglés) | 0 textos en español ✅ |
| Unitarias · TypeScript · regresión e2e completa | 224/224 ✅ · sin errores ✅ · todas ✅ (e2e1: solo el aviso de la fuente de Google bloqueada por la red del entorno) |

## Fase 8 · Subfase 8.1: simulación espacial 3D ✅

| Pedido | Qué se hizo |
|---|---|
| Tierra 3D con continentes, océanos, nubes y atmósfera | Tierra a escala real (radio 6 371 km) con continentes reconocibles, biomas por latitud, desiertos, hielo, brillo del Sol en el océano, capa de nubes a 6 km con bandas reales de nubosidad y halo atmosférico. Gira con el día sideral. |
| Luna 3D con cráteres, relieve y texturas | Luna a escala (1 737 km, a 384 400 km) con los mares principales en su posición real aproximada, miles de cráteres con relieve (mapa de altura) y cráteres con rayos. Rota de forma síncrona: siempre muestra la misma cara a la Tierra. |
| Plataforma, torre y cohete realistas | Plataforma con zócalo, foso de llamas, torre de servicio, brazo de acceso y cuatro pararrayos, sobre terreno detallado. El cohete es el modelo existente con las dimensiones reales de cada vehículo. |
| Motores, propulsión y separación de etapas | Encendido 3 s antes del despegue con el cohete sujeto, humo en la plataforma, chorros de primera y segunda etapa, separación de etapas, cofia y nave, y despliegue de paneles. |
| Espacio profundo | Cielo azul que se oscurece con la altitud real de la cámara; 5 000 estrellas que aparecen al salir de la atmósfera. |
| Etapas del vuelo (1 a 10) | Plataforma → cuenta regresiva → ignición → despegue → ascenso atmosférico → separación → inserción en órbita (200 km) → inyección translunar → crucero de 4 días → aproximación a la Luna. |
| Trayectoria con modelo físico | `sim/FlightDynamics.ts`: integración numérica de Newton con gravedad terrestre y lunar, giro de la Tierra, arrastre y cónicas enlazadas. Llega al periapsis lunar a la altitud del plan justo al final del crucero. La telemetría usa los mismos datos. |
| Cámaras | Externa, A bordo, Seguimiento, Orbital y Libre. Arrastrar gira, la rueda acerca y aleja, en la libre el botón derecho desplaza; «Restablecer vista» vuelve al encuadre inicial. |
| Que nada tape los gráficos | HUD nuevo: reloj en una franja fina, barra de cámaras y tiempo abajo, verificación y telemetría en cajones plegables (la verificación se pliega sola al despegar), mapa esquemático opcional. Una prueba comprueba que el centro de la pantalla queda libre. |

**No se modificó:** Centro, LAB, análisis, Planner, Revisión ni Operaciones. Las reglas del juego (etapas, botones de crucero e inserción, tiempos de eventos) siguen igual.

### Verificación realizada
| Prueba | Resultado |
|---|---|
| Unitarias nuevas `flightDynamics.test.ts` (plataforma, ascenso sin desplome, órbita de 200 km, conservación de la energía, TLI ≈ 3,1 km/s, crucero, periapsis a la altitud del plan en 96 h, energía lunar, fases, otras altitudes, polilínea) | 11/11 ✅ |
| e2e-f8 (cinco cámaras, centro despejado antes y durante el vuelo, cajones, telemetría física en SECO, TLI y llegada, mapa, móvil) | ✅ |
| e2e-f8-en (vuelo en inglés) | 0 textos en español ✅ |
| Texturas generadas y revisadas como imagen (continentes, nubes, Luna) | ✅ |
| Escena 3D (WebGL) | ⚠️ No se puede dibujar en este entorno (sin three.js instalado ni WebGL): revisar en un equipo real |

### Pendiente (siguientes subfases)
- Revisar en un equipo real la escena 3D y ajustar encuadres, brillo e intensidades.
- Operaciones en órbita lunar con el mismo HUD despejado.

## Fase 8 · Subfases 8.2 y 8.3: centro de control y eventos inesperados ✅

### 8.2 Centro de control y telemetría
| Pedido | Qué se hizo |
|---|---|
| Telemetría | Altitud, velocidad, aceleración (g o ingravidez), combustible (etapas según su tiempo de encendido y kg de la nave), energía (batería, generación y consumo, Sol o sombra de la Tierra), temperatura interior estimada, dosis de radiación, estado de cada motor, comunicaciones (red, calidad, retardo de la señal y velocidad de datos), distancia al destino, posición (sobre qué continente u océano pasa, o a qué distancia de la Tierra y de la Luna) y tiempo de misión. Todo se actualiza con la simulación. |
| Controles | Iniciar, Pausar / Reanudar (también en el crucero), Reiniciar (con confirmación, vuelve a la plataforma con un intento nuevo), Más rápido / Más lento (×1 a ×120 en el lanzamiento; 1 a 48 h/s en el crucero), Siguiente evento, cinco cámaras, Restablecer vista, Trayectoria 3D (mostrar u ocultar) y Mapa. |
| Ventanas flotantes | Verificación, Telemetría, Eventos y bitácora, Mapa, Controles y Alertas son ventanas que se arrastran por la cabecera, se minimizan a una barra, pasan al frente al tocarlas y recuerdan su posición. «Ordenar paneles» vuelve a la distribución inicial, que deja libre el centro de la escena. |

### 8.3 Eventos inesperados
| Pedido | Qué se hizo |
|---|---|
| Eventos posibles | Pérdida temporal de comunicación, temperatura elevada, desviación de trayectoria, anomalía de sensores, consumo elevado de combustible, problemas de energía, interferencia de comunicación y radiación solar elevada. |
| Positivos y descubrimientos | Trayectoria casi perfecta (combustible ahorrado), antena extra de la DSN, paneles mejor de lo previsto, la Tierra y la Luna juntas, lluvia de meteoros desde la órbita y destello de un meteorito en la Luna. |
| Funcionamiento | Alerta (ALERTA / BUENAS NOTICIAS / DESCUBRIMIENTO) → mensaje del centro de control → «¿Qué está pasando?» en lenguaje sencillo → 2 o 3 decisiones con sus consecuencias a la vista → resultado y «Continuar el vuelo». El tiempo se detiene mientras se decide. |
| Coherencia | Cada evento solo aparece en su etapa (ascenso, órbita, crucero o aproximación) y su probabilidad depende del diseño: sin control térmico, más calor; con poco margen de energía, más problemas de energía; antena lenta, más pérdidas de señal. 3–4 eventos por vuelo, sin repetir y sin el mismo tipo de problema seguido; siempre hay algo positivo en el crucero. En modo sandbox solo hay eventos positivos. |
| Consecuencias reales | Las decisiones cambian combustible, batería, temperatura, comunicaciones, sensores, paneles, radiación, desviación de la trayectoria, datos científicos y el reloj del crucero. Una desviación cuesta más cuanto más tarde se corrige (Δv = distancia ÷ tiempo restante, ecuación del cohete). |
| Recuperación | Los efectos temporales caducan solos y el panel «Estado de los sistemas» ofrece «Recuperar» (reorientar la antena, reiniciar el sensor, sacudir el panel, girar la nave) y «Corregir ahora». |
| No terminar la misión | El combustible necesario para frenar en la Luna está protegido; con la batería baja la nave entra en modo seguro. Al llegar a Operaciones, el combustible gastado y los datos de los descubrimientos pasan a la misión y aparecen en su registro. |

### Verificación realizada
| Prueba | Resultado |
|---|---|
| Unitarias nuevas `flightEvents.test.ts` (energía con Sol y sombra, modo seguro, temperatura, dosis, retardo de la señal, coste de corregir pronto o tarde, reserva protegida, efectos que caducan, catálogo, programación reproducible y sin repeticiones, coherencia con el diseño, sandbox) | 12/12 ✅ |
| e2e-f8 (telemetría completa, mover/minimizar/recordar/ordenar paneles, mapa, trayectoria 3D, iniciar, pausar, reanudar, más rápido/lento, reiniciar, vuelo completo con eventos, tiempo detenido en la alerta, bitácora, paso a Operaciones) | ✅ |
| e2e-f8-en (vuelo con eventos en inglés, varias veces con eventos distintos) y comprobación de todos los textos de eventos | 0 textos en español ✅ |
| Unitarias · TypeScript · regresión e2e | 247/247 ✅ · sin errores ✅ · todas ✅ |

## Fase 8 · Subfases 8.4 y 8.5: descubrimientos espaciales y misiones de rescate ✅

### 8.4 Descubrimientos espaciales
| Pedido | Qué se hizo |
|---|---|
| Objetos posibles | Satélites artificiales reales (Estación Espacial Internacional, Hubble, GPS y geoestacionarios), basura espacial y fragmentos rocosos (meteoroides), asteroides cercanos a la Tierra, regiones lunares (Mar de la Tranquilidad, Tycho, Copérnico, Polo Sur, Mar de las Lluvias), estrellas y constelaciones (Orión, Cruz del Sur, Osa Mayor, Sirio) y nebulosas (Orión M42, Laguna M8). |
| Coherencia con la ubicación | Cada objeto solo aparece donde tiene sentido: satélites bajos en la órbita de aparcamiento, GPS y geoestacionarios al cruzar su altitud real (20 200 y 35 786 km), meteoroides y asteroides en el crucero, regiones lunares en la aproximación y solo en la cara que mira a la nave, y objetos del cielo fuera de la atmósfera, en sus coordenadas celestes reales y nunca cerca del Sol. Los satélites se mueven con su velocidad orbital real. Los objetos simulados (basura, meteoroide, asteroide) se marcan como tales. |
| Interacción | 1) Notificación «¡Objeto detectado!» con lo que dicen los sensores (el tiempo se detiene). 2) Identificación: con la cámara (análisis de la imagen, +50 % de puntos) o con los datos del radar. 3) Cámara de observación: montada en la nave, apunta al objeto y ajusta el zoom a su tamaño real (la rueda acerca o aleja). 4) Ficha científica sencilla. 5) «Registrar en el diario». 6) Puntos de descubrimiento. |
| Mapa | Panel «Diario de exploración» con tres pestañas: Registros, Mapa (Tierra, Luna, nave y objetos en su posición real con escala logarítmica) y Cielo (carta de ascensión recta y declinación con las constelaciones y nebulosas registradas). El botón «Diario» de los controles lo abre. |
| Representación 3D | Modelos propios con sus proporciones reales: Estación Espacial (109 m), Hubble (13,2 m), satélites GPS y geoestacionario, restos de cohete, rocas y asteroide; anillo sobre la región lunar; estrellas, líneas de constelación y nebulosas en el cielo. |

### 8.5 Misiones de rescate espacial
| Pedido | Qué se hizo |
|---|---|
| Escenario | Durante el crucero el centro de control pide ayuda para un CubeSat (ficticio) que gira sin control y se queda sin batería. Es opcional: «Aceptar» o «Rechazar». |
| Los 7 pasos | Barra de pasos: recibir la solicitud → localizar (girar la nave hasta centrar el satélite en la mira y «Fijar objetivo») → observar (la cámara lo sigue y se mide su movimiento) → planificar (aproximación segura, lenta o rápida) → controlar distancia y velocidad → ejecutar la asistencia (a menos de 120 m, casi quietos y apuntando) → objetivo completado. |
| Controles | Botones que se mantienen pulsados y teclado: flechas para girar, W/S avanzar o frenar, A/D y R/F para desplazarse, espacio para el motor principal. Velocidad del tiempo del rescate ×1 a ×20. «Abandonar el rescate» en cualquier momento. |
| Indicadores | Radar (vista desde la nave, con la zona de 120 m y la flecha de movimiento del satélite), mira de orientación, distancia, velocidad de acercamiento con su máximo según el plan (verde, ámbar, rojo), velocidad relativa y lateral, paso más cercano si no se hace nada y combustible del rescate. Consejos del copiloto calculados con los mismos datos. |
| Física | Movimiento relativo en línea recta sin motores; el empuje de la nave cambia la velocidad relativa; combustible por la ecuación del cohete con la masa y el Isp de la nave. Chocar a más de 0,5 m/s, alejarse más de 40 km o gastar el combustible del rescate lo hacen fallar (con un reintento tras un choque), pero nunca la misión. |
| Premio | 300 puntos + hasta 150 por ahorrar combustible − penalización por ir demasiado rápido; +1,5 Gbit de datos. El combustible gastado y el necesario para volver al rumbo se descuentan, y el tiempo de la maniobra pasa en el reloj del crucero. |

### Verificación realizada
| Prueba | Resultado |
|---|---|
| Unitarias nuevas `discoveriesRescue.test.ts` (catálogo, coherencia de zonas en 39 vuelos, órbitas reales, coordenadas del cielo, bonificación, física del rescate, combustible, choque, rescate completo con los mismos mandos que el jugador) | 9/9 ✅ |
| e2e-f84 (descubrimientos con notificación, pausa, cámara, ficha, diario, puntos, mapa y cielo; rescate pilotado con el teclado siguiendo solo los consejos e indicadores de la pantalla hasta completarlo, tres vuelos distintos) | 26/26 ✅ |
| e2e-f8-en (vuelo completo en inglés con descubrimientos, diario y rescate) | 0 textos en español ✅ |
| Unitarias · TypeScript · regresión e2e | 256/256 ✅ · sin errores ✅ · todas ✅ (salvo e2e.mjs, por las fuentes de Google sin red en este entorno, y 2 comprobaciones de e2e9.mjs que esperan el flujo antiguo en el que «Comenzar diseño» abría el LAB; no tienen que ver con el vuelo) |

### Pendiente
- Comprobar en un navegador con WebGL los modelos 3D nuevos (satélites, rocas, anillo lunar, constelaciones, CubeSat) y la cámara de observación: aquí la escena 3D no se puede dibujar.
- Actualizar e2e9.mjs al flujo actual (no es de esta fase).

## Fase 8 · Rescate: tutorial · Subfases 8.6, 8.8 y 8.9 ✅

### Rescate espacial: arreglos y tutorial «¿Cómo se juega?»
- Al aceptar el primer rescate se abre un tutorial de 5 tarjetas con dibujos: tu misión, girar la nave, moverse con los propulsores, leer los instrumentos y consejos de piloto. Se puede volver a abrir en cualquier momento con «❓ ¿Cómo se juega?» y, mientras está abierto, el rescate se detiene.
- La barra de los 7 pasos queda fija arriba del panel e indica «Paso N de 7 · …»; se quitó texto repetido para que los instrumentos quepan mejor.

### 8.6 Decisiones contrarreloj
| Pedido | Qué se hizo |
|---|---|
| Situaciones | Desviación repentina de trayectoria, silencio de radio, temperatura disparada y caída de energía. |
| Cada situación | Descripción en una frase, alerta visual (borde rojo que late y «¡CONTRARRELOJ!»), 2–3 opciones con su efecto previsto, temporizador (anillo y barra que cambian de verde a rojo) y aviso de lo que pasará si se acaba el tiempo. |
| Tiempo configurable | De 15 a 25 s (20 por defecto) en la verificación previa del vuelo o en el propio aviso. Se guarda para los siguientes vuelos. |
| Desactivar | «Temporizadores activados»: si se desactiva, la situación espera a que el jugador decida. |
| Ocasional | Como mucho una por vuelo y no en todos (80 % de los vuelos con problemas activados), en el crucero y a más de 3 h de otros eventos. |
| Consecuencias | Las opciones y el «se acabó el tiempo» cambian variables del simulador (combustible, batería, temperatura, señal, sensores, desviación). Dejar pasar el tiempo siempre sale peor que la mejor opción, y queda en la bitácora. |

### 8.8 Minijuego de aterrizaje lunar
| Pedido | Qué se hizo |
|---|---|
| Cuándo | En la verificación previa se puede elegir «Objetivo del vuelo: aterrizar en la Luna». Con él, la llegada ofrece «Inserción en órbita y descenso a la Luna» (o solo la inserción). |
| Física | Gravedad lunar real (1,62 m/s²), sin aire, empuje según la inclinación, consumo por la ecuación del cohete. Módulo de juego con valores de un módulo robótico pequeño. Empieza a 1 200 m, a unos 650 m de la zona segura. |
| 3D | Módulo con patas, tobera y lámina dorada; llama del motor; polvo levantado cerca del suelo; terreno con relieve, cráteres con borde y rocas; Sol bajo con sombras largas; estrellas y la Tierra en el cielo. Cámaras: persecución, desde el suelo y desde arriba. |
| Indicadores | Altitud sobre el suelo, velocidad vertical (con la recomendada para cada altura), velocidad de lado y su dirección, combustible, empuje (con la marca del empuje de flotar), orientación (horizonte artificial), inclinación (indicador con la zona permitida) y zona segura (radar, distancia y estado del suelo). |
| Mandos | Teclado (W/S empuje, flechas inclinación, L nivelar, H empuje de flotar, P pausa) y botones que se mantienen pulsados. |
| Objetivo | Tocar el suelo a ≤ 2 m/s de bajada, ≤ 1 m/s de lado, ≤ 10° de inclinación, en suelo de ≤ 8° y sin rocas. En la zona verde, puntuación máxima. |
| Éxito | Cinemática: franjas de cine, la cámara rodea el módulo mientras el polvo se asienta, «¡Alunizaje!». Después, la tabla con cada medida frente a su límite y los puntos. |
| Fallo | El módulo vuelca (sin explosiones), la tabla marca lo que falló y «Qué mejorar» explica con números qué hacer. «Intentarlo otra vez», «Ver los mandos» o volver a la órbita. |

### 8.9 Minijuego de exploración con rover
| Pedido | Qué se hizo |
|---|---|
| Desbloqueo | Solo tras un aterrizaje correcto («Explorar con el rover →»). |
| Rover | Seis ruedas, mástil con cámaras, paneles solares, antena y brazo de instrumentos que se mueve al recoger o medir. Se apoya en el terreno y se inclina con él. |
| Mandos y cámaras | W/S o ↑/↓ adelante y atrás, A/D o ←/→ girar, E acción, C cámara. Cámara de seguimiento, desde el rover y desde arriba. |
| Energía | Conducir y subir cuestas gasta batería; parado, los paneles la recargan. Sin batería no se mueve. |
| Terreno | Cráteres, rocas (las grandes bloquean el paso), pendientes (no sube más de 22°), una colina y zonas por explorar. |
| Mapa | Relieve sombreado que se descubre por donde pasa el rover, con el módulo, la zona segura, el rover y las misiones; porcentaje explorado. |
| Misiones | 1 Localizar una roca · 2 Explorar un cráter · 3 Recoger una muestra virtual · 4 Encontrar una ubicación (cima de la colina) · 5 Completar una investigación (medir y responder una pregunta) · 6 Enviar los resultados desde el módulo. Cada una con objetivo visible (columna de luz en 3D, mapa, distancia y brújula) y recompensa en puntos y datos. |
| Final | Resumen y vuelta a la órbita; el resumen de la superficie y los datos pasan a Operaciones. |

### Verificación realizada
| Prueba | Resultado |
|---|---|
| Unitarias nuevas: `countdown.test.ts` (4) y `lunarSurface.test.ts` (9: terreno, gravedad y combustible, aterrizaje con los mismos mandos del jugador en 4 intentos, choque, vuelco, rover, rocas, las 6 misiones conduciendo) | 269/269 ✅ |
| e2e-f86: contrarreloj (15 s, desactivar y reactivar, tiempo agotado con consecuencias), aterrizaje (instrucciones, mandos, pausa, fallo con consejos, segundo intento pilotado con el teclado hasta la cinemática y el éxito) y rover (cámaras, misión 1 conduciendo, recompensa, energía, mapa, resumen en Operaciones) | 35/35 ✅ |
| e2e-f84 (con el tutorial del rescate) y e2e-f8-en (todo en inglés, también el aterrizaje y el rover) | ✅ |

### Pendiente
- Ver en un navegador con WebGL la escena 3D de la superficie (terreno, rocas, módulo, polvo, rover, cinemática) y las sombras: aquí no se puede dibujar.
- La subfase 8.7 no se pidió en este paso.

## Siguiente: pruebas, optimización y demostración

**Plan propuesto:**
1. **Verificación 3D en un equipo real** (lo único no comprobado): Mission Center, Lab, cohete, lanzamiento y órbita. Corregir lo que aparezca.
2. **Rendimiento:** medir fotogramas por segundo; reducir geometría o sombras si hace falta; carga diferida ya activa; comprobar el tamaño de `npm run build`.
3. **Pruebas de navegador en el repositorio** (Playwright) para que el equipo las ejecute con `npm run e2e`.
4. **Accesibilidad y móvil:** navegación con teclado, contraste y diseño en tabletas.
5. **Demostración:** modo guion de 5 minutos para el jurado (misión precargada), fuentes alojadas en local y despliegue estático (GitHub Pages o Netlify).
