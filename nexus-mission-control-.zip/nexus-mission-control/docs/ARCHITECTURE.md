# Arquitectura

```
src/
├── main.tsx, App.tsx      Arranque y composición de capas (sin lógica de juego)
├── data/                  5. DATOS DE COMPONENTES y misiones (+ 6. VALIDACIONES con Zod)
│   ├── schemas.ts         Esquemas Zod: fuente única de verdad de la forma de los datos
│   ├── components/        Catálogo de piezas (masa, precio, W, Wh, Gbit, sockets, requisitos…)
│   ├── missions/          Plantillas de misión (LUNA-01 jugable; resto bloqueadas con motivo)
│   ├── launchers/         Vehículos de lanzamiento (ficticios)
│   └── glossary.ts
├── sim/                   3. MOTOR DE SIMULACIÓN: funciones puras, sin React ni Three.js
│   ├── units.ts           Conversiones (Mbps→Gbit/h, W·h→Wh, autonomía)
│   ├── BudgetSystem.ts    Contabilidad de la misión
│   ├── DesignSystem.ts    Reglas del constructor: colocar/mover/retirar, cambio de chasis, totales, diagnóstico
│   ├── EnvelopeSystem.ts  Tamaño de la nave plegada (¿cabe en la cofia?)
│   ├── OrbitSystem.ts     Periodo, velocidad, eclipse, contacto con Tierra
│   ├── PowerSystem.ts     Balance energético por órbita (W, Wh, descarga, autonomía)
│   ├── DataSystem.ts      Producción, memoria, enlace y datos que llegan (Data + Comms)
│   ├── MassSystem.ts      Masa seca/húmeda con margen y lanzadores capaces
│   ├── TrajectorySystem.ts  Δv (inserción, mantenimiento, correcciones), Tsiolkovsky, ventanas, cobertura
│   ├── PlanningSystem.ts  Verificación completa de un plan de vuelo (plan por defecto incluido)
│   ├── LaunchSystem.ts    Cronología del lanzamiento y perfil de ascenso simplificado
│   ├── MissionSystem.ts   Simulación en órbita paso a paso (estado de vuelo guardado en la misión)
│   ├── EventSystem.ts     7. SISTEMA DE EVENTOS: calendario, efectos, opciones, previsión y resolución
│   ├── ScoringSystem.ts   8. EVALUACIÓN: puntuación transparente e informe (aciertos, errores, recomendaciones)
│   └── EngineeringAnalysis.ts  Informe de viabilidad que une todos los sistemas
├── state/                 4. ESTADO DE LA MISIÓN
│   ├── missionLogic.ts    Reglas puras del ciclo de vida (crear, etapas, sanear guardado)
│   ├── persistence.ts     Lectura/escritura en localStorage con validación
│   └── useGameStore.ts    Store de Zustand: orquesta, no decide
├── scene/                 2. RENDERIZADO 3D (React Three Fiber)
│   ├── layout.ts          Posiciones y encuadres de cámara (puro, probado)
│   ├── MissionCenterScene.tsx
│   ├── CameraRig.tsx, SceneBoundary.tsx
│   ├── proceduralTextures.ts
│   ├── objects/           HoloTable, Console, CommandDeck, Earth, Starfield
│   ├── spacecraft/        SpacecraftModel (dibuja el diseño real; modo plegado), partModels, materials
│   ├── launcher/          rocketLayout y flightVisual (puros, probados), LaunchVehicle + LaunchPad, LaunchScene
│   ├── ops/               orbitGeometry (pura, probada), OpsScene
│   └── lab/               LabScene (hangar, OrbitControls), SocketMarker
└── ui/                    1. INTERFAZ
    ├── hud/               TopBar, NavRail, Tutorial, Toast
    ├── screens/           Center, MissionSelect, Briefing, Lab, Planner, Flight (Launch Control + Operaciones), Debrief, Archive, Glossary
    ├── lab/               LabCatalog, LabInspector, LabPlacementBar, LabRocketPanel
    ├── analysis/          EngineeringPanel (+ hook useEngineeringReport)
    ├── flight/            trajectory (pura, probada), TrajectoryMap, EventDecision
    ├── components/        Panel, Meter, iconos
    └── styles/            tokens.css (identidad) + app.css
```

Capas previstas para fases posteriores: `sim/` (el análisis de MassSystem/PowerSystem/DataSystem/CommsSystem partirá de `designTotals`, PowerSystem, DataSystem, CommsSystem, OrbitSystem, MissionSystem), `events/` (7. sistema de eventos) y `sim/scoring` (8. evaluación).

## Reglas de dependencia

```
ui ──► state ──► sim ──► data
 │       ▲
scene ───┘  (solo lectura del estado + acciones de navegación)
```

- `sim/` y `data/` **no importan** React, Zustand ni Three.js. Se ejecutan y prueban en Node.
- El estado no depende de la escena: si WebGL falla, `SceneBoundary` muestra un aviso y el juego sigue siendo jugable desde la interfaz.
- Los componentes de React solo muestran valores calculados por `sim/`. No hay cifras escritas a mano en la interfaz.

## Unidades

| Magnitud | Unidad | Nota |
|---|---|---|
| Masa | kg | masa húmeda = seca + propelente |
| Dinero | MUSD | escala de juego |
| Potencia | W | tasa instantánea |
| Energía | Wh | cantidad almacenada |
| Datos | Gbit | |
| Generación de datos | Gbit/h | |
| Enlace | Mbps | 1 Mbps = 3,6 Gbit/h |
| Distancia orbital | km | |
| Escena 3D | 1 unidad = 1 m | la órbita del holograma está exagerada (ver ASSUMPTIONS) |
