# NEXUS: MISSION CONTROL

**Design. Build. Launch. Discover.**

Videojuego web 3D educativo para el NASA Space Apps Challenge. El jugador dirige una agencia espacial, y diseña, lanza y opera su propia misión. Todas las decisiones están conectadas por un motor de simulación.

## Puesta en marcha

Requisitos: Node.js 20 o superior.

```bash
npm install
npm run dev        # servidor de desarrollo en http://localhost:5173
npm test           # pruebas (Vitest)
npm run typecheck  # comprobación de tipos
npm run build      # compilación de producción en dist/
```

## Estado actual: FASES 1 a 6 completadas · MVP funcional

| Funcionalidad | Estado |
|---|---|
| Identidad visual (logo, paleta, tipografía, HUD) | ✅ |
| Mission Center 3D (sala de mando, holograma lunar con órbita, Tierra, consolas interactivas, partículas, cámara cinematográfica) | ✅ |
| Navegación (barra lateral + objetos 3D clicables + encuadres de cámara por sección) | ✅ |
| Selección de misión → briefing LUNA-01 → elección de objetivo científico → misión creada | ✅ |
| Expediente: objetivos, restricciones (críticas/optimización), recompensas | ✅ |
| Presupuesto calculado por `BudgetSystem` (partidas futuras como *Pendiente*, sin cifras inventadas) | ✅ |
| Progreso por etapas, Archivo (cargar/eliminar), guardado automático validado con Zod | ✅ |
| Catálogo real de 18 componentes (consultable en el Lab) | ✅ |
| Glosario con búsqueda, tutorial progresivo, diseño adaptable a móvil | ✅ |
| **Spacecraft Lab: constructor modular 3D** (catálogo, arrastrar y soltar, anclajes, rotar/zoom, selección, mover, eliminar, cambiar chasis, vista interna) | ✅ Fase 2 |
| 18 modelos 3D procedurales diferenciados (provisionales) | ✅ Fase 2 |
| Ingeniería en vivo (masa, costo, potencia, batería, datos, enlace) y diagnóstico crítico/optimización | ✅ Fase 2 |
| Guardar/descartar el diseño en la misión; reflejado en Progreso, Presupuesto y Archivo | ✅ Fase 2 |
| Modelos más realistas (mantas MLI, RCS, adaptador de separación, paneles plegables) y **vista del cohete** (3 lanzadores, etapas, motores, interetapa, cofia con corte, vista explosionada, plataforma y torre) | ✅ |
| **Motor de simulación**: órbita (Kepler, eclipse), energía por órbita (W/Wh, descarga, autonomía), datos y comunicaciones, masa con margen, presupuesto con operación | ✅ Fase 3 |
| **Engineering Analysis** con fórmulas visibles y aprobación del diseño (bloqueada si hay críticos) | ✅ Fase 3 |
| **Mission Planner**: lanzador, altitud, inclinación, duración y ventana de lanzamiento; verificaciones de masa, cofia, Δv (Tsiolkovsky), ventana, energía, datos, cobertura y presupuesto; confirmación → Lanzamiento | ✅ Fase 4 |
| **Launch Control**: verificación GO/NO-GO, cuenta regresiva (abortable), despegue del cohete con TU nave, separación de etapas y cofia, inyección translunar, separación y despliegue de paneles | ✅ Fase 5 |
| **Mission Operations**: simulación paso a paso (energía, eclipse, contacto, datos, memoria, propelente, modo seguro), instrumentos encendibles, control del tiempo, telemetría y registro | ✅ Fase 5 |
| **Pantalla de trayectoria** Tierra–Luna (ascenso, aparcamiento, inyección translunar, crucero animado de 4 días, órbita lunar) | ✅ |
| **Acontecimientos con decisiones**: caída de generación, avería de estación, anomalía de instrumento; 3 opciones cada uno, dependientes del diseño, con previsión simulada hasta el final | ✅ Fase 6 |
| **Mission Debrief**: resultados, recursos, presupuesto, eventos, aciertos, errores, recomendaciones y puntuación transparente; XP, desbloqueos y nuevo intento con el diseño | ✅ Fase 6 |
| **Referencias técnicas de NASA integradas**: Junta de revisión (Concept Maturity Levels, Matriz de Trazabilidad Científica, Master Equipment List con contingencia por herencia, riesgos 5 × 5, ciclo de vida NASA/CubeSat), simulador de órbita elíptica (Kepler, vis-viva) con órbitas de LRO, Lunar Prospector y LADEE, avisos del catálogo al estilo del juego del Webb, misiones reales parecidas en el informe | ✅ |
| **Reto NASA**: dificultades (Fácil / Intermedio / Difícil / Sandbox), recurso Tiempo (calendario y vida útil), panel de 6 recursos con los críticos, valor científico de instrumentos, **modo equipo** (2–4 roles, votaciones, coordinación), clasificación, compartir/importar y comparar diseños | ✅ |
| **Mejora de experiencia — Fase 1**: nueva misión guiada en 6 pasos con glosario interactivo | ✅ |
| **Mejora de experiencia — Fase 2**: botón «Siguiente: Construir nave» del Diseño al LAB | ✅ |
| **Mejora de experiencia — Fase 3**: LAB guiado (mano animada, parámetros críticos interactivos, «Solucionar problema», validación con «¡Diseño listo!») | ✅ |
| **Mejora de experiencia — Fase 4**: pantalla de análisis y aprobación («DISEÑO APROBADO», tarjetas y gráficos, «Continuar con la planificación de lanzamiento») | ✅ |
| **Mejora de experiencia — Fase 6**: catálogo de 8 vehículos reales de *CubeSat 101* (datos reales separados de los del juego, compatibilidad con la misión) y Planner en 4 ventanas | ✅ |
| **Idioma español / inglés** (selector arriba a la derecha) y vista del cohete con la información en la columna derecha | ✅ |
| **Mejora de experiencia — Fase 7**: Junta de revisión gamificada (directora de vuelo, 4 pasos, poderes y estrellas, peligros como meteoritos, salida al vuelo); LAB → Planner → Revisión → Vuelo | ✅ |
| **Fase 8.1 — Vuelo**: simulación 3D a escala real Tierra → Luna con trayectoria física integrada, cinco cámaras y HUD que no tapa la escena | ✅ |
| **Fases 8.2 y 8.3 — Vuelo**: centro de control con telemetría completa, controles y ventanas flotantes; eventos inesperados (problemas, buenas noticias y descubrimientos) con decisiones que cambian el simulador | ✅ |
| **Fases 8.6, 8.8 y 8.9 — Vuelo**: decisiones contrarreloj ocasionales y configurables; minijuego de aterrizaje lunar pilotable con cinemática; rover lunar con 6 misiones, energía y mapa | ✅ |
| **Fases 8.4 y 8.5 — Vuelo**: descubrimientos espaciales coherentes con la posición (satélites, rocas, asteroides, regiones lunares, estrellas y nebulosas) con cámara de observación, diario y mapa; rescate espacial opcional y pilotable | ✅ |
| Navegación y progreso (Fase 5) | ⏳ |
| Tipos de viaje: flyby, aterrizador, rover y retorno de muestras (Luna) | ⏳ Entrega B |
| Pruebas finales, optimización y preparación para la demostración | ⏳ |

Para saber qué se ha verificado y cómo, consulta [docs/PHASES.md](docs/PHASES.md).

## Documentación

- [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md): capas, carpetas y flujo de datos
- [docs/DECISIONS.md](docs/DECISIONS.md): decisiones técnicas y su justificación
- [docs/ASSUMPTIONS.md](docs/ASSUMPTIONS.md): simplificaciones científicas, unidades y modelos provisionales
- [docs/PHASES.md](docs/PHASES.md): estado por fase, verificación y plan de la Fase 2
